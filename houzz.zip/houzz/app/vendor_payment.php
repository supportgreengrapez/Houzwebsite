<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class vendor_payment extends Model
{
    //
}
