<?php

namespace App;
use Session;

class Cart
{
 
    public $items = null;
    public $totalQty = 0;
    public $totalPrice=0;
    public $Price=0;
    public $delivery_charges=0;
   public $sub_cat=0;
   public $abc=0;
   public $qty=0;
 
   
    public function __construct($oldCart)
    {
        if($oldCart)
        {
            
            $this->items = $oldCart->items;
            $this->totalQty = $oldCart->totalQty;
            $this->totalPrice = $oldCart->totalPrice;
            $this->delivery_charges = $oldCart->delivery_charges;
            $this->sub_cat = $oldCart->sub_cat;
            $this->Price = $oldCart->Price;
            $this->abc = $oldCart->abc;


            
        }
    }

 
    public function remove($id,$qty,$delivery)
    {
        
      
        
       // $this->items[$id]['qty'];
         $this->totalQty -= 1;
        //   $this->totalPrice =  $this->totalPrice - ($this->items[$id]['price'] * $qty);
        // $this->delivery_charges -= 1;
          //  $this->totalQty -= $this->items[$id]['qty'];
        $this->totalPrice -= $this->items[$id]['price'];
        $this->totalPrice -= $this->items[$id]['delivery_charges'];
        unset($this->items[$id]);
        return true;
    }


    public function add($item,$id,$size,$q,$seller,$delivery,$sub_cat)
    {
        if($delivery == "Urgent Delivery")
        {
            $delivery_charges = $item->urgent_charges;
            $delivery_time =  $item->urgent_time;
        }
          if($delivery == "Express Delivery")
        {
            $delivery_charges = $item->express_charges;
            $delivery_time =  $item->express_time;
        }
          if($delivery == "Normal Delivery")
        {
            $delivery_charges = $item->normal_charges;
            $delivery_time =  $item->normal_time;
        }
        if($delivery == "Free Delivery")
        {
            $delivery_charges = 0;
            $delivery_time =  $item->free_delivery;
        }
        $storedItem = ['qty'=>$q,'sub_cat'=>$sub_cat,'price'=>$item->price,'save'=>0,'item'=>$item,'size'=>$size,'package'=>$seller,'delivery_charges'=>$delivery_charges,'delivery_time'=>$delivery_time];
        $id = $id.$size;
      
        
           if($this->items)
        {
           
            if(array_key_exists($id,$this->items))
            {
                
            
                     $this->totalQty -= 1;
        $this->totalPrice -= $this->items[$id]['price'];
        unset($this->items[$id]);
   
                $storedItem['price'] = $item->price * $storedItem['qty'] - $delivery_charges;
             

            }
        }
        
        
       
       // $storedItem['qty']++;
        $storedItem['price'] = $item->price * $storedItem['qty'];
        $this->items[$id] = $storedItem;
        $this->totalQty++;
        $this->abc += $storedItem['qty'];
        $this->Price=  $item->price * $storedItem['qty'];
       $this->totalPrice +=  $storedItem['price']+$delivery_charges ;

       
       
    }

    public function discount($item,$id,$size,$q,$seller,$delivery,$sub_cat)
    {
           if($delivery == "Urgent Delivery")
   {
       $delivery_charges = $item->urgent_charges;
       $delivery_time =  $item->urgent_time;
   }
     if($delivery == "Express Delivery")
   {
       $delivery_charges = $item->express_charges;
       $delivery_time =  $item->express_time;
   }
     if($delivery == "Normal Delivery")
   {
       $delivery_charges = $item->normal_charges;
       $delivery_time =  $item->normal_time;
   }
   if($delivery == "Free Delivery")
        {
            $delivery_charges = 0;
            $delivery_time =  $item->free_delivery;
        }
  $discount =($item->price*$item->percentage)/100;
        $discount_price = $item->price - $discount;
        $storedItem = ['qty'=>$q,'sub_cat'=>$sub_cat,'price'=>$discount_price,'save'=>$discount,'item'=>$item,'size'=>$size,'package'=>$seller,'delivery_charges'=>$delivery_charges,'delivery_time'=>$delivery_time];
        if($this->items)
        {
           
            if(array_key_exists($id,$this->items))
            {
                
            
                     $this->totalQty -= 1;
        $this->totalPrice -= $this->items[$id]['price'];
        unset($this->items[$id]);
   
                $storedItem['price'] = $item->price * $storedItem['qty'];
         
            }
        }
        
        
       
      //  $storedItem['qty']++;
        $storedItem['price'] = $discount_price * $storedItem['qty'];
        $this->items[$id] = $storedItem;
        $this->totalQty++;
        $this->totalPrice +=  $storedItem['price'] + $delivery_charges;

   
       
    }

 


}

