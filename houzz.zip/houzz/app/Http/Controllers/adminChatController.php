<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\User;
use Pusher\Pusher;

class adminChatController extends Controller
{
    public function sendAdminMessage(Request $request)
    {
        $message = $request->input('message');

       
        $pmessage = $message;
        $message =  DB::connection()->getPdo()->quote($message);
        $to = $request->input('selected_user');
        $file = '';
        $name = $file;
        $file = url('/') .'/'.'storage'.'/'.'images'.'/'.$file;
        $from = session()->get('pk_id');
        
        if($name =='')
        {
            DB::insert("insert into admin_chats (user_to,user_from,message) values('$to','$from',$message)");
        }
        else
        {
        DB::insert("insert into admin_chats (user_to,user_from,message,file,name) values('$to','$from',$message,'$file','$name')");
        }
        
     $pusher = new Pusher("c271052b8d017b6a07c8", "12f0b74379bca304638d", "984839", array('cluster' => 'ap2'));
     $pusher->trigger('private-admin-channel', 'my-event', array('message' => $pmessage,
     'from' => $from,
     'file' => ''));
    
    }
    public function sendCustomerMessage(Request $request)
    {
      
        $to = $request->input('selected_user');
        $message = $request->input('message');
        $pmessage = $message;
        $message =  DB::connection()->getPdo()->quote($message);
        
        $file = '';
        $name = $file;
        $file = url('/') .'/'.'storage'.'/'.'images'.'/'.$file;
        $from = session()->get('pk_id');
        if($name =='')
        {
            DB::insert("insert into admin_chats (user_to,user_from,message) values('$to','$from',$message)");
        }
        else
        DB::insert("insert into admin_chats (user_to,user_from,message,file,name) values('$to','$from',$message,'$file','$name')");
     $pusher = new Pusher("c271052b8d017b6a07c8", "12f0b74379bca304638d", "984839", array('cluster' => 'ap2'));
 
     $pusher->trigger('private-user-channel', 'my-event', array('message' => $pmessage,
     'from' => $from,
     'file' => ''));
    }
    public function auth()
    {
     $pusher = new Pusher("c271052b8d017b6a07c8", "12f0b74379bca304638d", "984839", array('cluster' => 'ap2'));
     $str= $pusher->socket_auth($_POST['channel_name'], $_POST['socket_id']);
     return $str;
    }
    public function getClientMessages($id)
    {

        $me = session()->get('pk_id');
        
        $result = DB::select("select* from admin_chats where (user_to='$id' and user_from='$me') or (user_to='$me' and user_from='$id')");
        $str= "<ul>";
        if(count($result)>0)
        {
            foreach($result as $r)
            {
                if($r->user_from == $me)
                {
                    $str .= "<li class='sent'>
                    <p>".$r->message."</p>
                </li>";
                }
                else
                {
                    $str .= "<li class='replies'>
                    <p>".$r->message."</p>
                </li>";
                }
            }
            $str.="</ul>";
        }
        return $str;
    }
    public function getAdminMessages($id)
    {
        $me = session()->get('pk_id');
        $result = DB::select("select* from admin_chats where (user_to='$id' and user_from='$me') or (user_to='$me' and user_from='$id')");
        $str= "<ul>";
        if(count($result)>0)
        {
            foreach($result as $r)
            {
                if($r->user_from == $me)
                {
                    $str .= "<li class='sent'>
                    <p>".$r->message."</p>
                </li>";
                }
                else
                {
                    $str .= "<li class='replies'>
                    <p>".$r->message."</p>
                </li>";
                }
            }
            $str.="</ul>";
        }
        return $str;
        
    }

    public function getFirstUser()
    {
        $u = user::all()->first();

        return $u->id;
    }
}
