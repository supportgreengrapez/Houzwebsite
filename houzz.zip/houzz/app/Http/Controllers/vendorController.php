<?php
namespace App\Http\Controllers;
use Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\vendor;
use Session;
use Response;

class vendorController extends Controller
{

    public function chat_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $pk_id = session()->get('pk_id');

        $user = db::select("Select client_details.*, (Select message from chats where chats.user_from = '$pk_id' and user_to=client_details.pk_id  or (user_to='$pk_id' and user_from=client_details.pk_id) order by chats.id desc limit 1) as lastmessage from client_details where customer_type = 'buyer'");

        return view('vendor.chat-system', compact('user'));
    }

    public function admin_chat_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $pk_id = session()->get('pk_id');

        //  $user = db::select("Select client_details.*, (Select message from admin_chats where chats.user_from = '$pk_id' and user_to=client_details.pk_id  or (user_to='$pk_id' and user_from=client_details.pk_id) order by admin_chats.id desc limit 1) as lastmessage from client_details where customer_type = 'seller'");
        return view('vendor.admin_chat_view');
    }

    public function message_list_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $pk_id = session()->get('pk_id');
        $result = DB::select("select* from message where seller_name = '$pk_id' and reply IS NULL");
        $result1 = DB::select("select* from message where seller_name = '$pk_id' and reply IS NOT NULL order by pk_id DESC");
        return view('vendor.message_list_view', compact('result', 'result1'));
    }

    public function message_send_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $result = DB::select("select* from message where pk_id = '$id'");

        return view('vendor.message_send_view', compact('result'));
    }
    public function send_message(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $reply = $request->input('reply');
        //  DB::update("update message set reply ='$reply' where pk_id='$id'");
        DB::table('message')
            ->where('pk_id', $id)->update(array(
            'reply' => $reply,
        ));
        return redirect('/vendor/home/view/message');
    }

    public function collection_set_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $result = DB::select("select* from collection_set where pk_id='$id'");
        $array = [];
        $product_array = [];
        $str = $result[0]->products;
        $id = $result[0]->collection_id;
        $tok = strtok($str, ",");

        $skillset = $tok;
        $array = array_wrap($skillset);

        while ($tok !== false)
        {
            $tok = strtok(",");

            if (is_string($tok)) $skillset = $tok;
            //  $array = array_prepend($array, $skillset);
            array_push($array, $skillset);

        }
        array_pop($array);
        foreach ($array as $arrays)
        {
            $product = DB::select("select* from product where pk_id='$arrays'");
            array_push($product_array, $product);
        }

        $result1 = DB::select("select* from collection where pk_id='$id'");
        return view('vendor.collect_list_detail', compact('result', 'product_array', 'result1'));

    }

    public function collection_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $vendor_id = session()->get('pk_id');
        $result = DB::select("select* from collection where user_id = '$vendor_id'");
        return view('vendor.collection-list', compact('result'));
    }

    public function add_collection_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $user_id = session()->get('pk_id');
        $vendor_id = session()->get('username');
        $result = DB::select("select* from collection where user_id = '$user_id' order by pk_id DESC");
        $result1 = DB::select("select* from product where vendor_id = '$user_id'");

        return view('vendor.collect_list', compact('result', 'result1'));
    }

    public function add_offline_client_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        return view('vendor.add_offline_client_view');
    }

    public function add_collection_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $collection_name = $request->input('collection_name');
        $order = DB::select("select* from collection where collection_name = '$collection_name'");
        if (count($order) > 0)
        {
            return Redirect::back()->withErrors('Collection Name already Exist');
        }
        else
        {
            $thumbnail = "";
            if ($request->hasFile('file'))
            {
                $image = $request->file('file');
                $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                $image->storeAs('public/images', $uniqueFileName);
                $thumbnail = $uniqueFileName;
            }

            $user_id = session()->get('pk_id');
            DB::insert("insert into collection (user_id,collection_name,description,thumbnail) values (?,?,?,?)", array(
                $user_id,
                $request->input('collection_name') ,
                $request->input('description') ,
                $thumbnail
            ));

        }
        return redirect()->back();

    }

    public function add_collection(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $pk_id = $request->input('category');
        $user_id = session()->get('pk_id');
        $category = DB::select("select* from collection where pk_id = '$pk_id'");
        $category = $category[0]->collection_name;
        $id = $request->input('sku');

        $final_id = "";

        foreach ($id as $sizes)
        {
            $final_id = $final_id . $sizes . ',';
        }

        $id = rtrim($final_id, ',');

        DB::insert("insert into collection_set(user_id,collection_id,collection_name,products) values (?,?,?,?)", array(
            $user_id,
            $pk_id,
            $category,
            $id
        ));

        return redirect('/vendor/collection/list/view');

    }

    public function add_offline_client(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $vendor_id = session()->get('username');
        DB::insert("insert into offline_client(name,email,phone,country,state,city,zip,vendor_id) values (?,?,?,?,?,?,?,?)", array(
            $request->input('name') ,
            $request->input('email') ,
            $request->input('phone') ,
            $request->input('country') ,
            $request->input('state') ,
            $request->input('city') ,
            $request->input('zip') ,
            $vendor_id
        ));

        return redirect('/vendor/home/view/offline/client');

    }

    public function edit_collection_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from collection where pk_id = '$pk_id'");

        return view('vendor.edit_collection_view', compact('result'));

    }

    public function edit_collection_set_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $user_id = session()->get('pk_id');
        $vendor_id = session()->get('username');
        $product = DB::select("select* from product where vendor_id = '$user_id'");
        $result = DB::select("select* from collection where user_id = '$user_id'");
        $result1 = DB::select("select* from collection_set where collection_id = '$pk_id'");
        return view('vendor.edit_collection_set_view', compact('result', 'result1', 'product'));

    }

    public function edit_collection_set(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $pk_id = $request->input('category');

        $category = DB::select("select* from collection where pk_id = '$pk_id'");
        $category = $category[0]->collection_name;
        $id = $request->input('sku');

        $final_id = "";

        foreach ($id as $sizes)
        {
            $final_id = $final_id . $sizes . ',';
        }

        $id = rtrim($final_id, ',');

        DB::table('collection_set')->where('pk_id', $pk_id)->update(['collection_id' => $pk_id, 'collection_name' => $category, 'products' => $id]);

        return redirect('/vendor/collection/list/view');

    }

    public function edit_collection(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $result = DB::select("select* from collection where pk_id='$pk_id'");

        $thumbnail = $result[0]->thumbnail;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        DB::table('collection')->where('pk_id', $pk_id)->update(['collection_name' => $request->Input('collection_name') , 'description' => $request->Input('description') , 'thumbnail' => $thumbnail]);

        return redirect('/vendor/collection/list/view');

    }

    public function edit_offline_client(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::table('offline_client')
            ->where('pk_id', $pk_id)->update(['name' => $request->Input('name') , 'email' => $request->Input('email') , 'address' => $request->Input('address') , 'phone' => $request->Input('phone') , 'country' => $request->Input('country') , 'state' => $request->Input('state') , 'city' => $request->Input('city') , 'zip' => $request->Input('zip') ]);

        return redirect('/vendor/home/view/offline/client');

    }

    public function update_product_hot_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $id = $request->input('id');
        DB::table('product')
            ->where('pk_id', $id)->update(['hot_product' => $request->input('status') ]);

        return URL('/') . "/vendor/home/view/product";
    }
    public function commission_invoice_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('username');
        $seller_subscription = 'COMMISSION';
        $result = DB::select("select* from detail_table where vendor_id = '$vendor_id' and seller_subscription = '$seller_subscription'");

        return view('vendor.commission_seller_invoice', compact('result'));

    }

    public function subscription_invoice_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('username');
        $seller_subscription = 'BASIC';
        $result = DB::select("select* from detail_table where vendor_id = '$vendor_id' and seller_subscription = '$seller_subscription'");

        return view('vendor.subscription_seller_invoice', compact('result'));

    }

    public function edit_basic_info_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('username');
        $result = DB::select("select* from vendors where id = '$vendor_id' ");

        return view('vendor.edit_basic_info_view', compact('result'));

    }

    public function edit_basic_info(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::table('vendors')
            ->where('id', $id)->update(['bank_name' => $request->input('bank_name') , 'account_no' => $request->input('account_no') , 'account_type' => $request->input('account_type') , 'routing_no' => $request->input('routing_no') ]);

        return redirect('/vendor/home/view/bank/account');
    }

    public function edit_notification(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $a = $request->input('notification_email');

        DB::table('vendors')
            ->where('id', $id)->update(['email1' => $request->input('email1') , 'notification_email' => $a]);

        return redirect()->back();
    }

    public function edit_notification_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from vendors where user_id = '$vendor_id' ");

        return view('vendor.edit_notification_email', compact('result'));

    }

    public function bank_account_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from vendors where user_id = '$vendor_id' ");

        return view('vendor.bank_account_view', compact('result'));

    }

    public function edit_bank_account_view($vendor_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from vendors where id = '$vendor_id' ");

        return view('vendor.edit_bank_account_view', compact('result'));

    }

    public function edit_bank_account(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::table('vendors')
            ->where('id', $id)->update(['bank_name' => $request->input('bank_name') , 'account_no' => $request->input('account_no') , 'account_type' => $request->input('account_type') , 'routing_no' => $request->input('routing_no') ]);

        return redirect('/vendor/home/view/bank/account');
    }

    public function update_payment_invoice_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $id = $request->input('id');

        DB::table('payment_invoice')
            ->where('pk_id', $request->input('id'))
            ->update(['status' => $request->input('status') ]);

        return URL('/') . "/vendor/home/view/payment/invoice";
    }

    public function view_payment_invoice()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from payment_invoice where vendor_id = '$vendor_id'");

        return view('vendor.payment_invoice_list_view', compact('result'));

    }

    public function view_submit_payment_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from payment_invoice where vendor_id = '$vendor_id' and status ='0' ");

        return view('vendor.submit_payment_invoice_list_view', compact('result'));

    }

    public function view_submit_package_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from subscription where vendor_id = '$vendor_id' and status ='waiting' order by pk_id DESC ");
        return view('vendor.submit_package_invoice_list_view', compact('result'));

    }

    public function view_approved_package_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');
        $result1 = DB::select("select* from admin_details ");
        $result = DB::select("select* from subscription where vendor_id = '$vendor_id' and status ='approved' order by pk_id DESC");
        return view('vendor.approved_package_invoice_list_view', compact('result', 'result1'));

    }

    public function view_pending_package_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from subscription where vendor_id = '$vendor_id' and status ='pending' order by pk_id DESC ");
        return view('vendor.pending_package_invoice_list_view', compact('result'));

    }

    public function view_rejected_package_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from subscription where vendor_id = '$vendor_id' and status ='rejected' order by pk_id DESC");
        return view('vendor.rejected_package_invoice_list_view', compact('result'));

    }

    public function view_approved_payment_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from payment_invoice where vendor_id = '$vendor_id' and status ='1' ");

        return view('vendor.approved_payment_invoice_list_view', compact('result'));

    }

    public function view_pending_payment_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from payment_invoice where vendor_id = '$vendor_id' and status ='2' ");

        return view('vendor.pending_payment_invoice_list_view', compact('result'));

    }

    public function view_rejected_payment_invoice()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from payment_invoice where vendor_id = '$vendor_id' and status ='3' ");

        return view('vendor.rejected_payment_invoice_list_view', compact('result'));

    }

    public function add_payment_invoice_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from subscription where vendor_id = '$vendor_id' order by pk_id DESC");
        return view('vendor.add_payment_invoice_view', compact('result'));

    }

    public function add_payment_invoice(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $user_id = session()->get('pk_id');
        $invoice_no = $request->input('invoice_no');
        
        $thumbnail = "";
                    if ($request->hasFile('slip'))
                    {
                        $image = $request->file('slip');
                        $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                        $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                        $image->storeAs('public/images', $uniqueFileName);
                        $thumbnail = $uniqueFileName;
                    }
                
        $date = $request->input('date');
        $amount = $request->input('amount');
        $status = 0;
        $subscription = DB::select("select* from subscription where vendor_id = '$user_id' ORDER BY pk_id DESC");
        if (empty($subscription))
        {
            return Redirect::back()->withErrors('Please Subscribed to Package');

        }
        else
        {
            DB::insert("insert into payment_invoice (invoice_no,thumbnail,package_name,amount,subscription,vendor_id,status,created_at) values (?,?,?,?,?,?,?,?)", array(
                $invoice_no,
                $thumbnail,
                $subscription[0]->package_name,
                $amount,
                $subscription[0]->subscription,
                $user_id,
                $status,
                $date
            ));

            session()->flush();
            return redirect('/vendor/login')
                ->withErrors('Wait for admin approvel');
        }

    }

    public function add_discount_view()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $seller = session()->get('pk_id');

        $result = DB::select("select* from product where vendor_id = '$seller'");
        return view('vendor.add_discount_view', compact('result'));

    }

    public function add_discount(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $user_id = session()->get('pk_id');
        DB::insert("insert into discount_table (sku,start_date,end_date,percentage,vendor_id) values (?,?,?,?,?)", array(
            $request->input('sku') ,
            $request->input('start_date') ,
            $request->input('end_date') ,
            $request->input('percentage') ,
            $user_id
        ));
        return redirect('/vendor/home/view/discount');
    }

    public function view_discount()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');

        $result = DB::select("select* from discount_table where vendor_id = '$vendor_id'");

        return view('vendor.view_discount', compact('result'));

    }

    public function edit_discount_view($pk_id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from discount_table where pk_id = '$pk_id'");

        return view('vendor.edit_discount_view', compact('result'));

    }

    public function edit_discount(Request $request, $pk_id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        DB::table('discount_table')
            ->where('pk_id', $pk_id)->update(['sku' => $request->input('sku') , 'start_date' => $request->input('start_date') , 'end_date' => $request->input('end_date') , 'percentage' => $request->input('percentage') ]);
        return redirect('/vendor/home/view/discount');

    }

    public function delete_offline_client($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        DB::delete("delete from offline_client  where pk_id = '$id'");

        return redirect()->back();

    }

    public function delete_discount($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        DB::delete("delete from discount_table  where pk_id = '$id'");

        return redirect()->back();

    }
    public function rating_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('username');

        $result = DB::select("select* from product,review_table where product.vendor_id ='$vendor_id' and product.pk_id = review_table.product_id");

        return view('vendor.rating_list_view', compact('result'));

    }
    public function search_package_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('pk_id');
        $search = $request->input('search');
        $result = DB::select("select* from subscription where pk_id = '$search' and vendor_id = '$vendor_id'");

        return view('vendor.submit_package_invoice_list_view', compact('result'));

    }

    public function search_order_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('username');

        $search = $request->input('search');
        $result = DB::select("select* from detail_table where order_id = '$search' and vendor_id = '$vendor_id'");

        return view('vendor.active_order_view', compact('result'));

    }
    public function search_order_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $vendor_id = session()->get('username');
        $from = $request->input('from');
        $to = $request->input('to');
        $order_status = $request->input('order_status');

        // $result = DB::select("select* from order_table where pk_id = '$search'");
        if (empty($from) && empty($to) && empty($order_status))
        {

            $result = DB::select("select * from detail_table where vendor_id = '$vendor_id'");

        }
        else if (empty($from) && empty($to))
        {
            if ($order_status == 5)
            {
                $result = DB::select("select * from detail_table where vendor_id = '$vendor_id'");
            }

            else
            {
                $result = DB::select("select * from detail_table where v_order_status = '$order_status' and vendor_id = '$vendor_id'");
            }

        }
        else if (empty($order_status) && empty($from))
        {

            $result = DB::select("select * from detail_table where vendor_id = '$vendor_id' and (created_at < '$to' or created_at = '$to')");

        }

        else if (empty($order_status) && empty($to))
        {
            $result = DB::select("select * from detail_table where vendor_id = '$vendor_id' and (created_at > '$from' or created_at = '$from')");

        }

        else if (empty($order_status))
        {
            $result = DB::select("select * from detail_table where vendor_id = '$vendor_id' and (created_at > '$from' or created_at = '$from') and (created_at < '$to' or created_at = '$to') ");

        }
        else
        {

            if ($order_status == 5)
            {
                $result = DB::select("select * from detail_table where vendor_id = '$vendor_id' and (created_at > '$from' or created_at = '$from') and (created_at < '$to' or created_at = '$to') ");
            }
            else
            {
                $result = DB::select("select * from detail_table where vendor_id = '$vendor_id' and v_order_status = '$order_status' and (created_at > '$from' or created_at = '$from') and (created_at < '$to' or created_at = '$to') ");
            }

        }

        return view('vendor.active_order_view', compact('result'));
    }

    public function sub(Request $request)
    {
        $value = $request->Input('cat_id');

        $subcategories = DB::select(DB::raw("SELECT * FROM sub_category WHERE main_category = :value") , array(
            'value' => $value,
        ));

        return Response::json($subcategories);

    }

    public function type(Request $request)
    {
        $type_id = $request->Input('type_id');

        $sub_id = DB::select("select* from sub_category where SKU = '$type_id' ");
        $sub_id = $sub_id[0]->sub_category;

        $subcategories = DB::select(DB::raw("SELECT * FROM product_type WHERE sub_category = :value") , array(
            'value' => $sub_id,
        ));

        //  $sub_id = DB::select("select* from product_type where sub_category = '$sub_id' and username='admin' ");
        return Response::json($subcategories);

    }

    public function add_product_type_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from main_category where username = 'admin'");
        $result1 = DB::select("select* from sub_category where username = 'admin'");
        return view('vendor.add_product_type_view', compact('result', 'result1'));
    }

    public function add_product_type(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $cat = $request->input('productType');
        $cat1 = urldecode($request->input('mainCategory'));

        $cat2 = $request->input('subCategory');

        $result = DB::select(DB::raw("SELECT * FROM product_type WHERE product_type = :value and main_category= :value2 and sub_category= :value3 ") , array(
            'value' => $cat,
            'value2' => $cat1,
            'value3' => $cat2,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Product Type already Exist');

        }
        else

        {
            $username = session()->get('username');
            DB::insert("insert into product_type (product_type,main_category,sub_category,username) values (?,?,?,?)", array(
                $request->input('productType') ,
                $cat1,
                $request->input('subCategory') ,
                $username
            ));
            return redirect('/vendor/view/product/type');
        }

    }

    public function edit_product_type_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from product_type where pk_id = '$pk_id'");

        return view('vendor.edit_product_type_view', compact('result'));

    }

    public function edit_product_type(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $cat = $request->input('productType');
        $result = DB::select("select* from product_type where product_type = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Product Type already Exist');

        }
        else

        {
            $product_type = $request->input('productType');
            $main_category = $request->input('mainCategory');
            $sub_category = $request->input('subCategory');

            DB::table('product_type')
                ->where('pk_id', $pk_id)->update(['product_type' => $product_type, 'main_category' => $main_category, 'sub_category' => $sub_category]);
            return redirect('/vendor/view/product/type');

        }
    }

    public function delete_product_type($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::delete("delete from product_type where pk_id = '$id'");

        return redirect()->back();
    }

    public function product_type_list_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $username = session()->get('username');
        $result = DB::select("select* from product_type where username = '$username'");

        return view('vendor.product_type_list_view', compact('result'));

    }

    public function delete_main_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::delete("delete from main_category where SKU = '$id'");

        return redirect()->back();
    }

    public function delete_sub_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::delete("delete from sub_category where SKU = '$id'");

        return redirect()->back();
    }

    public function add_main_category_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        return view('vendor.add_main_category_view');

    }

    public function add_main_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $cat = $request->input('mainCategory');
        $result = DB::select("select* from main_category where main_category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {
            $username = session()->get('username');

            DB::insert("insert into main_category (main_category,username) values (?,?)", array(
                $request->input('mainCategory') ,
                $username
            ));
            return redirect('/vendor/home/view/main/category');
        }
    }
    public function add_sub_category_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from main_category");
        return view('vendor.add_sub_category_view', compact('result'));
    }

    public function add_sub_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $category = $request->input('mainCategory');

        $cat = $request->input('subCategory');
        $result = DB::select(DB::raw("SELECT * FROM sub_category WHERE sub_category = :value and main_category= :value2") , array(
            'value' => $cat,
            'value2' => $category,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Subcategory already Exist');

        }
        else

        {
            $username = session()->get('username');
            $category = $request->input('mainCategory');

            DB::insert("insert into sub_category (main_category,sub_category,username) values (?,?,?)", array(
                $category,
                $request->input('subCategory') ,
                $username
            ));
            return redirect('/vendor/home/view/sub/category');
        }
    }

    public function main_category_list_view()
    {

        $username = session()->get('username');

        $result = DB::select("select* from main_category where username  = '$username'");

        return view('vendor.view_main_category_list', compact('result'));

    }
    public function sub_category_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $username = session()->get('username');
        $result = DB::select("select* from sub_category where username  = '$username'");

        return view('vendor.view_sub_category_list', compact('result'));

    }

    public function edit_main_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from main_category where SKU = '$sku'");

        return view('vendor.edit_main_category', compact('result'));

    }

    public function edit_main_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $cat = $request->input('mainCategory');
        $result = DB::select("select* from main_category where main_category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $main_category = $request->input('mainCategory');

            DB::table('main_category')
                ->where('SKU', $sku)->update(['main_category' => $main_category]);
            return redirect('/vendor/home/view/main/category');

        }
    }

    public function edit_sub_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from main_category");

        $result1 = DB::select("select* from sub_category where SKU = '$sku'");

        return view('vendor.edit_sub_category', compact('result', 'result1'));

    }

    public function edit_sub_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $cat = $request->input('subCategory');
        $result = DB::select("select* from sub_category where sub_category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Subcategory already Exist');

        }
        else

        {

            $main_category = $request->input('mainCategory');
            $sub_category = $request->input('subCategory');

            DB::table('sub_category')
                ->where('SKU', $sku)->update(['main_category' => $main_category, 'sub_category' => $sub_category]);
            return redirect('/vendor/home/view/sub/category');

        }

    }

    public function verify_code($username, $code)
    {
        $result = DB::select("select* from vendor_reset_password where username= '$username' and verification_code= '$code' and TIMESTAMPDIFF(MINUTE,vendor_reset_password.created_at,NOW()) <=30 ");

        if (count($result) > 0)
        {
            return view('vendor.change_password', compact('username'));
        }
        else return "The Verification code is expired";
    }

    public function reset_password_view()
    {

        return view('vendor.password_reset');

    }

    public function vendor_reset_password(Request $request)
    {

        $username = $request->input('username');
        $result = DB::select("select* from vendors where email = '$username'");
        if (count($result) > 0)
        {
            $vcode = uniqid();
            DB::insert("insert into vendor_reset_password (username,verification_code) values('$username','$vcode') ");
            $customer_name = $result[0]->{'fname'};
            $data = array(
                'customer_name' => $customer_name,
                'customer_username' => $username,
                'customer_verification_code' => $vcode,

            );
            Mail::send('vendor_email_reset_password', $data, function ($message) use ($username)
            {

                $message->from('no-reply@fashionfactory.world', 'Fashion Factory');

                $message->to($username)->subject('Password Reset Confirmation Link');

            });
            return redirect()
                ->back()
                ->with('message', 'A Password reset link sent to your email');
        }
        else
        {
            return Redirect::back()
                ->withErrors('Username not found');
        }

    }

    public function password_change(Request $request, $username)
    {
        $password = md5($request->input('password'));
        DB::update("update vendors set password ='$password' where email='$username'");
        return redirect('/vendor/login')->with('message', 'Your Password has been changed Successfully');
    }
    public function vendor_signup_view()
    {

        return view('vendor.vendor_signup_view');

    }

    public function business_info_view()
    {

        return view('vendor.business_info_view');

    }

    public function vendor_login_view()
    {

        return view('vendor.vendor_login_view');

    }

    public function admin_home()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('username');
        $user_id = session()->get('pk_id');

        $result = DB::select("select * from detail_table where vendor_id = '$v_id' and (v_order_status = '0' or v_order_status = '1')");
        $week = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and created_at between date_sub(now(),INTERVAL 1 WEEK) and now()");
        $week = count($week);
        $process = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '0'");
        $hold = count($hold);
        $hold = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '1'");
        $hold = count($hold);
        $return = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '3'");
        $return = count($return);
        $cancel = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '4'");
        $cancel = count($cancel);
        $shipped = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '2'");
        $shipped = count($shipped);
        $result4 = DB::select("select* from product where vendor_id = '$user_id' and status = '1'");
        $p = count($result4);
        $pro = DB::select("select* from product where vendor_id = '$user_id'");
        $pro = count($pro);
        $mem = DB::select("select distinct(user_id) from order_table,detail_table where detail_table.vendor_id = '$v_id' and order_table.pk_id = detail_table.order_id");
        $mem = count($mem);
        return view('vendor.home', compact('result', 'c', 'com', 'p', 'week', 'pro', 'mem', 'hold', 'return', 'cancel', 'shipped', 'process'));

    }

    public function add_product_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from product_type where product_type IS NOT NULL and username = 'admin'");

        $result2 = DB::select("select* from main_category where username = 'admin'");

        $result1 = DB::select("select* from brand");

        $material = DB::select("select* from material");

        $style = DB::select("select* from style");

        $result3 = DB::select("select* from sub_category where sub_category IS NOT NULL and username = 'admin'");

        return view('vendor.add_product_view', compact('result', 'result2', 'result3', 'result1', 'material', 'style'));
    }

    public function add_product(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $vendor_id = session()->get('pk_id');
        $total = DB::select("select * from product where vendor_id ='$vendor_id'");
        $total = count($total);

        if (Session::get('subscription') == "SUBSCRIPTION")
        {
            if (Session::get('package') [0]->no_of_product > $total)
            {
                $tags = $request->input('tags');
                $final_tags = "";

                foreach ($tags as $sizes)
                {
                    $final_tags = $final_tags . $sizes . ',';
                }

                $tags = rtrim($final_tags, ',');

                $cat = $request->input('sku');
                $result = DB::select("select* from product where SKU = '$cat' ");
                if (count($result) > 0)
                {
                    return Redirect::back()->withErrors('SKU already Exist');

                }
                else

                {
                    $main_category = urldecode($request->input('mainCategory'));

                    $a = $request->input('SubCategory');

                    $sub_category = DB::select("select* from sub_category where SKU = '$a' ");
                    if (count($sub_category) > 0)
                    {
                        $sub_category = $sub_category[0]->sub_category;
                    }
                    $product_type = $request->input('ProductType');

                    $thumbnail = "";
                    if ($request->hasFile('file'))
                    {
                        $image = $request->file('file');
                        $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                        $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                        $image->storeAs('public/images', $uniqueFileName);
                        $thumbnail = $uniqueFileName;
                    }
                    $thumbnail2 = "";
                    if ($request->hasFile('images2'))
                    {
                        $image = $request->file('images2');
                        $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                        $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                        $image->storeAs('public/images', $uniqueFileName);
                        $thumbnail2 = $uniqueFileName;
                    }

                    $thumbnail3 = "";
                    if ($request->hasFile('images3'))
                    {
                        $image = $request->file('images3');
                        $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                        $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                        $image->storeAs('public/images', $uniqueFileName);

                        $thumbnail3 = $uniqueFileName;
                    }
                    $status = 0;
                    if ($request->input('status'))
                    {
                        $status = 1;
                    }

                    $color = $request->input('_color');
                    $price =0;
                    $q = $request->input('mytextt');
                    $v_product_status = 1;
                    $vendor_id = session()->get('username');
                    $user_id = session()->get('pk_id');
                    $unit = $request->input('unit');
                    $account_t = session()->get('account_t');

                    if (session()
                        ->get('account_t') == "Business")
                    {

                        $vendor_cat = session()->get('vendor_cat');

                        $q = $request->input('mytexttt');
                        $sku = $request->input('sku');
                        for($i=0; $i < count($q); $i++ )
                    {
                
                        DB::insert("insert into pricing_detail (product_sku,quantity,price) values (?,?,?)",array($sku,$q[$i],$q[++$i]));

                    }

                    }
                    else
                    {
                        $price=$request->input('price'); 
                        $vendor_cat = "none";
                    }

                    $discount_status = "0";
                    
                    DB::insert("insert into product (SKU,name,price,color,category,sub_category,brand_name,tags,material,style,product_type,thumbnail,thumbnail2,thumbnail3,description,status,unit,v_product_status,vendor_id,account_t,vendor_cat,urgent_charges,urgent_time,express_charges,express_time,normal_charges,normal_time,free_delivery,return_policy,discount_status) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                        $request->input('sku') ,
                        $request->input('name') ,
                        $price,
                        $color,
                        $main_category,
                        $sub_category,
                        $request->input('BrandName') ,
                        $tags,
                        $request->input('material') ,
                        $request->input('style') ,
                        $product_type,
                        $thumbnail,
                        $thumbnail2,
                        $thumbnail3,
                        $request->input('description') ,
                        $status,
                        $unit,
                        $v_product_status,
                        $user_id,
                        $account_t,
                        $vendor_cat,
                        $request->input('urgent_charges') ,
                        $request->input('urgent_time') ,
                        $request->input('express_charges') ,
                        $request->input('express_time') ,
                        $request->input('normal_charges') ,
                        $request->input('normal_time') ,
                        $request->input('free_delivery') ,
                        $request->input('return_policy') ,
                        $discount_status
                    ));

                    $type = 'new product created';
                    $noti_status = 'unread';
                    DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
                        $user_id,
                        $type,
                        $noti_status
                    ));
                    
                    $sku = $request->input('sku');
                    $sku = DB::select("select* from product where SKU = '$sku' and color='$color'");
                    if (count($sku) > 0)
                    {
                        $sku = $sku[0]->pk_id;
                        for ($i = 0;$i < count($q);$i++)
                        {
            
                            DB::insert("insert into size_detail (product_id,quantity,size) values (?,?,?)", array(
                                $sku,
                                $q[$i],
                                $q[++$i]
                            ));
            
                        }
                    }

                    return redirect('/vendor/home/view/product');
                }
            }
            else
            {
                return Redirect::back()->withErrors('Please Update Your Package');
            }

        }

        else
        {

            $tags = $request->input('tags');
            $final_tags = "";

            foreach ($tags as $sizes)
            {
                $final_tags = $final_tags . $sizes . ',';
            }

            $tags = rtrim($final_tags, ',');

            $cat = $request->input('sku');
            $result = DB::select("select* from product where SKU = '$cat' ");
            if (count($result) > 0)
            {
                return Redirect::back()->withErrors('SKU already Exist');

            }
            else

            {
                $main_category = urldecode($request->input('mainCategory'));

                $a = $request->input('SubCategory');

                $sub_category = DB::select("select* from sub_category where SKU = '$a' ");
                if (count($sub_category) > 0)
                {
                    $sub_category = $sub_category[0]->sub_category;
                }
                $product_type = $request->input('ProductType');
                $thumbnail = "";
                if ($request->hasFile('file'))
                {
                    $image = $request->file('file');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                    $image->storeAs('public/images', $uniqueFileName);
                    $thumbnail = $uniqueFileName;
                }
                $thumbnail2 = "";
                if ($request->hasFile('images2'))
                {
                    $image = $request->file('images2');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                    $image->storeAs('public/images', $uniqueFileName);
                    $thumbnail2 = $uniqueFileName;
                }

                $thumbnail3 = "";
                if ($request->hasFile('images3'))
                {
                    $image = $request->file('images3');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                    $image->storeAs('public/images', $uniqueFileName);

                    $thumbnail3 = $uniqueFileName;
                }
                
                $thumbnail4 = "";
                if ($request->hasFile('images4')) {
                    $image = $request->file('images4');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                   $image->storeAs('public/images',$uniqueFileName);
            
                    $thumbnail4=$uniqueFileName;
                }

                $thumbnail5 = "";
                if ($request->hasFile('images5')) {
                    $image = $request->file('images5');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                   $image->storeAs('public/images',$uniqueFileName);
            
                    $thumbnail5=$uniqueFileName;
                }
            
                $thumbnail6 = "";
                if ($request->hasFile('images6')) {
                    $image = $request->file('images6');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                   $image->storeAs('public/images',$uniqueFileName);
            
                    $thumbnail6=$uniqueFileName;
                }
            
                $thumbnail7 = "";
                if ($request->hasFile('images7')) {
                    $image = $request->file('images7');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                   $image->storeAs('public/images',$uniqueFileName);
            
                    $thumbnail7=$uniqueFileName;
                }
                $status = 0;
                if ($request->input('status'))
                {
                    $status = 1;
                }

                $color = $request->input('_color');
                $q = $request->input('mytextt');
                $v_product_status = 1;
                $vendor_id = session()->get('username');
                $user_id = session()->get('pk_id');
                $unit = $request->input('unit');
                $account_t = session()->get('account_t');

                if (session()
                    ->get('account_t') == "Business")
                {

                    $vendor_cat = session()->get('vendor_cat');

                }
                else
                {
                    $vendor_cat = "none";
                }

                $discount_status = "0";
                $main_category = urldecode($request->input('mainCategory'));
        
                    $com = DB::select("select* from main_category where main_category = '$main_category' ");
                    
                    $commission = $com[0]->commission;
                    
                    
                    
                    if (($commission)=="0")
                    {
                        $a = $request->input('SubCategory');
                        
                        $sub_category = DB::select("select* from sub_category where SKU = '$a' ");
                        $commission = $sub_category[0]->commission;
                    }
                DB::insert("insert into product (SKU,name,price,commission,color,category,sub_category,brand_name,tags,material,style,product_type,thumbnail,thumbnail2,thumbnail3,thumbnail4,thumbnail5,thumbnail6,thumbnail7,description,status,unit,v_product_status,vendor_id,account_t,vendor_cat,urgent_charges,urgent_time,express_charges,express_time,normal_charges,normal_time,free_delivery,return_policy,discount_status) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                    $request->input('sku') ,
                    $request->input('name') ,
                    $request->input('price') ,
                    $commission,
                    $color,
                    $main_category,
                    $sub_category,
                    $request->input('BrandName') ,
                    $tags,
                    $request->input('material') ,
                    $request->input('style') ,
                    $product_type,
                    $thumbnail,
                    $thumbnail2,
                    $thumbnail3,
                    $thumbnail4,
                    $thumbnail5,
                    $thumbnail6,
                    $thumbnail7,
                    $request->input('description') ,
                    $status,
                    $unit,
                    $v_product_status,
                    $user_id,
                    $account_t,
                    $vendor_cat,
                    $request->input('urgent_charges') ,
                    $request->input('urgent_time') ,
                    $request->input('express_charges') ,
                    $request->input('express_time') ,
                    $request->input('normal_charges') ,
                    $request->input('normal_time') ,
                    $request->input('free_delivery') ,
                    $request->input('return_policy') ,
                    $discount_status
                ));

                $type = 'new product created';
                $noti_status = 'unread';
                DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
                    $user_id,
                    $type,
                    $noti_status
                ));
                
                $sku = $request->input('sku');
                $sku = DB::select("select* from product where SKU = '$sku' and color='$color'");
                if (count($sku) > 0)
                {
                    $sku = $sku[0]->pk_id;
                    for ($i = 0;$i < count($q);$i++)
                    {
        
                        DB::insert("insert into size_detail (product_id,quantity,size) values (?,?,?)", array(
                            $sku,
                            $q[$i],
                            $q[++$i]
                        ));
        
                    }
                }

                return redirect('/vendor/home/view/product');
            }

        }

    }

    public function offline_client_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');

        }
        $v_id = session()->get('username');
        $result = DB::select("select * from offline_client where vendor_id= '$v_id'");
        return view('vendor.offline_client_list_view', compact('result'));
    }

    public function product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');

        }
        $v_id = session()->get('username');
        $user_id = session()->get('pk_id');
        $result = DB::select("select * from product where vendor_id= '$user_id' and (v_product_status = '1' or v_product_status = '2')");

        $result2 = DB::select("select * from subscription where vendor_id= '$user_id' and status = 'approved'");
        $package_name = $result2[0]->package_name;

        $package = DB::select("select * from custom_package where package_name= '$package_name'");
        if (count($package) > 0)
        {
            $p_quantity = $package[0]->no_of_product;
        }

        return view('vendor.product_list_view', compact('result', 'p_quantity', 'package'));
    }

    public function updateProductStatus($pk_id, $status)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');

        }

        DB::update("update product set status='$status' where pk_id = '$pk_id'");

        return $status;
    }

    public function pending_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $v_id = session()->get('pk_id');
        $result = DB::select("select* from product where v_product_status = '1' and vendor_id = '$v_id'");
        return view('vendor.pending_product_list_view', compact('result'));
    }

    public function approved_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $v_id = session()->get('pk_id');
        $result = DB::select("select* from product where v_product_status = '2' and vendor_id = '$v_id'");
        return view('vendor.approved_product_list_view', compact('result'));
    }

    public function cancel_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('pk_id');
        $result = DB::select("select* from product where v_product_status = '3' and vendor_id = '$v_id'");
        return view('vendor.cancel_product_list_view', compact('result'));
    }

    public function vendor_home()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('username');
        
        $user_id = session()->get('pk_id');

        $result = DB::select("select * from detail_table where vendor_id = '$v_id' and (v_order_status = '0' or v_order_status = '1')");
        $week = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and created_at between date_sub(now(),INTERVAL 1 WEEK) and now()");
        $week = count($week);
        $process = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '0'");
        // $hold = count($hold);
        //   $hold = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '1'");
        // $hold = count($hold);
        $return = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '3'");
        $return = count($return);
        $cancel = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '4'");
        $cancel = count($cancel);
        $shipped = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '2'");
        $shipped = count($shipped);
        $result4 = DB::select("select* from product where vendor_id = '$user_id' and status = '1'");
        $p = count($result4);
        $pro = DB::select("select* from product where vendor_id = '$user_id'");
        $pro = count($pro);
        $mem = DB::select("select distinct(user_id) from order_table,detail_table where detail_table.vendor_id = '$v_id' and order_table.pk_id = detail_table.order_id");
        $mem = count($mem);
        return view('vendor.home', compact('result', 'c', 'com', 'p', 'week', 'pro', 'mem', 'hold', 'return', 'cancel', 'shipped', 'process'));

    }
    public function vendor_login(Request $request)
    {

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $password = md5($request->input('password'));
        $username = $request->input('username');
        $customer_type = "seller";

        $result = DB::select("select* from client_details where username = '$username' and password='$password' and customer_type='$customer_type' ");
        $package = "";
        if (count($result) > 0)
        {
            $user_id = $result[0]->pk_id;
            $vendor_detail = DB::select("select* from vendors where user_id = '$user_id' ");

            $subs = DB::select("select* from payment_invoice where vendor_id = '$user_id' ORDER BY pk_id DESC ");

            if (count($subs) > 0)
            {
                $package_name = $subs[0]->package_name;
                $package = DB::select("select* from custom_package where package_name = '$package_name'");

            }

            $subscriptions = DB::select("select * from subscription where vendor_id = '$user_id' and status = 'approved' order by pk_id DESC");

            if (count($subscriptions) > 0)
            {

                session()->put('status', $subscriptions[0]->status);
                session()
                    ->put('package_name', $subscriptions[0]->package_name);
                session()
                    ->put('subscription', $subscriptions[0]->subscription);
                session()
                    ->put('p_status', $subscriptions[0]->p_status);
            }

            if ($vendor_detail[0]->vendor_status == 0)
            {

                $request->session()
                    ->put('pk_id', $result[0]->pk_id);
                $request->session()
                    ->put('username', $username);

                if ($vendor_detail[0]->account_t == "Business")
                {

                    session()
                        ->put('vendor_cat', $vendor_detail[0]->vendor_cat);

                }
                session()
                    ->put('fname', $result[0]->fname);
                session()
                    ->put('lname', $result[0]->lname);
                session()
                    ->put('account_t', $vendor_detail[0]->account_t);

                $request->session()
                    ->put('type', 'vendor');

                session()
                    ->put('package', $package);

                $v_id = session()->get('username');
                $user_id = session()->get('pk_id');

                $result = DB::select("select * from detail_table where vendor_id = '$v_id' and (v_order_status = '0' or v_order_status = '1')");
                $week = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and created_at between date_sub(now(),INTERVAL 1 WEEK) and now()");
                $week = count($week);
                //       $hold = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and (v_order_status = '0' or v_order_status = '1')");
                //   $hold = count($hold);
                $return = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '3'");
                $return = count($return);
                $cancel = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '4'");
                $cancel = count($cancel);
                $shipped = DB::select("select distinct(order_id) from detail_table where vendor_id = '$v_id' and v_order_status = '2'");
                $shipped = count($shipped);
                $result4 = DB::select("select* from product where vendor_id = '$user_id' and status = '1'");
                $p = count($result4);
                $pro = DB::select("select* from product where vendor_id = '$user_id'");
                $pro = count($pro);
                $mem = DB::select("select distinct(user_id) from order_table,detail_table where detail_table.vendor_id = '$v_id' and order_table.pk_id = detail_table.order_id");
                $mem = count($mem);
                return view('vendor.home', compact('result', 'c', 'com', 'p', 'week', 'pro', 'mem', 'hold', 'return', 'cancel', 'shipped'));
            }
            elseif ($vendor_detail[0]->vendor_status == 2)
            {
                return Redirect::back()
                    ->withErrors('Please wait for Admin approval');
            }
            else
            {
                return Redirect::back()
                    ->withErrors('User has been blocked');
            }
        }

        else
        {
            return Redirect::back()
                ->withErrors('Username or Password is incorrect');
        }
    }
    public function delete_product($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        DB::delete("delete from product where pk_id = '$id'");

        return redirect()->back();
    }

    public function package_view()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('pk_id');
        $result3 = DB::select("select * from subscription where vendor_id = '$v_id' order by pk_id DESC");
        $result = DB::select("select * from payment_invoice where vendor_id = '$v_id'");
        $result1 = DB::select("select * from custom_package ORDER BY pk_id DESC");

        return view('vendor.package_view', compact('result', 'result1', 'result3'));

    }

    public function subscribe_package($subscription, $package_name, $package_price, Request $request)
    {
        if ($subscription =="COMMISSION")
        {
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        $user_id = session()->get('pk_id');
        $status2 = 'rejected';
        $status3 = '0';
        DB::update("update  subscription set status ='$status2', p_status = '$status3' where vendor_id='$user_id'");
        $status = 'waiting';
        $amount = $package_price;
        
        DB::insert("insert into subscription (vendor_id,package_name,subscription,amount,status,p_status) values (?,?,?,?,?,?)", array(
            $user_id,
            $package_name,
            $subscription,
            $amount,
            $status,
            $status3
        ));

        session()->put('subscription', $subscription);
        session()->put('package_name', $package_name);

        $type = $subscription;
        $noti_status = 'unread';
        DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
            $user_id,
            $type,
            $noti_status
        ));

        session()->flush();
        return redirect('/vendor/login')
            ->withErrors('Wait for admin approvel');
    }
    elseif($subscription =="SUBSCRIPTION"){
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        $user_id = session()->get('pk_id');
        $status2 = 'rejected';
        $status3 = '0';
        DB::update("update  subscription set status ='$status2', p_status = '$status3' where vendor_id='$user_id'");
        $status = 'waiting';
        $amount = $package_price;
        
        DB::insert("insert into subscription (vendor_id,package_name,subscription,amount,status,p_status) values (?,?,?,?,?,?)", array(
            $user_id,
            $package_name,
            $subscription,
            $amount,
            $status,
            $status3
        ));

        session()->put('subscription', $subscription);
        session()->put('package_name', $package_name);

        $type = $subscription;
        $noti_status = 'unread';
        DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
            $user_id,
            $type,
            $noti_status
        ));
        

        $result = DB::select("select* from subscription where vendor_id = '$user_id' order by pk_id DESC");
        return view('vendor.add_payment_invoice_view', compact('result'));

    }
    }

    public function edit_product($pk_id, Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $tags = $request->input('tags');
        $final_tags = "";

        foreach ($tags as $sizes)
        {
            $final_tags = $final_tags . $sizes . ',';
        }

        $tags = rtrim($final_tags, ',');

        $main_category = urldecode($request->input('mainCategory'));

        $a = $request->input('subCategory');

        $sub_category = DB::select(DB::raw("SELECT * FROM sub_category WHERE sub_category = :value") , array(
            'value' => $a,
        ));

        if (count($sub_category) > 0)
        {
            $sub_category = $sub_category[0]->sub_category;

        }
        else
        {

            $sub_category = DB::select(DB::raw("SELECT * FROM sub_category WHERE SKU = :value") , array(
                'value' => $a,
            ));

            $sub_category = $sub_category[0]->sub_category;
        }

        $product_type = $request->input('productType');

        $result = DB::select("select * from product where pk_id = '$pk_id'");
        $status = 0;
        if ($request->input('status'))
        {
            $status = 1;
        }

        $final_size = "";
        $size = $request->input('mytextt');

        foreach ($size as $sizes)
        {
            $final_size = $final_size . $sizes . ',';
        }

        $final_size = rtrim($final_size, ',');
        $unit = $request->input('unit');
        $thumbnail = $result[0]->thumbnail;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail2 = $result[0]->thumbnail2;
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }

        $thumbnail3 = $result[0]->thumbnail3;
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail3 = $uniqueFileName;
        }

        $v_product_status = 1;

        DB::table('product')->where('pk_id', $pk_id)->update(['sku' => $request->input('sku') , 'name' => $request->input('name') , 'price' => $request->input('price') , 'color' => $request->input('_color') , 'category' => $main_category, 'sub_category' => $sub_category, 'brand_name' => $request->input('brandName') , 'tags' => $tags, 'product_type' => $product_type, 'thumbnail' => $thumbnail, 'thumbnail2' => $thumbnail2, 'thumbnail3' => $thumbnail3, 'status' => $status, 'size' => $final_size, 'unit' => $unit, 'quantity_on_hand' => $request->input('quantity_on_hand') , 'v_product_status' => $v_product_status, 'description' => $request->input('description') ]);
        return redirect('/vendor/home/view/product');

    }
    public function offline_client_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select * from offline_client where pk_id = '$id'");

        return view('vendor.offline_client_detail_view', compact('result'));

    }

    public function active_order_detail_view($id, $o_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        

        $result = DB::select("select * from product where pk_id = '$id'");

        $result1 = DB::select("select * from detail_table where order_id = '$o_id' and  product_id = '$id'");
        
        $result2 = DB::select("select * from order_table where pk_id = '$o_id'");

        return view('vendor.active_order_detail_view', compact('result', 'result1','result2'));

    }

    public function complete_order_detail_view($id, $o_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select * from product where pk_id = '$id'");

        $result1 = DB::select("select * from detail_table where order_id = '$o_id' and  product_id = '$id'");
        
        $result2 = DB::select("select * from order_table where pk_id = '$o_id'");

        return view('vendor.complete_order_detail_view', compact('result', 'result1','result2'));

    }
    public function logout()
    {
        session()->flush();
        return redirect('/vendor/login');
    }

    public function cancel_order_detail_view($id, $o_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select * from product where pk_id = '$id'");

        $result1 = DB::select("select * from detail_table where order_id = '$o_id' and  product_id = '$id'");

        return view('vendor.cancel_order_detail_view', compact('result', 'result1'));

    }
    public function return_order_detail_view($id, $o_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select * from product where pk_id = '$id'");

        $result1 = DB::select("select * from detail_table where order_id = '$o_id' and  product_id = '$id'");

        return view('vendor.return_order_detail_view', compact('result', 'result1'));

    }

    public function edit_offline_client_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from offline_client where pk_id = '$pk_id'");

        return view('vendor.edit_offline_client_view', compact('result'));

    }

    public function edit_product_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $result = DB::select("select* from product where pk_id = '$pk_id'");
        $result1 = DB::select("select* from main_category where username = 'admin'");
        $result2 = DB::select("select* from sub_category where username = 'admin'");
        $result3 = DB::select("select* from product_type");
        $result4 = DB::select("select* from brand");

        return view('vendor.edit_product', compact('result', 'result1', 'result2', 'result3', 'result4'));

    }

    public function product_detail_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        
        $result = DB::select("select* from product where pk_id='$pk_id'");

        $result2 = DB::select("select* from size_detail where product_id='$pk_id'");
        return view('vendor.view_product', compact('result','result2'));

    }

    public function create_vendor(Request $request)
    {
        $v = new vendor;

        $e = $request->input('email');
        $result = DB::select("select * from vendors where email = '$e' ");
        if (count($result) > 0)
        {

            return Redirect::back()->withErrors('Email already exist');
        }
        else
        {
            if ($request->input('password') == $request->input('confirm_password'))
            {
                $v->fname = $request->input('fname');
                $v->lname = $request->input('lname');
                $v->store_name = $request->input('store_name');
                $v->phone = $request->input('phone');
                $v->city = $request->input('city');
                $v->email = $request->input('email');
                $v->password = md5($request->input('password'));

                $v->address = $request->input('address');
                $v->cnic = $request->input('cnic');

                $v->bank_title = $request->input('bank_title');
                $v->bank_name = $request->input('bank_name');

                $v->account_number = $request->input('bank_number');
                $v->bank_code = $request->input('bank_code');
                $v->zip_code = $request->input('zip_code');

                $thumbnail = "";
                if ($request->hasFile('file'))
                {
                    $image = $request->file('file');
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                    $image->storeAs('public/images', $uniqueFileName);
                    $thumbnail = $uniqueFileName;
                }

                $v->cheque_copy = $thumbnail;
                $v->vendor_status = 2;
                $v->save();
                return redirect('/vendor/login');
            }

            else
            {

                return Redirect::back()
                    ->withErrors('Password Does Not Match');
            }
        }

    }

    public function active_order_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('pk_id');
        
        $result = DB::select("select detail_table.sku,detail_table.product_id,detail_table.vendor_id,detail_table.v_order_status,detail_table.order_id,detail_table.product_name,detail_table.price,detail_table.size,detail_table.quantity,detail_table.seller_subscription,product.category,product.sub_category,product.commission,product.pk_id from detail_table,product where detail_table.product_id = product.pk_id and detail_table.vendor_id = '$v_id'");
       
        return view('vendor.active_order_view', compact('result'));

    }

    public function cancel_order_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        //$result = DB::select("select order_table.pk_id,order_table.fname,order_table.lname,address_table.fname,address_table.lname,order_table.amount,order_table.placed_at from order_table,address_table where order_table.shipment_address_id=address_table.pk_id or order_table.status = '0'");
        $v_id = session()->get('username');

        $result = DB::select("select * from detail_table where vendor_id = '$v_id' and v_order_status = '2'");

        return view('vendor.canceled_order_list_view', compact('result'));

    }

    public function return_order_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        //$result = DB::select("select order_table.pk_id,order_table.fname,order_table.lname,address_table.fname,address_table.lname,order_table.amount,order_table.placed_at from order_table,address_table where order_table.shipment_address_id=address_table.pk_id or order_table.status = '0'");
        $v_id = session()->get('username');

        $result = DB::select("select * from detail_table where vendor_id = '$v_id' and v_order_status = '3'");

        return view('vendor.return_order_list_view', compact('result'));

    }

    public function complete_order_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        //$result = DB::select("select order_table.pk_id,order_table.fname,order_table.lname,address_table.fname,address_table.lname,order_table.amount,order_table.placed_at from order_table,address_table where order_table.shipment_address_id=address_table.pk_id or order_table.status = '0'");
        $v_id = session()->get('username');

        $result = DB::select("select * from detail_table where vendor_id = '$v_id' and v_order_status = '4' ");

        return view('vendor.complete_order_list_view', compact('result'));

    }
    public function update_order_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $id = $request->input('id');

        DB::table('detail_table')
            ->where('pk_id', $request->input('id'))
            ->update(['v_order_status' => $request->input('status') ]);

        $v_id = session()->get('username');
        $sum = 0;
        $status = 0;
        $s = 0;

        $total = 0;

        $order_result = DB::select("select* from detail_table where vendor_id ='$v_id' and v_order_status = '1' and pk_id = '$id' and v_payment_status = '0'");

        if (count($order_result) > 0)
        {
            foreach ($order_result as $results)
            {
                $pay_result = DB::select("select* from vendor_payments where vendor_id ='$v_id'");

                if (count($pay_result) > 0)
                {

                    $sum = $pay_result[0]->payment;

                    if ($results->discount_price == "") $sum = $sum + ($results->quantity * $results->price);
                    else $sum = $sum + ($results->quantity * $results->discount_price);

                    $result_total = DB::select("select* from detail_table where vendor_id ='$v_id' and (v_order_status = '4' or v_order_status = '1')");

                    if (count($result_total) > 0)
                    {
                        foreach ($result_total as $results)
                        {
                            if ($results->discount_price == "") $total = $total + ($results->quantity * $results->price);
                            else $total = $total + ($results->quantity * $results->discount_price);
                        }
                    }

                    DB::table('vendor_payments')
                        ->where('vendor_id', $v_id)->update(['payment' => $sum, 'status' => $s, 'total_earned' => $total]);

                }

                else
                {

                    if ($results->discount_price == "") $sum = $sum + ($results->quantity * $results->price);
                    else $sum = $sum + ($results->quantity * $results->discount_price);

                    $result_total = DB::select("select* from detail_table where vendor_id ='$v_id' and (v_order_status = '4' or v_order_status = '1')");

                    if (count($result_total) > 0)
                    {
                        foreach ($result_total as $results)
                        {
                            if ($results->discount_price == "") $total = $total + ($results->quantity * $results->price);
                            else $total = $total + ($results->quantity * $results->discount_price);
                        }
                    }

                    DB::insert("insert into vendor_payments (vendor_id,payment,total_earned,status) values (?,?,?,?)", array(
                        $v_id,
                        $sum,
                        $total,
                        $status
                    ));

                }

            }

        }

        DB::update("update detail_table set v_payment_status ='1' where vendor_id ='$v_id' and pk_id ='$id' and v_order_status = '1' ");

        return URL('/') . "/vendor/home/view/active/orders";
    }

    public function v_test()
    {
        $v_id = "vendor@gmail.com";
        $id = 192;
        $sum = 0;
        $status = 0;
        $s = 0;

        $total = 0;

        $order_result = DB::select("select* from detail_table where vendor_id ='$v_id' and v_order_status = '1' and order_id = '$id' and v_payment_status = '0'");

        if (count($order_result) > 0)
        {
            foreach ($order_result as $results)
            {
                $pay_result = DB::select("select* from vendor_payments where vendor_id ='$v_id'");

                if (count($pay_result) > 0)
                {

                    if ($results->discount_price == "") $sum = $sum + ($results->quantity * $results->price);
                    else $sum = $sum + ($results->quantity * $results->discount_price);

                    $result_total = DB::select("select* from detail_table where vendor_id ='$v_id' and (v_order_status = '4' or v_order_status = '1')");

                    if (count($result_total) > 0)
                    {
                        foreach ($result_total as $results)
                        {
                            if ($results->discount_price == "") $total = $total + ($results->quantity * $results->price);
                            else $total = $total + ($results->quantity * $results->discount_price);
                        }
                    }

                    DB::table('vendor_payments')
                        ->where('vendor_id', $v_id)->update(['payment' => $sum, 'status' => $s, 'total_earned' => $total]);

                    return "true";
                }

                else
                {

                    if ($results->discount_price == "") $sum = $sum + ($results->quantity * $results->price);
                    else $sum = $sum + ($results->quantity * $results->discount_price);

                    $result_total = DB::select("select* from detail_table where vendor_id ='$v_id' and (v_order_status = '4' or v_order_status = '1')");

                    if (count($result_total) > 0)
                    {
                        foreach ($result_total as $results)
                        {
                            if ($results->discount_price == "") $total = $total + ($results->quantity * $results->price);
                            else $total = $total + ($results->quantity * $results->discount_price);
                        }
                    }

                    DB::insert("insert into vendor_payments (vendor_id,payment,total_earned,status) values (?,?,?,?)", array(
                        $v_id,
                        $sum,
                        $total,
                        $status
                    ));

                }

            }

        }

        //  DB::update("update detail_table set v_payment_status ='1' where vendor_id ='$v_id' and order_id ='$id' and v_order_status = '1' ");
        return "done";
    }
    public function reporting_by_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('pk_id');

        $result = DB::select("select* from product where vendor_id = '$v_id' and v_product_status = '2'");

        return view('vendor.product_reporting_view', compact('result'));

    }

    public function earning_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('pk_id');

        $result = DB::select("select* from vendor_payments where vendor_id = '$v_id' and status = '0'");

        return view('vendor.earning_view', compact('result'));

    }

    public function reporting_by_product($sku)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $total = 0;
        $result = DB::select("select* from detail_table where product_id = '$sku' and v_order_status = '4'");
        foreach ($result as $results)
        {
            if ($results->discount_price == 0) $total = $total + $results->price;
            else $total = $results->discount_price;
        }

        return view('vendor.product_reporting_detail_view', compact('result', 'total'));
    }
    public function reporting_by_sale_list_view()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        $total = 0;

        $v_id = session()->get('pk_id');

        $result = DB::select("select* from detail_table where vendor_id ='$v_id' and v_order_status = '2'");

        foreach ($result as $results)
        {
            if ($results->discount_price == "") $total = $total + $results->price;
            else $total = $total + $results->discount_price;
        }
        return view('vendor.reporting_by_sale_list_view', compact('result', 'total'));
    }
    
    public function reporting_by_earning_list_view()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        
        $v_id = session()->get('pk_id');
        
        $result = DB::select("select * from vendor_payments where vendor_id='$v_id' ");
        
        return view('vendor.earning', compact('result'));
    }
    
    public function payment_duration()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }

        $v_id = session()->get('pk_id');
        
        
        $result = DB::select("select * from vendors where user_id='$v_id' ");
        
        return view('vendor.payment_duration', compact('result'));

    }
    public function payment_duration_form_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        
        return view('vendor.payment_duration_form');

    }
    
    public function payment_duration_form(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/login');
        }
        
        $v_id = session()->get('pk_id');
        
        $payment_duration = $request->input('payment_duration');
        DB::table('vendors')
            ->where('user_id', $v_id)->update(array(
            'payment_duration' => $payment_duration,
        ));
        return redirect('/vendor/payement/duration');
    }
}