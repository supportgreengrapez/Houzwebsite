<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use Mail;
use Illuminate\Http\Request;
use Response;

class realtorController extends Controller
{

    public function logout()
    {
        session()->flush();
        return redirect('/admin');
    }

    public function realtor_dashboard_view()
    {
        if(!(session()->has('type') && session()->get('type')=='realtor'))
        {
            return redirect('/');
        }
    return view('adminRealtor.home');
    }


    public function realtor_property_view()
    {
        if(!(session()->has('type') && session()->get('type')=='realtor'))
        {
            return redirect('/');
        }
      
        $sale = DB::select("select* from property where sale = '1'");
        $rent = DB::select("select* from property where rent = '1'");
        $hot = DB::select("select* from property where property_type = '1'");
        $superhot = DB::select("select* from property where property_type = '2'");

        $sales = DB::select("select* from project where sale = '1'");
        $rents = DB::select("select* from project where rent = '1'");
        $hots = DB::select("select* from project where property_type = '1'");
        $superhots = DB::select("select* from project where property_type = '2'");
       
    return view('adminRealtor.view_property',compact('sale','rent','hot','superhot','sales','rents','hots','superhots'));
    }

    public function realtor_add_property_view()
    {
        if(!(session()->has('type') && session()->get('type')=='realtor'))
        {
            return redirect('/');
        }
    return view('adminRealtor.add_property_view');
    }
    public function realtor_add_property(Request $request) {

        if(!(session()->has('type') && session()->get('type')=='realtor'))
        {
            return redirect('/');
        }
             $user_id = session()->get('pk_id');
if($request->input('features'))
{
         $features   =  $request->input('features');
    
         $final_size = "";
         foreach($features as $sizes)
         {
             $final_size = $final_size . $sizes. ',';
         }

         $final_features = rtrim($final_size,',');
        }
        else{
            $final_features = "";
        }
$rent = 0;
$sale = 0;
$home = 0;
$plot = 0;
$commercial = 0;
$land = 0;
$flat = 0;
$office = 0;



if($request->input('rent'))
{
    $rent = 1;
}
if($request->input('sale'))
{
    $sale = 1;
}

if($request->input('home'))
{
    $home = 1;
}
if($request->input('plot'))
{
    $plot = 1;
}
if($request->input('commercial'))
{
    $commercial = 1;
}
if($request->input('land'))
{
    $land = 1;
}
if($request->input('flat'))
{
    $flat = 1;
}
if($request->input('office'))
{
    $office = 1;
}
             $uniqueFile="";
             if ($_FILES["document_file"]["name"]) {
                 $image = $request->file('document_file');
                 $uniqueFile = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();

                 $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());

                     $image->storeAs('public/images',$uniqueFile);
             }

             $document_file = $uniqueFile;

             $payment_plan = "";
             if ($request->hasFile('payment_plan')) {
                 $image = $request->file('payment_plan');
                 $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                 $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                 $image->storeAs('public/images',$uniqueFileName);
                 $payment_plan=$uniqueFileName;
             }

             $images = [];

             if($files=$request->file('file'))
             {
                 foreach($files as $image){
                    $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                    $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                    $image->storeAs('public/images',$uniqueFileName);

                     $images[]=$uniqueFileName;
                 }
                }



     $final_images = "";
         foreach($images as $sizes)
         {
             $final_images = $final_images . $sizes. ',';
         }

         $final_images = rtrim($final_images,',');

$property_type = 0;
              DB::insert("insert into property (user_id,rent,sale,home,plots,commercial,land,flats,offices,city,location,area,unit,price,property_title,description,document_file,payment_plan_image,features,expiry_date,thumbnail,property_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",array($user_id,$rent,$sale,$home,$plot,$commercial,$land,$flat,$office,$request->input('city'),$request->input('location'),$request->input('area'),$request->input('unit'),$request->input('price'),$request->input('title'),$request->input('description'),$document_file,$payment_plan,$final_features,$request->input('expiry_date'),$final_images,$property_type));
              return redirect('/realtor/home/view/property');
             }

             public function update_realtor_property_type(Request $request)
             {
                if(!(session()->has('type') && session()->get('type')=='realtor'))
                {
                    return redirect('/');
                }

                $id = $request->input('id');
                $status = $request->input('status');
                  DB::table('property')->where('pk_id', $request->input('id'))->update(['property_type' =>$request->input('status')]);
                  return URL('/')."/realtor/home/view/property";
             }
             public function realtor_property_detail_view($id)
             {
                if(!(session()->has('type') && session()->get('type')=='realtor'))
                {
                    return redirect('/');
                }

                $result = DB::select("select* from property where pk_id = '$id'");
                  return view('adminRealtor.realtor_property_detail_view',compact('result'));
      
             }
             public function edit_realtor_property_view($id)
             {
                if(!(session()->has('type') && session()->get('type')=='realtor'))
                {
                    return redirect('/');
                }

                $result = DB::select("select* from property where pk_id = '$id'");
                  return view('adminRealtor.edit_realtor_property_view',compact('result'));
      
             }

             public function edit_realtor_property(Request $request,$id)
             {
                if(!(session()->has('type') && session()->get('type')=='realtor'))
                {
                    return redirect('/');
                }
              $rent = 0;
              $sale = 0;
              $home = 0;
              $plot = 0;
              $commercial = 0;
              $land = 0;
              $flat = 0;
              $office = 0;
              
              
              
              if($request->input('rent'))
              {
                  $rent = 1;
              }
              if($request->input('sale'))
              {
                  $sale = 1;
              }
              
              if($request->input('home'))
              {
                  $home = 1;
              }
              if($request->input('plot'))
              {
                  $plot = 1;
              }
              if($request->input('commercial'))
              {
                  $commercial = 1;
              }
              if($request->input('land'))
              {
                  $land = 1;
              }
              if($request->input('flat'))
              {
                  $flat = 1;
              }
              if($request->input('office'))
              {
                  $office = 1;
              }
              $result = DB::select("select * from property where pk_id = '$id'");


              $uniqueFile= $result[0]->document_file;
              if ($_FILES["document_file"]["name"]) {
                  $image = $request->file('document_file');
                  $uniqueFile = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
 
                  $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
 
                      $image->storeAs('public/images',$uniqueFile);
                      
              }
              $document_file = $uniqueFile;

              $payment_plan = $result[0]->payment_plan_image;
              if ($request->hasFile('payment_plan')) {
                  $image = $request->file('payment_plan');
                  $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                  $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                  $image->storeAs('public/images',$uniqueFileName);
                  $payment_plan=$uniqueFileName;
              }

              if($request->input('features'))
         {
         $features   =  $request->input('features');
    
         $final_size = "";
         foreach($features as $sizes)
         {
             $final_size = $final_size . $sizes. ',';
         }

         $final_features = rtrim($final_size,',');
        }
        else{
            $final_features = "";
        }

        $final_images = $result[0]->thumbnail;

        if($files=$request->file('file'))
        {
            foreach($files as $image){
               $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
               $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
               $image->storeAs('public/images',$uniqueFileName);

                $images[]=$uniqueFileName;
            }

            $final_images = "";
    foreach($images as $sizes)
    {
        $final_images = $final_images . $sizes. ',';
    }

    $final_images = rtrim($final_images,',');
           }


              DB::table('property')->where('pk_id', $id)->update(['rent' =>$rent,'sale' =>$sale,'home' =>$home,'plots' =>$plot,'commercial' =>$commercial,'land' =>$land,'flats' =>$flat,'offices' =>$office,'city' =>$request->input('city'),'location' =>$request->input('location'),'area' =>$request->input('area'),'unit' =>$request->input('unit'),'price' =>$request->input('price'),'property_title' =>$request->input('property_title'),'description' =>$request->input('description'),'document_file' =>$document_file,'payment_plan_image' =>$payment_plan,'features' =>$final_features,'expiry_date' =>$request->input('expiry_date'),'thumbnail' =>$final_images]);
          
              return redirect('/realtor/home/view/property');
             }


             public function realtor_delete_property($id) {

                if(!(session()->has('type') && session()->get('type')=='realtor'))
                {
                    return redirect('/');
                }
                DB::delete("delete from property where pk_id = '$id'");


                return redirect()->back();
               }


               public function realtor_add_project_view()
               {
                   if(!(session()->has('type') && session()->get('type')=='realtor'))
                   {
                       return redirect('/');
                   }
               return view('adminRealtor.add_project_view');
               }
               public function realtor_add_project(Request $request) {
           
                   if(!(session()->has('type') && session()->get('type')=='realtor'))
                   {
                       return redirect('/');
                   }
                        $user_id = session()->get('pk_id');
           if($request->input('features'))
           {
                    $features   =  $request->input('features');
               
                    $final_size = "";
                    foreach($features as $sizes)
                    {
                        $final_size = $final_size . $sizes. ',';
                    }
           
                    $final_features = rtrim($final_size,',');
                   }
                   else{
                       $final_features = "";
                   }
           $rent = 0;
           $sale = 0;
           $home = 0;
           $plot = 0;
           $commercial = 0;
           $land = 0;
           $flat = 0;
           $office = 0;
           
           
           
           if($request->input('rent'))
           {
               $rent = 1;
           }
           if($request->input('sale'))
           {
               $sale = 1;
           }
           
           if($request->input('home'))
           {
               $home = 1;
           }
           if($request->input('plot'))
           {
               $plot = 1;
           }
           if($request->input('commercial'))
           {
               $commercial = 1;
           }
           if($request->input('land'))
           {
               $land = 1;
           }
           if($request->input('flat'))
           {
               $flat = 1;
           }
           if($request->input('office'))
           {
               $office = 1;
           }
                        $uniqueFile="";
                        if ($_FILES["document_file"]["name"]) {
                            $image = $request->file('document_file');
                            $uniqueFile = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
           
                            $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
           
                                $image->storeAs('public/images',$uniqueFile);
                        }
           
                        $document_file = $uniqueFile;
           
                        $payment_plan = "";
                        if ($request->hasFile('payment_plan')) {
                            $image = $request->file('payment_plan');
                            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                            $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                            $image->storeAs('public/images',$uniqueFileName);
                            $payment_plan=$uniqueFileName;
                        }
           
                        $images = [];
           
                        if($files=$request->file('file'))
                        {
                            foreach($files as $image){
                               $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                               $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                               $image->storeAs('public/images',$uniqueFileName);
           
                                $images[]=$uniqueFileName;
                            }
                           }
           
           
           
                $final_images = "";
                    foreach($images as $sizes)
                    {
                        $final_images = $final_images . $sizes. ',';
                    }
           
                    $final_images = rtrim($final_images,',');
           
           $property_type = 0;
                         DB::insert("insert into project (user_id,rent,sale,home,plots,commercial,land,flats,offices,city,location,property_title,description,document_file,payment_plan_image,features,expiry_date,thumbnail,property_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",array($user_id,$rent,$sale,$home,$plot,$commercial,$land,$flat,$office,$request->input('city'),$request->input('location'),$request->input('title'),$request->input('description'),$document_file,$payment_plan,$final_features,$request->input('expiry_date'),$final_images,$property_type));
                         return redirect('/realtor/home/view/property');
                        }
           
                        public function update_realtor_project_type(Request $request)
                        {
                           if(!(session()->has('type') && session()->get('type')=='realtor'))
                           {
                               return redirect('/');
                           }
           
                           $id = $request->input('id');
                           $status = $request->input('status');
                             DB::table('project')->where('pk_id', $request->input('id'))->update(['property_type' =>$request->input('status')]);
                             return URL('/')."/realtor/home/view/property";
                        }
                        public function realtor_project_detail_view($id)
                        {
                           if(!(session()->has('type') && session()->get('type')=='realtor'))
                           {
                               return redirect('/');
                           }
           
                           $result = DB::select("select* from project where pk_id = '$id'");
                             return view('adminRealtor.realtor_project_detail_view',compact('result'));
                 
                        }
                        public function edit_realtor_project_view($id)
                        {
                           if(!(session()->has('type') && session()->get('type')=='realtor'))
                           {
                               return redirect('/');
                           }
           
                           $result = DB::select("select* from project where pk_id = '$id'");
                             return view('adminRealtor.edit_realtor_project_view',compact('result'));
                 
                        }
           
                        public function edit_realtor_project(Request $request,$id)
                        {
                           if(!(session()->has('type') && session()->get('type')=='realtor'))
                           {
                               return redirect('/');
                           }
                         $rent = 0;
                         $sale = 0;
                         $home = 0;
                         $plot = 0;
                         $commercial = 0;
                         $land = 0;
                         $flat = 0;
                         $office = 0;
                         
                         
                         
                         if($request->input('rent'))
                         {
                             $rent = 1;
                         }
                         if($request->input('sale'))
                         {
                             $sale = 1;
                         }
                         
                         if($request->input('home'))
                         {
                             $home = 1;
                         }
                         if($request->input('plot'))
                         {
                             $plot = 1;
                         }
                         if($request->input('commercial'))
                         {
                             $commercial = 1;
                         }
                         if($request->input('land'))
                         {
                             $land = 1;
                         }
                         if($request->input('flat'))
                         {
                             $flat = 1;
                         }
                         if($request->input('office'))
                         {
                             $office = 1;
                         }
                         $result = DB::select("select * from project where pk_id = '$id'");
           
           
                         $uniqueFile= $result[0]->document_file;
                         if ($_FILES["document_file"]["name"]) {
                             $image = $request->file('document_file');
                             $uniqueFile = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            
                             $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
            
                                 $image->storeAs('public/images',$uniqueFile);
                                 
                         }
                         $document_file = $uniqueFile;
           
                         $payment_plan = $result[0]->payment_plan_image;
                         if ($request->hasFile('payment_plan')) {
                             $image = $request->file('payment_plan');
                             $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                             $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                             $image->storeAs('public/images',$uniqueFileName);
                             $payment_plan=$uniqueFileName;
                         }
           
                         if($request->input('features'))
                    {
                    $features   =  $request->input('features');
               
                    $final_size = "";
                    foreach($features as $sizes)
                    {
                        $final_size = $final_size . $sizes. ',';
                    }
           
                    $final_features = rtrim($final_size,',');
                   }
                   else{
                       $final_features = "";
                   }
           
                   $final_images = $result[0]->thumbnail;
           
                   if($files=$request->file('file'))
                   {
                       foreach($files as $image){
                          $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                          $input['imagename'] = time().'.'.strtolower($image->getClientOriginalExtension());
                          $image->storeAs('public/images',$uniqueFileName);
           
                           $images[]=$uniqueFileName;
                       }
           
                       $final_images = "";
               foreach($images as $sizes)
               {
                   $final_images = $final_images . $sizes. ',';
               }
           
               $final_images = rtrim($final_images,',');
                      }
           
           
                         DB::table('project')->where('pk_id', $id)->update(['rent' =>$rent,'sale' =>$sale,'home' =>$home,'plots' =>$plot,'commercial' =>$commercial,'land' =>$land,'flats' =>$flat,'offices' =>$office,'city' =>$request->input('city'),'location' =>$request->input('location'),'property_title' =>$request->input('title'),'description' =>$request->input('description'),'document_file' =>$document_file,'payment_plan_image' =>$payment_plan,'features' =>$final_features,'expiry_date' =>$request->input('expiry_date'),'thumbnail' =>$final_images]);
                     
                         return redirect('/realtor/home/view/property');
                        }
           
           
                        public function realtor_delete_project($id) {
           
                           if(!(session()->has('type') && session()->get('type')=='realtor'))
                           {
                               return redirect('/');
                           }
                           DB::delete("delete from project where pk_id = '$id'");
           
           
                           return redirect()->back();
                          }
           
}
