<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\User;
use Pusher\Pusher;
class chatController extends Controller
{
    
    public function sendAdminMessage(Request $request)
    {
        
        $message = $request->input('message');
        $file = $request->input('file');
       
        $pmessage = $message;
        $message =  DB::connection()->getPdo()->quote($message);
        $file =  DB::connection()->getPdo()->quote($file);
        $to = $request->input('selected_user');
       // $file = '';
        $name = $file;
        $file = url('/') .'/'.'storage'.'/'.'images'.'/'.$file;
        $from = session()->get('pk_id');
        
        if($name =='')
        {
           
           DB::insert("insert into chats (user_to,user_from,message,created_at) values('$to','$from',$message,NOW())");
        }
        else
        {
        DB::insert("insert into chats (user_to,user_from,message,file,name,created_at) values('$to','$from',$message,'$file','$name',NOW())");
        }
        
     $pusher = new Pusher("a12fe1bfb7e5bbca358e", "b03eb08651b13bc6afd2", "967290", array('cluster' => 'ap2'));
 
     $pusher->trigger('private-admin-channel', 'my-event', array('message' => $pmessage,
     'from' => $from,
     'file' => ''));
       return "ok";
    }
    public function sendCustomerMessage(Request $request)
    {
         date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
      
        $to = $request->input('selected_user');
        $message = $request->input('message');
        $pmessage = $message;
        $message =  DB::connection()->getPdo()->quote($message);
        
        $file = '';
        $name = $file;
        $file = url('/') .'/'.'storage'.'/'.'images'.'/'.$file;
        $from = session()->get('pk_id');
        if($name =='')
        {
            DB::insert("insert into chats (user_to,user_from,message,created_at) values('$to','$from',$message,NOW())");
        }
        else
        DB::insert("insert into chats (user_to,user_from,message,file,name,created_at) values('$to','$from',$message,'$file','$name',NOW())");
     $pusher = new Pusher("a12fe1bfb7e5bbca358e", "b03eb08651b13bc6afd2", "967290", array('cluster' => 'ap2'));
 
     $pusher->trigger('private-user-channel', 'my-event', array('message' => $pmessage,
     'from' => $from,
     'file' => ''));
    }
    public function auth()
    {
     $pusher = new Pusher("a12fe1bfb7e5bbca358e", "b03eb08651b13bc6afd2", "967290", array('cluster' => 'ap2'));
     $str= $pusher->socket_auth($_POST['channel_name'], $_POST['socket_id']);
     return $str;
    }
    public function getClientMessages($id)
    {

        $me = session()->get('pk_id');
        
        $result = DB::select("select* from chats where (user_to='$id' and user_from='$me') or (user_to='$me' and user_from='$id')");
        $str= "<ul>";
        if(count($result)>0)
        {
            foreach($result as $r)
            {
                $time = $r->created_at;

              $time = date("g:i A",strtotime($time));
                if($r->user_from == $me)
                {
                    $str .= "<li class='sent'>
                    <p>".$r->message."</p><span>".$time."</span>
                </li>";
                }
                else
                {
                    $str .= "<li class='replies'>
                    <p>".$r->message."</p><span>".$time."</span>
                </li>";
                }
            }
            $str.="</ul>";
        }
        return $str;
    }
    public function getAdminMessages($id)
    {
        $me = session()->get('pk_id');
        $result = DB::select("select* from chats where (user_to='$id' and user_from='$me') or (user_to='$me' and user_from='$id')");
        $str= "<ul>";
        if(count($result)>0)
        {
            foreach($result as $r)
            {
                  $time = $r->created_at;

              $time = date("g:i A",strtotime($time));
                if($r->user_from == $me)
                {
                    $str .= "<li class='sent'>
                    <p>".$r->message."</p><span>".$time."</span>
                </li>";
                }
                else
                {
                    $str .= "<li class='replies'>
                    <p>".$r->message."</p><span>".$time."</span>
                </li>";
                }
            }
            $str.="</ul>";
        }
        return $str;
        
    }

    public function getFirstUser()
    {
        $u = user::all()->first();

        return $u->id;
    }
}
