<?php
namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use App\vendor_payment;
use App\houzz_earning;
use Mail;
use Illuminate\Http\Request;
use Response;
use Carbon\Carbon;

class adminController extends Controller
{
    public function admin_chat_view()
    {

        $pk_id = session()->get('pk_id');
        $user = db::select("Select client_details.*, (Select message from admin_chats where admin_chats.user_from = '$pk_id' and user_to=client_details.pk_id  or (user_to='$pk_id' and user_from=client_details.pk_id) order by admin_chats.id desc limit 1) as lastmessage from client_details where customer_type = 'seller'");
        return view('admin.chat_system', compact('user'));
    }

    public function update_payment_invoice_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $id = $request->input('id');
        $result = DB::select("select invoice_no from payment_invoice where pk_id = '$id'");
        $invoice_no = $result[0]->invoice_no;
        $date = date('Y-m-d', strtotime("+1 months", strtotime("NOW")));
        DB::table('payment_invoice')->where('pk_id', $request->input('id'))
            ->update(['status' => $request->input('status') ]);
        DB::table('payment_invoice')
            ->where('pk_id', $request->input('id'))
            ->update(['expiry_date' => $date]);
        DB::update("update subscription set p_status ='1' where pk_id='$invoice_no'");
        return URL('/') . "/admin/home/view/package/payment";
    }

    public function update_invoice_package_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $id = $request->input('id');
        DB::table('subscription')
            ->where('pk_id', $request->input('id'))
            ->update(['status' => $request->input('status') ]);

        return URL('/') . "/admin/home/view/package/invoice";
    }

    public function search_subs_order_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $search = $request->input('search');
        $result = DB::select("select* from client_details where pk_id = '$search' and customer_type = 'seller'");

        return view('admin.package_view', compact('result'));
    }

    public function search_subs_package(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $search = $request->input('package');
        if ($search == 'All')
        {
            $result = DB::select("select* from client_details, vendors where client_details.pk_id = vendors.user_id ");

        }
        else
        {
            $result = DB::select("select* from client_details, vendors where client_details.pk_id = vendors.user_id and vendors.subscription = '$search'");

        }

        return view('admin.package_view', compact('result'));
    }

    public function search_order_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $search = $request->input('search');
        $result = DB::select("select* from order_table where pk_id = '$search'");

        return view('admin.active_order_view', compact('result'));
    }

    public function message_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $value = "admin";
        $result = DB::select(DB::raw("SELECT * FROM message WHERE seller_name = :value and reply IS NULL") , array(
            'value' => $value,
        ));
        // $result = DB::select("select* from message where seller_name = 'admin' and reply IS NULL");
        $result1 = DB::select(DB::raw("SELECT * FROM message WHERE seller_name = :value and reply IS NOT NULL order by pk_id DESC") , array(
            'value' => $value,
        ));
        // $result1 = DB::select("select* from message where seller_name = 'admin' and reply IS NOT NULL order by pk_id DESC");
        return view('admin.message_list_view', compact('result', 'result1'));
    }

    public function message_send_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        //  $result = DB::select("select* from message where pk_id = '$id'");
        $result = DB::select(DB::raw("SELECT * FROM message WHERE pk_id = :value") , array(
            'value' => $id,
        ));
        return view('admin.message_send_view', compact('result'));
    }

    public function send_message(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $reply = $request->input('reply');
        // DB::statement("update message set reply ='$reply' where pk_id='$id'");
        DB::table('message')
            ->where('pk_id', $id)->update(array(
            'reply' => $reply,
        ));

        return redirect('/admin/home/view/message');
    }

    public function search_seller_order_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $search = $request->input('search');
        $result = DB::select("select* from payment_invoice where vendor_id = '$search' order by pk_id DESC LIMIT 1");

        return view('admin.commission_vendor_list_view', compact('result'));
    }

    public function search_order_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $from = $request->input('from');
        $to = $request->input('to');
        $order_status = $request->input('order_status');

        // $result = DB::select("select* from order_table where pk_id = '$search'");
        if (empty($from) && empty($to) && empty($order_status))
        {

            $result = DB::select("select * from order_table");

        }
        else if (empty($from) && empty($to))
        {
            if ($order_status == 5)
            {
                $result = DB::select("select * from order_table");
            }

            else
            {
                $result = DB::select("select * from order_table where status = '$order_status'");
            }

        }
        else if (empty($order_status) && empty($from))
        {

            $result = DB::select("select * from order_table where placed_at < '$to' or placed_at = '$to'");

        }

        else if (empty($order_status) && empty($to))
        {
            $result = DB::select("select * from order_table where placed_at > '$from' or placed_at = '$from'");

        }

        else if (empty($order_status))
        {
            $result = DB::select("select * from order_table where (placed_at > '$from' or placed_at = '$from') and (placed_at < '$to' or placed_at = '$to') ");

        }
        else
        {

            if ($order_status == 5)
            {
                $result = DB::select("select * from order_table where  (placed_at > '$from' or placed_at = '$from') and (placed_at < '$to' or placed_at = '$to') ");
            }
            else
            {
                $result = DB::select("select * from order_table where status = '$order_status' and (placed_at > '$from' or placed_at = '$from') and (placed_at < '$to' or placed_at = '$to') ");
            }

        }

        return view('admin.active_order_view', compact('result'));
    }

    public function photo_sub(Request $request)
    {
        $value = $request->Input('cat_id');

        $subcategories = DB::select(DB::raw("SELECT * FROM photo_sub_category WHERE photo_category = :value") , array(
            'value' => $value,
        ));

        return Response::json($subcategories);

    }

    public function sub(Request $request)
    {
        $value = $request->Input('cat_id');

        $subcategories = DB::select(DB::raw("SELECT * FROM sub_category WHERE main_category = :value") , array(
            'value' => $value,
        ));

        return Response::json($subcategories);

    }

    public function type(Request $request)
    {
        $type_id = $request->Input('type_id');

        $sub_id = DB::select("select* from sub_category where SKU = '$type_id' ");
        $sub_id = $sub_id[0]->sub_category;

        $subcategories = DB::select(DB::raw("SELECT * FROM product_type WHERE sub_category = :value") , array(
            'value' => $sub_id,
        ));

        //  $sub_id = DB::select("select* from product_type where sub_category = '$sub_id' and username='admin' ");
        return Response::json($subcategories);

    }

    public function verify_code($username, $code)
    {
        $result = DB::select("select* from admin_reset_password where username= '$username' and verification_code= '$code' and TIMESTAMPDIFF(MINUTE,admin_reset_password.created_at,NOW()) <=30 ");

        if (count($result) > 0)
        {
            return view('admin.change_password', compact('username'));
        }
        else return "The Verification code is expired";
    }

    public function reset_password_view()
    {

        return view('admin.password_reset');

    }

    public function admin_reset_password(Request $request)
    {

        $username = $request->input('username');
        $result = DB::select("select* from admin_details where username = '$username'");
        if (count($result) > 0)
        {
            $vcode = uniqid();
            DB::insert("insert into admin_reset_password (username,verification_code) values('$username','$vcode') ");
            $customer_name = $result[0]->{'fname'};
            $data = array(
                'customer_name' => $customer_name,
                'customer_username' => $username,
                'customer_verification_code' => $vcode,

            );
            Mail::send('admin_email_reset_password', $data, function ($message) use ($username)
            {

                $message->from('no-reply@fashionfactory.world', 'Fashion Factory');

                $message->to($username)->subject('Password Reset Confirmation Link');

            });
            return redirect()
                ->back()
                ->with('message', 'A Password reset link sent to your email');
        }
        else
        {
            return Redirect::back()
                ->withErrors('Username not found');
        }

    }

    public function password_change(Request $request, $username)
    {
        $password = md5($request->input('password'));
        DB::update("update admin_details set password ='$password' where username='$username'");
        return redirect('/admin')->with('message', 'Your Password has been changed Successfully');
    }

    public function update_order_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');

        $status = $request->input('status');
        DB::table('order_table')
            ->where('pk_id', $request->input('id'))
            ->update(['status' => $request->input('status') ]);

        DB::table('detail_table')
            ->where('order_id', $request->input('id'))
            ->update(['v_order_status' => $request->input('status') ]);
            
        $current = Carbon::now();
        $trialExpires = $current->addDays(7);

        if($status =="2")
        {
            DB::table('order_table')
                    ->where('pk_id', $request->input('id'))
                    ->update(['expire_at' =>  $trialExpires ]);
                    
            DB::table('detail_table')
                    ->where('pk_id', $request->input('id'))
                    ->update(['return_date' =>  $trialExpires ]);
               
        }

        $order_result = DB::table('detail_table')->where('order_id', $id)->get();

        $product_id = $order_result[0]->product_id;

        $result2 = DB::table('product')->where('pk_id', $product_id)->get();

        $commission = $result2[0]->commission;

        if ($order_result[0]->discount_price == "")
        {
            $com = ($order_result[0]->price * $commission) / 100;

            $amount = $order_result[0]->price - $com;
        }

        else
        {
            $com = ($order_result[0]->discount_price * $commission) / 100;

            $amount = $order_result[0]->discount_price - $com;
        }
    
        
        $houzz_earning = DB::table('houzz_earning')->get();
            if (count($houzz_earning) > 0)
            {
                $pk="1";
                $houzz_earn = $houzz_earning[0]->houzz_earning;
                $sum = $houzz_earn + $com;
                DB::table('houzz_earning')->where('pk_id', $pk)->update(['houzz_earning' => $sum]);

            }
            else
            {
                DB::insert("insert into houzz_earning (houzz_earning) values (?)", array(
                    $com
                ));

            }

        $vendor_id = $order_result[0]->vendor_id;
            
        if ($vendor_id > 0)
        {

            $payment_result = DB::table('vendor_payments')->where('vendor_id', $vendor_id)->get();

            if (count($payment_result) > 0)
            {

                $payment = $payment_result[0]->total_earned;
                $sum = $payment + $amount;

                DB::table('vendor_payments')->where('vendor_id', $vendor_id)->update(['total_earned' => $sum]);

            }
            elseif ($status == "2")
            {

                $payment_status = "0";
                $pay = "0";
                $vendor_pay = new vendor_payment();
                $vendor_pay->vendor_id = $vendor_id;
                $vendor_pay->payment = $pay;
                $vendor_pay->total_earned = $amount;
                $vendor_pay->remaining = $amount;
                $vendor_pay->status = $payment_status;
                $vendor_pay->save();

            }

        }
        return URL('/') . "/admin/home/view/active/orders";
    }

    public function create_payment_view($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from vendor_payments,client_details where vendor_payments.payment_id = '$id' and vendor_payments.vendor_id=client_details.pk_id");

        return view('admin.create_payment', compact('result'));

    }
    
    public function houzz_earning()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $houzz_earning = DB::table('houzz_earning')->get();
        return view('admin.houzz_earning', compact('houzz_earning'));

    }

    public function print_invoice_payment($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from vendor_payments,client_details,vendors where vendor_payments.payment_id = '$id' and vendor_payments.vendor_id=client_details.pk_id and client_details.pk_id= vendors.user_id and vendor_payments.vendor_id=vendors.user_id");

        return view('admin.vendor_payment_invoice_print', compact('result'));

    }

    public function create_payment(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from vendor_payments where payment_id='$id' ");

        $amount_pay = $result[0]->payment;

        $payment = $request->input('amount_pay');

        $remaining = $request->input('remaining') - $request->input('amount_pay');

        $tota_payment = $amount_pay + $request->input('amount_pay');

        DB::table('vendor_payments')
            ->where('payment_id', $id)->update(['payment' => $tota_payment, 'remaining' => $remaining]);

        return redirect('/admin/home/view/reporting/by/sale/vendor');
    }
    public function test(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $payment_status = "0";
        $pay = "0";
        $vendor_id = "4";
        $sum = "4";

        $vendor_pay = new vendor_payment();
        $vendor_pay->vendor_id = $vendor_id;
        $vendor_pay->payment = $pay;
        $vendor_pay->total_earned = $sum;
        $vendor_pay->status = $payment_status;
        $vendor_pay->save();

        return "helo";

    }

    public function update_vendor_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');
        DB::table('vendors')
            ->where('id', $id)->update(['vendor_status' => $request->input('status') ]);

        return URL('/') . "/admin/home/view/vendor";
    }

    public function update_vendor_amount_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');

        DB::table('detail_table')
            ->where('pk_id', $id)->update(['v_payment_status' => $request->input('status') ]);

        return URL('/') . "/admin/home/view/reporting/by/sale/vendor";
    }

    public function update_payment_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');
        DB::table('payment')
            ->where('pk_id', $id)->update(['status' => $request->input('status') ]);

        return URL('/') . "/admin/payment/list/view";
    }

    public function update_product_hot_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');
        DB::table('product')
            ->where('pk_id', $id)->update(['hot_product' => $request->input('status') ]);

        return URL('/') . "/admin/home/view/product";
    }

    public function update_promo_status($pk_id, $status)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::update("update promo_code set status='$status' where pk_id = '$pk_id'");

        return $status;
    }

    public function admin_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        if (session()
            ->has('username'))
        {
            $result = DB::select("select* from admin_details");

            return view('admin.view_admin_list', compact('result'));

        }
        else
        {
            return redirect('/admin');
        }

    }

    public function admin_specific_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from admin_details where pk_id = '$id'");
        return view('admin.view_admin_profile', compact('result'));
    }

    public function edit_admin_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        if (session()
            ->has('username'))
        {
            $result = DB::select("select*  from admin_details where pk_id = '$id'");
            return view('admin.edit_admin_profile', compact('result'));
        }
        else
        {
            return redirect('/admin');
        }

    }

    public function add_seller_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        return view('admin.create_seller');

    }

    public function add_seller(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $fname = $request->input('fname');
        $lname = $request->input('lname');
        $username = $request->input('username');
        $result = DB::select("select* from client_details where username = '$username' ");

        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Username already Exist');
        }
        $password = md5($request->input('password'));
        $business_name = $request->input('business_name');
        $address = $request->input('address');
        $zip = $request->input('zip');
        $country = $request->input('country');
        $state = $request->input('state');
        $city = $request->input('city');
        $phone = $request->input('phone');
        $fax = $request->input('fax');
        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        $federal_tax = $request->input('federal_tax');
        $primary_contact = $request->input('primary_contact');
        $payee = $request->input('payee');
        $phone1 = $request->input('phone1');
        $fax1 = $request->input('fax1');
        $email1 = $request->input('email1');

        $support_hourz = $request->input('support_hourz');
        $return_country = $request->input('return_country');
        $return_state = $request->input('return_state');
        $return_city = $request->input('return_city');
        $return_zip = $request->input('return_zip');
        $return_phone = $request->input('return_phone');
        $return_fax = $request->input('return_fax');
        $return_address = $request->input('return_address');
        $notification_email = $request->input('notification_email');
        $bank_name = $request->input('bank_name');

        $account_no = $request->input('account_no');
        $account_type = $request->input('account_type');
        $routing_no = $request->input('routing_no');

        $cheque = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('cheque');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $cheque = $uniqueFileName;
        }

        $customer_type = "seller";

        DB::insert("insert into client_details (fname,lname, username, password,country,customer_type) values (?,?,?,?,?,?)", array(
            $fname,
            $lname,
            $username,
            $password,
            $country,
            $customer_type
        ));
        $result1 = DB::select("select* from client_details where username = '$username' ");

        if (count($result1) > 0)
        {
            $user_id = $result1[0]->pk_id;

            DB::insert("insert into vendors (user_id,business_name,address,country,state,city,zip,phone,fax,thumbnail,federal_tax,primary_contact,payee,phone1,fax1,email1,support_hourz,return_address,return_country,return_state,return_city,return_zip,return_phone,return_fax,notification_email,bank_name,account_no,account_type,routing_no,cheque) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $user_id,
                $business_name,
                $address,
                $country,
                $state,
                $city,
                $zip,
                $phone,
                $fax,
                $thumbnail,
                $federal_tax,
                $primary_contact,
                $payee,
                $phone1,
                $fax1,
                $email1,
                $support_hourz,
                $return_address,
                $return_country,
                $return_state,
                $return_city,
                $return_zip,
                $return_phone,
                $return_fax,
                $notification_email,
                $bank_name,
                $account_no,
                $account_type,
                $routing_no,
                $cheque
            ));
            $type = 'new vendor created';
            $noti_status = 'unread';
            DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
                $user_id,
                $type,
                $noti_status
            ));

        }

        return redirect('/admin/home/view/vendor');

    }

    public function create_admin_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        if (session()
            ->has('username'))
        {
            return view('admin.create_admin');
        }
        else
        {
            return redirect('/admin');
        }

    }

    public function edit_admin($id, Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select * from admin_details where pk_id = '$id'");

        if (session()->has('username'))
        {
            $thumbnail = $result[0]->thumbnail;
            if ($request->hasFile('file'))
            {
                $image = $request->file('file');
                $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                $destinationPath = public_path('/storage/images');
                $image->storeAs('public/images', $uniqueFileName);
                $thumbnail = $uniqueFileName;
            }
            $admin_management = 0;
            $product_management = 0;
            $category_management = 0;
            $brand_management = 0;
            $order_management = 0;
            $reporting = 0;
            $discount = 0;
            $promocode = 0;
            $vendor_management = 0;
            if ($request->input('admin_management'))
            {
                $admin_management = 1;
            }
            if ($request->input('product_management'))
            {
                $product_management = 1;
            }
            if ($request->input('category_management'))
            {
                $category_management = 1;
            }

            if ($request->input('brand_management'))
            {
                $brand_management = 1;
            }
            if ($request->input('order_management'))
            {
                $order_management = 1;
            }
            if ($request->input('reporting'))
            {
                $reporting = 1;
            }

            if ($request->input('discount'))
            {
                $discount = 1;
            }
            if ($request->input('promocode'))
            {
                $promocode = 1;
            }
            if ($request->input('vendor_management'))
            {
                $vendor_management = 1;
            }

            if ($admin_management == 0 && $product_management == 0 && $category_management == 0 && $brand_management == 0 && $order_management == 0 && $reporting == 0 && $discount == 0 && $promocode == 0 && $vendor_management == 0)
            {
                return Redirect::back()->withErrors('atleast you neeed to select one permission');
            }
        }
        if (is_null($request->input('password')) && is_null($request->input('confirm')))
        {
            DB::table('admin_details')
                ->where('pk_id', $id)->update(['fname' => $request->input('fname') , 'lname' => $request->input('lname') , 'phone' => $request->input('phone') , 'address' => $request->input('address') , 'thumbnail' => $thumbnail, 'admin_management' => $admin_management, 'product_management' => $product_management, 'category_management' => $category_management, 'brand_management' => $brand_management, 'order_management' => $order_management, 'reporting' => $reporting, 'discount' => $discount, 'promocode' => $promocode, 'vendor_management' => $vendor_management]);

            return redirect('/admin/home/view/admin');
        }
        elseif ($request->input('password') == $request->input('confirm'))
        {

            DB::table('admin_details')
                ->where('pk_id', $id)->update(['fname' => $request->input('fname') , 'lname' => $request->input('lname') , 'phone' => $request->input('phone') , 'address' => $request->input('address') , 'thumbnail' => $thumbnail, 'password' => md5($request->input('password')) , 'admin_management' => $admin_management, 'product_management' => $product_management, 'category_management' => $category_management, 'brand_management' => $brand_management, 'order_management' => $order_management, 'reporting' => $reporting, 'discount' => $discount, 'promocode' => $promocode, 'vendor_management' => $vendor_management]);

            return redirect('/admin/home/view/admin');
        }
        else
        {
            return Redirect::back()->withErrors('Password does not match');
        }

    }

    public function create_admin(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        $admin_management = 0;
        $product_management = 0;
        $category_management = 0;
        $brand_management = 0;
        $order_management = 0;
        $reporting = 0;
        $discount = 0;
        $promocode = 0;
        $vendor_management = 0;

        if ($request->input('admin_management'))
        {
            $admin_management = 1;
        }
        if ($request->input('product_management'))
        {
            $product_management = 1;
        }
        if ($request->input('category_management'))
        {
            $category_management = 1;
        }

        if ($request->input('brand_management'))
        {
            $brand_management = 1;
        }
        if ($request->input('order_management'))
        {
            $order_management = 1;
        }
        if ($request->input('reporting'))
        {
            $reporting = 1;
        }

        if ($request->input('discount'))
        {
            $discount = 1;
        }
        if ($request->input('promocode'))
        {
            $promocode = 1;
        }
        if ($request->input('vendor_management'))
        {
            $vendor_management = 1;
        }

        if ($admin_management == 0 && $product_management == 0 && $category_management == 0 && $brand_management == 0 && $order_management == 0 && $reporting == 0 && $discount == 0 && $promocode == 0 && $vendor_management == 0)
        {
            return Redirect::back()->withErrors('atleast you neeed to select one permission');

        }

        if ($request->input('password') == $request->input('confirm'))
        {
            $username = $request->input('email');

            $result = DB::select("select* from admin_details where username = '$username' ");

            if (count($result) > 0)
            {

                return Redirect::back()->withErrors('Username already Exist');
            }
            else
            {

                DB::insert("insert into admin_details (fname,lname,phone,address,thumbnail, username, password, admin_management,product_management, category_management,brand_management,order_management,reporting,discount,promocode,vendor_management ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                    $request->input('fname') ,
                    $request->input('lname') ,
                    $request->input('phone') ,
                    $request->input('address') ,
                    $thumbnail,
                    $request->input('email') ,
                    md5($request->input('password')) ,
                    $admin_management,
                    $product_management,
                    $category_management,
                    $brand_management,
                    $order_management,
                    $reporting,
                    $discount,
                    $promocode,
                    $vendor_management
                ));

                return redirect('/admin/home/view/admin');
            }

        }
        else
        {
            return Redirect::back()->withErrors('Password does not match');
        }
    }

    public function update_vendor_payment_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $s = 1;
        $id = $request->input('id');
        DB::table('vendor_payments')
            ->where('vendor_id', $request->input('id'))
            ->update(['status' => $request->input('status') ]);
        DB::table('detail_table')
            ->where('vendor_id', $request->input('id'))
            ->update(['v_payment_status' => $s]);

        return URL('/') . "/admin/view/vendors/payments";
    }

    public function update_vendor_order_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');
        DB::table('detail_table')
            ->where('pk_id', $request->input('id'))
            ->update(['v_order_status' => $request->input('status') ]);

        return URL('/') . "/admin/home/view/active/orders";
    }

    public function update_ven_product_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $id = $request->input('id');
        DB::table('product')
            ->where('pk_id', $request->input('id'))
            ->update(['v_product_status' => $request->input('status') ]);

        return URL('/') . "/admin/home/view/approved/products";
    }

    public function product_detail_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from product where pk_id='$pk_id'");
        
        $result2 = DB::select("select* from size_detail where product_id='$pk_id'");

        return view('admin.view_product', compact('result','result2'));

    }

    public function invoice_detail_view($pk_id, $order_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from invoice where pk_id='$pk_id'");
        $result1 = DB::select("select* from invoice_detail where order_id='$order_id'");
        return view('admin.invoice_detail_view', compact('result', 'result1'));

    }

    public function pending_product_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product  where pk_id = '$id'");
        $v_id = $result[0]->vendor_id;
        $v_id = DB::select("select* from client_details  where pk_id = '$v_id'");
        $user_id = $v_id[0]->pk_id;
        $result1 = DB::select("select* from vendors  where user_id = '$user_id'");
        return view('admin.vendor_product_detail_view', compact('result', 'result1', 'v_id'));

    }

    public function approved_product_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product  where pk_id = '$id'");
        $v_id = $result[0]->vendor_id;
        $v_id = DB::select("select* from client_details  where pk_id = '$v_id'");
        $user_id = $v_id[0]->pk_id;
        $result1 = DB::select("select* from vendors  where user_id = '$user_id'");
        return view('admin.approved_product_detail_view', compact('result', 'result1', 'v_id'));

    }

    public function cancel_product_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product  where pk_id = '$id'");
        $v_id = $result[0]->vendor_id;
        $result1 = DB::select("select* from vendors  where email  = '$v_id'");
        return view('admin.cancel_product_detail_view', compact('result', 'result1'));

    }

    public function admin_login_view()
    {

        if ((session()->has('username') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin/home');
        }
        elseif ((session()
            ->has('username') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/home');
        }
        elseif ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {
            return view('admin.login');
        }

    }
    public function logout()
    {
        session()
            ->flush();
        return redirect('/admin');
    }
    public function index(Request $request)
    {

        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $password = md5($request->input('password'));
        $username = $request->input('username');
        $admin_type = $request->input('type');
        $result = DB::select("select* from admin_details where username = '$username' and password='$password'");
        if (count($result) > 0)
        {

            $request->session()
                ->put('pk_id', $result[0]->pk_id);
            $request->session()
                ->put('username', $username);
            $request->session()
                ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});

            if ($admin_type == "admin")
            {
                $request->session()
                    ->put('admin_management', $result[0]->{'admin_management'});
                $request->session()
                    ->put('product_management', $result[0]->{'product_management'});
                $request->session()
                    ->put('category_management', $result[0]->{'category_management'});
                $request->session()
                    ->put('brand_management', $result[0]->{'brand_management'});
                $request->session()
                    ->put('order_management', $result[0]->{'order_management'});
                $request->session()
                    ->put('reporting', $result[0]->{'reporting'});
                $request->session()
                    ->put('discount', $result[0]->{'discount'});
                $request->session()
                    ->put('promocode', $result[0]->{'promocode'});
                $request->session()
                    ->put('vendor_management', $result[0]->{'vendor_management'});

                $request->session()
                    ->put('type', 'admin');
                $result = DB::select("select* from order_table where status = '0' ");
                $o = count($result);
                $hold = DB::select("select* from order_table where status = '1' ");
                $hold = count($hold);

                $result1 = DB::select("select* from client_details where customer_type = 'buyer'");
                $c = count($result1);
                $shipped = DB::select("select* from order_table where status = '2' ");
                $shipped = count($shipped);
                $cancel = DB::select("select* from order_table where status = '4' ");
                $cancel = count($cancel);
                $return = DB::select("select* from order_table where status = '3' ");
                $return = count($return);
                $result4 = DB::select("select* from product where vendor_id IS NULL ");
                $p = count($result4);
                $result5 = DB::select("select* from product where status = '1' and vendor_id IS NULL ");
                $pa = count($result5);
                $week = DB::select("select* from order_table where placed_at between date_sub(now(),INTERVAL 1 WEEK) and now()");
                $week = count($week);
                return view('admin.home', compact('result', 'c', 'o', 'com', 'p', 'pa', 'shipped', 'cancel', 'return', 'week', 'hold'));
            }
            if ($admin_type == "realtor")
            {
                $request->session()
                    ->put('type', 'realtor');
                return view('adminRealtor.home', compact('result'));

            }
        }
        else
        {
            return Redirect::back()
                ->withErrors('Username or Password is incorrect');
        }
    }
    public function reporting_by_product_list_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product");

        return view('admin.product_reporting_view', compact('result'));

    }

    public function reporting_by_product($sku)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $total = 0;
        $result = DB::select("select* from order_table , detail_table where detail_table.product_id = '$sku' and order_table.pk_id = detail_table.order_id and order_table.status = '2' ");
        $sum = 0;
        if (count($result) > 0)
        {
            foreach ($result as $results)
            {
                $sum = $results->price * $results->quantity;
                $total = $sum + $total;
            }

        }

        return view('admin.product_reporting_detail_view', compact('result', 'total'));
    }

    public function customer_reporting_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from client_details");

        return view('admin.customer_reporting_list_view', compact('result'));

    }

    public function customer_reporting($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $sum = 0;
        $result = DB::select("select * from order_table, client_details where order_table.user_id = client_details.pk_id and order_table.user_id = '$id' and order_table.status = '4'");

        if (count($result) > 0) foreach ($result as $results)
        {
            if ($results->promo_amount == "") $sum = $sum + $results->amount;
            else $sum = $sum + $results->promo_amount;
        }
        return view('admin.customer_reporting_detail_view', compact('result', 'sum'));

    }

    public function reporting_by_sale($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where pk_id = '$id'");

        $o_id = $result[0]->user_id;
        if (empty($o_id))
        {
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.sale_reporting_detail_view', compact('result', 'result1'));

        }
        else
        {
            $result = DB::select("select order_table.pk_id,address_table.fname,address_table.lname,order_table.amount,address_table.address,order_table.status,address_table.phone from order_table,address_table where order_table.shipment_address_id=address_table.pk_id and order_table.pk_id = '$id'");
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.sale_reporting_detail_view', compact('result', 'result1'));
        }
    }

    public function reporting_by_sale_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $total = 0;

        $result = DB::select("select* from order_table where status = '2'");

        $result2 = DB::select("select* from detail_table where v_order_status = '2' and seller_subscription = 'NONE' ");

        $result3 = DB::select("select * from detail_table where v_order_status = '2' and seller_subscription = 'COMMISSION' ");
        
        // $p_id = $result3[0]->product_id;

        foreach ($result as $results)
        {
            $total = $total + $results->amount;
        }
        return view('admin.reporting_by_sale_list_view', compact('result', 'total'));
    }

    public function reporting_by_sale_list_view_vendor()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select * from client_details,vendor_payments where client_details.pk_id =vendor_payments.vendor_id");

        return view('admin.reporting_by_sale_list_view_vendor', compact('result'));
    }

    public function vendor_reporting_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from vendors, vendor_payments where vendors.email = vendor_payments.vendor_id ");

        return view('admin.vendor_reporting_list_view', compact('result'));
    }

    public function vendor_payments_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from vendor_payments, vendors where vendor_payments.vendor_id = vendors.email and vendor_payments.status = '0' and vendor_payments.payment > '0' ");

        return view('admin.vendor_payment_list_view', compact('result'));
    }

    public function admin_home()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where status = '0' ");
        $o = count($result);
        $hold = DB::select("select* from order_table where status = '1' ");
        $hold = count($hold);

        $result1 = DB::select("select* from client_details where customer_type = 'buyer'");
        $c = count($result1);
        $shipped = DB::select("select* from order_table where status = '2' ");
        $shipped = count($shipped);
        $cancel = DB::select("select* from order_table where status = '4' ");
        $cancel = count($cancel);
        $return = DB::select("select* from order_table where status = '3' ");
        $return = count($return);
        $result4 = DB::select("select* from product where vendor_id IS NULL ");
        $p = count($result4);
        $result5 = DB::select("select* from product where status = '1' and vendor_id IS NULL ");
        $pa = count($result5);
        $week = DB::select("select* from order_table where placed_at between date_sub(now(),INTERVAL 1 WEEK) and now()");
        $week = count($week);
        return view('admin.home', compact('result', 'c', 'o', 'com', 'p', 'pa', 'shipped', 'cancel', 'return', 'week', 'hold'));

    }

    public function add_discount_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product where discount_status ='0' and status ='1'");
        return view('admin.add_discount_view', compact('result'));

    }

    public function add_discount(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $a = urldecode($request->input('sku'));

        // return $sku;
        $result = DB::select("select* from product where sku = '$a'");
        $main_category = $result[0]->category;
        $sub_category = $result[0]->sub_category;
        $discount_status = "1";

        DB::table('product')->where('sku', $a)->update(['discount_status' => $discount_status]);
        DB::insert("insert into discount_table (sku,start_date,end_date,percentage,main_category,sub_category) values (?,?,?,?,?,?)", array(
            $request->input('sku') ,
            $request->input('start_date') ,
            $request->input('end_date') ,
            $request->input('percentage') ,
            $main_category,
            $sub_category
        ));
        return redirect('/admin/home/view/discount');
    }

    public function view_discount()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from discount_table");

        return view('admin.view_discount', compact('result'));

    }

    public function edit_discount_view($pk_id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from discount_table where pk_id = '$pk_id'");

        return view('admin.edit_discount_view', compact('result'));

    }

    public function edit_discount(Request $request, $pk_id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::table('discount_table')
            ->where('pk_id', $pk_id)->update(['sku' => $request->input('sku') , 'start_date' => $request->input('start_date') , 'end_date' => $request->input('end_date') , 'percentage' => $request->input('percentage') ]);
        return redirect('/admin/home/view/discount');

    }

    public function add_promo_view()
    {

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from client_details ");
        $result1 = DB::select("select* from sub_category ");
        return view('admin.add_promo_code', compact('result', 'result1'));

    }

    public function add_promo(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $promo_name = $request->input('promoinput');
        // return $promo_name;
        if ($request->input('category'))

        {
            $discount_category = $request->input('category');

        }
        else
        {

            $discount_category = "0";

        }

        //   $discount_category = $request->input('category') ;
        $use_time = $request->input('use_time');
        //   return $discount_category;
        

        // return $promo_name;
        $status = 1;
        if ($request->input('status'))
        {
            $status = 0;
        }

        if ($request->input('radio') == '1')
        {
            $discount_type = 'fixed';
        }
        if ($request->input('radio') == '2')
        {
            $discount_type = 'percentage';
        }
        DB::insert("insert into promo_code (promo_code,use_time,discount_type,discount_amount,start_date,end_date,min_total,max_total, discount_category,status) values (?,?,?,?,?,?,?,?,?,?)", array(
            $request->input('promo') ,
            $use_time,
            $discount_type,
            $request->input('discount') ,
            $request->input('start_date') ,
            $request->input('end_date') ,
            $request->input('min') ,
            $request->input('max') ,
            // $discount_for,
            $discount_category,
            $status
        ));

        $dietPlanId = DB::getPdo()->lastInsertId();
        // return $dietPlanId;
        

        $promo_name = $request->input('promoinput');
        //  return $promo_name;
        if (count($promo_name) > 0)
        {

            for ($i = 0;$i < count($promo_name);$i++)
            {

                DB::insert("insert into promo_for (promo_id,discount_for) values (?,?)", array(
                    $dietPlanId,
                    $promo_name[$i]
                ));

            }
        }

        DB::update("update client_details set promostatus = '$use_time' where username= '$promo_name[0]' ");
        return redirect('/admin/home/view/promo');
    }

    public function view_promo_list()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from promo_code,promo_for where promo_code.pk_id= promo_for.promo_id");
        // return $result;
        $result1 = DB::select("select* from promo_code");
        return view('admin.view_promo_list', compact('result', 'result1'));

    }

    public function search_promo(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $search = $request->input('search');
        $result = DB::select("select* from promo_code where promo_code = '$search'");

        return view('admin.view_promo_list', compact('result'));

    }

    public function edit_promo_view($pk_id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from promo_code where pk_id = '$pk_id'");

        return view('admin.edit_promo_view', compact('result'));

    }

    public function edit_promo(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $discount_type = "";

        $status = 0;
        if ($request->input('status'))
        {
            $status = 1;
        }

        if ($request->input('radio') == '1')
        {
            $discount_type = 'fixed';
        }
        if ($request->input('radio') == '2')
        {
            $discount_type = 'percentage';
        }

        if ($request->input('optradio') == '3')
        {
            $discount_for = 'all customers';
        }
        if ($request->input('optradio') == '4')
        {
            $discount_for = 'existing customers';
        }
        if ($request->input('optradio') == '5')
        {
            $discount_for = 'new customers';
        }
        DB::table('promo_code')->where('pk_id', $pk_id)->update(['promo_code' => $request->input('promo') , 'discount_type' => $discount_type, 'start_date' => $request->input('start_date') , 'end_date' => $request->input('end_date') , 'min_total' => $request->input('min') , 'max_total' => $request->input('max') , 'discount_for' => $discount_for, 'discount_amount' => $request->input('discount') , 'status' => $status]);
        return redirect('/admin/home/view/promo');

    }

    public function add_brand_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_brand_view');

    }

    public function payment_list_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from payment order by pk_id DESC");

        return view('admin.payment_list_view', compact('result'));

    }

    public function add_brand(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $cat = $request->input('brandname');
        $result = DB::select("select* from brand where brand_name = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Brand already Exist');

        }
        else

        {
            $thumbnail = "";
            if ($request->hasFile('file'))
            {
                $image = $request->file('file');
                $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                $image->storeAs('public/images', $uniqueFileName);
                $thumbnail = $uniqueFileName;
            }

            DB::insert("insert into brand (brand_name,thumbnail) values (?,?)", array(
                $request->input('brandname') ,
                $thumbnail
            ));
            return redirect('/admin/home/view/brand');
        }
    }

    public function brand_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from brand");

        return view('admin.view_brand_list', compact('result'));

    }

    public function edit_brand_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from brand where SKU = '$sku'");

        return view('admin.edit_brand', compact('result'));

    }

    public function edit_brand(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('brandname');
        $result = DB::select("select* from brand where brand_name = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Brand already Exist');

        }
        else

        {
            $thumbnail = "";
            if ($request->hasFile('file'))
            {
                $image = $request->file('file');
                $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                $image->storeAs('public/images', $uniqueFileName);
                $thumbnail = $uniqueFileName;
            }

            $brand_name = $request->input('brandname');

            DB::table('brand')
                ->where('SKU', $sku)->update(['brand_name' => $brand_name, 'thumbnail' => $thumbnail]);
            return redirect('/admin/home/view/brand');

        }
    }

    public function add_photo_category_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_photo_category_view');

    }

    public function add_main_category_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_main_category_view');

    }

    public function add_material_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_material_view');

    }

    public function add_custom_package_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_custom_package_view');

    }

    public function add_style_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_style_view');

    }

    public function add_photo_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('mainCategory');
        $result = DB::select(DB::raw("SELECT * FROM photo_category WHERE photo_category = :value") , array(
            'value' => $cat,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $username = 'admin';

            DB::insert("insert into photo_category (photo_category,username) values (?,?)", array(
                $request->input('mainCategory') ,
                $username
            ));
            return redirect('/admin/home/view/photo/category');
        }
    }

    public function add_main_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('mainCategory');

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        $result = DB::select(DB::raw("SELECT * FROM main_category WHERE main_category = :value") , array(
            'value' => $cat,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $username = 'admin';

            DB::insert("insert into main_category (main_category,thumbnail,commission,username) values (?,?,?,?)", array(
                $request->input('mainCategory') ,
                $thumbnail,
                $request->input('commission') ,
                $username
            ));
            return redirect('/admin/home/view/main/category');
        }
    }
    public function add_custom_package(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $online_inventory = 0;
        $offline_inventory = 0;
        $promotion = 0;
        $invoice = 0;
        $payment_report = 0;
        $client = 0;
        $message_box = 0;
        $chat_box = 0;
        $featured_seller = 0;
        $featured_product = 0;
        $hot_product = 0;
        $no_of_product = 0;
        $status = 0;

        if ($request->input('online_inventory'))
        {
            $online_inventory = 1;
        }
        if ($request->input('offline_inventory'))
        {
            $offline_inventory = 1;
        }
        if ($request->input('promotion'))
        {
            $promotion = 1;
        }
        if ($request->input('invoice'))
        {
            $invoice = 1;
        }
        if ($request->input('payment_report'))
        {
            $payment_report = 1;
        }
        if ($request->input('client'))
        {
            $client = 1;
        }
        if ($request->input('message_box'))
        {
            $message_box = 1;
        }
        if ($request->input('chat_box'))
        {
            $chat_box = 1;
        }
        if ($request->input('featured_seller'))
        {
            $featured_seller = 1;
        }
        if ($request->input('featured_product'))
        {
            $featured_product = $request->input('no_of_featured_product');
        }
        if ($request->input('hot_product'))
        {
            $hot_product = $request->input('no_of_hot_product');
        }

        if ($request->input('product'))
        {
            $no_of_product = $request->input('no_of_product');
        }
        if ($request->input('status'))
        {
            $status = 1;
        }

        DB::insert("insert into custom_package (package_name,package_price,online_inventory,offline_inventory,promotion,invoice,payment_report,client,message_box,chat_box,featured_seller,featured_product,hot_product,no_of_product,status) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
            $request->input('package_name') ,
            $request->input('package_price') ,
            $online_inventory,
            $offline_inventory,
            $promotion,
            $invoice,
            $payment_report,
            $client,
            $message_box,
            $chat_box,
            $featured_seller,
            $featured_product,
            $hot_product,
            $no_of_product,
            $status
        ));
        return redirect('/admin/home/view/custom/package');

    }
    public function add_style(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('style');
        $result = DB::select(DB::raw("SELECT * FROM style WHERE style = :value") , array(
            'value' => $cat,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('style already Exist');

        }
        else

        {

            DB::insert("insert into style (style) values (?)", array(
                $request->input('style')
            ));
            return redirect('/admin/home/view/style');
        }
    }

    public function add_material(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('material');
        $result = DB::select(DB::raw("SELECT * FROM material WHERE material = :value") , array(
            'value' => $cat,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('material already Exist');

        }
        else

        {

            DB::insert("insert into material (material) values (?)", array(
                $request->input('material')
            ));
            return redirect('/admin/home/view/material');
        }
    }

    public function add_sub_category_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from main_category");
        return view('admin.add_sub_category_view', compact('result'));
    }

    public function add_photo_sub_category_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from photo_category");
        return view('admin.add_photo_sub_category_view', compact('result'));
    }

    public function add_sub_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $category = $request->input('mainCategory');

        $cat = $request->input('subCategory');

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        $result = DB::select(DB::raw("SELECT * FROM sub_category WHERE sub_category = :value and main_category= :value2") , array(
            'value' => $cat,
            'value2' => $category,
        ));

        //     $result = DB::select("select* from sub_category where sub_category = '$cat' and main_category='$category'  ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Subcategory already Exist');

        }
        else

        {
            $username = 'admin';
            $category = $request->input('mainCategory');
            $commission = $request->input('commission');

            DB::insert("insert into sub_category (main_category,sub_category,thumbnail,commission,username) values (?,?,?,?,?)", array(
                $category,
                $request->input('subCategory') ,
                $thumbnail,
                $commission,
                $username
            ));

            return redirect('/admin/home/view/sub/category');
        }
    }

    public function add_photo_sub_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $category = $request->input('mainCategory');

        $cat = $request->input('subCategory');

        $result = DB::select(DB::raw("SELECT * FROM photo_sub_category WHERE photo_sub_category = :value and photo_category= :value2") , array(
            'value' => $cat,
            'value2' => $category,
        ));

        //     $result = DB::select("select* from sub_category where sub_category = '$cat' and main_category='$category'  ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Subcategory already Exist');

        }
        else

        {
            $username = 'admin';
            $category = $request->input('mainCategory');

            DB::insert("insert into photo_sub_category (photo_category,photo_sub_category,username) values (?,?,?)", array(
                $category,
                $request->input('subCategory') ,
                $username
            ));
            return redirect('/admin/home/view/photo/sub/category');
        }
    }

    public function main_category_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from main_category");

        return view('admin.view_main_category_list', compact('result'));

    }

    public function material_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from material");

        return view('admin.view_material_list', compact('result'));

    }

    public function style_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from style");

        return view('admin.view_style_list', compact('result'));

    }
    public function custom_package_detail_view($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from custom_package where pk_id = '$id'");

        return view('admin.custom_package_detail_view', compact('result'));

    }
    public function custom_package_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from custom_package");

        return view('admin.custom_package_list_view', compact('result'));

    }

    public function photo_category_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from photo_category");

        return view('admin.view_photo_category_list', compact('result'));

    }

    public function package_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from client_details,subscription where client_details.customer_type = 'seller' and subscription.vendor_id = client_details.pk_id");

        return view('admin.package_view', compact('result'));

    }

    public function blog_category_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from blog_category");

        return view('admin.view_blog_category_list', compact('result'));

    }

    public function form_category_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_category");

        return view('admin.view_form_category_list', compact('result'));

    }

    public function forum_topic_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_topic");

        return view('admin.topics_list', compact('result'));

    }

    public function forum_post_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_post");

        return view('admin.post_list_view', compact('result'));

    }

    public function forum_post_detail_view($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_post where pk_id ='$id'");

        return view('admin.view_post', compact('result', 'id'));

    }

    public function bloglist()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from blog_post");

        return view('admin.blog_list_view', compact('result'));

    }

    public function addblog(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        DB::insert("insert into blog_post (category,title,body,post) values (?,?,?,?)", array(
            $request->input('category') ,
            $request->input('title') ,
            $request->input('body') ,
            $thumbnail
        ));
        return redirect("/admin-blog/");

    }

    public function add_forum_topic(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        DB::insert("insert into forum_topic (category,topic) values (?,?)", array(
            $request->input('category') ,
            $request->input('topic')
        ));
        return redirect("/admin/home/view/forum/topic");

    }

    public function add_forum_post(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        DB::insert("insert into forum_post (category,topic, title, description) values (?,?,?,?)", array(
            $request->input('category') ,
            $request->input('topic') ,
            $request->input('title') ,
            $request->input('description')
        ));
        return redirect("/admin/home/view/forum/post");

    }

    public function add_blog_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('blogCategory');
        $result = DB::select(DB::raw("SELECT * FROM blog_category WHERE category = :value") , array(
            'value' => $cat,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Blog Category already Exist');

        }
        else

        {

            DB::insert("insert into blog_category (category) values (?)", array(
                $request->input('blogCategory')
            ));
            return redirect('/admin/home/view/blog/category');
        }
    }

    public function add_blog_category_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_blog_category_view');

    }

    public function add_form_category_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_forum_category_view');

    }

    public function add_form_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('forumCategory');
        $result = DB::select(DB::raw("SELECT * FROM forum_category WHERE category = :value") , array(
            'value' => $cat,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Forum Category already Exist');

        }
        else

        {

            DB::insert("insert into forum_category (category) values (?)", array(
                $request->input('forumCategory')
            ));
            return redirect('/admin/home/view/forum/category');
        }
    }

    public function add_forum_topic_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from forum_category");
        return view('admin.add_topic', compact('result'));

    }

    public function create_blog_post_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from blog_category");
        return view('admin.add_blog_view', compact('result'));

    }

    public function add_forum_post_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from forum_category");
        $topic = DB::select("select* from forum_topic");
        return view('admin.add_post', compact('result', 'topic'));

    }

    public function edit_blog_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $category = DB::select("select* from blog_category");
        $result = DB::select("select* from blog_post where pk_id='$id'");

        return view('admin.edit_blog_view', compact('id', 'result', 'category'));

    }

    public function edit_blog(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select * from blog_post where pk_id = '$id'");
        $thumbnail = $result[0]->post;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        DB::table('blog_post')->where('pk_id', $id)->update(['category' => $request->input('category') , 'title' => $request->input('title') , 'body' => $request->input('body') , 'post' => $thumbnail]);
        return redirect('/admin-blog');

    }

    public function delete_material($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from material where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_style($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from style where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_blog($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from blog_post where pk_id = '$id'");

        return redirect()->back();
    }
    public function delete_slider($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from slider where pk_id = '$id'");

        return redirect()->back();
    }
    public function delete_invoice($id, $order_id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from invoice where pk_id = '$id'");
        DB::delete("delete from invoice_detail where order_id = '$order_id'");

        return redirect()->back();
    }
    public function sub_category_list_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from sub_category");

        return view('admin.view_sub_category_list', compact('result'));

    }

    public function photo_sub_category_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from photo_sub_category");

        return view('admin.view_photo_sub_category_list', compact('result'));

    }
    public function edit_main_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from main_category where SKU = '$sku'");

        return view('admin.edit_main_category', compact('result'));

    }

    public function edit_main_category_commission_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from main_category where SKU = '$sku'");

        return view('admin.edit_main_category_commission', compact('result'));

    }

    public function edit_material_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from material where pk_id = '$sku'");

        return view('admin.edit_material', compact('result'));

    }

    public function edit_style_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from style where pk_id = '$sku'");

        return view('admin.edit_style', compact('result'));

    }

    public function edit_slider_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from slider where pk_id = '$pk_id'");

        return view('admin.edit_slider_view', compact('result', 'result1'));

    }

    public function edit_collection_set_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $product = DB::select("select* from product");
        $result = DB::select("select* from collection");
        $result1 = DB::select("select* from collection_set where pk_id = '$pk_id'");
        return view('admin.edit_collection_set_view', compact('result', 'result1', 'product'));

    }

    public function edit_collection_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from collection where pk_id = '$pk_id'");

        return view('admin.edit_collection_view', compact('result'));

    }
    public function edit_invoice_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from invoice where pk_id = '$pk_id'");
        $order_id = $result[0]->order_id;
        $order_detail = DB::select("select* from invoice_detail where order_id = '$order_id'");

        return view('admin.edit_invoice_view', compact('result', 'order_detail'));

    }

    public function edit_photo_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from photo_category where SKU = '$sku'");

        return view('admin.edit_photo_category', compact('result'));

    }

    public function edit_forum_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_category where pk_id = '$sku'");

        return view('admin.edit_forum_category', compact('result'));

    }

    public function edit_forum_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('forumCategory');
        $result = DB::select("select* from forum_category where category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $forum_category = $request->input('forumCategory');

            DB::table('forum_category')
                ->where('pk_id', $sku)->update(['category' => $forum_category]);
            return redirect('/admin/home/view/forum/category');

        }
    }
    public function edit_blog_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from blog_category where pk_id = '$sku'");

        return view('admin.edit_blog_category', compact('result'));

    }
    public function edit_forum_topic_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_topic where pk_id = '$sku'");

        return view('admin.edit_topic', compact('result'));

    }

    public function edit_forum_topic(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        DB::table('forum_topic')
            ->where('pk_id', $sku)->update(['category' => $request->input('category') , 'topic' => $request->input('topic') ]);
        return redirect('/admin/home/view/forum/topic');
    }

    public function edit_forum_post_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from forum_category");
        $topic = DB::select("select* from forum_topic");
        $post = DB::select("select* from forum_post where pk_id = '$sku'");

        return view('admin.edit_post', compact('result', 'topic', 'post'));

    }

    public function edit_forum_post(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        DB::table('forum_post')
            ->where('pk_id', $sku)->update(['category' => $request->input('category') , 'topic' => $request->input('topic') , 'title' => $request->input('title') , 'description' => $request->input('description') ]);
        return redirect('/admin/home/view/forum/post');
    }

    public function edit_blog_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('mainCategory');
        $result = DB::select("select* from blog_category where category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $main_category = $request->input('mainCategory');

            DB::table('blog_category')
                ->where('pk_id', $sku)->update(['category' => $main_category]);
            return redirect('/admin/home/view/blog/category');

        }
    }
    public function edit_main_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('mainCategory');
        $result = DB::select("select* from main_category where main_category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $main_category = $request->input('mainCategory');
            DB::table('main_category')
                ->where('SKU', $sku)->update(['main_category' => $main_category]);
            return redirect('/admin/home/view/main/category');

        }
    }

    public function edit_main_category_commission(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        if ($request->input('commission') == '')
        {
            $commission = "0";

        }
        else
        {
            $commission = $request->input('commission');

        }

        DB::table('main_category')
            ->where('SKU', $sku)->update(['commission' => $commission]);
        return redirect('/admin/home/view/main/category');
    }

    public function edit_style(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('style');
        $result = DB::select("select* from style where style = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Style already Exist');

        }
        else

        {

            $style = $request->input('style');

            DB::table('style')
                ->where('pk_id', $sku)->update(['style' => $style]);
            return redirect('/admin/home/view/style');

        }
    }
    public function edit_material(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('material');
        $result = DB::select("select* from material where material = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Material already Exist');

        }
        else

        {

            $material = $request->input('material');

            DB::table('material')
                ->where('pk_id', $sku)->update(['material' => $material]);
            return redirect('/admin/home/view/material');

        }
    }

    public function edit_photo_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('mainCategory');
        $result = DB::select("select* from photo_category where photo_category = '$cat' ");
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Category already Exist');

        }
        else

        {

            $main_category = $request->input('mainCategory');

            DB::table('photo_category')
                ->where('SKU', $sku)->update(['photo_category' => $main_category]);
            return redirect('/admin/home/view/photo/category');

        }
    }
    public function edit_sub_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from main_category");

        $result1 = DB::select("select* from sub_category where SKU = '$sku'");

        return view('admin.edit_sub_category', compact('result', 'result1'));

    }

    public function commission(Request $request)
    {

        $type_id = $request->Input('commission');

        $sub_id = DB::select("select* from main_category where main_category = '$type_id' ");
        $sub_id = $sub_id[0]->commission;
        return Response::json($sub_id);
    }

    public function edit_sub_category_commission_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from sub_category where SKU = '$sku'");

        return view('admin.edit_sub_category_commission', compact('result'));

    }

    public function edit_sub_category_commission(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from sub_category where SKU = '$sku'");
        $result = $result[0]->main_category;

        $result1 = DB::select("select* from main_category where main_category = '$result'");
        $result1 = $result1[0]->commission;
        // return $result1;
        if ($result1 != 0)
        {
            return Redirect::back()->withErrors('Main Category has commission');

        }
        else

        {

            $commission = $request->input('commission');

            DB::table('sub_category')
                ->where('SKU', $sku)->update(['commission' => $commission]);
            return redirect('/admin/home/view/sub/category');

        }
    }

    public function edit_photo_sub_category_view($sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from photo_category");

        $result1 = DB::select("select* from photo_sub_category where SKU = '$sku'");

        return view('admin.edit_photo_sub_category', compact('result', 'result1'));

    }

    public function edit_sub_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $main_category = $request->input('mainCategory');
        $cat = $request->input('subCategory');

        $result = DB::select(DB::raw("SELECT * FROM sub_category WHERE sub_category = :value and main_category= :value2") , array(
            'value' => $cat,
            'value2' => $main_category,
        ));

        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Subcategory already Exist');

        }
        else

        {

            DB::table('sub_category')
                ->where('SKU', $sku)->update(['main_category' => $main_category, 'sub_category' => $cat]);
            return redirect('/admin/home/view/sub/category');

        }
    }

    public function edit_photo_sub_category(Request $request, $sku)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $main_category = $request->input('mainCategory');
        $cat = $request->input('subCategory');

        $result = DB::select(DB::raw("SELECT * FROM photo_sub_category WHERE photo_sub_category = :value and photo_category= :value2") , array(
            'value' => $cat,
            'value2' => $main_category,
        ));

        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Subcategory already Exist');

        }
        else

        {

            DB::table('photo_sub_category')
                ->where('SKU', $sku)->update(['photo_category' => $main_category, 'photo_sub_category' => $cat]);
            return redirect('/admin/home/view/photo/sub/category');

        }
    }

    public function add_product_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $material = DB::select("select* from material");
        $style = DB::select("select* from style");
        $result = DB::select("select* from product_type where product_type IS NOT NULL and username = 'admin'");
        $result1 = DB::select("select* from brand");
        $result2 = DB::select("select* from main_category where username = 'admin'");
        $result3 = DB::select("select* from sub_category where sub_category IS NOT NULL and username = 'admin'");

        return view('admin.add_product_view', compact('result', 'result1', 'result2', 'result3', 'style', 'material'));
    }

    public function add_idea_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from photo_category where username = 'admin'");

        return view('admin.add_idea', compact('result'));
    }

    public function add_product(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        
        $q = $request->input('mytextt');
        $tags = $request->input('tags');
        $final_tags = "";

        foreach ($tags as $sizes)
        {
            $final_tags = $final_tags . $sizes . ',';
        }

        $tags = rtrim($final_tags, ',');

        $status = 0;
        if ($request->input('status'))
        {
            $status = 1;
        }

        $main_category = urldecode($request->input('mainCategory'));
        $sub_category = '';
        $product_type = '';
        if (!empty($main_category))
        {
            $a = $request->input('SubCategory');
            $sub_category = DB::select("select* from sub_category where SKU = '$a' ");
            $commission = $sub_category[0]->commission;
            $sub_category = $sub_category[0]->sub_category;

            $product_type = $request->input('ProductType');

        }
        
        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail2 = "";
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }

        $thumbnail3 = "";
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail3 = $uniqueFileName;
        }

        $thumbnail4 = "";
        if ($request->hasFile('images4'))
        {
            $image = $request->file('images4');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail4 = $uniqueFileName;
        }

        $thumbnail5 = "";
        if ($request->hasFile('images5'))
        {
            $image = $request->file('images5');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail5 = $uniqueFileName;
        }

        $thumbnail6 = "";
        if ($request->hasFile('images6'))
        {
            $image = $request->file('images6');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail6 = $uniqueFileName;
        }

        $thumbnail7 = "";
        if ($request->hasFile('images7'))
        {
            $image = $request->file('images7');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail7 = $uniqueFileName;
        }

        $color = $request->input('_color');

        $main_category = urldecode($request->input('mainCategory'));

        $com = DB::select("select* from main_category where main_category = '$main_category' ");

        $commission = $com[0]->commission;

        if (($commission) == "0")
        {
            $a = $request->input('SubCategory');

            $sub_category = DB::select("select* from sub_category where SKU = '$a' ");
            $commission = $sub_category[0]->commission;
        }

        $vendor_id = "admin";
        $v_product_status = 0;
        $unit = $request->input('unit');
        $discount_status = "0";
        DB::insert("insert into product (SKU,name,price,commission,color,category,sub_category,brand_name,tags,material,style,product_type,thumbnail,thumbnail2,thumbnail3,thumbnail4,thumbnail5,thumbnail6,thumbnail7,description,status,unit,v_product_status,urgent_charges,urgent_time,express_charges,express_time,normal_charges,normal_time,free_delivery,return_policy,discount_status) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
            $request->input('sku') ,
            $request->input('name') ,
            $request->input('price') ,
            $commission,
            $color,
            $main_category,
            $sub_category,
            $request->input('BrandName') ,
            $tags,
            $request->input('material') ,
            $request->input('style') ,
            $product_type,
            $thumbnail,
            $thumbnail2,
            $thumbnail3,
            $thumbnail4,
            $thumbnail5,
            $thumbnail6,
            $thumbnail7,
            $request->input('description') ,
            $status,
            $unit,
            $v_product_status,
            $request->input('urgent_charges') ,
            $request->input('urgent_time') ,
            $request->input('express_charges') ,
            $request->input('express_time') ,
            $request->input('normal_charges') ,
            $request->input('normal_time') ,
            $request->input('free_delivery') ,
            $request->input('return_policy') ,
            $discount_status
        ));
        
        $sku = $request->input('sku');
        $sku = DB::select("select* from product where SKU = '$sku' and color='$color'");
        if (count($sku) > 0)
        {
            $sku = $sku[0]->pk_id;
            for ($i = 0;$i < count($q);$i++)
            {

                DB::insert("insert into size_detail (product_id,quantity,size) values (?,?,?)", array(
                    $sku,
                    $q[$i],
                    $q[++$i]
                ));

            }
        }
        
        return redirect('/admin/home/view/product');
    }

    public function add_slider(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail2 = "";
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }

        $thumbnail3 = "";
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail3 = $uniqueFileName;
        }

        $thumbnail4 = "";
        if ($request->hasFile('images4'))
        {
            $image = $request->file('images4');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail4 = $uniqueFileName;
        }
        $thumbnail5 = "";
        if ($request->hasFile('images5'))
        {
            $image = $request->file('images5');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail5 = $uniqueFileName;
        }
        $thumbnail6 = "";
        if ($request->hasFile('images6'))
        {
            $image = $request->file('images6');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail6 = $uniqueFileName;
        }
        $thumbnail7 = "";
        if ($request->hasFile('images7'))
        {
            $image = $request->file('images7');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail7 = $uniqueFileName;
        }

        DB::insert("insert into slider (thumbnail,thumbnail1,thumbnail2,thumbnail3,thumbnail5,thumbnail6,thumbnail7) values (?,?,?,?,?,?,?)", array(
            $thumbnail,
            $thumbnail2,
            $thumbnail3,
            $thumbnail4,
            $thumbnail5,
            $thumbnail6,
            $thumbnail7
        ));

        return redirect('/admin/slider/list/view');

    }

    public function add_collection_category(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $collection_name = $request->input('collection_name');
        $order = DB::select("select* from collection where collection_name = '$collection_name'");
        if (count($order) > 0)
        {
            return Redirect::back()->withErrors('Collection Name already Exist');
        }
        else
        {
            $thumbnail = "";
            if ($request->hasFile('file'))
            {
                $image = $request->file('file');
                $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                $image->storeAs('public/images', $uniqueFileName);
                $thumbnail = $uniqueFileName;
            }

            DB::insert("insert into collection (collection_name,description,thumbnail) values (?,?,?)", array(
                $request->input('collection_name') ,
                $request->input('description') ,
                $thumbnail
            ));

        }
        return redirect()->back();

    }

    public function add_collection(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $pk_id = $request->input('category');

        $category = DB::select("select* from collection where pk_id = '$pk_id'");
        $category = $category[0]->collection_name;
        $id = $request->input('sku');

        $final_id = "";

        foreach ($id as $sizes)
        {
            $final_id = $final_id . $sizes . ',';
        }

        $id = rtrim($final_id, ',');

        DB::insert("insert into collection_set(collection_id,collection_name,products) values (?,?,?)", array(
            $pk_id,
            $category,
            $id
        ));

        return redirect('/admin/collection/list/view');

    }

    public function add_invoice(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $order_id = $request->input('order_id');
        $order = DB::select("select* from invoice where order_id = '$order_id'");
        $product_id = $request->input('product_id');
        $wordcount = count($product_id);
        $product_name = $request->input('product_name');
        $product_description = $request->input('product_description');
        $quantity = $request->input('quantity');
        $price = $request->input('price');
        $size = $request->input('size');
        $promotion = $request->input('promotion');
        if (count($order) > 0)
        {
            return Redirect::back()->withErrors('Order ID already Exist');
        }
        else
        {
            DB::insert("insert into invoice (order_id,bill_from,bill_to,shipment_address,amount,date) values (?,?,?,?,?,?)", array(
                $request->input('order_id') ,
                $request->input('bill_from') ,
                $request->input('bill_to') ,
                $request->input('shipment') ,
                $request->input('amount') ,
                $request->input('date')
            ));
            for ($i = 0;$i < $wordcount;$i++)
            {
                DB::insert("insert into invoice_detail (order_id,product_id,product_name,description,quantity,price,size,discount) values (?,?,?,?,?,?,?,?)", array(
                    $request->input('order_id') ,
                    $product_id[$i],
                    $product_name[$i],
                    $product_description[$i],
                    $quantity[$i],
                    $price[$i],
                    $size[$i],
                    $promotion[$i]
                ));
            }
        }

        return redirect('/admin/invoice/list/view');

    }

    public function add_idea(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $photo_category = urldecode($request->input('photo_category'));

        $a = $request->input('photo_sub_category');
        $photo_sub_category = DB::select("select* from photo_sub_category where SKU = '$a' ");
        $photo_sub_category = $photo_sub_category[0]->photo_sub_category;

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail2 = "";
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }

        $thumbnail3 = "";
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $thumbnail3 = $uniqueFileName;
        }

        DB::insert("insert into photo_idea (photo_category,photo_sub_category,description,thumbnail,thumbnail2,thumbnail3) values (?,?,?,?,?,?)", array(
            $photo_category,
            $photo_sub_category,
            $request->input('description') ,
            $thumbnail,
            $thumbnail2,
            $thumbnail3
        ));
        return redirect('/admin/home/view/idea/list');

    }
    public function delete_product($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from product where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_idea($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from photo_idea where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_promo_code($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from promo_code  where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_admin($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from admin_details  where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_discount($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from discount_table  where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_product_type($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from product_type where pk_id = '$id'");

        return redirect()->back();
    }
    public function delete_photo_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from photo_category where SKU = '$id'");

        return redirect()->back();
    }

    public function delete_main_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from main_category where SKU = '$id'");

        return redirect()->back();
    }
    public function delete_forum_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from forum_category where pk_id = '$id'");

        return redirect()->back();
    }

    public function delete_forum_topic($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from forum_topic where pk_id = '$id'");

        return redirect()->back();
    }
    public function delete_forum_post($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from forum_post where pk_id = '$id'");

        return redirect()->back();
    }
    public function delete_blog_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from blog_category where pk_id = '$id'");

        return redirect()->back();
    }
    public function delete_sub_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from sub_category where SKU = '$id'");

        return redirect()->back();
    }

    public function delete_photo_sub_category($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from photo_sub_category where SKU = '$id'");

        return redirect()->back();
    }

    public function delete_brand($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::delete("delete from brand where SKU = '$id'");

        return redirect()->back();
    }

    public function edit_product($pk_id, Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $tags = $request->input('tags');
        $final_tags = "";

        foreach ($tags as $sizes)
        {
            $final_tags = $final_tags . $sizes . ',';
        }

        $tags = rtrim($final_tags, ',');
        $result = DB::select("select * from product where pk_id = '$pk_id'");

        $status = 0;
        if ($request->input('status'))
        {
            $status = 1;
        }

        $commission = urldecode($request->input('commission'));
        $main_category = urldecode($request->input('mainCategory'));

        $a = $request->input('SubCategory');
        $sub_category = DB::select(DB::raw("SELECT * FROM sub_category WHERE sub_category = :value") , array(
            'value' => $a,
        ));

        if (count($sub_category) > 0)
        {
            $a = $sub_category[0]->sub_category;

        }
        else
        {

            $sub_category = DB::select(DB::raw("SELECT * FROM sub_category WHERE SKU = :value") , array(
                'value' => $a,
            ));

            if (count($sub_category) > 0)

            {
                $a = $sub_category[0]->sub_category;
            }
            else
            {
                $a = "";
            }
        }

        $product_type = $request->input('ProductType');

        $final_size = "";
        $size = $request->input('size');

        foreach ($size as $sizes)
        {
            $final_size = $final_size . $sizes . ',';
        }

        $final_size = rtrim($final_size, ',');
        $unit = $request->input('unit');
        $thumbnail = $result[0]->thumbnail;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail2 = $result[0]->thumbnail2;
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }

        $thumbnail3 = $result[0]->thumbnail3;
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail3 = $uniqueFileName;
        }
        $color = $result[0]->color;

        if ($request->input('_color'))
        {
            $color = $request->input('_color');
        }

        DB::table('product')
            ->where('pk_id', $pk_id)->update(['sku' => $request->input('sku') , 'name' => $request->input('name') , 'price' => $request->input('price') , 'commission' => $request->input('commission') , 'color' => $color, 'category' => $main_category, 'sub_category' => $a, 'brand_name' => $request->input('brandName') , 'tags' => $tags, 'product_type' => $product_type, 'thumbnail' => $thumbnail, 'thumbnail2' => $thumbnail2, 'thumbnail3' => $thumbnail3, 'status' => $status, 'quantity_on_hand' => $request->input('quantity_on_hand') , 'size' => $final_size, 'unit' => $unit, 'description' => $request->input('description') , 'urgent_charges' => $request->input('urgent_charges') , 'urgent_time' => $request->input('urgent_time') , 'express_charges' => $request->input('express_charges') , 'express_time' => $request->input('express_time') , 'normal_charges' => $request->input('normal_charges') , 'normal_time' => $request->input('normal_time') , 'free_delivery' => $request->input('free_delivery') , 'return_policy' => $request->input('return_policy') ]);
        return redirect('/admin/home/view/product');

    }

    public function edit_idea($pk_id, Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select * from photo_idea where pk_id = '$pk_id'");

        $photo_category = urldecode($request->input('photo_category'));

        $a = $request->input('photo_sub_category');
        $photo_sub_category = DB::select(DB::raw("SELECT * FROM photo_sub_category WHERE photo_sub_category = :value") , array(
            'value' => $a,
        ));

        if (count($photo_sub_category) > 0)
        {
            $a = $photo_sub_category[0]->photo_sub_category;

        }
        else
        {

            $photo_sub_category = DB::select(DB::raw("SELECT * FROM photo_sub_category WHERE SKU = :value") , array(
                'value' => $a,
            ));

            if (count($photo_sub_category) > 0)

            {
                $a = $photo_sub_category[0]->photo_sub_category;
            }
            else
            {
                $a = "";
            }
        }

        $thumbnail = $result[0]->thumbnail;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail2 = $result[0]->thumbnail2;
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }

        $thumbnail3 = $result[0]->thumbnail3;
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail3 = $uniqueFileName;
        }

        DB::table('photo_idea')->where('pk_id', $pk_id)->update(['photo_category' => $photo_category, 'photo_sub_category' => $a, 'thumbnail' => $thumbnail, 'thumbnail2' => $thumbnail2, 'thumbnail3' => $thumbnail3, 'description' => $request->input('description') ]);
        return redirect('/admin/home/view/idea/list');

    }

    public function edit_product_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product where pk_id = '$pk_id'");
        $result1 = DB::select("select* from main_category");
        $result2 = DB::select("select* from sub_category");
        $result3 = DB::select("select* from product_type");
        $result4 = DB::select("select* from brand");

        return view('admin.edit_product', compact('result', 'result1', 'result2', 'result3', 'result4'));

    }

    public function edit_idea_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result1 = DB::select("select* from photo_idea where pk_id = '$pk_id'");
        $result = DB::select("select* from photo_category");

        return view('admin.edit_idea', compact('result', 'result1'));

    }
    public function updatePackageStatus($pk_id, $status)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::update("update custom_package set status='$status' where pk_id = '$pk_id'");

        return $status;
    }
    public function updateProductStatus($pk_id, $status)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        DB::update("update product set status='$status' where pk_id = '$pk_id'");

        return $status;
    }
    public function add_product_type_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from main_category");
        $result1 = DB::select("select* from sub_category");
        return view('admin.add_product_type_view', compact('result', 'result1'));
    }

    public function add_product_type(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $cat = $request->input('productType');
        $cat1 = urldecode($request->input('mainCategory'));

        $cat2 = $request->input('subCategory');

        $result = DB::select(DB::raw("SELECT * FROM product_type WHERE product_type = :value and main_category= :value2 and sub_category= :value3 ") , array(
            'value' => $cat,
            'value2' => $cat1,
            'value3' => $cat2,
        ));

        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Product Type already Exist');

        }
        else

        {
            $username = 'admin';
            DB::insert("insert into product_type (product_type,main_category,sub_category,username) values (?,?,?,?)", array(
                $request->input('productType') ,
                $cat1,
                $request->input('subCategory') ,
                $username
            ));
            return redirect('/admin/home/view/product/type');
        }
    }
    public function collection_set_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from collection_set where pk_id='$id'");
        $array = [];
        $product_array = [];
        $str = $result[0]->products;
        $id = $result[0]->collection_id;
        $tok = strtok($str, ",");

        $skillset = $tok;
        $array = array_wrap($skillset);

        while ($tok !== false)
        {
            $tok = strtok(",");

            if (is_string($tok)) $skillset = $tok;
            //  $array = array_prepend($array, $skillset);
            array_push($array, $skillset);

        }
        array_pop($array);
        foreach ($array as $arrays)
        {
            $product = DB::select("select* from product where pk_id='$arrays'");
            array_push($product_array, $product);
        }

        $result1 = DB::select("select* from collection where pk_id='$id'");
        return view('admin.collect_list_detail', compact('result', 'product_array', 'result1'));

    }

    public function product_type_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product_type");

        return view('admin.product_type_list_view', compact('result'));

    }
    public function edit_custom_package_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from custom_package where pk_id = '$pk_id'");

        return view('admin.edit_custom_package_view', compact('result'));

    }
    public function edit_product_type_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product_type where pk_id = '$pk_id'");

        return view('admin.edit_product_type_view', compact('result'));

    }

    public function edit_product_type(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $cat = $request->input('productType');
        $cat1 = urldecode($request->input('mainCategory'));

        $cat2 = $request->input('subCategory');

        $result = DB::select(DB::raw("SELECT * FROM product_type WHERE product_type = :value and main_category= :value2 and sub_category= :value3 ") , array(
            'value' => $cat,
            'value2' => $cat1,
            'value3' => $cat2,
        ));
        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Product Type already Exist');

        }
        else

        {

            DB::table('product_type')
                ->where('pk_id', $pk_id)->update(['product_type' => $cat, 'main_category' => $cat1, 'sub_category' => $cat2]);
            return redirect('/admin/home/view/product/type');

        }
    }

    public function edit_custom_package(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $online_inventory = 0;
        $offline_inventory = 0;
        $promotion = 0;
        $invoice = 0;
        $payment_report = 0;
        $client = 0;
        $message_box = 0;
        $chat_box = 0;
        $featured_seller = 0;
        $featured_product = 0;
        $hot_product = 0;
        $no_of_product = 0;
        $status = 0;

        if ($request->input('online_inventory'))
        {
            $online_inventory = 1;
        }
        if ($request->input('offline_inventory'))
        {
            $offline_inventory = 1;
        }
        if ($request->input('promotion'))
        {
            $promotion = 1;
        }
        if ($request->input('invoice'))
        {
            $invoice = 1;
        }
        if ($request->input('payment_report'))
        {
            $payment_report = 1;
        }
        if ($request->input('client'))
        {
            $client = 1;
        }
        if ($request->input('message_box'))
        {
            $message_box = 1;
        }
        if ($request->input('chat_box'))
        {
            $chat_box = 1;
        }
        if ($request->input('featured_seller'))
        {
            $featured_seller = 1;
        }
        if ($request->input('featured_product'))
        {
            $featured_product = $request->input('no_of_featured_product');
        }
        if ($request->input('hot_product'))
        {
            $hot_product = $request->input('no_of_hot_product');
        }

        if ($request->input('product'))
        {
            $no_of_product = $request->input('no_of_product');
        }

        DB::table('custom_package')
            ->where('pk_id', $pk_id)->update(['package_name' => $request->input('package_name') , 'package_price' => $request->input('package_price') , 'online_inventory' => $online_inventory, 'offline_inventory' => $offline_inventory, 'promotion' => $promotion, 'invoice' => $invoice, 'payment_report' => $payment_report, 'client' => $client, 'message_box' => $message_box, 'chat_box' => $chat_box, 'featured_seller' => $featured_seller, 'featured_product' => $featured_product, 'hot_product' => $hot_product, 'no_of_product' => $no_of_product]);
        return redirect('/admin/home/edit/custom/package');

    }

    public function edit_collection(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from collection where pk_id='$pk_id'");

        $thumbnail = $result[0]->thumbnail;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        DB::table('collection')->where('pk_id', $pk_id)->update(['collection_name' => $request->Input('collection_name') , 'description' => $request->Input('description') , 'thumbnail' => $thumbnail]);

        return redirect('/admin/collection/list/view');

    }
    public function edit_collection_set(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $pk_id = $request->input('category');

        $category = DB::select("select* from collection where pk_id = '$pk_id'");
        $category = $category[0]->collection_name;
        $id = $request->input('sku');

        $final_id = "";

        foreach ($id as $sizes)
        {
            $final_id = $final_id . $sizes . ',';
        }

        $id = rtrim($final_id, ',');

        DB::table('collection_set')->where('pk_id', $pk_id)->update(['collection_id' => $pk_id, 'collection_name' => $category, 'products' => $id]);

        return redirect('/admin/collection/list/view');

    }
    public function edit_invoice(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from invoice where pk_id = '$pk_id'");
        $order_id = $result[0]->order_id;

        DB::delete("delete from invoice_detail where order_id = '$order_id'");

        DB::table('invoice')->where('pk_id', $pk_id)->update(['order_id' => $request->Input('order_id') , 'bill_from' => $request->Input('bill_from') , 'bill_to' => $request->Input('bill_to') , 'shipment_address' => $request->Input('shipment') , 'amount' => $request->Input('amount') , 'date' => $request->Input('date') ]);
        DB::insert("insert into invoice_detail (order_id,product_id,product_name,description,quantity,price,size,discount) values (?,?,?,?,?,?,?,?)", array(
            $request->input('order_id') ,
            $request->input('product_id') ,
            $request->input('product_name') ,
            $request->input('product_description') ,
            $request->input('quantity') ,
            $request->input('price') ,
            $request->input('size') ,
            $request->input('promotion')
        ));

        return redirect('/admin/invoice/list/view');

    }

    public function edit_slider(Request $request, $pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from slider where pk_id='$pk_id'");

        $thumbnail = $result[0]->thumbnail;
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $thumbnail1 = $result[0]->thumbnail1;
        if ($request->hasFile('images2'))
        {
            $image = $request->file('images2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail1 = $uniqueFileName;
        }

        $thumbnail2 = $result[0]->thumbnail2;
        if ($request->hasFile('images3'))
        {
            $image = $request->file('images3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail2 = $uniqueFileName;
        }
        $thumbnail3 = $result[0]->thumbnail3;
        if ($request->hasFile('images4'))
        {
            $image = $request->file('images4');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail3 = $uniqueFileName;
        }
        $thumbnail5 = $result[0]->thumbnail5;
        if ($request->hasFile('images5'))
        {
            $image = $request->file('images5');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail5 = $uniqueFileName;
        }
        $thumbnail6 = $result[0]->thumbnail6;
        if ($request->hasFile('images6'))
        {
            $image = $request->file('images6');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail6 = $uniqueFileName;
        }
        $thumbnail7 = $result[0]->thumbnail7;
        if ($request->hasFile('images7'))
        {
            $image = $request->file('images7');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail7 = $uniqueFileName;
        }
        DB::table('slider')->where('pk_id', $pk_id)->update(['thumbnail' => $thumbnail, 'thumbnail1' => $thumbnail1, 'thumbnail2' => $thumbnail2, 'thumbnail3' => $thumbnail3, 'thumbnail5' => $thumbnail5, 'thumbnail6' => $thumbnail6, 'thumbnail7' => $thumbnail7]);

        return redirect('/admin/slider/list/view');

    }

    public function commission_vendor_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $customer_type = "BASIC";
        $result = DB::select("select DISTINCT(vendor_id) from subscription where package_name ='$customer_type'");
        return view('admin.commission_vendor_list_view', compact('result'));
    }

    public function vendor_order_list_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select detail_table.sku,detail_table.product_id,detail_table.vendor_id,detail_table.v_order_status,detail_table.order_id,detail_table.product_name,detail_table.price,detail_table.size,detail_table.quantity,product.category,product.sub_category,product.commission from detail_table,product where detail_table.product_id = product.pk_id and detail_table.vendor_id = '$id'");

        return view('admin.vendor_order_list_view', compact('result'));
    }

    public function vendor_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $customer_type = "seller";
        $result = DB::select("select client_details.pk_id, client_details.fname,client_details.lname,client_details.username,vendors.account_t, 
    vendors.vendor_cat,vendors.cnic from client_details,vendors where client_details.pk_id = vendors.user_id and client_details.customer_type='$customer_type'");

        return view('admin.vendor_list_view', compact('result'));
    }

    public function vendor_detail_view($pk_id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from vendors where user_id = '$pk_id'");

        return view('admin.vendor_detail_view', compact('result'));

    }

    public function collection_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from collection_set where user_id IS NULL");
        return view('admin.collection-list', compact('result'));
    }

    public function slider_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from slider");
        return view('admin.view_slider_list', compact('result'));
    }

    public function invoice_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from invoice");
        return view('admin.invoice_list_view', compact('result'));
    }
    public function search_invoice_order_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $search = $request->input('search');

        $result = DB::select("select* from invoice where order_id = '$search'");
        return view('admin.invoice_list_view', compact('result'));
    }

    public function add_invoice_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.add_invoice_view');
    }

    public function add_slider_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.create_image_slider', compact('result'));
    }

    public function add_collection_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from collection where user_id IS NULL order by pk_id DESC");
        $vendor_id = "";
        $result1 = DB::select("select* from product where vendor_id IS NULL");
        return view('admin.collect_list', compact('result', 'result1'));
    }

    public function product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from product where v_product_status='2' or v_product_status='0' ");
        return view('admin.product_list_view', compact('result'));
    }

    public function idea_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }
        $result = DB::select("select* from photo_idea ");
        return view('admin.view_idea_list', compact('result'));
    }

    public function active_order_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        //  $result = DB::select("select order_table.pk_id,order_table.amount,order_table.placed_at from order_table.pk_id = detail_table.order_id and detail_table.seller_subscription !='SUBSCRIPTION'");
        

        $result = DB::select("select order_table.pk_id,order_table.fname,order_table.lname,order_table.status,order_table.amount,order_table.promo_amount,order_table.placed_at from order_table,detail_table where order_table.pk_id = detail_table.order_id and detail_table.seller_subscription !='SUBSCRIPTION'");
        //  $result = DB::select("select* from order_table");
        return view('admin.active_order_view', compact('result'));

    }

    public function package_payment_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from subscription,payment_invoice where subscription.pk_id = payment_invoice.invoice_no");

        return view('admin.vendor_package_invoice_list_view', compact('result'));

    }

    public function payment_invoice_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from subscription,payment_invoice where subscription.pk_id = payment_invoice.invoice_no");

        return view('admin.payment-invoice-page', compact('result'));

    }

    public function package_invoice_list_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from subscription,vendors where subscription.vendor_id = vendors.user_id");

        return view('admin.vendor_invoice_package_list_view', compact('result'));

    }

    public function printinvoice($id)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from client_details,vendors,subscription where subscription.vendor_id = vendors.user_id and vendors.user_id= client_details.pk_id and subscription.pk_id= '$id'");

        return view('admin.invoice-page', compact('result'));

    }

    public function seller_rating_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from review_table,client_details where review_table.vendor_id = client_details.username and client_details.customer_type = 'seller' ");

        return view('admin.seller_product_rating', compact('result'));

    }

    public function rating_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        //$result = DB::select("select order_table.pk_id,order_table.fname,order_table.lname,address_table.fname,address_table.lname,order_table.amount,order_table.placed_at from order_table,address_table where order_table.shipment_address_id=address_table.pk_id or order_table.status = '0'");
        

        $result = DB::select("select* from review_table ");

        return view('admin.rating_list_view', compact('result'));

    }

    public function active_order_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where pk_id = '$id'");

        $o_id = $result[0]->user_id;
        if (empty($o_id))
        {
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.active_order_detail_view', compact('result', 'result1', 'id'));

        }
        else
        {
            $result = DB::select("select * from order_table,address_table where order_table.shipment_address_id=address_table.pk_id and order_table.pk_id = '$id'");
            $result1 = DB::select("select * from detail_table where order_id = '$id'");
            return view('admin.active_order_detail_view', compact('result', 'result1', 'id'));
        }
    }

    public function print_invoice($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where pk_id = '$id'");

        $o_id = $result[0]->user_id;
        if (empty($o_id))
        {
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.active_order_detail_view', compact('result', 'result1', 'id'));

        }
        else
        {
            $result = DB::select("select * from order_table,address_table where order_table.shipment_address_id=address_table.pk_id and order_table.pk_id = '$id'");
            $result1 = DB::select("select * from detail_table where order_id = '$id'");
            return view('admin.invoice_page', compact('result', 'result1', 'id'));
        }
    }

    public function complete_order_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where status = '4'");
        return view('admin.complete_order_list_view', compact('result'));
    }

    public function pending_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product where v_product_status = '1'");
        return view('admin.pending_product_list_view', compact('result'));
    }

    public function approved_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product where v_product_status = '2'");
        return view('admin.approved_product_list_view', compact('result'));
    }

    public function cancel_product_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from product where v_product_status = '3'");
        return view('admin.cancel_products_list_view', compact('result'));
    }

    public function cancel_order_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where status = '2'");
        return view('admin.canceled_order_list_view', compact('result'));
    }

    public function return_order_list_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table,detail_table,return_reason where order_table.status = '3' and order_table.pk_id=return_reason.order_id and order_table.pk_id= detail_table.order_id");
        return view('admin.return_order_list_view', compact('result'));
    }
    
    
    public function confirmed_return(Request $request)
    {
       
        if (!(session()->has('type') && session()
        ->get('type') == 'admin'))
    {
        return redirect('/admin');
    }
    
    $id = $request->input('id');
        
    if($request->input('status')=="3"){
    
    $status="2";
    DB::table('detail_table')
            ->where('order_id', $id)
            ->update(['return_status' => $status]);
    $user_id = DB::select("select user_id from order_table where pk_id = '$id'");
    
    $user_id= $user_id[0]->user_id;
    $price = DB::select("select amount from order_table where pk_id = '$id'");
    $price= $price[0]->amount;


            $pro_id = DB::select("select product_id from detail_table where order_id = '$id'");
            $prod = $pro_id[0]->product_id;
            $size = DB::select("select size from detail_table where order_id = '$id'");
            $sizee = $size[0]->size;
            $q = DB::select("select quantity from detail_table where order_id = '$id'");
           $qq = $q[0]->quantity;
        
           
            $resulting = DB::select("select * from size_detail where product_id = '$prod' and size = '$sizee'");
            
            $qn = $resulting[0]->quantity + $qq;
            DB::update("update size_detail set quantity = '$qn' where product_id='$prod' and size='$sizee'");
            
    }
    elseif($request->input('status')=="2"){
        
        $status="2";
         DB::table('order_table')
            ->where('pk_id', $id)
            ->update(['status' => $status]);
            
        DB::table('detail_table')
            ->where('order_id', $id)
            ->update(['v_order_status' => $status,'return_status' => $status]);
            
    }
            
            return URL('/') . "/admin/home/view/return/orders";

    }

    public function complete_order_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where pk_id = '$id'");

        $o_id = $result[0]->user_id;
        if (empty($o_id))
        {
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.complete_order_detail_view', compact('result', 'result1'));

        }
        else
        {
            $result = DB::select("select order_table.pk_id,address_table.fname,address_table.lname,order_table.amount,address_table.address,order_table.status,address_table.phone from order_table,address_table where order_table.shipment_address_id=address_table.pk_id and order_table.pk_id = '$id'");
            $result1 = DB::select("select * from detail_table where order_id = '$id'");
            return view('admin.complete_order_detail_view', compact('result', 'result1'));
        }
    }

    public function cancel_order_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where pk_id = '$id'");

        $o_id = $result[0]->user_id;
        if (empty($o_id))
        {
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.cancel_order_detail_view', compact('result', 'result1'));

        }
        else
        {
            $result = DB::select("select order_table.pk_id,address_table.fname,address_table.lname,order_table.amount,address_table.address,order_table.status,address_table.phone from order_table,address_table where order_table.shipment_address_id=address_table.pk_id and order_table.pk_id = '$id'");
            $result1 = DB::select("select * from detail_table where order_id = '$id'");
            return view('admin.cancel_order_detail_view', compact('result', 'result1'));
        }
    }

    public function return_order_detail_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        $result = DB::select("select* from order_table where pk_id = '$id'");

        $o_id = $result[0]->user_id;
        if (empty($o_id))
        {
            $result1 = DB::select("select * from detail_table where order_id = '$id'");

            return view('admin.return_order_detail_view', compact('result', 'result1'));

        }
        else
        {
            $result = DB::select("select order_table.pk_id,address_table.fname,address_table.lname,order_table.amount,address_table.address,order_table.status,address_table.phone from order_table,address_table where order_table.shipment_address_id=address_table.pk_id and order_table.pk_id = '$id'");
            $result1 = DB::select("select * from detail_table where order_id = '$id'");
            return view('admin.return_order_detail_view', compact('result', 'result1'));
        }
    }

    public function import_product_view()
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin');
        }

        return view('admin.import_new_product');
    }

    public function CSV(Request $request)
    {

        $requestBody = $request->all();

        //get file
        $upload = $request->file('file');
        $filePath = $upload->getRealPath();
        //open and read
        $file = fopen($filePath, 'r');
        $header = fgetcsv($file);
        // dd($header);
        $escapedHeader = [];
        //validate
        foreach ($header as $key => $value)
        {
            $lheader = strtolower($value);
            $escapedItem = preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);

        }
        //looping through othe columns
        while ($columns = fgetcsv($file))
        {
            if ($columns[0] == "")
            {
                continue;
            }
            //trim data
            /*    foreach ($columns as $key => &$value) {
               $value = strtok($value, ",");
             //   $value=preg_replace('/\D/','',$value);
             //   return $value;
            }*/
            $data = array_combine($escapedHeader, $columns);

            // setting type
            /*    foreach ($data as $key => &$value) {
            $value=($key=="SKU")?(integer)$value: (float)$value;
            }*/
            // Table update
            $SKU = $data['sku'];

            $Name = $data['name'];
            $Price = $data['price'];

            $Description = $data['description'];

        }
    }
}

