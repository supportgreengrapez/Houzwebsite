<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Cart;
use Session;
use Response;
use Illuminate\Support\Str;
use Carbon\Carbon;
class clientController extends Controller
{
    public function UUID()
    {
        return rand();
        // return (string) Str::uuid();
        
    }
    public function property_listed_view($home, $city)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        if ($home == "home")
        {
            $sale = DB::select("select * from property where home = '1' and city = '$city'");

        }

        if ($home == "commercial")
        {
            $sale = DB::select("select * from property where commercial = '1' and city = '$city'");

        }

        if ($home == "plot")
        {
            $sale = DB::select("select * from property where plots = '1' and city = '$city'");

        }
        if ($home == "flat")
        {
            $sale = DB::select("select * from property where flats = '1' and city = '$city'");

        }

        if ($home == "land")
        {
            $sale = DB::select("select * from property where land = '1' and city = '$city'");

        }
        if ($home == "rent")
        {
            $sale = DB::select("select * from property where rent = '1' and city = '$city'");

        }
        if ($home == "sale")
        {
            $sale = DB::select("select * from property where sale = '1' and city = '$city'");

        }
        if ($home == "office")
        {
            $sale = DB::select("select * from property where offices = '1' and city = '$city'");

        }

        return view('client.property_listed_view', compact('sale') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }
    public function message_compose_view()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $result = DB::select("select * from client_details,vendors where client_details.customer_type ='seller' and client_details.pk_id = vendors.user_id");

        return view('client.message_compose_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }
    public function message_send_view()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $pk_id = session()->get('pk_id');
        // $result = DB::select("select * from client_details where customer_type ='seller'");
        $result = DB::select(DB::raw("SELECT * FROM message WHERE customer_name = :value and reply IS NULL order by pk_id DESC") , array(
            'value' => $pk_id,
        ));
        // $result = DB::select("select * from message where customer_name ='$pk_id' and reply IS NULL order by pk_id DESC");
        $result1 = DB::select(DB::raw("SELECT * FROM message WHERE customer_name = :value and reply IS NOT NULL order by pk_id DESC") , array(
            'value' => $pk_id,
        ));
        //$result1 = DB::select("select * from message where customer_name ='$pk_id' and reply IS NOT NULL order by pk_id DESC");
        return view('client.message_send_view', compact('result', 'result1') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function property_detail_view($id)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $result = DB::select("select * from property where pk_id = '$id'");

        return view('client.property_detail_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function properties_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        //$result = DB::select("select* from realtor_signin,property where realtor_signin.status = '1' and property.user_id = realtor_signin.user_id ");
        $home = DB::select("SELECT COUNT(pk_id) as count, city from property where home = '1' GROUP BY city");
        $offices = DB::select("SELECT COUNT(pk_id) as count, city from property where offices = '1' GROUP BY city");
        $plots = DB::select("SELECT COUNT(pk_id) as count, city from property where plots = '1' GROUP BY city");
        $commercial = DB::select("SELECT COUNT(pk_id) as count, city from property where commercial = '1' GROUP BY city");
        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' GROUP BY city");
        $land = DB::select("SELECT COUNT(pk_id) as count, city from property where land = '1' GROUP BY city");
        $flats = DB::select("SELECT COUNT(pk_id) as count, city from property where flats = '1' GROUP BY city");

        return view('client.properties_list_view', compact('products', 'home', 'offices', 'plots', 'land', 'flats', 'commercial', 'rent', 'sale') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function home_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and home='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and home='1'  GROUP BY city");

        return view('client.home_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function commercial_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and commercial='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and commercial='1'  GROUP BY city");

        return view('client.commercial_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function plot_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and plots='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and plots='1'  GROUP BY city");

        return view('client.plot_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function flat_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and flats='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and flats='1'  GROUP BY city");

        return view('client.flat_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function land_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and land='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and land='1'  GROUP BY city");

        return view('client.land_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function rent_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' GROUP BY city");
        //$sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and plot='1'  GROUP BY city");
        

        return view('client.rent_list_view', compact('rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function sale_list()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        //$rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and plot='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' GROUP BY city");

        return view('client.sale_list_view', compact('sale') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function office_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and offices='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and offices='1'  GROUP BY city");

        return view('client.office_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function hot_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $rent = DB::select("SELECT COUNT(pk_id) as count, city from property where rent = '1' and property_type='1' GROUP BY city");
        $sale = DB::select("SELECT COUNT(pk_id) as count, city from property where sale = '1' and property_type='1'  GROUP BY city");

        return view('client.hot_list_view', compact('sale', 'rent') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function realtor_add_property_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'realtor'))
        {
            return redirect('/');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.add_property_view', compact('products') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }
    public function realtor_add_property(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'realtor'))
        {
            return redirect('/');
        }
        $user_id = session()->get('pk_id');
        if ($request->input('features'))
        {
            $features = $request->input('features');

            $final_size = "";
            foreach ($features as $sizes)
            {
                $final_size = $final_size . $sizes . ',';
            }

            $final_features = rtrim($final_size, ',');
        }
        else
        {
            $final_features = "";
        }
        $rent = 0;
        $sale = 0;
        $home = 0;
        $plot = 0;
        $commercial = 0;
        $land = 0;
        $flat = 0;
        $office = 0;

        if ($request->input('rent'))
        {
            $rent = 1;
        }
        if ($request->input('sale'))
        {
            $sale = 1;
        }

        if ($request->input('home'))
        {
            $home = 1;
        }
        if ($request->input('plot'))
        {
            $plot = 1;
        }
        if ($request->input('commercial'))
        {
            $commercial = 1;
        }
        if ($request->input('land'))
        {
            $land = 1;
        }
        if ($request->input('flat'))
        {
            $flat = 1;
        }
        if ($request->input('office'))
        {
            $office = 1;
        }
        $uniqueFile = "";
        if ($_FILES["document_file"]["name"])
        {
            $image = $request->file('document_file');
            $uniqueFile = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();

            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());

            $image->storeAs('public/images', $uniqueFile);
        }

        $document_file = $uniqueFile;

        $payment_plan = "";
        if ($request->hasFile('payment_plan'))
        {
            $image = $request->file('payment_plan');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $payment_plan = $uniqueFileName;
        }

        $images = [];

        if ($files = $request->file('file'))
        {
            foreach ($files as $image)
            {
                $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
                $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
                $image->storeAs('public/images', $uniqueFileName);

                $images[] = $uniqueFileName;
            }
        }

        $final_images = "";
        foreach ($images as $sizes)
        {
            $final_images = $final_images . $sizes . ',';
        }

        $final_images = rtrim($final_images, ',');

        $property_type = 0;
        DB::insert("insert into property (user_id,rent,sale,home,plots,commercial,land,flats,offices,city,location,area,unit,price,property_title,description,document_file,payment_plan_image,features,expiry_date,thumbnail,property_type) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
            $user_id,
            $rent,
            $sale,
            $home,
            $plot,
            $commercial,
            $land,
            $flat,
            $office,
            $request->input('city') ,
            $request->input('location') ,
            $request->input('area') ,
            $request->input('unit') ,
            $request->input('price') ,
            $request->input('title') ,
            $request->input('description') ,
            $document_file,
            $payment_plan,
            $final_features,
            $request->input('expiry_date') ,
            $final_images,
            $property_type
        ));
        return redirect('/properties');
    }

    public function agent_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $result = DB::select("select* from realtor_signin where status = '1'");

        return view('client.agent_list_view', compact('products', 'result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function seller_list_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $result = DB::select("select* from client_details,vendors where client_details.pk_id = vendors.user_id and vendors.vendor_status= '0' and client_details.customer_type = 'seller'");
        
        return view('client.seller_list_view', compact('products', 'result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function seller_detail_view($id)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $result = DB::select("select* from client_details,vendors where  client_details.pk_id = vendors.user_id and client_details.pk_id='$id'  and client_details.customer_type = 'seller'");

        
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        
        if($customer_type == "buyer"){
        
        $pro = DB::select("select * from product where
           vendor_id ='$id' and v_product_status = '2'and status = '1' 
           and ((account_t = 'Individual' or vendor_cat ='Retailer') or (account_t = 'NULL' or vendor_cat ='NULL')) and
            discount_status ='0'");
        }
        
        
        elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){

           $pro = DB::select("select * from product where
            vendor_id ='$id' and v_product_status = '2' and status = '1' and (account_t = 'Business' or vendor_cat ='Wholeseller')and
            discount_status ='0'");
            
        }

        elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){

            $pro = DB::select("select * from product where
            vendor_id ='$id' and v_product_status = '2' and status = '1' and (account_t = 'Business' or vendor_cat ='Manufacture') and
            discount_status ='0'");
}
        else{
            
            $pro = DB::select("select * from product where
            status = '1' and vendor_id ='$id' and v_product_status = '2' and 
            ((account_t = 'Individual' or vendor_cat ='Retailer') or (account_t = 'NULL' or vendor_cat ='NULL')) and
            discount_status ='0'");
            
        }


        return view('client.seller_detail', compact('products', 'result', 'pro') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function sell_on()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        return view('client.sell_on', compact('products') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }
    public function advertise_with_us()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        return view('client.advertise_with_us', compact('products') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }
    public function message_compose(Request $request)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $seller_name = $request->input('seller_name');
        $message = $request->input('message');
        $pk_id = Session::get('pk_id');
        DB::insert("insert into message (seller_name,customer_name,message) values (?,?,?)", array(
            $seller_name,
            $pk_id,
            $message
        ));

        return redirect('/client/send/message');

    }

    public function add_review(Request $request, $id)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $rating = $request->input('rating');
        $comment = $request->input('comment');
        $result = DB::select("select* from product where pk_id = $id");
        $vendor_id = $result[0]->vendor_id;

        $username = Session::get('pk_id');
        DB::insert("insert into review_table (product_id,user_id,vendor_id,rating,comment ) values (?,?,?,?,?)", array(
            $id,
            $username,
            $vendor_id,
            $rating,
            $comment
        ));

        return Redirect::back();

    }
    public function guest_order_tracking_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        return view('client.guest_order_tracking_view', compact('products'));

    }

    public function payment_list_view($id)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $result = DB::select("select* from payment where user_id = '$id' order by pk_id DESC");

        return view('client.payment_list_view', compact('products', 'result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function search_payment_by_id(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $user_id = session()->get('pk_id');

        $search = $request->input('search');
        $result = DB::select("select* from payment where invoice_no = '$search' and user_id = '$user_id'");
        if (count($result) > 0) return view('client.payment_list_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        else return view('client.payment_list_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart
            ->totalPrice])
            ->withErrors('No Invoice Exist');
    }

    public function search_payment_by_status(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $user_id = session()->get('pk_id');

        $status = $request->input('status');
        $start_date = $request->input('start_date');
        $end_date = $request->input('end_date');

        if (empty($status) && empty($start_date) && empty($end_date))
        {
            $result = DB::select("select* from payment where user_id = '$user_id'");

        }
        else if (empty($start_date) && empty($end_date))
        {

            $result = DB::select("select* from payment where status = '$status' and user_id = '$user_id'");

        }
        else if (empty($status) && empty($end_date))
        {

            $result = DB::select("select* from payment where  user_id = '$user_id' and (date < '$end_date' or date = '$end_date')  ");

        }

        else if (empty($status) && empty($start_date))
        {

            $result = DB::select("select* from payment where  user_id = '$user_id' and (date > '$start_date' or date = '$start_date')");

        }
        else if (empty($status))
        {

            $result = DB::select("select* from payment where  user_id = '$user_id' and (date > '$start_date' or date = '$start_date') and (date < '$end_date' or date = '$end_date')");

        }
        else if (empty($start_date))
        {

            $result = DB::select("select* from payment where  user_id = '$user_id' and status= '$status' and (date < '$end_date' or date = '$end_date')");

        }
        else if (empty($end_date))
        {

            $result = DB::select("select* from payment where  user_id = '$user_id' and status= '$status'");

        }
        else
        {
            $result = DB::select("select* from payment where  user_id = '$user_id' and  status= and '$status' (date > '$start_date' or date = '$start_date') and (date < '$end_date' or date = '$end_date')");
        }

        if (count($result) > 0) return view('client.payment_list_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        else return view('client.payment_list_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart
            ->totalPrice])
            ->withErrors('No Invoice Exist');
    }

    public function blog_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $result = DB::select("select* from blog_post ");

        return view('client.blog', compact('products', 'result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function order_tracking_view()
    {
    
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $username = Session::get('username');

        $ordertracking = DB::select("select* from client_details where username = '$username' ");
        $user = $ordertracking[0]->pk_id;

        $orderdetail = DB::select("select* from order_table where user_id = '$user' ");
        
        date_default_timezone_set("Asia/Karachi");
        $time = now()->toDateString();
        $duration = Carbon::now()->toTimeString();
        $button = DB::select("select* from order_table where username = '$username' and expire_at > '$time'");
        
        return view('client.order_id', compact('products', 'orderdetail','button','duration') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function order_tracking_detail_view($id)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $username = Session::get('username');
        $user = DB::select("select* from client_details where username = '$username' ");
        
        $user = $user[0]->pk_id;

        $ordertracking = DB::select("select* from order_table where pk_id ='$id' and user_id = '$user'");

        $address = $ordertracking[0]->shipment_address_id;
        $ad = DB::select("select* from address_table where pk_id = '$address' ");

        $orderdetail = DB::select("select* from detail_table where  order_id ='$id'");

        if (count($ordertracking) > 0)
        {

        return view('client.view_order_tracking', compact('products', 'ordertracking', 'orderdetail', 'ad') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        
        }
        else
        {
            return Redirect::back()
            ->withErrors('No Order Exist');
        }

    }

    public function order_tracking(Request $request)
    {

        $address = 0;
        $ad = 0;
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $orderid = $request->input('orderid');
        $username = Session::get('username');
        $user = DB::select("select* from client_details where username = '$username' ");
        $user = $user[0]->pk_id;

        $ordertracking = DB::select("select* from order_table where tracking_id ='$orderid' and user_id = '$user'");
        
        
        if (count($ordertracking) > 0)
        {
            $address = $ordertracking[0]->shipment_address_id;
            $pk_id = $ordertracking[0]->pk_id;
            $ad = DB::select("select* from address_table where pk_id = '$address' ");
            $orderdetail = DB::select("select* from detail_table where  order_id ='$pk_id'");
        }


        if (count($ordertracking) > 0)
        {
        return view('client.view_order_tracking', compact('products', 'ordertracking', 'orderdetail', 'ad') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }
        else {
        
        return Redirect::back()
            ->withErrors('No Order Exist');
        }

    }

    public function guest_order_tracking(Request $request)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $email = $request->input('email');
        $orderid = $request->input('orderid');
        $ordertracking = DB::select("select* from order_table where username = '$email' and pk_id ='$orderid'");

        $orderdetail = DB::select("select* from detail_table where  order_id ='$orderid'");

        if (count($ordertracking) > 0)

        return view('client.order_detail_view', compact('products', 'ordertracking', 'orderdetail'));
        else return Redirect::back()->withErrors('No Order Exist');

    }

    public function verify_code($username, $code)
    {
        $result = DB::select("select* from reset_password where username= '$username' and verification_code= '$code' and TIMESTAMPDIFF(MINUTE,reset_password.created_at,NOW()) <=30 ");

        if (count($result) > 0)
        {
            return view('client.change_password', compact('username'));
        }
        else return "The Verification code is expired";
    }

    public function reset_password_view()
    {

        return view('client.password_reset');

    }

    public function reset_password(Request $request)
    {

        $username = $request->input('username');
        $result = DB::select("select* from client_details where username = '$username'");
        if (count($result) > 0)
        {
            $vcode = uniqid();
            DB::insert("insert into reset_password (username,verification_code) values('$username','$vcode') ");
            $customer_name = $result[0]->{'fname'};
            $data = array(
                'customer_name' => $customer_name,
                'customer_username' => $username,
                'customer_verification_code' => $vcode,

            );
            Mail::send('email_reset_password', $data, function ($message) use ($username)
            {

                $message->from('no-reply@fashionfactory.world', 'Fashion Factory');

                $message->to($username)->subject('Password Reset Confirmation Link');

            });
            return redirect()
                ->back()
                ->with('message', 'A Password reset link sent to your email');
        }
        else
        {
            return Redirect::back()
                ->withErrors('Username not found');
        }

    }

    public function password_change(Request $request, $username)
    {
        $password = md5($request->input('password'));
        DB::update("update client_details set password ='$password' where username='$username'");
        return redirect('/login')->with('message', 'Your Password has been changed Successfully');
    }
    public function searchByCategory($main, $sub)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $a = "1";
        $b = "2";
        $c = "0";
        $f = "0";
        $d="Individual";
        $e="Retailer";
        $g="";
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $result = [];
        $d = [];

        $a = "1";
        $b = "2";
        $c = "0";
        $f = "0";
        $d="Individual";
        $e="Retailer";
        $g="";
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        if($customer_type == "buyer"){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.category = :value and product.status = :value2 and product.discount_status = :value3 and (product.v_product_status = :value4 or product.v_product_status = :value5) or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $main,
            'value5' => $f,

        ));
    }elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.category = :value and product.status = :value2 and product.discount_status = :value3 and (product.v_product_status = :value4 or product.v_product_status = :value5) and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $main,
            'value5' => $f,

        ));

    }elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.category = :value and product.status = :value2 and product.discount_status = :value3 and (product.v_product_status = :value4 or product.v_product_status = :value5) and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $main,
            'value5' => $f,

        ));

    }
    
    else{
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.category = :value and product.status = :value2 and (product.v_product_status = :value4 or product.v_product_status = :value5) and product.discount_status = :value3 or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $main,
            'value5' => $f,
        ));


    }
    


        $main_category = DB::select("select* from sub_category where main_category = '$main' and sub_category != '$sub' limit 4");
        $material = DB::select("select* from material ");
        $brand = DB::select("select* from brand ");
        $style = DB::select("select* from style ");
        return view('client.product_list', compact('result', 'd', 'main', 'sub', 'main_category','material' ,'brand','style') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function sub_category($main = '')
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        $main_category = DB::select("select* from sub_category where main_category = '$main'");
        $category = DB::select("select* from main_category where main_category !='$main'");

        return view('client.product_view', compact('main_category', 'main', 'category') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function shop_view()
    {


        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        $main_category = DB::select("select* from main_category where username = 'admin'");
        $kitchen = DB::select("select * from sub_category where main_category ='Kitchen and Dining' limit 6");
        $bath = DB::select("select * from sub_category where main_category ='Bath' limit 6");
        $bed = DB::select("select * from sub_category where main_category = 'Bedroom' limit 6 ");
        $living = DB::select("select * from sub_category where main_category = 'Living' limit 6");
        $lighting = DB::select("select * from sub_category where main_category ='Lighting' limit 6 ");
        $furniture = DB::select("select * from sub_category where main_category = 'Furniture'  limit 6");
        $decore = DB::select("select * from sub_category where main_category = 'Home Decor' limit 6 ");
        $outdoor = DB::select("select * from sub_category where main_category = 'Outdoor' limit 6");
        $slider = DB::select("select * from slider order by pk_id DESC");
        return view('client.shop_view', compact('main_category', 'kitchen','bath', 'bed', 'living', 'lighting', 'furniture', 'decore', 'outdoor', 'slider') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function partner_view()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        return view('client.partner', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function partner_detail()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        return view('client.partner_detail', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function sub_category_view()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        $sub_category = DB::select("select* from sub_category where username = 'admin'");

        return view('client.sub_category', compact('sub_category') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }



    public function sale_view()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        // $d = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from product,discount_table where product.sku = discount_table.sku and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0')");

        
        $sale_category = DB::select("select MAX(discount_table.percentage),discount_table.main_category
         from discount_table,main_category where  (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') GROUP BY discount_table.main_category");
        
        
        
        //  return $sale_category;
         
        //  $main_category = $sale_category[0]->main_category;
         

        // //  return  $main_category;

        //  $image = DB::select("select thumbnail from main_category where main_category = '$main_category'");

        //  return $image;

        $main_category = DB::select("select* from main_category where username = 'admin'");
        $slider = DB::select("select * from slider order by pk_id DESC");
        return view('client.sale_view', compact('sale_category','main_category','slider') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function sale_product($main)

    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

$customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');

// return $customer_type;
if($customer_type == "buyer"){
        
        $d = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
        product,discount_table where product.sku = discount_table.sku and 
        ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) and 
        (discount_table.start_date < '$date' or discount_table.start_date = '$date') and 
        (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
        product.status = '1' and 
        (product.v_product_status = '2' or product.v_product_status = '0') and
        product.category = '$main'");

        }
        elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){

            
             $d = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
             product,discount_table where product.sku = discount_table.sku and 
             (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') and  
             (discount_table.start_date < '$date' or discount_table.start_date = '$date') and 
             (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
             product.status = '1' and 
             (product.v_product_status = '2' or product.v_product_status = '0') and
             product.category = '$main'");
}

        elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){

            $d = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
            product,discount_table where product.sku = discount_table.sku and 
            (product.account_t = 'Business' and product.vendor_cat ='Manufacture') and 
            (discount_table.start_date < '$date' or discount_table.start_date = '$date') and 
            (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
            product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') 
            and product.category = '$main'");
}
        else{
            $d = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku,
            discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
            product,discount_table where product.sku = discount_table.sku  and  
            (discount_table.start_date < '$date' or discount_table.start_date = '$date') and
            (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
            product.status = '1' and 
            (product.v_product_status = '2' or product.v_product_status = '0') and 
            
            product.category = '$main' or
            
            ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') and (product.account_t = 'NULL' or product.vendor_cat ='NULL'))
            ");
            

            
        }
        $material = DB::select("select* from material ");
        $brand = DB::select("select* from brand ");
        $style = DB::select("select* from style ");
        
        return view('client.sale_product_view', compact('d','material','brand','style') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);


    }

    public function home_view()
    {

        if ((session()
            ->has('username') && session()
            ->get('type') == 'admin'))
        {
            return redirect('/admin/home');
        }
        elseif ((session()
            ->has('username') && session()
            ->get('type') == 'vendor'))
        {
            return redirect('/vendor/home');
        }
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $result = [];
        $result1 = [];
        $result2 = [];
        $result3 = [];
$customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        
if($customer_type == "buyer"){
        
        $res = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = 'NULL' or product.vendor_cat ='NULL')) and
            ( product.v_product_status = '2' or product.v_product_status = '0') and
            product.discount_status ='0' and hot_product ='0' LIMIT 10");
            
        $hot = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = 'NULL' or product.vendor_cat ='NULL')) and
            ( product.v_product_status = '2' or product.v_product_status = '0') and
            product.discount_status ='0' and hot_product ='1' LIMIT 10");
            
        $dis = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
        product,discount_table where product.sku = discount_table.sku and 
        (discount_table.start_date < '$date' or discount_table.start_date = '$date') and 
        (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
        product.status = '1' and 
        (product.v_product_status = '2' or product.v_product_status = '0')
        OR 
        ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) LIMIT 10");

        }
        
        
        elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){

            $res = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and (product.account_t = 'Business' or product.vendor_cat ='Wholeseller') and
            ( product.v_product_status = '2' or product.v_product_status = '0') and
            product.discount_status ='0' and hot_product ='0' LIMIT 10");
            
            $hot = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and (product.account_t = 'Business' or product.vendor_cat ='Wholeseller') and
            ( product.v_product_status = '2' or product.v_product_status = '0') and
            product.discount_status ='0' and hot_product ='1' LIMIT 10");
            
            
             $dis = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
             product,discount_table where product.sku = discount_table.sku and 
             (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') and  
             (discount_table.start_date < '$date' or discount_table.start_date = '$date') and 
             (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
             product.status = '1' and 
             (product.v_product_status = '2' or product.v_product_status = '0') LIMIT 10");
}

        elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){

            $res = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and (product.account_t = 'Business' or product.vendor_cat ='Manufacture') and
            ( product.v_product_status = '2' or product.v_product_status = '0') and
            product.discount_status ='0' and hot_product ='0' LIMIT 10");
            
            $hot = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and (product.account_t = 'Business' or product.vendor_cat ='Manufacture') and
            ( product.v_product_status = '2' or product.v_product_status = '0') and
            product.discount_status ='0' and hot_product ='1' LIMIT 10");


            $dis = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku, discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
            product,discount_table where product.sku = discount_table.sku and 
            (product.account_t = 'Business' and product.vendor_cat ='Manufacture') and 
            (discount_table.start_date < '$date' or discount_table.start_date = '$date') and 
            (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
            product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') LIMIT 10");
}
        else{
            
            $res = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1'and (product.v_product_status = '2' or product.v_product_status = '0') and product.discount_status ='0' and hot_product ='0' or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = 'NULL' or product.vendor_cat ='NULL')) LIMIT 10");
            
            $hot = DB::select("select product.pk_id,product.thumbnail,product.name,product.sku,product.price from product where
            product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') and product.discount_status ='0' and hot_product ='1'  and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = 'NULL' or product.vendor_cat ='NULL')) LIMIT 10");

            
            $dis = DB::select("select product.pk_id,product.thumbnail,product.name, product.product_type,product.price,product.description,product.sku,
            discount_table.sku,discount_table.start_date,discount_table.end_date,discount_table.percentage from 
            product,discount_table where product.sku = discount_table.sku and  
            (discount_table.start_date < '$date' or discount_table.start_date = '$date') and
            (discount_table.end_date > '$date' or discount_table.end_date = '$date') and 
            product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') and (product.account_t = 'NULL' or product.vendor_cat ='NULL')) LIMIT 10");

            
        }
        
        

        $slider = DB::select("select* from slider ORDER BY pk_id DESC");
        return view('client.client_home', compact( 'dis','slider', 'res','hot') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function payment_policy()
    {

        return view('client.payment_policy');
    }

    public function create_client_view(Request $request)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.signin_1', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function create_signin_2_view(Request $request)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $request->session()
            ->put('fname', $request->input('fname'));

        $request->session()
            ->put('lname', $request->input('lname'));
        $request->session()
            ->put('username1', $request->input('username'));

        $username = $request->input('username');
        $result = DB::select("select* from client_details where username = '$username' ");

        if (count($result) > 0)
        {
            return Redirect::back()->withErrors('Username already Exist');
        }

        return view('client.signin_2', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function seller_basic_info(Request $request)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $request->session()
            ->put('business_name', $request->input('business_name'));
            $request->session()
            ->put('intro', $request->input('intro'));
            $request->session()
            ->put('vendor_cat', $request->input('vendor_cat'));
        $request->session()
            ->put('address', $request->input('address'));
        $request->session()
            ->put('zip', $request->input('zip'));
        $request->session()
            ->put('country', $request->input('country'));
        $request->session()
            ->put('state', $request->input('state'));
        $request->session()
            ->put('city', $request->input('city'));
        $request->session()
            ->put('phone', $request->input('phone'));
        $request->session()
            ->put('fax', $request->input('fax'));
        $request->session()
            ->put('url', $request->input('url'));

        $request->session()
        ->put('account_t', $request->input('account_t'));
        
        $request->session()
        ->put('p_package', $request->input('p_package'));

        $request->session()
        ->put('cnic', $request->input('cnic'));

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $certificate = "";
        if ($request->hasFile('certificate'))
        {
            $image = $request->file('certificate');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $certificate = $uniqueFileName;
        }

        $request->session()
            ->put('thumbnail', $thumbnail);
        $request->session()
        ->put('certificate', $certificate);

        return view('client.seller_detail_info', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function seller_detail_info(Request $request)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        
        $fname = session()->get('fname');
        $lname = session()->get('lname');
        $username = session()->get('username');
        $password = session()->get('password');
        $business_name = session()->get('business_name');
        $intro = session()->get('intro');
        $customer_type = session()->get('customer_type');
        $vendor_cat = session()->get('vendor_cat');
        $address = session()->get('address');
        $country = session()->get('country');
        $state = session()->get('state');
        $city = session()->get('city');
        $zip = session()->get('zip');
        $phone = session()->get('phone');
        $fax = session()->get('fax');

        $url = session()->get('url');
        $account_t = session()->get('account_t');
        $cnic = session()->get('cnic');
        $thumbnail = session()->get('thumbnail');
        $certificate = session()->get('certificate');
        $p_package = session()->get('p_package');

        $federal_tax = $request->input('federal_tax');
        $primary_contact = $request->input('primary_contact');
        $payee = $request->input('payee');
        $phone1 = $request->input('phone1');
        $fax1 = $request->input('fax1');
        $email1 = $request->input('email1');

        $support_hourz = $request->input('support_hourz');
        $return_country = $request->input('return_country');
        $return_state = $request->input('return_state');
        $return_city = $request->input('return_city');
        $return_zip = $request->input('return_zip');
        $return_phone = $request->input('return_phone');
        $return_fax = $request->input('return_fax');
        $return_address = $request->input('return_address');
        $notification_email = $request->input('notification_email');
        $bank_name = $request->input('bank_name');

        $account_no = $request->input('account_no');
        $account_type = $request->input('account_type');
        $routing_no = $request->input('routing_no');

        $warehouse_address = $request->input('warehouse_address');
        $warehouse_country = $request->input('warehouse_country');
        $warehouse_state = $request->input('warehouse_state');
        $warehouse_city = $request->input('warehouse_city');

        $cheque = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $cheque = $uniqueFileName;
        }

        $slide = "";
        if ($request->hasFile('slide'))
        {
            $image = $request->file('slide');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $slide = $uniqueFileName;
        }
        $slide2 = "";
        if ($request->hasFile('slide2'))
        {
            $image = $request->file('slide2');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $slide2 = $uniqueFileName;
        }

        $slide3 = "";
        if ($request->hasFile('slide3'))
        {
            $image = $request->file('slide3');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);

            $slide3 = $uniqueFileName;
        }

        DB::insert("insert into client_details (fname,lname, username, password,country,customer_type) values (?,?,?,?,?,?)", array(
            $fname,
            $lname,
            $username,
            md5($password) ,
            $country,
            $customer_type
        ));

        
            $pk = DB::select("select* from client_details where username = '$username' ");
            if (count($pk) > 0)

            {
                $user_id = $pk[0]->pk_id;

        DB::insert("insert into vendors (user_id,business_name,intro,account_t,cnic,vendor_cat,certificate,p_package,address,country,state,city,zip,phone,fax,url,thumbnail,federal_tax,primary_contact,payee,phone1,fax1,email1,support_hourz,return_address,return_country,return_state,return_city,return_zip,return_phone,return_fax,notification_email,bank_name,account_no,account_type,routing_no,cheque,warehouse_address,warehouse_country,warehouse_state,warehouse_city,slide,slide2,slide3) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
            $user_id,
            $business_name,
            $intro,
            $account_t,
            $cnic,
            $vendor_cat,
            $certificate,
            $p_package,
            $address,
            $country,
            $state,
            $city,
            $zip,
            $phone,
            $fax,
            $url,
            $thumbnail,
            $federal_tax,
            $primary_contact,
            $payee,
            $phone1,
            $fax1,
            $email1,
            $support_hourz,
            $return_address,
            $return_country,
            $return_state,
            $return_city,
            $return_zip,
            $return_phone,
            $return_fax,
            $notification_email,
            $bank_name,
            $account_no,
            $account_type,
            $routing_no,
            $cheque,
            $warehouse_address,
            $warehouse_country,
            $warehouse_state,
            $warehouse_city,
            $slide,
            $slide2,
            $slide3
        ));
    }
        $type = 'new vendor created';
        $noti_status = 'unread';
        DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
            $user_id,
            $type,
            $noti_status
        ));
        session()->flush();
        return redirect('/vendor/login')
            ->with('message', 'Waiting for admin approval');

    }

    public function create_signin_detail_view(Request $request)
    {

        $oldCart = Session::get('cart');

        $cart = new Cart($oldCart);

        $a = $request->input('customer_type');

        if ($request->input('password') == $request->input('cpassword'))
        {

            $request->session()
                ->put('country', $request->input('country'));

            $request->session()
                ->put('password', $request->input('password'));
            $request->session()
                ->put('customer_type', $request->input('customer_type'));
            if ($request->input('customer_type') == "buyer")
            {
                return view('client.buyer-signin', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
            }
            if ($request->input('customer_type') == "seller")
            {
                return view('client.seller_basic_info', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
            }
            if ($request->input('customer_type') == "realtor")
            {
                return view('client.realtor_signin', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
            }

        }
        else
        {
            return Redirect::back()
                ->withErrors('Password does not match');
        }
    }

    public function realtor_signin(Request $request)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $username = session()->get('username1');
        $fname = session()->get('fname');
        $lname = session()->get('lname');
        $password = session()->get('password');
        $country = session()->get('country');
        $customer_type = session()->get('customer_type');

        $status = 0;
        if ($request->input('agent'))
        {
            $status = 1;
        }

        $phone = $request->input('phone');
        $city = $request->input('city');
        $deal_city = $request->input('deal_city');
        $agency_name = $request->input('agency_name');
        $description = $request->input('description');
        $agency_phone = $request->input('agency_phone');
        $fax = $request->input('fax');
        $address = $request->input('address');
        $company_email = $request->input('company_email');
        $thumbnail = "";

        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $destinationPath = public_path('/storage/images');
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }

        DB::insert("insert into client_details (fname,lname, username, password,country,customer_type) values (?,?,?,?,?,?)", array(
            $fname,
            $lname,
            $username,
            md5($password) ,
            $country,
            $customer_type
        ));
        $result = DB::select("select* from client_details where username = '$username' ");

        if (count($result) > 0)
        {
            $user_id = $result[0]->pk_id;

            DB::insert("insert into realtor_signin(user_id,phone,city,status,deal_city,agency_name,description,agency_phone,fax,address,company_email,thumbnail) values (?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $user_id,
                $phone,
                $city,
                $status,
                $deal_city,
                $agency_name,
                $description,
                $agency_phone,
                $fax,
                $address,
                $company_email,
                $thumbnail
            ));
            $type = 'new realtor created';
            $noti_status = 'unread';
            DB::insert("insert into notification (vendor_id,type,status) values (?,?,?)", array(
                $user_id,
                $type,
                $noti_status
            ));

        }

        return redirect('/login');

    }

    public function add_payment_view()
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.add_payment_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function add_payment(Request $request)
    {

        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $thumbnail = "";
        if ($request->hasFile('file'))
        {
            $image = $request->file('file');
            $uniqueFileName = uniqid() . $image->getClientOriginalName() . '.' . $image->getClientOriginalExtension();
            $input['imagename'] = time() . '.' . strtolower($image->getClientOriginalExtension());
            $image->storeAs('public/images', $uniqueFileName);
            $thumbnail = $uniqueFileName;
        }
        $user_id = session()->get('pk_id');
        DB::insert("insert into payment (user_id,invoice_no,thumbnail,payee,payer,date,amount) values (?,?,?,?,?,?,?)", array(
            $user_id,
            $request->input('invoice_no') ,
            $thumbnail,
            $request->input('payee') ,
            $request->input('payer') ,
            $request->input('date') ,
            $request->input('amount')
        ));
        $result = DB::select("select* from payment where user_id = '$user_id' order by pk_id DESC");

        return view('client.payment_list_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function create_client(Request $request)
    {

        $username = session()->get('username1');
        $fname = session()->get('fname');
        $lname = session()->get('lname');
        $password = session()->get('password');
        $country = session()->get('country');
        $customer_type = session()->get('customer_type');

        $phone = $request->input('phone');
        $zip = $request->input('zip');
        $age = $request->input('age');
        $gender = $request->input('gender');
        DB::insert("insert into client_details (fname,lname, username, password,country,customer_type) values (?,?,?,?,?,?)", array(
            $fname,
            $lname,
            $username,
            md5($password) ,
            $country,
            $customer_type
        ));
        $result = DB::select("select* from client_details where username = '$username' ");

        if (count($result) > 0)
        {
            $user_id = $result[0]->pk_id;
            DB::insert("insert into buyer (user_id,phone,zip,age,gender) values (?,?,?,?,?)", array(
                $user_id,
                $phone,
                $zip,
                $age,
                $gender
            ));

        }

        return redirect('/login');
    }

    public function create_account(Request $request)
    {
        $username = $request->input('username');
        $fname = $request->input('fname');
        $lname = $request->input('lname');
        $password = $request->input('password');
        $country = $request->input('country');
        $customer_type = $request->input('customer_type');

        $phone = $request->input('phone');
        $zip = $request->input('zip');
        $age = $request->input('age');
        $gender = $request->input('gender');

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        if ($request->input('customer_type') == "buyer")
        {
            if ($request->input('password') == $request->input('cpassword'))
            {
                $username = $request->input('username');

                $result = DB::select("select* from client_details where username = '$username' ");

                if (count($result) > 0)
                {
                    return Redirect::back()->withErrors('Username already Exist');
                }
                else
                {

                    DB::insert("insert into client_details (fname,lname, username, password,country,customer_type) values (?,?,?,?,?,?)", array(
                        $fname,
                        $lname,
                        $username,
                        md5($password) ,
                        $country,
                        $customer_type
                    ));

                    
                        $pk = DB::select("select* from client_details where username = '$username' ");
                        if (count($pk) > 0)

                        {
                            $user_id = $pk[0]->pk_id;
                            DB::insert("insert into buyer (user_id,phone,zip,age,gender) values (?,?,?,?,?)", array(
                                $user_id,
                                $phone,
                                $zip,
                                $age,
                                $gender
                            ));

                        }
                        $username = $request->input('username');
                        $password = md5($request->input('password'));
                        $result = DB::select("select* from client_details where username = '$username' and password='$password' ");

                        if (count($result) > 0)
                        {
                            $request->session()
                                ->put('pk_id', $result[0]->{'pk_id'});
                            $request->session()
                                ->put('username', $username);
                            $request->session()
                                ->put('type', 'client');
                            $request->session()
                                ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                            $request->session()
                                ->put('fname', $result[0]->{'fname'});
                            $request->session()
                                ->put('lname', $result[0]->{'lname'});
                            return Redirect::to('/');
                        }

                    
                    

                }
            }
            else
            {
                return view('client.signin_1', ['products' => $cart->items, 'totalPrice' => $cart
                    ->totalPrice])
                    ->withErrors('username or password incorrect');
            }
        }
        elseif ($request->input('customer_type') == "seller")
            {
                if ($request->input('password') == $request->input('cpassword'))
                {
                    $username = $request->input('username');

                    $result = DB::select("select* from client_details where username = '$username' ");

                    if (count($result) > 0)
                    {
                        return Redirect::back()->withErrors('Username already Exist');
                    }
                    else
                    {
                        $request->session()
                ->put('fname', $request->input('fname'));
                $request->session()
                ->put('lname', $request->input('lname'));
                
                $request->session()
                ->put('username', $request->input('username'));
                $request->session()
                ->put('password', $request->input('password'));
                
                $request->session()
                ->put('customer_type', $request->input('customer_type'));
                        return view('client.seller_basic_info', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
                    }
                }
                else
            {
                return view('client.signin_1', ['products' => $cart->items, 'totalPrice' => $cart
                    ->totalPrice])
                    ->withErrors('username or password incorrect');
            }
                    

            }
    }

    public function about_us()
    {

        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.about_us', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function accounts()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.accounts', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function faq()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.faq', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function returns()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.returns_and_refunds', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function privacy_policy()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.privacy_policy', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function terms()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.terms_and_conditions', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function client_login_view()
    {

        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.login', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function collection_view()
    {
        $main_category = DB::select("select* from main_category where username = 'admin'");
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $result = DB::select("select* from collection");
        return view('client.collection_list', compact('main_category', 'result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function collection_detail_view($pk_id)
    {
        $main_category = DB::select("select* from main_category where username = 'admin'");
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $result = DB::select("select* from collection,collection_set where collection_set.collection_id = '$pk_id' and collection_set.collection_id = collection.pk_id ");
        return view('client.collection_list_detail', compact('main_category', 'result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function client_login(Request $request)
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $this->validate($request, ['username' => 'required', 'password' => 'required']);
        $username = $request->input('username');
        $password = md5($request->input('password'));
        $result = DB::select("select* from client_details where username = '$username' and password='$password' ");

        if (count($result) > 0)
        {

            if ($result[0]->customer_type == 'realtor')
            {
                $realtor = "realtor";
                $request->session()
                    ->put('pk_id', $result[0]->{'pk_id'});
                $request->session()
                    ->put('username', $username);
                $request->session()
                    ->put('type', $realtor);
                $request->session()
                    ->put('type1', 'realtor');
                $request->session()
                    ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                $request->session()
                    ->put('fname', $result[0]->{'fname'});
                $request->session()
                    ->put('lname', $result[0]->{'lname'});
                return Redirect::to('/');

            }

            elseif ($result[0]->customer_type == 'buyer')
            {
                $request->session()
                    ->put('pk_id', $result[0]->{'pk_id'});
                $request->session()
                    ->put('username', $username);
                $request->session()
                    ->put('type', 'client');
                $request->session()
                    ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                $request->session()
                    ->put('fname', $result[0]->{'fname'});
                $request->session()
                    ->put('lname', $result[0]->{'lname'});

                    return redirect()->back();
                // return Redirect::to('/');
            }

            elseif ($result[0]->customer_type == 'seller')
            {

                $request->session()
                    ->put('pk_id', $result[0]->{'pk_id'});
                $request->session()
                    ->put('username', $username);
                $request->session()
                    ->put('type', 'client');
                $request->session()
                    ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                $request->session()
                    ->put('fname', $result[0]->{'fname'});
                $request->session()
                    ->put('lname', $result[0]->{'lname'});
                $user_id=$result[0]->{'pk_id'};

                $result11 = DB::select("select* from vendors where user_id = '$user_id'");

                $request->session()
                    ->put('account_t', $result11[0]->{'account_t'});

                if($result11[0]->account_t == 'Business'){

                    $request->session()
                    ->put('vendor_cat', $result11[0]->{'vendor_cat'});
                }
                
                return Redirect::to('/');
            }

        }
        else
        {

            return view('client.login', ['products' => $cart->items, 'totalPrice' => $cart
                ->totalPrice])
                ->withErrors('username or password incorrect');
        }

    }

    public function search_wishlist()
    {

        return view('client.search_wishlist_view');

    }

    public function search_wishlist_by_username(Request $request)
    {

        $username = $request->input('username');

        $result = DB::select("select* from wishlist,product where wishlist.user_id = '$username' and wishlist.product_id=product.pk_id and product.status='0'");

        if (count($result) > 0)
        {
            return view('client.wishlist_product_view', compact('result'));
        }
        else
        {
            return Redirect::back()->withErrors('No result found');
        }

    }

    public function search_wishlist_by_name(Request $request)
    {

        $fname = $request->input('fname');
        $lname = $request->input('lname');
        $city = $request->input('city');

        $result = DB::select("select* from wishlist,product,address_table where wishlist.product_id=product.pk_id and address_table.fname = '$fname' and address_table.lname = '$lname' and address_table.city = '$city' and product.status='0' ");

        if (count($result) > 0)
        {
            return view('client.wishlist_product_view', compact('result'));
        }

        else
        {
            return Redirect::back()->withErrors('No result found');
        }

    }

    public function view_wishlist(Request $request)
    {

        $username = session()->get('username');

        $result = DB::select("select* from wishlist,product where wishlist.user_id = '$username' and wishlist.product_id=product.pk_id and product.status='0'");

        if (count($result) > 0)
        {
            return view('client.wishlist_product_view', compact('result'));
        }
        else
        {
            return Redirect::back()->withErrors('No result found');
        }

    }

    public function men_collection_view()
    {

        return view('client.men_collection_view');

    }

    public function checkout_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        if (session::has('pk_id'))
        {

            $pk_id = session()->get('pk_id');
            // return $pk_id;
            $result1 = DB::select("select* from address_table where user_id = '$pk_id'");
            if (count($result1) > 0)
            {
                return view('client.client_address_view', compact('result1') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
            }
            else
            {

                return view('client.address_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

            }
        }

        else

        return view('client.login_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function address_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        return view('client.client_address_view');

    }
    public function edit_address_view($id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        $result = DB::select("select* from address_table where pk_id = '$id'");
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        return view('client.edit_address_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function edit_address(Request $request, $id)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }
        $result = DB::select("select* from address_table where pk_id = '$id'");
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        return view('client.edit_address_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function add_address_view()
    {
        if (!(session()
            ->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        return session()
            ->get('id');
        $result1 = DB::select("select* from address_table where user_id = '$id'");
        return view('client.client_address_view', compact('result', 'result1'));

        return view('client.address_view');

    }
    public function add_new_address_view()
    {

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        return view('client.add_address_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }
    public function add_new_address(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        $user_id = session()->get('pk_id');

        DB::insert("insert into address_table (user_id,fname,lname,address, phone,zip,country,state,city) values (?,?,?,?,?,?,?,?,?)", array(
            $user_id,
            $request->input('fname') ,
            $request->input('lname') ,
            $request->input('address') ,
            $request->input('phone') ,
            $request->input('zip') ,
            $request->input('country') ,
            $request->input('state') ,
            $request->input('city')
        ));

        // $result = DB::select("select* from client_details where pk_id = '$user_id'");
        $result1 = DB::select("select* from address_table where user_id = '$user_id'");
        return redirect('/cart/checkout')->with('result1');

        //  return view('client.client_address_view',compact('result1'));
        

        
    }

    public function add_address(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        $id = session()->get('pk_id');

        DB::insert("insert into address_table (user_id,fname,lname,address,phone,zip,country,state,city ) values (?,?,?,?,?,?,?,?,?)", array(
            $id,
            $request->input('fname') ,
            $request->input('lname') ,
            $request->input('address') ,
            $request->input('phone') ,
            $request->input('zip') ,
            $request->input('country') ,
            $request->input('state') ,
            $request->input('city')
        ));

        $result1 = DB::select("select* from address_table where user_id = '$id'");

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.order_view', compact('result1') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function women_handbags_view()
    {

        $result = DB::select("select* from product where category = 'handbags' and status = '1'");

        if (count($result) > 0)
        {
            return view('client.women_handbags_view', compact('result'));
        }

    }

    public function product_detail_view($pk_id, $sku)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $review = DB::select(DB::raw("SELECT * FROM review_table WHERE product_id = :value") , array(
            'value' => $pk_id,
        ));
        $sum = 0;
        $average = 0;
        if (count($review) > 0)
        {
            foreach ($review as $results)
            {
                $sum = $sum + $results->rating;
            }
            $average = $sum / count($review);
        }

        $one = DB::select("select* from review_table where product_id = '$pk_id' and rating = '1'");
        $two = DB::select("select* from review_table where product_id = '$pk_id' and rating = '2'");
        $three = DB::select("select* from review_table where product_id = '$pk_id' and rating = '3'");
        $four = DB::select("select* from review_table where product_id = '$pk_id' and rating = '4'");
        $five = DB::select("select* from review_table where product_id = '$pk_id' and rating = '5'");

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $result = DB::select("select* from product where pk_id = '$pk_id'");
        $sub_category = $result[0]->sub_category;
        $email = $result[0]->vendor_id;

        //  $vendor = DB::select("select* from vendors where email = '$email'");
        

        $result1 = DB::select("select* from product where sku = '$sku'");
        
        
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        
        if($customer_type == "buyer"){
        
        $related = DB::select("select * from product where
            status = '1' and (v_product_status = '2' or v_product_status = '0') and sub_category = '$sub_category' and sku != '$sku' and discount_status ='0' or ((account_t = 'Individual' or vendor_cat ='Retailer') or (account_t = 'NULL' or vendor_cat ='NULL')) 
           LIMIT 4");
        }
        
        
        elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){

           $related = DB::select("select * from product where
            status = '1' and sub_category = '$sub_category' and sku != '$sku' and (account_t = 'Business' or vendor_cat ='Wholeseller') and
            (.v_product_status = '2' or v_product_status = '0') and
            discount_status ='0' LIMIT 4");
            
        }

        elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){

            $related = DB::select("select * from product where
            status = '1' and sub_category = '$sub_category' and sku != '$sku' and (account_t = 'Business' or vendor_cat ='Manufacture') and
            (v_product_status = '2' or v_product_status = '0') and
            discount_status ='0' LIMIT 4");
}
        else{
            
            $related = DB::select("select * from product where
            status = '1' and ( v_product_status = '2' or v_product_status = '0') and 
            sub_category = '$sub_category' and sku != '$sku' and discount_status ='0' or
            ((account_t = 'Individual' or vendor_cat ='Retailer') or (account_t = 'NULL' or vendor_cat ='NULL'))
            LIMIT 4");
            
        }
        
        
        
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and product.pk_id = '$pk_id' and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1'");
// return $d;
        $result3 = DB::table('detail_table')->where('sku', '=', $sku)->sum('quantity');

        if (count($d) > 0)
        {

            $discount = ($d[0]->price * $d[0]->percentage) / 100;

            $discount_price = $d[0]->price - $discount;

        }
        else{

            $discount_price = "0";
            $discount ='0';
        }
        
        
        $array = DB::select("select* from size_detail where product_id = '$pk_id' order by pk_id ASC");
        
        if (count($result) > 0)
        {
            return view('client.product_detail_view', compact('related', 'one', 'two', 'three', 'four', 
            'five', 'result', 'result1', 'array', 'discount_price', 'discount', 'd','result3', 'review', 'average') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }
    public function size_detail(Request $request)
    {

        $type_id = $request->Input('type_id');

        $sub_id = DB::select("select* from size_detail where pk_id = '$type_id' ");
        $sub_id = $sub_id[0]->quantity;

        return Response::json($sub_id);
    }


    public function removeCart($id,  $qty,$delivery_charges)
    {
        // return $delivery_charges
        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);
        // return $qty;
        $cart->remove($id, $qty,$delivery_charges);
        session()->put('cart', $cart);
        return redirect()->back();
    }


  
    


    public function addToCart(Request $request, $pk_id)
    {
        
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $size = $request->input('size');
        $size = DB::select("select* from size_detail where pk_id = '$size'");
        $size = $size[0]->size;

        $q = $request->input('quantity');
        $delivery = $request->input('tab');

     
        
        $result = DB::select("select* from product where pk_id = '$pk_id'");
        $cat = DB::select("select sub_category from product where pk_id = '$pk_id'");
        
        $sub_cat = $cat[0]->sub_category;
        $seller = $result[0]->vendor_id;
        if (empty($result[0]->vendor_id))
        {
            $seller = "COMMISSION";
        }
        else
        {

            $seller = DB::select("select* from client_details where pk_id = '$seller'");
            $seller = $seller[0]->pk_id;
            $seller = DB::select("select* from subscription where vendor_id = '$seller' ORDER BY pk_id DESC");
            if ($seller[0]->subscription == "COMMISSION")
            {
                $seller = "COMMISSION";
            }
            else
            {
                $seller = "SUBSCRIPTION";
            }

        }
// return $sub_cat;


        $oldCart = Session::has('cart') ? Session::get('cart') : null;
        $cart = new Cart($oldCart);
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and product.pk_id = '$pk_id' and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1'");

        if (count($d) > 0)
        {
            if (session::has('promoPrice'))
            {
                session()->forget('promoPrice');
            }
            $cart->discount($d[0], $d[0]->pk_id, $size, $q, $seller, $delivery, $sub_cat);
        }

        else
        {
            if (session::has('promoPrice'))
            {
                session()->forget('promoPrice');
            }
            $cart->add($result[0], $result[0]->pk_id, $size, $q, $seller, $delivery, $sub_cat);
        }

        // $cart->discount($result[0],$result[0]->pk_id);
        session()->put('cart', $cart);
        //dd(Session::get('cart'));
        return redirect()
                ->back()
                ->with("modal_message", "Add to Cart Successfully");

    }
    public function getCart()
    {

        //return session()->flush();
        if (!Session::has('cart'))
        {
            return view('client.cart_view', ['products' => null]);
        }

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
// return   $cart->items;
        return view('client.cart_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice,'totalQty' => $cart->totalQty]);
    }

    public function order_view($id)

    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }
        if (!Session::has('cart'))
        {
            return view('client.order_view', ['products' => null]);
        }

        $user_id = session()->get('pk_id');
        // $result1 = DB::select("select client_details.username,client_details.fname,client_details.lname,address_table.phone,address_table.pk_id,address_table.city,address_table.address from client_details,address_table where client_details.pk_id = '$id'and address_table.user_id = '$id'");
        

        $result = DB::select("select* from client_details where pk_id = '$user_id'");
        $result1 = DB::select("select* from address_table where user_id = '$user_id' and pk_id = '$id'");
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.order_view', compact('result', 'result1') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function login(Request $request)
    {
        $this->validate($request, ['email' => 'required', 'password' => 'required']);
        $username = $request->input('email');
        $password = md5($request->input('password'));
        //  $result = DB::select("select* from client_details where username = '$username' and password='$password' ");
        $result = DB::select("select* from client_details where username = '$username'");

        if (count($result) > 0)
        {

            $pass = $result[0]->password;
            if ($pass == $password)

            {
                $request->session()
                    ->put('pk_id', $result[0]->{'pk_id'});
                $request->session()
                    ->put('username', $username);
                $request->session()
                    ->put('type', 'client');
                $request->session()
                    ->put('name', $result[0]->{'fname'} . ' ' . $result[0]->{'lname'});
                $request->session()
                    ->put('fname', $result[0]->{'fname'});
                $request->session()
                    ->put('lname', $result[0]->{'lname'});
                $id = $result[0]->pk_id;
                session()
                    ->put('id', $id);

                $result1 = DB::select("select client_details.username,client_details.fname,client_details.lname,address_table.phone,address_table.pk_id,address_table.city,address_table.address from client_details,address_table where client_details.pk_id = '$id'and address_table.user_id = '$id'");
                $result2 = DB::select("select* from address_table where user_id = '$id'");
                if (count($result2) > 0)
                {

                    return view('client.client_address_view', compact('result', 'result1'));
                }
                else
                {
                    return view('client.address_view', compact('result'));
                }
            }
            else
            {
                return view('client.client_checkout_view')->withErrors('username or password incorrect');

            }
        }
        else
        {

            return redirect('/signup');
        }

    }
    public function address(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        if (session()
            ->has('id'))
        {
            $username = session()->get('username');

            $result = DB::select("select* from client_details where username = '$username' ");
            if (count($result) > 0)
            {
                $id = $result[0]->pk_id;
                $result = DB::select("select* from address_table where user_id = '$id' ");
                if (count($result) > 0)
                {
                    $fname = $request->input('fname');
                    $lname = $request->input('lname');
                    $phone = $request->input('phone');
                    $city = $request->input('city');
                    $region = $request->input('region');
                    $address = $request->input('address');
                    DB::update("update address_table set fname = '$fname', lname='$lname',phone='$phone',city = '$city', address= '$address', region='$region' where user_id='$id'");
                    return redirect('/cart/checkout/address/view/order');
                }
                else
                {
                    DB::insert("insert into address_table (user_id,fname,lname, address, city, phone, region ) values (?,?,?,?,?,?,?)", array(
                        $id,
                        $request->input('fname') ,
                        $request->input('lname') ,
                        $request->input('address') ,
                        $request->input('city') ,
                        $request->input('phone') ,
                        $request->input('region')
                    ));
                    return redirect('/cart/checkout/address/view/order');
                }
            }
            else
            {
                return redirect('/cart/checkout');

            }

        }

    }

        public function confirm_order(Request $request)
    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }

        $array = json_decode($request->input('prod') , true);
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $time = Carbon::now()->toTimeString();
        $timeafter = Carbon::now()->addHour(3)->toTimeString();
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $username = session()->get('username');
        $tracking_id = rand();

        $pk_id = session()->get('pk_id');
        
        $user_id = session()->get('user_id');
        $result = DB::select("select* from client_details where pk_id = '$pk_id' ");

        
        $result1 = DB::select("select* from address_table where user_id = '$pk_id' and pk_id = '$user_id' ");
        
        $status = 0;
        $v_order_status = 0;
        $s = 0;
        $products = $cart->items;
        // foreach ($array as $product)
        // {
        //     $amount = $amount + $product['price'] + $product['delivery_charges'];
        // }
        if (session::has('promoPrice'))
        {
            $promo = session()->get('promoPrice');
            DB::insert("insert into order_table (tracking_id,user_id,promo_amount,amount, shipment_address_id,fname,lname,status,username,phone,address,city,state,country,zipcode) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $tracking_id,
                $result[0]->pk_id,
                $promo,
                $cart->totalPrice,
                $result1[0]->pk_id,
                $result1[0]->fname,
                $result1[0]->lname,
                $status,
                $result[0]->username,
                $result1[0]->phone,
                $result1[0]->address,
                $result1[0]->city,
                $result1[0]->state,
                $result1[0]->country,
                $result1[0]->zip,

            ));

        }

        else
        {
            DB::insert("insert into order_table (tracking_id,user_id,amount, shipment_address_id,fname,lname,status ,username,phone,address,city,state,country,zipcode) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $tracking_id,
                $result[0]->pk_id,
                $cart->totalPrice,
                $result1[0]->pk_id,
                $result1[0]->fname,
                $result1[0]->lname,
                $status,
                $result[0]->username,
                $result1[0]->phone,
                $result1[0]->address,
                $result1[0]->city,
                $result1[0]->state,
                $result1[0]->country,
                $result1[0]->zip,
            ));
        }

        $result = DB::select("select* from order_table where user_id = '$pk_id' ORDER BY pk_id DESC");
        
        


        foreach ($products as $product)
        {

            $seller = 'seller';
            $seller_id = $product['item']->vendor_id;
            
            if (empty($seller_id))
            {
                $subscription = "NONE";
            }
            else
            {
                $seller_id = DB::select("select* from client_details where pk_id = '$seller_id' and customer_type = '$seller'");
                $sell_id = $seller_id[0]->pk_id;
                $subscription = DB::select("select* from subscription where vendor_id = '$sell_id' ORDER BY pk_id DESC");
                $subscription = $subscription[0]->subscription;
            }
            if ($product['save'] > 0) DB::insert("insert into detail_table (product_id,order_id, sku, product_name, quantity,discount_price,price,percentage,size,vendor_id,v_order_status,v_payment_status,seller_subscription,delivery_charges,delivery_time,time,timeafter ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $product['item']->pk_id,
                $result[0]->pk_id,
                $product['item']->sku,
                $product['item']->name,
                $product['qty'],
                $product['price'],
                $product['item']->price,
                $product['item']->percentage,
                $product['size'],
                $product['item']->vendor_id,
                $v_order_status,
                $s,
                $subscription,
                $product['delivery_charges'],
                $product['delivery_time'],
                $time,
                $timeafter
            ));

            else DB::insert("insert into detail_table (product_id,order_id, sku, product_name, quantity,price,size,vendor_id, v_order_status,v_payment_status,seller_subscription,delivery_charges,delivery_time,time,timeafter ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", array(
                $product['item']->pk_id,
                $result[0]->pk_id,
                $product['item']->sku,
                $product['item']->name,
                $product['qty'],
                $product['item']->price,
                $product['size'],
                $product['item']->vendor_id,
                $v_order_status,
                $s,
                $subscription,
                $product['delivery_charges'],
                $product['delivery_time'],
                $time,
                $timeafter
            ));
            
            
            
            $id = $product['item']->sku;
            $pro_id = DB::select("select pk_id from product where sku = '$id'");
            $prod = $pro_id[0]->pk_id;
            $size = $product['size'];
            $resulting = DB::select("select * from size_detail where product_id = '$prod' and size = '$size'");
            
            $q = $resulting[0]->quantity - $product['qty'];
            
            DB::update("update size_detail set quantity = '$q' where product_id='$prod' and size='$size'");
        
        }
        session()->forget('promoPrice');
        session() ->forget('pro');
        session()->forget('cart');
        
        session()->forget($cart->totalPrice);

        return view('client.thanks_view', compact('result') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }
    
    public function cancel_active_order($id)
    {
       
        if (!(session()->has('type') && session()
        ->get('type') == 'client'))
    {
        return redirect('/login');
    }

    $status = "4";
  
       
        DB::table('order_table')
            ->where('pk_id', $id)
            ->update(['status' => $status ]);
        DB::table('detail_table')
            ->where('order_id', $id)
            ->update(['v_order_status' => $status ]);
       


            $pro_id = DB::select("select product_id from detail_table where order_id = '$id'");
            $prod = $pro_id[0]->product_id;
            $size = DB::select("select size from detail_table where order_id = '$id'");
            $sizee = $size[0]->size;
            $q = DB::select("select quantity from detail_table where order_id = '$id'");
           $qq = $q[0]->quantity;
        
           
            $resulting = DB::select("select * from size_detail where product_id = '$prod' and size = '$sizee'");
            
            $qn = $resulting[0]->quantity + $qq;
            DB::update("update size_detail set quantity = '$qn' where product_id='$prod' and size='$sizee'");

           

            return redirect('/order/tracking/view');

    }
    
    public function order_payment_view($id)

    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }
        session()
            ->put('user_id', $id);
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;

        $commission = "";
        $subscription = "";

        foreach ($products as $product)
        {
            if ($product['package'] == "COMMISSION")
            {
                $commission = "COMMISSION";
            }
            if ($product['package'] == "SUBSCRIPTION")
            {
                $subscription = "SUBSCRIPTION";
            }
        }
        $array = [];
        $vendor_price = 0;
        $result = DB::select("select* from address_table where pk_id = '$id'");

        return view('client.payment_view', compact('result', 'array', 'vendor_price', 'commission', 'subscription') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }

    public function add_promo_code(Request $request, $pk_id, $sub_cat, $price)

    {
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $username = session()->get('username');
        // return $username;
        $promo = $request->input('promo');

        $promoCode_cat = DB::select("select* from promo_code,promo_for where promo_code.promo_code = '$promo' and promo_for.discount_for = '$username' and promo_code.discount_category = '$sub_cat'  and promo_code.status = '0'");
        $promoCodee = DB::select("select* from promo_for,promo_code where promo_code.pk_id=promo_for.promo_id and promo_code.promo_code = '$promo'  and promo_for.discount_for = '$username' and promo_code.discount_category = '0' and promo_code.status = '0'");

        $promoCode_all = DB::select("select* from promo_for,promo_code where promo_code.pk_id=promo_for.promo_id and promo_code.promo_code = '$promo'  and promo_for.discount_for = 'All Customer' and promo_code.discount_category = '0' and promo_code.status = '0'");

        if (count($promoCode_cat) > 0)
        {
            if ($promoCode_cat[0]->discount_type == 'fixed' && $promoCode_cat[0]->discount_for == "$username")
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus != '0'");

                if (count($user) > 0)
                {

                    $price = $price - $promoCode_cat[0]->discount_amount;
                    // return  $price;
                    // DB::update("update client_details set promostatus -= 1 where username='$username'");
                    session()
                        ->put('promoPrice', $price);
                    $value = $cart->totalPrice - Session::get('promoPrice');
                    $ac = $value - $promoCode_cat[0]->discount_amount;
                    $new = $ac + Session::get('promoPrice');
                    session()->put('pro', $new);
                    $use_time = $user[0]->promostatus;
                    $use_timee = $use_time - 1;
                    DB::update("update client_details set promostatus = '$use_timee' where username='$username'");
                    // session()->put('promoPrice', $cart->totalPrice);
                    return redirect()->back();
                }
                else
                {
                    Session::flash('message', 'u have used  more than required  time');
                    return redirect()
                        ->back();

                }
            }

            elseif ($promoCodee[0]->discount_type == 'percentage' && $promoCodee[0]->discount_for == "$username")
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus != '0'");
                if (count($user) > 0)
                {
                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    $pricee = $price - (($price * $promoCodee[0]->discount_amount) / 100);
                    // DB::update("update client_details set promostatus = '1' where username='$username'");
                    //    return $price;
                    

                    session()
                        ->put('promoPrice', $pricee);
                    $value = $cart->totalPrice - Session::get('promoPrice');
                    // return ($pricee * $promoCodee[0]->discount_amount) / 100;
                    $ac = $value - (($price * $promoCodee[0]->discount_amount) / 100);
                    // return $ac;
                    $new = $ac + Session::get('promoPrice');
                    session()->put('pro', $new);
                    $use_time = $user[0]->promostatus;
                    $use_timee = $use_time - 1;
                    DB::update("update client_details set promostatus = '$use_timee' where username='$username'");

                    // session()->put('promoPrice', $cart->totalPrice);
                    return redirect()->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('more than one time');
                }
            }

        }
        elseif (count($promoCodee) > 0)

        {

            // $promoCodee = DB::select("select* from promo_for,promo_code where promo_code.pk_id=promo_for.promo_id and promo_code.promo_code = '$promo'  and promo_for.discount_for = '$username' and promo_code.status = '0'");
            // return $promoCodee;
            // if (count($promoCodee) > 0) {
            if ($promoCodee[0]->discount_type == 'fixed' && $promoCodee[0]->discount_for == "$username")
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus != '0'");
                if (count($user) > 0)
                {
                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    $cart->totalPrice = $cart->totalPrice - $promoCodee[0]->discount_amount;

                    session()
                        ->put('promoPrice', $cart->totalPrice);

                    $use_time = $user[0]->promostatus;
                    $use_timee = $use_time - 1;
                    DB::update("update client_details set promostatus = '$use_timee' where username='$username'");

                    return redirect()->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('In Valid');
                }
            }

            elseif ($promoCodee[0]->discount_type == 'percentage' && $promoCodee[0]->discount_for == "$username")
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus != '0'");
                if (count($user) > 0)
                {
                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    //   $cart->totalPrice;
                    //   return  session()->get('promoPrice');
                    $cart->totalPrice = $cart->totalPrice - (($cart->totalPrice * $promoCodee[0]->discount_amount) / 100);
                    // return $cart->totalPrice;
                    session()
                        ->put('promoPrice', $cart->totalPrice);

                    $use_time = $user[0]->promostatus;
                    $use_timee = $use_time - 1;
                    DB::update("update client_details set promostatus = '$use_timee' where username='$username'");

                    return redirect()->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('In Valid');
                }
            }

        }

        elseif (count($promoCode_all) > 0)
        {

            // $promoCodee = DB::select("select* from promo_for,promo_code where promo_code.pk_id=promo_for.promo_id and promo_code.promo_code = '$promo'  and promo_for.discount_for = '$username' and promo_code.status = '0'");
            // return $promoCodee;
            // if (count($promoCodee) > 0) {
            if ($promoCode_all[0]->discount_type == 'fixed' && $promoCode_all[0]->discount_for == "All Customer")
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus = '0'");
                if (count($user) > 0)
                {
                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    $cart->totalPrice = $cart->totalPrice - $promoCode_all[0]->discount_amount;

                    session()
                        ->put('promoPrice', $cart->totalPrice);
                    DB::update("update client_details set promostatus = '1' where username='$username'");

                    return redirect()->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('In Valid');
                }
            }

            elseif ($promoCode_all[0]->discount_type == 'percentage' && $promoCode_all[0]->discount_for == "All Customer")
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus = '0'");
                if (count($user) > 0)
                {
                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    //   $cart->totalPrice;
                    //   return  session()->get('promoPrice');
                    $cart->totalPrice = $cart->totalPrice - (($cart->totalPrice * $promoCode_all[0]->discount_amount) / 100);
                    // return $cart->totalPrice;
                    session()
                        ->put('promoPrice', $cart->totalPrice);

                    DB::update("update client_details set promostatus = '1' where username='$username'");

                    return redirect()->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('In Valid');
                }
            }

        }
        else
        {
            return Redirect::back()
                ->withErrors('In Valid ha');
        }

        // $cat = DB::select("select discount_category from promo_code ");
        //   return $cat;
        $promoCode = DB::select("select* from promo_code where promo_code = '$promo' and (start_date < '$date' or start_date = '$date') and (end_date > '$date' or end_date = '$date') and min_total <= '$cart->totalPrice' and max_total >= '$cart->totalPrice' and status = '0'");
        // return $promoCode;
        if (count($promoCode) > 0)
        {

            if ($promoCode[0]->discount_type == 'fixed' && $promoCode[0]->discount_for == 'all customers')
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus = '0'");
                if (count($user) > 0)
                {
                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    $cart->totalPrice = $cart->totalPrice - $promoCode[0]->discount_amount;
                    DB::update("update client_details set promostatus = '1' where username='$username'");
                    session()->put('promoPrice', $cart->totalPrice);
                    return redirect()
                        ->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('promocode cannot be used more than one time');
                }
            }

            // ========================= catt
            

            if ($promoCode[0]->discount_type == 'fixed' && $promoCode[0]->discount_for == 'existing customers')
            {
                $user = DB::select("select client_details.username, client_details.pk_id, order_table.user_id from client_details, order_table where client_details.username = '$username' and client_details.promostatus = '0' and client_details.pk_id = order_table.user_id");
                if (count($user) > 0)
                {

                    $cart->totalPrice = $cart->totalPrice - $promoCode[0]->discount_amount;
                    DB::update("update client_details set promostatus = '1' where username='$username'");
                    session()->put('promoPrice', $cart->totalPrice);
                    return redirect()
                        ->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('promocode cannot be used more than one time');
                }
            }
            if ($promoCode[0]->discount_type == 'fixed' && $promoCode[0]->discount_for == 'new customers')
            {
                $user = DB::select("select client_details.username, client_details.pk_id, order_table.user_id from client_details, order_table where client_details.username = '$username' and client_details.promostatus = '0' and client_details.pk_id != order_table.user_id");
                if (count($user) > 0)
                {

                    $cart->totalPrice = $cart->totalPrice - $promoCode[0]->discount_amount;
                    DB::update("update client_details set promostatus = '1' where username='$username'");
                    session()->put('promoPrice', $cart->totalPrice);
                    return redirect()
                        ->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('promocode cannot be used more than one time');
                }
            }

            $promoCodee = DB::select("select* from promo_code where promo_code = '$promo' and discount_for = '$username'  and (start_date < '$date' or start_date = '$date') and (end_date > '$date' or end_date = '$date') and min_total <= '$cart->totalPrice' and max_total >= '$cart->totalPrice' and status = '0'");

            if (count($promoCodee) > 0)
            {
                if ($promoCodee[0]->discount_type == 'percentage' && $promoCodee[0]->discount_for == "$username")
                {
                    $user = DB::select("select* from client_details where username = '$username' and promostatus = '0'");
                    if (count($user) > 0)
                    {
                        //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                        $cart->totalPrice = $cart->totalPrice - (($cart->totalPrice * $promoCode[0]->discount_amount) / 100);
                        DB::update("update client_details set promostatus = '1' where username='$username'");
                        session()->put('promoPrice', $cart->totalPrice);
                        return redirect()
                            ->back();
                    }
                    else
                    {
                        return Redirect::back()
                            ->withErrors('promocode cannot be used more than one time');
                    }
                }
            }
            else
            {
                return Redirect::back()
                    ->withErrors('invalid promocode');
            }

            if ($promoCode[0]->discount_type == 'percentage' && $promoCode[0]->discount_for == 'all customers')
            {
                $user = DB::select("select* from client_details where username = '$username' and promostatus = '0'");
                if (count($user) > 0)
                {
                    $cart->totalPrice = $cart->totalPrice - (($cart->totalPrice * $promoCode[0]->discount_amount) / 100);
                    DB::update("update client_details set promostatus = '1' where username='$username'");
                    session()->put('promoPrice', $cart->totalPrice);
                    return redirect()
                        ->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('promocode cannot be used more than one time');
                }
            }
            if ($promoCode[0]->discount_type == 'percentage' && $promoCode[0]->discount_for == 'existing customers')
            {
                $user = DB::select("select client_details.username, client_details.pk_id, order_table.user_id from client_details, order_table where client_details.username = '$username' and client_details.promostatus = '0' and client_details.pk_id = order_table.user_id");

                if (count($user) > 0)
                {

                    //  $cart->addPromo($cart->totalPrice,$promoCode[0]->discount_amount);
                    // return $cart->totalPrice;
                    $cart->totalPrice = $cart->totalPrice - (($cart->totalPrice * $promoCode[0]->discount_amount) / 100);
                    DB::update("update client_details set promostatus = '1' where username='$username'");
                    session()->put('promoPrice', $cart->totalPrice);
                    return redirect()
                        ->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('promocode cannot be used more than one time');
                }
            }
            if ($promoCode[0]->discount_type == 'percentage' && $promoCode[0]->discount_for == 'new customers')
            {
                $user = DB::select("select client_details.username, client_details.pk_id, order_table.user_id from client_details, order_table where client_details.username = '$username' and client_details.promostatus = '0' and client_details.pk_id != order_table.user_id");
                if (count($user) > 0)
                {

                    $cart->totalPrice = $cart->totalPrice - (($cart->totalPrice * $promoCode[0]->discount_amount) / 100);
                    DB::update("update client_details set promostatus = '1' where username='$username'");
                    session()->put('promoPrice', $cart->totalPrice);
                    return redirect()
                        ->back();
                }
                else
                {
                    return Redirect::back()
                        ->withErrors('promocode cannot be used more than one time');
                }
            }
        }
        else
        {

            return Redirect::back()
                ->withErrors('invalid promocode');
        }
    }

    public function add_wishlist($id)

    {
        if (!(session()->has('type') && session()
            ->get('type') == 'client'))
        {
            return redirect('/login');
        }
        $username = session()->get('username');

        if (!(session()
            ->has('type') && session()
            ->get('type') == 'client'))
        {
            return "login to add wishlist";
        }
        else
        {
            DB::insert("insert into wishlist (user_id,product_id) values (?,?)", array(
                $username,
                $id
            ));

        }

        return redirect()->back();
    }

    public function guest_checkout_view()
    {

        return view('client.guest_checkout_view');
    }

    public function contact_us()
    {
        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.contact_us', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function warranty_and_repairs()
    {

        if ((session()
            ->has('username') && session()
            ->get('type') == 'client'))
        {
            return redirect('/');
        }
        else
        {

            $oldCart = Session::get('cart');
            $cart = new Cart($oldCart);
            return view('client.warranty_and_repairs', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
        }

    }

    public function guest_checkout(Request $request)
    {

        $fname = $request->input('fname');
        $lname = $request->input('lname');
        $email = $request->input('email');
        $phone = $request->input('phone');
        $city = $request->input('city');
        $zip = $request->input('zip');
        $address = $request->input('address');
        $country = $request->input('country');
        $state = $request->input('state');

        if (!empty($request->input('password')))
        {

            if ($request->input('password') == $request->input('confirm'))
            {

                $result = DB::select("select* from client_details where username = '$email'");

                if (count($result) > 0)
                {
                    return Redirect::back()->withErrors('This email is already registered');
                }
                else
                {
                    if (!empty($request->input('email')))
                    {
                        $password = $request->input('password');
                        $confirm = $request->input('confirm');
                        session()
                            ->put('password', $password);
                        session()->put('confirm', $confirm);
                    }
                    else
                    {
                        return Redirect::back()->withErrors('Email is required to create account');
                    }
                }

            }
            else
            {
                return Redirect::back()
                    ->withErrors('Password does not match');
            }

        }

        session()
            ->put('fname', $fname);
        session()->put('lname', $lname);
        session()->put('email', $email);
        session()->put('phone', $phone);
        session()->put('city', $city);
        session()->put('zip', $zip);
        session()->put('address', $address);

        session()->put('country', $country);
        session()->put('state', $state);

        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.guest_order_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function guest_payment_view()
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        return view('client.guest_payment_view', ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);

    }

    public function client_logout()
    {
        session()
            ->flush();
        return redirect('/');
    }

    public function search(Request $request)
    {
        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $word = $request->input('search');
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        
        // return $word;

        if (!empty($word))
        {

            if($customer_type == "buyer"){
            $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and product.status = '1'  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and (product.v_product_status = '2' or product.v_product_status = '0')  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            }
            }
            
            
            elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" )
            {
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and product.status = '1'  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and (product.v_product_status = '2' or product.v_product_status = '0')  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ");

            }

    }
    elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" )
    {
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and product.status = '1'  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and (product.v_product_status = '2' or product.v_product_status = '0')  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' ) and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ");

            }

    }
    
    else{
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' )");
        $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and (product.v_product_status = '2' or product.v_product_status = '0') and product.status = '1'  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' )");
    
            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and (product.v_product_status = '2' or product.v_product_status = '0')  and (product.category LIKE '%$word%' or product.sub_category LIKE '%$word%' or product.product_type LIKE '%$word%' or product.name LIKE '%$word%' )");

            }

    }
        }
        else
        {
            
              
            return "def";
            if($customer_type == "buyer"){
        
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat =''))  ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and ( v_product_status = '2' or v_product_status = '0') and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            }
    }
    elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" )
    {
        
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller')  ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and ( v_product_status = '2' or v_product_status = '0') and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ");

            }

    }
    elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" )
    {
       
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and ( v_product_status = '2' or v_product_status = '0') and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ");

            }

    }
    
    else{
        
        $d = DB::select("select * from product,discount_table where product.sku = discount_table.sku and (discount_table.start_date < '$date' or discount_table.start_date = '$date') and (discount_table.end_date > '$date' or discount_table.end_date = '$date') and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            $result = DB::select("select * from product,discount_table where product.sku != discount_table.sku and product.status = '1' and (product.v_product_status = '2' or product.v_product_status = '0') or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            if (empty($d))
            {

                $result = DB::select("select* from product where status = '1' and ( v_product_status = '2' or v_product_status = '0') or ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ");

            }


    }



        }

        $material = DB::select("select* from material ");
        $brand = DB::select("select* from brand ");
        $style = DB::select("select* from style ");
        return view('client.search_product', compact('result', 'd', 'material' ,'brand','style') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    
    }

    public function guest_confirm_order(Request $request)
    {

        date_default_timezone_set("Asia/Karachi");
        $date = date('Y-m-d');
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);

        $fname = session()->get('fname');
        $lname = session()->get('lname');
        $email = session()->get('email');
        $phone = session()->get('phone');
        $city = session()->get('city');
        $zip = session()->get('zip');
        $address = session()->get('address');

        $country = session()->get('country');
        $state = session()->get('state');
        $status = 0;
        $v_order_status = 0;
        $s = 0;
        $products = $cart->items;
        if (session::has('password'))
        {
            $promostatus = 0;
            $password = session()->get('password');
            DB::insert("insert into client_details (fname,lname,username, password, promostatus) values (?,?,?,?,?)", array(
                $fname,
                $lname,
                $email,
                md5($password) ,
                $promostatus
            ));

            $result1 = DB::select("select* from client_details where username = '$email' ");

            DB::insert("insert into address_table (user_id,fname,lname, address, city, phone, zip,country,state) values (?,?,?,?,?,?,?,?,?)", array(
                $result1[0]->pk_id,
                $fname,
                $lname,
                $address,
                $city,
                $phone,
                $zip,
                $country,
                $state
            ));

            $id = $result1[0]->pk_id;

            $result2 = DB::select("select* from address_table where user_id = '$id' ");

            DB::insert("insert into order_table (user_id,shipment_address_id,fname,lname,amount, status ) values (?,?,?,?,?,?)", array(
                $result1[0]->pk_id,
                $result2[0]->pk_id,
                $fname,
                $lname,
                $cart->totalPrice,
                $status
            ));
            $result = DB::select("select* from order_table where user_id = '$id' ORDER BY pk_id DESC");

            foreach ($products as $product)
            {
                if ($product['save'] > 0) DB::insert("insert into detail_table (product_id,order_id, sku, product_name, quantity,discount_price,price,percentage,size,vendor_id,v_order_status,v_payment_status ) values (?,?,?,?,?,?,?,?,?,?,?,?)", array(
                    $product['item']->pk_id,
                    $result[0]->pk_id,
                    $product['item']->sku,
                    $product['item']->category,
                    $product['qty'],
                    $product['price'],
                    $product['item']->price,
                    $product['item']->percentage,
                    $product['size'],
                    $product['item']->vendor_id,
                    $v_order_status,
                    $s
                ));

                else DB::insert("insert into detail_table (product_id,order_id, sku, product_name, quantity,price,size,vendor_id, v_order_status,v_payment_status ) values (?,?,?,?,?,?,?,?,?,?)", array(
                    $product['item']->pk_id,
                    $result[0]->pk_id,
                    $product['item']->sku,
                    $product['item']->category,
                    $product['qty'],
                    $product['item']->price,
                    $product['size'],
                    $product['item']->vendor_id,
                    $v_order_status,
                    $s
                ));

                $id = $product['item']->pk_id;
                $resulting = DB::select("select quantity_on_hand from product where pk_id = '$id' ");
                $q = $resulting[0]->quantity_on_hand - $product['qty'];
                DB::table('product')->where('pk_id', $id)->update(['quantity_on_hand' => $q]);

            }

        }
        else
        {
            DB::insert("insert into order_table (fname,lname,username, address, city, phone, zipcode,country,state ,amount, status ) values (?,?,?,?,?,?,?,?,?,?,?)", array(
                $fname,
                $lname,
                $email,
                $address,
                $city,
                $phone,
                $zip,
                $country,
                $state,
                $cart->totalPrice,
                $status
            ));

            $result = DB::select("select* from order_table where username = '$email' ORDER BY pk_id DESC");

            foreach ($products as $product)
            {
                if ($product['save'] > 0) DB::insert("insert into detail_table (product_id,order_id, sku, product_name, quantity,discount_price,price,percentage,size,vendor_id,v_order_status,v_payment_status ) values (?,?,?,?,?,?,?,?,?,?,?,?)", array(
                    $product['item']->pk_id,
                    $result[0]->pk_id,
                    $product['item']->sku,
                    $product['item']->name,
                    $product['qty'],
                    $product['price'],
                    $product['item']->price,
                    $product['item']->percentage,
                    $product['size'],
                    $product['item']->vendor_id,
                    $v_order_status,
                    $s
                ));

                else DB::insert("insert into detail_table (product_id,order_id, sku, product_name, quantity,price,size,vendor_id, v_order_status,v_payment_status  ) values (?,?,?,?,?,?,?,?,?,?)", array(
                    $product['item']->pk_id,
                    $result[0]->pk_id,
                    $product['item']->sku,
                    $product['item']->name,
                    $product['qty'],
                    $product['item']->price,
                    $product['size'],
                    $product['item']->vendor_id,
                    $v_order_status,
                    $s
                ));

                $id = $product['item']->pk_id;
                $resulting = DB::select("select quantity_on_hand from product where pk_id = '$id' ");
                $q = $resulting[0]->quantity_on_hand - $product['qty'];
                DB::table('product')->where('pk_id', $id)->update(['quantity_on_hand' => $q]);
            }
        }

        $data = array(
            'customer_fname' => session()->get('fname') ,
            'customer_lname' => session()
                ->get('lname') ,
            'customer_email' => session()
                ->get('username') ,
            'customer_address' => session()
                ->get('address') ,
            'customer_city' => session()
                ->get('city') ,
            'customer_phone' => session()
                ->get('phone') ,
            'customer_region' => session()
                ->get('zip') ,
            'customer_country' => session()
                ->get('country') ,
            'customer_state' => session()
                ->get('state') ,
            'order_id' => $result[0]->{'pk_id'},
            'date' => date('Y-m-d') ,

            'total_price' => $cart->totalPrice,

        );
        $o_id = $result[0]->{'pk_id'};
        Mail::send('email_order_confirm', $data, function ($message) use ($o_id)
        {

            $message->from('no-reply@fashionfactory.world', 'FASHION FACTORY');
            $id = session()->get('email');
            $message->to($id)->subject('Order ID# ' . $o_id . ' Received');

        });

        session()->flush();
        return view('client.thanks_view', compact('result'));
    }

    public function client_chat_view($id)
    {
        $oldCart = Session::get('cart');
        $cart = new Cart($oldCart);
        $products = $cart->items;
        $pk_id = session()->get('pk_id');
        $user = db::select("Select client_details.*, (Select message from chats where chats.user_from = '$pk_id' and user_to=client_details.pk_id  or (user_to='$pk_id' and user_from=client_details.pk_id) order by chats.id desc limit 1) as lastmessage from client_details where customer_type = 'seller'");
        return view('client.chat_system', compact('id', 'products', 'user') , ['products' => $cart->items, 'totalPrice' => $cart->totalPrice]);
    }
    
    
    
        public function style(Request $request)
    {
        $main = $request->Input('cat_id');

 
        $a = "1";
        $b = "2";
        $c = "0";
        $f = "0";
        $d="Individual";
        $e="Retailer";
        $g="";
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        
        
        $style = DB::select(DB::raw("SELECT * FROM style WHERE style.pk_id = :value") , array(
            'value' => $main,
        ));
        
        $sty = $style[0]->style;
        
        
        if($customer_type == "buyer"){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.style = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $sty,

        ));
    }elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.style = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $sty,

        ));

    }elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.style = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $sty,

        ));

    }
    
    else{
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.style = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $sty,
        ));
        
    }

    return $result;



    }
    
    public function brand(Request $request)
    {
        $main = $request->Input('cat_id');

 
        $a = "1";
        $b = "2";
        $c = "0";
        $f = "0";
        $d="Individual";
        $e="Retailer";
        $g="";
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        
        
        $brand = DB::select(DB::raw("SELECT * FROM brand WHERE brand.SKU = :value") , array(
            'value' => $main,
        ));
        
        $bran = $brand[0]->brand_name;
        
        
        
        
    if($customer_type == "buyer"){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.brand_name = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $bran,

        ));
    }elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.brand_name = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $bran,

        ));

    }elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.brand_name = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $bran,

        ));

    }
    
    else{
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.brand_name = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $bran,
        ));
        
    }

        return $result;



    }

    public function material(Request $request)
    {
        $main = $request->Input('cat_id');

 
        $a = "1";
        $b = "2";
        $c = "0";
        $f = "0";
        $d="Individual";
        $e="Retailer";
        $g="";
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');
        
        
        
        $material = DB::select(DB::raw("SELECT * FROM material WHERE material.pk_id = :value") , array(
            'value' => $main,
        ));
        
        $mat = $material[0]->material;
        
        

        if($customer_type == "buyer"){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));
    }elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));

    }elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));

    }
    
    else{
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,
        ));
        
    }

        return $result;



    }
    
        public function price(Request $request)
    {
        $main = $request->Input('cat_id');
        $sub = $request->Input('sub');

 
        $a = "1";
        $b = "2";
        $c = "0";
        $f = "0";
        $d="Individual";
        $e="Retailer";
        $g="";
        $customer_type = Session::get('customer_type');
        $vendor_cat = Session::get('vendor_cat');
        $account_t= Session::get('account_t');

        
    if($main == "1"){
        $price = DB::select("select min( price ) FROM product where sub_category='$sub'");
        
        $prc = $price[0]->price;
    if($customer_type == "buyer"){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));
    }elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));

    }elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));

    }
    else{
        
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.price = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ORDER BY price DESC") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $prc,
        ));
        
    }
    }elseif($main == "2" ){
        
        $price = DB::select("select max( price ) FROM product where sub_category='$sub'");
        
        $prc = $price[0]->price;
        
        if($customer_type == "buyer"){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));
    }elseif($customer_type == "seller" && $account_t == "Individual" or $vendor_cat == "Retailer" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Wholeseller') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));

    }elseif($customer_type == "seller" && $account_t == "Business" or $vendor_cat == "Wholeseller" ){
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.material = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and (product.account_t = 'Business' and product.vendor_cat ='Manufacture') ") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $mat,

        ));

    }
    else{
        $result = DB::select(DB::raw("SELECT * FROM product WHERE product.price = :value and product.status = :value2 and product.discount_status = :value3 and product.v_product_status = :value4 and ((product.account_t = 'Individual' or product.vendor_cat ='Retailer') or (product.account_t = '' or product.vendor_cat ='')) ORDER BY price ASC") , array(
            'value2' => $a,
            'value3' => $c,
            'value4' => $b,
            'value' => $prc,
        ));
        
    }
        
    }

        return $result;



    }
    
    
    public function return_active_order(Request $request ,$id)
    {
       
        if (!(session()->has('type') && session()
        ->get('type') == 'client'))
    {
        return redirect('/login');
    }

    $status = "3";
    date_default_timezone_set("Asia/Karachi");
    $date = date('Y-m-d');

    $reason = $request->input('reason');
    $user_id = DB::select("select user_id from order_table where pk_id = '$id'");
    $user_id= $user_id[0]->user_id;
    $price = DB::select("select amount from order_table where pk_id = '$id'");
    $price= $price[0]->amount;
  
       
        DB::table('order_table')
            ->where('pk_id', $id)
            ->update(['status' => $status ]);
            
        DB::table('detail_table')
            ->where('order_id', $id)
            ->update(['v_order_status' => $status ,'return_status' => $status]);
        


            $pro_id = DB::select("select product_id from detail_table where order_id = '$id'");
            $prod = $pro_id[0]->product_id;
            $size = DB::select("select size from detail_table where order_id = '$id'");
            $sizee = $size[0]->size;
            $q = DB::select("select quantity from detail_table where order_id = '$id'");
           $qq = $q[0]->quantity;
        
           
            
            DB::insert("insert into return_reason (user_id,product_id,size,quantity,price,order_id,reason,date) values('$user_id','$prod',' $sizee','$qq','$price','$id','$reason','$date') ");

            return redirect('/order/tracking/view');

    }
    
}