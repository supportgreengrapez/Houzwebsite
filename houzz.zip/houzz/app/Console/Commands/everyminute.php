<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use Illuminate\Support\Facades\DB;
class everyminute extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'status:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //
        
     DB::update("update detail_table set v_payment_status='1' where v_order_status='2' and DATEDIFF(NOW(),created_at)>7");  
    //  DB::update("update detail_table set v_payment_status='1' where v_order_status='2'");  
     
        // DB::delete("delete from review_table");
    }
}
