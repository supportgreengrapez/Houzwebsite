<?php
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::post('client/chat/auth-pusher','adminChatController@auth');

Route::post('admin/home/view/auth-pusher','adminChatController@auth');



Route::get('client/vendor/get-messages/{id}','adminChatController@getAdminMessages');

Route::get('admin/home/vendor/get-messages/{id}','adminChatController@getClientMessages');

Route::get('/get-first-user','adminChatController@getFirstUser');


////////////////////////////////////////////


Route::get('/uuid','clientController@UUID');

Route::get('/select/test','adminController@select');
Route::get('404',['as'=>'404','uses'=>'ErrorHandlerController@errorCode404']);

Route::get('405',['as'=>'405','uses'=>'ErrorHandlerController@errorCode405']);

Route::get('/ajax-subcat','adminController@sub');

Route::get('/ajax-product-type','adminController@type');


Route::get('/ajax-photocat','adminController@photo_sub');

Route::get('/admin/logout','adminController@logout');
Route::get('/admin','adminController@admin_login_view');
Route::post('/admin/login','adminController@index');

Route::get('/admin/home/view/chat','adminController@admin_chat_view');

Route::get('/admin/home/view/admin','adminController@admin_list_view');
Route::get('/admin/home/view/admin/{id}','adminController@admin_specific_view');
Route::get('/admin/home/view/admin/edit/admin/{id}','adminController@edit_admin_view');
Route::post('/admin/home/view/admin/edit/admin/{id}','adminController@edit_admin');
Route::post('admin/home/create/admin','adminController@create_admin');
Route::get('/admin/home/create/admin','adminController@create_admin_view');
Route::post('admin/home/delete/admin/{id}','adminController@delete_admin');


Route::get('/admin/home','adminController@admin_home');
Route::get('/admin/home/add/brand','adminController@add_brand_view');
Route::post('/admin/home/add/brand','adminController@add_brand');

Route::get('/admin/home/view/brand','adminController@brand_list_view');
Route::get('/admin/home/edit/brand/{sku}','adminController@edit_brand_view');
Route::post('/admin/home/edit/brand/{sku}','adminController@edit_brand');

Route::get('/admin/home/add/main/category','adminController@add_main_category_view');
Route::post('/admin/home/add/main/category','adminController@add_main_category');

Route::get('/admin/home/add/sub/category','adminController@add_sub_category_view');
Route::post('/admin/home/add/sub/category','adminController@add_sub_category');

Route::get('/admin/home/view/main/category','adminController@main_category_list_view');
Route::get('/admin/home/view/sub/category','adminController@sub_category_list_view');

Route::get('/admin/home/edit/main/category/{sku}','adminController@edit_main_category_view');
Route::post('/admin/home/edit/main/category/{sku}','adminController@edit_main_category');

Route::get('/admin/home/edit/main/category/commission/view/{sku}','adminController@edit_main_category_commission_view');
Route::post('/admin/home/edit/main/category/commission/{sku}','adminController@edit_main_category_commission');

Route::get('/admin/home/edit/sub/category/{sku}','adminController@edit_sub_category_view');
Route::post('/admin/home/edit/sub/category/{sku}','adminController@edit_sub_category');

Route::get('/client/commission','adminController@commission');

Route::get('/admin/home/edit/sub/category/commission/view/{sku}','adminController@edit_sub_category_commission_view');
Route::post('/admin/home/edit/sub/category/commission/{sku}','adminController@edit_sub_category_commission');


Route::get('/admin/home/add/product','adminController@add_product_view');
Route::post('/admin/home/add/product','adminController@add_product');

Route::get('/admin/home/edit/product/{id}','adminController@edit_product_view');
Route::post('/admin/home/edit/product/{id}','adminController@edit_product');


Route::post('/admin/home/product/hot/update/status','adminController@update_product_hot_status');
Route::post('/admin/home/payment/update/status','adminController@update_payment_status');


Route::get('/admin/home/add/product/type','adminController@add_product_type_view');
Route::post('/admin/home/add/product/type','adminController@add_product_type');

Route::get('/admin/home/view/product/type','adminController@product_type_list_view');
Route::get('/admin/home/edit/product/type/{pk_id}','adminController@edit_product_type_view');
Route::post('/admin/home/edit/product/type/{pk_id}','adminController@edit_product_type');
Route::get('/admin/home/delete/main/category/{pk_id}','adminController@delete_main_category');
Route::get('/admin/home/delete/sub/category/{pk_id}','adminController@delete_sub_category');
Route::get('/admin/home/delete/brand/{pk_id}','adminController@delete_brand');

Route::get('/admin/home/view/product','adminController@product_list_view');
Route::get('/admin/home/view/product/{id}','adminController@product_detail_view');
Route::get('/admin/home/delete/product/{id}','adminController@delete_product');
Route::get('/admin/home/delete/product/type/{id}','adminController@delete_product_type');

Route::get('/admin/home/view/product/status/update/{pk_id}/{status}','adminController@updateProductStatus');


Route::get('/admin/home/view/active/orders','adminController@active_order_view');
Route::get('/admin/home/view/active/order/view/specific/order/{id}','adminController@active_order_detail_view');
Route::post('/admin/home/order/update/status','adminController@update_order_status');
Route::post('/admin/home/vendor/update/status','adminController@update_vendor_status');
Route::get('/admin/home/print_invoice/{id}','adminController@print_invoice');
Route::post('/admin/home/order/update/test','adminController@test');

Route::post('/admin/home/order/update/amount/status','adminController@update_vendor_amount_status');

Route::get('/admin/home/view/complete/orders','adminController@complete_order_list_view');
Route::get('/admin/home/view/complete/order/view/specific/order/{id}','adminController@complete_order_detail_view');


Route::get('/admin/home/view/cancel/orders','adminController@cancel_order_list_view');
Route::get('/admin/home/view/cancel/order/view/specific/order/{id}','adminController@cancel_order_detail_view');


Route::get('/admin/home/view/return/orders','adminController@return_order_list_view');
Route::get('/admin/home/view/return/order/view/specific/order/{id}','adminController@return_order_detail_view');
Route::post('/admin/home/confirm/return','adminController@confirmed_return');

Route::get('/admin/home/view/reporting/by/products','adminController@reporting_by_product_list_view');
Route::get('/admin/home/view/detail/reporting/by/products/{id}','adminController@reporting_by_product');

Route::get('/admin/home/view/reporting/by/customer','adminController@customer_reporting_list_view');
Route::get('/admin/home/view/detail/reporting/by/customer/{id}','adminController@customer_reporting');
//Route::get('/admin/home/view/detail/reporting/by/specific/customer/{id}','adminController@customer_specific_reporting');


Route::get('/admin/home/view/reporting/by/sale','adminController@reporting_by_sale_list_view');
Route::get('/admin/home/view/reporting/by/sale/vendor','adminController@reporting_by_sale_list_view_vendor');
Route::get('/admin/home/view/detail/reporting/by/sale/{id}','adminController@reporting_by_sale');
Route::get('/admin/home/view/houzz/earning','adminController@houzz_earning');

Route::get('/admin/home/print/invoice/view/{id}','adminController@print_invoice_payment');
Route::get('/admin/home/create/payment/view/{id}','adminController@create_payment_view');
Route::post('/admin/home/create/payment/{id}','adminController@create_payment');

Route::get('/admin/home/add/discount','adminController@add_discount_view');
Route::post('/admin/home/add/discount','adminController@add_discount');
Route::get('/admin/home/view/discount','adminController@view_discount');

Route::get('/admin/home/edit/discount/{id}','adminController@edit_discount_view');
Route::post('/admin/home/edit/discount/{id}','adminController@edit_discount');
Route::get('/admin/home/delete/discount/{id}','adminController@delete_discount');

Route::get('/admin/home/add/promo','adminController@add_promo_view');
Route::post('/admin/home/add/promo','adminController@add_promo');
Route::get('/admin/home/view/promo','adminController@view_promo_list');

Route::get('/admin/home/edit/promo/{id}','adminController@edit_promo_view');
Route::post('/admin/home/edit/promo/{id}','adminController@edit_promo');
Route::get('/admin/home/delete/promo/{id}','adminController@delete_promo_code');
Route::post('/admin/home/search/promo','adminController@search_promo');

Route::get('/admin/home/view/promo/status/update/{pk_id}/{status}','adminController@update_promo_status');

Route::get('/admin/home/add/custom/package/view','adminController@add_custom_package_view');
Route::post('/admin/home/add/custom/package','adminController@add_custom_package');
Route::get('/admin/home/edit/custom/package/{id}','adminController@edit_custom_package_view');
Route::post('/admin/home/edit/custom/package/{id}','adminController@edit_custom_package');
Route::get('/admin/home/view/custom/package','adminController@custom_package_view');
Route::get('/admin/home/custom/package/detail/view/{id}','adminController@custom_package_detail_view');
Route::get('/admin/home/delete/custom/package/{id}','adminController@delete_custom_package');
Route::get('/admin/home/custom/package/status/update/{pk_id}/{status}','adminController@updatePackageStatus');

Route::get('/admin/home/add/style','adminController@add_style_view');
Route::post('/admin/home/add/style','adminController@add_style');
Route::get('/admin/home/edit/style/{sku}','adminController@edit_style_view');
Route::post('/admin/home/edit/style/{sku}','adminController@edit_style');
Route::get('/admin/home/view/style','adminController@style_list_view');
Route::get('/admin/home/delete/style/{pk_id}','adminController@delete_style');

Route::get('/admin/home/add/material','adminController@add_material_view');
Route::post('/admin/home/add/material','adminController@add_material');
Route::get('/admin/home/edit/material/{sku}','adminController@edit_material_view');
Route::post('/admin/home/edit/material/{sku}','adminController@edit_material');
Route::get('/admin/home/view/material','adminController@material_list_view');
Route::get('/admin/home/delete/material/{pk_id}','adminController@delete_material');


Route::get('/admin/home/add/photo/category','adminController@add_photo_category_view');
Route::post('/admin/home/add/photo/category','adminController@add_photo_category');
Route::get('/admin/home/edit/photo/category/{sku}','adminController@edit_photo_category_view');
Route::post('/admin/home/edit/photo/category/{sku}','adminController@edit_photo_category');
Route::get('/admin/home/view/photo/category','adminController@photo_category_list_view');
Route::get('/admin/home/delete/photo/category/{pk_id}','adminController@delete_photo_category');



Route::get('/admin/home/view/photo/sub/category','adminController@photo_sub_category_list_view');
Route::get('/admin/home/add/photo/sub/category','adminController@add_photo_sub_category_view');
Route::post('/admin/home/add/photo/sub/category','adminController@add_photo_sub_category');
Route::get('/admin/home/edit/photo/sub/category/{sku}','adminController@edit_photo_sub_category_view');
Route::post('/admin/home/edit/photo/sub/category/{sku}','adminController@edit_photo_sub_category');
Route::get('/admin/home/delete/photo/sub/category/{pk_id}','adminController@delete_photo_sub_category');


Route::get('/admin/home/view/idea/list','adminController@idea_list_view');
Route::get('/admin/home/add/idea','adminController@add_idea_view');
Route::post('/admin/home/add/idea','adminController@add_idea');
Route::get('/admin/home/edit/idea/{sku}','adminController@edit_idea_view');
Route::post('/admin/home/edit/idea/{sku}','adminController@edit_idea');
Route::get('/admin/home/delete/idea/{pk_id}','adminController@delete_idea');



Route::post('/admin/home/search/subs/by/order/id','adminController@search_subs_order_id');
Route::post('/admin/home/search/by/subs/package','adminController@search_subs_package');


Route::post('/admin/home/search/by/order/id','adminController@search_order_id');
Route::post('/admin/home/search/by/order/status','adminController@search_order_status');

Route::post('/admin/home/search/seller/by/order/id','adminController@search_seller_order_id');

//  ------------   vendor ---------------

Route::get('/admin/home/create/seller','adminController@add_seller_view');
Route::post('/admin/home/create/seller','adminController@add_seller');

Route::get('/admin/home/view/commission/vendor','adminController@commission_vendor_list_view');
Route::get('/admin/home/view/commission/vendor/{id}','adminController@commission_vendor_detail_view');
Route::get('/admin/home/view/vendor/orders/{id}','adminController@vendor_order_list_view');

Route::get('/admin/home/view/vendor','adminController@vendor_list_view');
Route::get('/admin/home/view/vendor/{id}','adminController@vendor_detail_view');


Route::get('/admin/home/view/pending/products','adminController@pending_product_list_view');
Route::get('/admin/home/view/pending/products/view/detail/product/{id}','adminController@pending_product_detail_view');
Route::post('/admin/home/product/update/status','adminController@update_ven_product_status');

Route::get('/admin/home/view/approved/products','adminController@approved_product_list_view');
Route::get('/admin/home/view/approved/products/view/detail/product/{id}','adminController@approved_product_detail_view');


Route::get('/admin/home/view/cancel/products','adminController@cancel_product_list_view');
Route::get('/admin/home/view/cancel/products/view/detail/product/{id}','adminController@cancel_product_detail_view');

Route::post('/admin/home/vendor/order/update/status','adminController@update_vendor_order_status');
Route::post('/admin/home/update/payment/status','adminController@update_vendor_payment_status');

Route::get('/admin/view/vendor/reporting','adminController@vendor_reporting_list_view');
Route::get('/admin/view/vendors/payments','adminController@vendor_payments_list_view');
Route::post('/admin/view/vendor/payment','adminController@create_payment');

Route::get('/admin/home/view/blog/category','adminController@blog_category_list_view');
Route::get('/admin/home/add/blog/category/view','adminController@add_blog_category_view');
Route::post('/admin/home/add/blog/category','adminController@add_blog_category');

Route::get('/admin/home/view/forum/category','adminController@form_category_list_view');
Route::get('/admin/home/add/forum/category/view','adminController@add_form_category_view');
Route::post('/admin/home/add/forum/category','adminController@add_form_category');

Route::get('/admin/home/edit/forum/category/view/{id}','adminController@edit_forum_category_view');
Route::post('/admin/home/edit/forum/category/{id}','adminController@edit_forum_category');
Route::get('/admin/home/delete/forum/category/{id}','adminController@delete_forum_category');

Route::get('/admin/home/view/forum/topic','adminController@forum_topic_list_view');
Route::get('/admin/home/add/forum/topic/view','adminController@add_forum_topic_view');
Route::post('/admin/home/add/forum/topic','adminController@add_forum_topic');

Route::get('/admin/home/edit/forum/topic/view/{id}','adminController@edit_forum_topic_view');
Route::post('/admin/home/edit/forum/topic/{id}','adminController@edit_forum_topic');
Route::get('/admin/home/delete/forum/topic/{id}','adminController@delete_forum_topic');

Route::get('/admin/home/view/forum/post','adminController@forum_post_list_view');
Route::get('/admin/home/detail/forum/post/{id}','adminController@forum_post_detail_view');
Route::get('/admin/home/add/forum/post/view','adminController@add_forum_post_view');
Route::post('/admin/home/add/forum/post','adminController@add_forum_post');

Route::get('/admin/home/edit/forum/post/view/{id}','adminController@edit_forum_post_view');
Route::post('/admin/home/edit/forum/post/{id}','adminController@edit_forum_post');
Route::get('/admin/home/delete/forum/post/{id}','adminController@delete_forum_post');

Route::get('/admin/home/edit/blog/category/view/{id}','adminController@edit_blog_category_view');
Route::post('/admin/home/edit/blog/category/{id}','adminController@edit_blog_category');
Route::get('/admin/home/delete/blog/category/{id}','adminController@delete_blog_category');


Route::get('/admin/slider/list/view','adminController@slider_list_view');
Route::get('/admin/slider/detail/view/{id}','adminController@slider_detail_view');
Route::get('/admin/add/slider/view','adminController@add_slider_view');
Route::post('/admin/add/slider','adminController@add_slider');
Route::get('/admin/edit/slider/view/{id}','adminController@edit_slider_view');
Route::post('/admin/edit/slider/{id}','adminController@edit_slider');
Route::get('/admin/delete/slider/{id}','adminController@delete_slider');

Route::get('/admin/collection/set/view/{id}','adminController@collection_set_view');
Route::get('/admin/collection/list/view','adminController@collection_list_view');
Route::get('/admin/collection/detail/view/{id}','adminController@collection_detail_view');
Route::get('/admin/add/collection/view','adminController@add_collection_view');
Route::post('/admin/add/collection/category','adminController@add_collection_category');
Route::post('/admin/add/collection','adminController@add_collection');
Route::get('/admin/edit/collection/view/{id}','adminController@edit_collection_view');
Route::get('/admin/edit/collection/set/view/{id}','adminController@edit_collection_set_view');
Route::post('/admin/edit/collection/{id}','adminController@edit_collection_set');
Route::post('/admin/edit/collection/category/{id}','adminController@edit_collection');
Route::get('/admin/delete/collection/{id}','adminController@delete_collection');


Route::get('/admin/invoice/list/view','adminController@invoice_list_view');
Route::get('/admin/invoice/detail/view/{id}/{order_id}','adminController@invoice_detail_view');
Route::get('/admin/add/invoice/view','adminController@add_invoice_view');
Route::post('/admin/add/invoice','adminController@add_invoice');
Route::get('/admin/edit/invoice/view/{id}','adminController@edit_invoice_view');
Route::post('/admin/edit/invoice/{id}','adminController@edit_invoice');
Route::get('/admin/delete/invoice/{id}/{order_id}','adminController@delete_invoice');

Route::post('/admin/home/search/invoice/by/order/id','adminController@search_invoice_order_id');
Route::post('/admin/home/search/invoice/by/order/status','adminController@search_invoice_order_status');


Route::get('/admin-blog','adminController@bloglist');
Route::get('/admin-create-a-post','adminController@create_blog_post_view');
Route::post('/admin-create-a-post','adminController@addblog');
Route::get('/admin-blog-edit/{id}','adminController@edit_blog_view');
Route::post('/admin-blog-edit/{id}','adminController@edit_blog');
Route::get('/admin-delete-blog-post/{id}','adminController@delete_blog');


Route::get('/admin/home/view/rating','adminController@rating_view');
Route::get('/admin/home/view/seller/rating','adminController@seller_rating_view');

Route::get('/admin/import/product/view','adminController@import_product_view');

Route::post('/admin/import/product/view','adminController@CSV');

Route::get('/admin/home/view/package','adminController@package_view');

Route::get('/admin/home/view/package/payment','adminController@package_payment_list_view');
Route::post('/admin/home/payment/invoice/update/status','adminController@update_payment_invoice_status');

Route::get('/admin/home/view/package/invoice','adminController@package_invoice_list_view');
Route::post('/admin/home/invoice/package/update/status','adminController@update_invoice_package_status');
Route::get('/printinvoice/{id}','adminController@printinvoice');

Route::get('/admin/payment/list/view','adminController@payment_list_view');

Route::get('/admin/home/view/message','adminController@message_list_view');
Route::get('/admin/home/send/message/{id}','adminController@message_send_view');
Route::post('/admin/home/send/message/{id}','adminController@send_message');

// ecom //
Route::get('/agents','clientController@agent_list_view');
Route::get('/properties','clientController@properties_list_view');
Route::get('/add/property','clientController@realtor_add_property_view');
Route::post('/add/property','clientController@realtor_add_property');

Route::get('/home','clientController@home_list_view');
Route::get('/commercial','clientController@commercial_list_view');
Route::get('/plot','clientController@plot_list_view');
Route::get('/flat','clientController@flat_list_view');
Route::get('/land','clientController@land_list_view');
Route::get('/rent','clientController@rent_list_view');
Route::get('/sale','clientController@sale_list');
Route::get('/office','clientController@office_list_view');
Route::get('/hot','clientController@hot_list_view');

Route::get('/property/{home}/{city}','clientController@property_listed_view');
Route::get('/property/detail/view/{id}','clientController@property_detail_view');


Route::get('/blog','clientController@blog_view');
Route::get('/blog/specific/view/{id}','clientController@blog_specific_view');

Route::get('/seller/list/view','clientController@seller_list_view');

Route::get('/seller_detail/{id}','clientController@seller_detail_view');

Route::get('/product/{main}/{sub}','clientController@searchByCategory');
Route::get('/product/{main?}','clientController@sub_Category');
Route::get('/','clientController@home_view');
Route::get('/shop','clientController@shop_view');
Route::get('/collection','clientController@collection_view');
Route::get('/collection/detail/view/{id}','clientController@collection_detail_view');
Route::get('/shop/sub/category','clientController@sub_category_view');
Route::get('/shop/products/list','clientController@products_list_view');
Route::get('/shop/products/detail','clientController@products_detail_view');
Route::get('/sale/view','clientController@sale_view');
Route::get('/sale/products/{main}','clientController@sale_product');
Route::get('/client/ajax-size','clientController@size_detail');

Route::post('/cancel_active_order/{id}','clientController@return_active_order');
Route::get('/customer-cancel-active-order/{id}','clientController@cancel_active_order');

Route::get('/partner','clientController@partner_view');
Route::get('/partner_detail','clientController@partner_detail');

Route::get('/sell_on_houzz','clientController@sell_on');
Route::get('/advertise_with_us','clientController@advertise_with_us');

Route::get('/client/payment/list/view/{id}','clientController@payment_list_view');
Route::get('/client/add/payment/view','clientController@add_payment_view');
Route::post('/client/add/payment','clientController@add_payment');
Route::post('/client/search/payment/by/id','clientController@search_payment_by_id');
Route::post('/client/search/payment/by/status','clientController@search_payment_by_status');

Route::post('/search','clientController@search');
Route::get('/search/wishlist','clientController@search_wishlist');
Route::post('/search/wishlist/by/name','clientController@search_wishlist_by_name');
Route::post('/search/wishlist/by/username','clientController@search_wishlist_by_username');
Route::get('/view/wishlist','clientController@view_wishlist');
Route::post('/product/add/wishlist/{id}','clientController@add_wishlist');
Route::get('/login','clientController@client_login_view');
Route::post('/login','clientController@client_login');
Route::get('/logout','clientController@client_logout');
Route::get('/payment/policy','clientController@payment_policy');
Route::get('/men/collection','clientController@men_collection_view');
Route::get('/handbags','clientController@women_handbags_view');
Route::get('/products/details/{pk_id}/{sku}','clientController@product_detail_view');
Route::post('/product/add/cart/{pk_id}','clientController@addToCart');
Route::get('/cart','clientController@getCart');
Route::get('/aboutus','clientController@about_us');
Route::get('/accounts','clientController@accounts');
Route::get('/faq','clientController@faq');
Route::get('/returns/and/refunds','clientController@returns');
Route::get('/privacy/policy','clientController@privacy_policy');
Route::get('/warranty/and/repairs','clientController@warranty_and_repairs');
Route::get('/contact/us','clientController@contact_us');
Route::get('/terms/and/conditions','clientController@terms');
Route::get('/cart/guest/checkout','clientController@guest_checkout_view');
Route::post('/cart/guest/checkout','clientController@guest_checkout');
Route::get('/cart/checkout','clientController@checkout_view');
Route::post('/cart/checkout','clientController@login');
Route::get('/cart/checkout/address','clientController@address_view');
Route::post('/cart/checkout/address','clientController@address');
Route::get('/cart/checkout/add/address','clientController@add_address_view');
Route::post('/cart/checkout/add/address','clientController@add_address');
Route::get('/cart/checkout/add/new/address','clientController@add_new_address_view');
Route::post('/cart/checkout/add/new/address','clientController@add_new_address');
Route::get('/cart/checkout/address/view/order/{id}','clientController@order_view');
Route::get('/cart/checkout/address/view/order/complete/order/{id}','clientController@order_payment_view');
Route::post('/cart/checkout/address/view/order/complete/order','clientController@confirm_order');
Route::get('/cart/guest/checkout/address/view/order/complete/order','clientController@guest_payment_view');
Route::post('/cart/guest/checkout/address/view/order/complete/order','clientController@guest_confirm_order');
Route::post('/cart/checkout/address/view/order/complete/order/add/promo/{id}/{sub_cat}/{price}','clientController@add_promo_code');
Route::get('remove/item/cart/{id}/{qty}/{delivery}','clientController@removeCart');
Route::get('order/tracking/view','clientController@order_tracking_view');
Route::get('/order/tracking/detail/{id}','clientController@order_tracking_detail_view');
Route::get('guest/order/tracking/view','clientController@guest_order_tracking_view');
Route::post('order/tracking','clientController@order_tracking');
Route::post('guest/order/tracking','clientController@guest_order_tracking');

Route::get('/cart/checkout/edit/address/{id}','clientController@edit_address_view');
Route::post('/cart/checkout/edit/address/{id}','clientController@edit_address');

Route::get('/signup','clientController@create_client_view');
Route::post('/signup/2','clientController@create_signin_2_view');

Route::post('/create_account','clientController@create_account');
Route::post('/signup/3/view','clientController@create_signin_detail_view');
Route::post('/signup','clientController@create_client');

Route::post('/signup/seller/basic','clientController@seller_basic_info');
Route::post('/signup/seller/detail','clientController@seller_detail_info');


Route::post('/realtor/signin','clientController@realtor_signin');

Route::get('/client/send/message','clientController@message_send_view');
Route::get('/client/compose/message','clientController@message_compose_view');
Route::post('/client/compose/message','clientController@message_compose');

Route::post('/client/add/review/{id}','clientController@add_review');


Route::get('/style','clientController@style');
Route::get('/brand','clientController@brand');
Route::get('/material','clientController@material');
Route::get('/price','clientController@price');



Route::get('vendor/signup','vendorController@vendor_signup_view');
Route::get('/vendor/logout','vendorController@logout');

Route::post('vendor/signup','vendorController@create_vendor');
Route::get('/vendor/home','vendorController@vendor_home');

Route::get('vendor/login','vendorController@vendor_login_view');
Route::post('vendor/login','vendorController@vendor_login');

Route::get('/vendor/home/view/active/order/view/specific/order/{id}/{o_id}','vendorController@active_order_detail_view');
Route::get('/vendor/home/view/complete/order/view/specific/order/{id}/{o_id}','vendorController@complete_order_detail_view');
Route::get('/vendor/home/view/cancel/order/view/specific/order/{id}/{o_id}','vendorController@cancel_order_detail_view');
Route::get('/vendor/home/view/return/order/view/specific/order/{id}/{o_id}','vendorController@return_order_detail_view');


Route::get('/vendor/home/add/product','vendorController@add_product_view');
Route::post('/vendor/home/add/product','vendorController@add_product');

Route::get('/vendor/home/edit/product/{id}','vendorController@edit_product_view');
Route::post('/vendor/home/edit/product/{id}','vendorController@edit_product');
Route::get('/vendor/home/delete/product/{id}','vendorController@delete_product');


Route::get('/vendor/home/add/main/category','vendorController@add_main_category_view');
Route::post('/vendor/home/add/main/category','vendorController@add_main_category');

Route::get('/vendor/home/add/sub/category','vendorController@add_sub_category_view');
Route::post('/vendor/home/add/sub/category','vendorController@add_sub_category');

Route::get('/vendor/home/view/main/category','vendorController@main_category_list_view');
Route::get('/vendor/home/view/sub/category','vendorController@sub_category_list_view');

Route::get('/vendor/home/edit/main/category/{sku}','vendorController@edit_main_category_view');
Route::post('/vendor/home/edit/main/category/{sku}','vendorController@edit_main_category');

Route::get('/vendor/home/edit/sub/category/{sku}','vendorController@edit_sub_category_view');
Route::post('/vendor/home/edit/sub/category/{sku}','vendorController@edit_sub_category');

Route::get('/vendor/home/delete/main/category/{pk_id}','vendorController@delete_main_category');
Route::get('/vendor/home/delete/sub/category/{pk_id}','vendorController@delete_sub_category');

Route::get('/vendor/home/view/product','vendorController@product_list_view');
Route::get('/vendor/home/view/product/{id}','vendorController@product_detail_view');
Route::get('/vendor/home/pending/product','vendorController@pending_product_list_view');
Route::get('/vendor/home/approved/product','vendorController@approved_product_list_view');
Route::get('/vendor/home/cancel/product','vendorController@cancel_product_list_view');

Route::get('/vendor/home/view/active/orders','vendorController@active_order_view');
Route::post('/vendor/home/order/update/status','vendorController@update_order_status');

Route::get('/vendor/home/view/cancel/orders','vendorController@cancel_order_list_view');
Route::get('/vendor/home/view/return/orders','vendorController@return_order_list_view');
Route::get('/vendor/home/view/complete/orders','vendorController@complete_order_list_view');

Route::get('/vendor/home/view/reporting/by/products','vendorController@reporting_by_product_list_view');
Route::get('/vendor/home/view/detail/reporting/by/products/{id}','vendorController@reporting_by_product');

Route::get('/vendor/home/view/reporting/by/sale','vendorController@reporting_by_sale_list_view');
Route::get('/vendor/home/view/earning','vendorController@earning_view');
Route::get('/vendor/home/view/product/status/update/{pk_id}/{status}','vendorController@updateProductStatus');


Route::get('/vendor/home/view/earning/by/sale','vendorController@reporting_by_earning_list_view');

Route::get('/vendor/home/add/product/type','vendorController@add_product_type_view');
Route::post('/vendor/home/add/product/type','vendorController@add_product_type');

Route::get('/vendor/view/product/type','vendorController@product_type_list_view');
Route::get('/vendor/home/edit/product/type/{pk_id}','vendorController@edit_product_type_view');
Route::post('/vendor/home/edit/product/type/{pk_id}','vendorController@edit_product_type');
Route::get('/vendor/home/delete/product/type/{id}','vendorController@delete_product_type');

Route::post('/vendor/home/search/by/order/id','vendorController@search_order_id');
Route::post('/vendor/home/search/by/order/status','vendorController@search_order_status');

Route::get('/vendor/home/view/package','vendorController@package_view');
Route::post('/vendor/home/subscribe/{subscription}/{package_name}/{package_price}','vendorController@subscribe_package');

Route::get('/vendor/home/add/discount','vendorController@add_discount_view');
Route::post('/vendor/home/add/discount','vendorController@add_discount');
Route::get('/vendor/home/view/discount','vendorController@view_discount');

Route::get('/vendor/home/edit/discount/{id}','vendorController@edit_discount_view');
Route::post('/vendor/home/edit/discount/{id}','vendorController@edit_discount');
Route::get('/vendor/home/delete/discount/{id}','vendorController@delete_discount');

Route::get('/vendor/home/view/rating','vendorController@rating_view');
Route::get('/vendor/home/view/bank/account','vendorController@bank_account_view');
Route::get('/vendor/home/edit/bank/account/{id}','vendorController@edit_bank_account_view');
Route::post('/vendor/home/edit/bank/account/{id}','vendorController@edit_bank_account');


Route::get('/vendor/home/edit/notification','vendorController@edit_notification_view');
Route::post('/vendor/home/edit/notification/{id}','vendorController@edit_notification');

Route::get('/vendor/home/edit/seller/info','vendorController@edit_basic_info_view');
Route::post('/vendor/home/edit/seller/info','vendorController@edit_basic_info');

Route::get('/vendor/home/view/commission/invoice','vendorController@commission_invoice_view');
Route::get('/vendor/home/view/subscription/invoice','vendorController@subscription_invoice_view');

Route::get('/vendor/ajax-subcat','vendorController@sub');
Route::get('/vendor/ajax-product-type','vendorController@type');


Route::get('/vendor/home/add/payment/invoice','vendorController@add_payment_invoice_view');
Route::post('/vendor/home/add/payment/invoice','vendorController@add_payment_invoice');
Route::get('/vendor/home/view/payment/invoice','vendorController@view_payment_invoice');
Route::post('/vendor/home/payment/invoice/update/status','vendorController@update_payment_invoice_status');

Route::get('/vendor/home/add/offline/client/view','vendorController@add_offline_client_view');
Route::post('/vendor/home/add/offline/client','vendorController@add_offline_client');
Route::get('/vendor/home/view/offline/client','vendorController@offline_client_list_view');
Route::get('/vendor/home/offline/client/detail/view/{id}','vendorController@offline_client_detail_view');
Route::get('/vendor/home/edit/offline/client/view/{id}','vendorController@edit_offline_client_view');
Route::post('/vendor/home/edit/offline/client/{id}','vendorController@edit_offline_client');
Route::get('/vendor/home/delete/offline/client/{id}','vendorController@delete_offline_client');


Route::get('/vendor/home/view/submit/payment/invoice','vendorController@view_submit_payment_invoice');
Route::get('/vendor/home/view/approved/payment/invoice','vendorController@view_approved_payment_invoice');
Route::get('/vendor/home/view/pending/payment/invoice','vendorController@view_pending_payment_invoice');
Route::get('/vendor/home/view/rejected/payment/invoice','vendorController@view_rejected_payment_invoice');

Route::get('/vendor/home/view/submit/package/invoice','vendorController@view_submit_package_invoice');
Route::get('/vendor/home/view/approved/package/invoice','vendorController@view_approved_package_invoice');
Route::get('/vendor/home/view/pending/package/invoice','vendorController@view_pending_package_invoice');
Route::get('/vendor/home/view/rejected/package/invoice','vendorController@view_rejected_package_invoice');

Route::post('/vendor/home/search/by/package/id','vendorController@search_package_id');

Route::get('/vendor/collection/set/view/{id}','vendorController@collection_set_view');
Route::get('/vendor/collection/list/view','vendorController@collection_list_view');
Route::get('/vendor/collection/detail/view/{id}','vendorController@collection_detail_view');
Route::get('/vendor/add/collection/view','vendorController@add_collection_view');
Route::post('/vendor/add/collection/category','vendorController@add_collection_category');
Route::post('/vendor/add/collection','vendorController@add_collection');
Route::get('/vendor/edit/collection/view/{id}','vendorController@edit_collection_view');
Route::get('/vendor/edit/collection/set/view/{id}','vendorController@edit_collection_set_view');
Route::post('/vendor/edit/collection/{id}','vendorController@edit_collection_set');
Route::post('/vendor/edit/collection/category/{id}','vendorController@edit_collection');
Route::get('/vendor/delete/collection/{id}','vendorController@delete_collection');


Route::get('/vendor/payement/duration','vendorController@payment_duration');
Route::get('/vendor/payment/add/duration','vendorController@payment_duration_form_view');
Route::post('/payment/duration','vendorController@payment_duration_form');

Route::get('/vendor/test','vendorController@v_test');

Route::get('/flush',function()
{
 session()->flush();
});

Route::get('/ssendmail',function(Request $request)
{
Log::info("asd");
//$json = $request->input('id');
//DB::insert("insert into pwebhook (wid,status,text) values('1','2','$json')");


 $data = array(
     'name' => "Sumra Riaz",
     'firstname'=> "nice",
);
Mail::send('test', $data, function ($message) {

$message->from('accounts@houz.pk', 'test');

$message->to('sumrariaz@yahoo.com')->subject('Learning Laravel test email');


});

return "asd";
});


Route::get('/verify/{username}/{verfication_code}','clientController@verify_code');
Route::get('/password/reset','clientController@reset_password_view');

Route::post('/password/reset','clientController@reset_password');


Route::post('/password/change/{username}','clientController@password_change');



Route::get('/admin/verify/{username}/{verfication_code}','adminController@verify_code');
Route::get('/admin/password/reset','adminController@reset_password_view');

Route::post('/admin/password/reset','adminController@admin_reset_password');


Route::post('/admin/password/change/{username}','adminController@password_change');



Route::get('/vendor/verify/{username}/{verfication_code}','vendorController@verify_code');
Route::get('/vendor/password/reset','vendorController@reset_password_view');

Route::post('/vendor/password/reset','vendorController@vendor_reset_password');


Route::post('/vendor/password/change/{username}','vendorController@password_change');

Route::get('/vendor/home/view/message','vendorController@message_list_view');
Route::get('/vendor/home/send/message/{id}','vendorController@message_send_view');
Route::post('/vendor/home/send/message/{id}','vendorController@send_message');


Route::get('/vendor/home/view/chat','vendorController@chat_view');
Route::get('/vendor/home/view/admin/chat','vendorController@admin_chat_view');

/* realtor  */

Route::get('/realtor/logout','realtorController@logout');
Route::get('/realtor/dashboard','realtorController@realtor_dashboard_view');

Route::get('/realtor/home/view/property','realtorController@realtor_property_view');
Route::get('/realtor/home/view/property/detail/{id}','realtorController@realtor_property_detail_view');
Route::get('/realtor/home/add/property','realtorController@realtor_add_property_view');
Route::post('/realtor/home/add/property','realtorController@realtor_add_property');
Route::get('/realtor/home/edit/property/{id}','realtorController@edit_realtor_property_view');
Route::post('/realtor/home/edit/property/{id}','realtorController@edit_realtor_property');
Route::get('/realtor/home/delete/property/{id}','realtorController@realtor_delete_property');
Route::post('/realtor/home/property/update/status','realtorController@update_realtor_property_type');

Route::get('/realtor/home/view/project/detail/{id}','realtorController@realtor_project_detail_view');
Route::get('/realtor/home/add/project','realtorController@realtor_add_project_view');
Route::post('/realtor/home/add/project','realtorController@realtor_add_project');
Route::get('/realtor/home/edit/project/{id}','realtorController@edit_realtor_project_view');
Route::post('/realtor/home/edit/project/{id}','realtorController@edit_realtor_project');
Route::get('/realtor/home/delete/project/{id}','realtorController@realtor_delete_project');
Route::post('/realtor/home/project/update/status','realtorController@update_realtor_project_type');

//Clear configurations:
Route::get('/config-clear', function() {
    $status = Artisan::call('config:clear');
    return '<h1>Configurations cleared</h1>';
});

//Clear cache:
Route::get('/cache-clear', function() {
    $status = Artisan::call('cache:clear');
    return '<h1>Cache cleared</h1>';
});

//Clear configuration cache:
Route::get('/config-cache', function() {
    $status = Artisan::call('config:Cache');
    return '<h1>Configurations cache cleared</h1>';
});

Route::post('client/chat/auth-pusher','chatController@auth');

Route::post('vendor/home/view/auth-pusher','chatController@auth');


Route::post('client/send-admin-message','chatController@sendAdminMessage');

Route::post('vendor/home/send-customer-message','chatController@sendAdminMessage');

Route::get('client/vendor/get-messages/{id}','chatController@getAdminMessages');

Route::get('vendor/home/vendor/get-messages/{id}','chatController@getClientMessages');

Route::get('/get-first-user','chatController@getFirstUser');

Route::get('/client/chat/{id}','clientController@client_chat_view');


Route::get('admin/partner-list','adminController@partnerList')->name('partner.list');
Route::get('admin/add-partner-detail','adminController@addPartnerDeati')->name('add.partner.detail');
Route::post('admin/partner-detail-submit','adminController@PartnerDetailSubmit')->name('partner.detail.submit');
Route::post('admin/partner-detail-update','adminController@partnerDetailUpdate')->name('partner.detail.update');
Route::get('admin/add-partner-product/{id}','adminController@addPartnerProduct')->name('add.partner.product');
Route::post('admin/add-partner-productPost','adminController@addPartnerProductPost')->name('add.product.post');
Route::get('admin/partner-view/{id}','adminController@partnerView');
Route::get('admin/partner-edit/{id}','adminController@partnerEdit');
Route::get('admin/partner-delete/{id}','adminController@partnerDelete');
Route::get('admin/create-partner/','adminController@createPartner');
Route::post('admin/create-partner/','adminController@createPartnerPost')->name('create.partner');

Route::get('admin/titanium-partner-list/','adminController@titaniumPartnerList')->name('titanium.partner.list');
Route::get('admin/edit-titanium-icon/{id}','adminController@editTitaniumIcon');
Route::get('admin/delete-titanium-icon/{id}','adminController@deleteTitaniumIcon');
Route::get('admin/add-titanium-icon/','adminController@addTitaniumIcon')->name('add.titanium.icon');
Route::post('admin/add-titanium-icon-post/','adminController@titaniumIconPost')->name('titanium.icon.post');
Route::post('admin/add-titanium-icon/','adminController@titaniumIconUpdate')->name('titanium.icon.update');



Route::get('admin/slider-image/','adminController@sliderImage')->name('slider.image');
Route::get('admin/add-slider-image/','adminController@addSliderImage')->name('add.slider.image');
Route::post('admin/add-slider-image-post/','adminController@addSliderImagePost')->name('add.slider.image.post');
Route::get('admin/slider-image-view/{id}','adminController@sliderImageView')->name('slider.image.view');
Route::get('admin/slider-image-delete/{id}','adminController@sliderImageDelete')->name('slider.image.delete');
// Route::get('admin/partner-view/{id}','adminController@partnerList');
Route::get('/client/chat/{id}','clientController@client_chat_view');

Route::get('admin/partner-category/','adminController@partnerCategory')->name('partner.catgory');
Route::get('admin/add-category','adminController@addCategory')->name('add.category');
Route::post('admin/add-category-post','adminController@addCategorPost')->name('add.category.post');
Route::get('admin/edit-category/{id}','adminController@editCategory')->name('category.edit');
Route::post('admin/update-category','adminController@updateCategory')->name('category.update');
Route::get('admin/delete-category/{id}','adminController@deleteCategory')->name('category.delete');



Route::get('admin/partner-sub-category/','adminController@partnerSubCategory')->name('partner.sub.catgory');
Route::get('admin/add-sub-category','adminController@addSubCategory')->name('add.sub.category');

Route::post('admin/add-sub-category-post','adminController@addSubCategorPost')->name('add.sub.category.post');

Route::get('admin/edit-sub-category/{id}','adminController@editSubCategory')->name('sub.category.edit');
Route::post('admin/update-sub-category','adminController@updateSubCategory')->name('sub.category.update');
Route::get('admin/delete-sub-category/{id}','adminController@deleteSubCategory')->name('sub.category.delete');


// partner search 

Route::post('admin-partner-search-name','adminController@partnerSearchByName')->name('partner.search.name');
Route::post('admin-partner-search-category','adminController@partnerSearchByCategory')->name('partner.search.category');



