@extends('adminRealtor.layout.appAdminRealtor')
@section('content')


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="textcen" style="margin-top:0px !important;">
            <h4 style="margin:0px;">Realtor Admin Dashboard</h4>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">
          <div class="carousel slide media-carousel" id="media">
            <div class="carousel-inner">
              <div class="item  active">
                <div class="row">
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/Untitled-2.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>99 <br>
                          <span>Total Owner Investor</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/2.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>145 <br>
                          <span>Total Agency</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/3.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>66 <br>
                          <span>Developer</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/4.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>45 <br>
                          <span>Listing</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/5.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>12 <br>
                          <span>Projects</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/6.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>08 <br>
                          <span>Sales</span></h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/Untitled-2.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>99 <br>
                          <span>Rent</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/2.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>145 <br>
                          <span>Hot</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/3.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>66 <br>
                          <span>Super Hot</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/4.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>45 <br>
                          <span>Paid</span></h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-2 col-sm-12 col-xs-12">
                    <div class="dbboticons"> <img src="{{url('/')}}/images2/5.png" alt="icons">
                      <div class="dbboticonstext">
                        <h4>12 <br>
                          <span>Free</span></h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <a data-slide="prev" href="#media" class="left carousel-control">‹</a> <a data-slide="next" href="#media" class="right carousel-control">›</a> </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>User Projects</h3>
            <img src="{{url('/')}}/images2/12.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <span>0 active products.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="">Add or manage your products <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>User Listing</h3>
            <img src="{{url('/')}}/images2/13.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <span>No recent payments.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="">View your payments <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Payments</h3>
            <img src="{{url('/')}}/images2/14.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have no Order in the last week. View <span>Previous Orders here.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="">Manage your Orders <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Performance</h4>
        </div>
      </div>
      <div class="row mt-20">
        <div class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-4">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="tabbable-panel mt-20 ">
          <div class="tabbable-line">
                      <div class="row">
              <ul class="nav nav-tabs tabtop">
                <li class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-2 active"> <a href="#tab_default_1" data-toggle="tab"> Property View </a> </li>
                <li class="col-lg-2 col-sm-12 col-xs-12 "> <a href="#tab_default_2" data-toggle="tab"> Property Visit</a> </li>
                <li class="col-lg-2 col-sm-12 col-xs-12" > <a href="#tab_default_3" data-toggle="tab"> Emails </a> </li>
                <li class="col-lg-2 col-sm-12 col-xs-12 "> <a href="#tab_default_4" data-toggle="tab"> Phone View</a> </li>
              </ul>
            </div>

            <div class="tab-content mt-20">
              <div class="tab-pane active fade in" id="tab_default_1">
                <div class="col-md-10">
                  <div class="row">
                    <div class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-2">
                      <div class="tab-insidebox">
                        <h4 class="">All</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Super Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Paid</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Free</h4>
                        <p>40</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="tab_default_2">
                <div class="col-md-10">
                  <div class="row">
                    <div class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-2">
                      <div class="tab-insidebox">
                        <h4 class="">All</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Super Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Paid</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Free</h4>
                        <p>40</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="tab_default_3">
                <div class="col-md-10">
                  <div class="row">
                    <div class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-2">
                      <div class="tab-insidebox">
                        <h4 class="">All</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Super Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Paid</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Free</h4>
                        <p>40</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="tab_default_4">
                <div class="col-md-10">
                  <div class="row">
                    <div class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-2">
                      <div class="tab-insidebox">
                        <h4 class="">All</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Super Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Hot</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Paid</h4>
                        <p>40</p>
                      </div>
                    </div>
                    <div class="col-lg-2 col-sm-12 col-xs-12">
                      <div class="tab-insidebox">
                        <h4 class="">Free</h4>
                        <p>40</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Recent Upload Listing</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
       <div class="x_content">
            <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Price</th>
                  <th>Purpose</th>
                  <th>Area</th>
                  <th>Unit</th>
                  <th>City</th>
                  <th>Location</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>11</td>
                  <td>3 Marla House For Sale</td>
                  <td>11,000,000</td>
                  <td>For Sale</td>
                  <td>10</td>
                  <td>Marla</td>
                  <td>Lahore</td>
                  <td>Johar Town</td>
                  <td><a href="" class="green">Edit</a>&nbsp;&nbsp; <a href="" class="green">View</a>&nbsp;&nbsp; <a href="" class="red">Delete</a></td>
                </tr>
                <tr>
                  <td>11</td>
                  <td>3 Marla House For Sale</td>
                  <td>11,000,000</td>
                  <td>For Sale</td>
                  <td>10</td>
                  <td>Marla</td>
                  <td>Lahore</td>
                  <td>Johar Town</td>
                  <td><a href="" class="green">Edit</a>&nbsp;&nbsp; <a href="" class="green">View</a>&nbsp;&nbsp; <a href="" class="red">Delete</a></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Recent Upload Projects</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content">
           <table id="datatable-responsive2" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Type of Property</th>
                  <th>Type of Listing</th>
                  <th>Purpose</th>
                  <th>Location</th>
                  <th>City</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>11</td>
                  <td>3 Marla House For Sale</td>
                  <td>Residental, House</td>
                  <td>Super Hot</td>
                  <td>For Sale, Rent</td>
                  <td>Johar Town</td>
                  <td>Lahore</td>
                  <td><a href="" class="green">View</a></td>
                </tr>
                <tr>
                  <td>11</td>
                  <td>3 Marla House For Sale</td>
                  <td>Residental, House</td>
                  <td>Super Hot</td>
                  <td>For Sale, Rent</td>
                  <td>Johar Town</td>
                  <td>Lahore</td>
                  <td><a href="" class="green">View</a></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

  </div>
</div>


      @endsection
