@extends('adminRealtor.layout.appAdminRealtor')

<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }

  </script>

<script>
  var OrgID=-1;
    function getProjectId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }

  </script>
@section('content')


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="textcen" style="margin-top:0px !important;">
            <h4 style="margin:0px;">Property Management</h4>
          </div>
        </div>
      </div>

      <div class="clearfix"></div>
      <div class="tabbable-panel mt-20">
          <div class="tabbable-line">
            <div class="row">
              <ul class="nav nav-tabs">
                <li class="col-lg-2 col-sm-12 col-xs-12 col-lg-offset-4 active"> <a href="#tab_default_1" data-toggle="tab"> Listing </a> </li>
                <li class="col-lg-2 col-sm-12 col-xs-12 "> <a href="#tab_default_2" data-toggle="tab"> Project</a> </li>

              </ul>
            </div>
            <div class="tab-content margin-tops">

            <div class="tab-pane active fade in" id="tab_default_1">







         <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">All Listing By Sale</h4>
        </div>
      </div>
           <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
      <a href="{{url('/')}}/realtor/home/add/property"><button type="button" class="btn btnnav" style="float:left;">Add Listing</button></a>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;">
            <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Price</th>
                  <th>Purpose</th>
                  <th>Area</th>
                  <th>Unit</th>
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                
             @if(count($sale)>0)
             @foreach($sale as $results)
             <tr>
             <td>{{$results->pk_id}}</td>
             <td>{{$results->property_title}}</td>
             <td>{{number_format($results->price)}}</td>
             <td>For Sale</td>
             <td>{{$results->area}}</td>
             <td>{{$results->unit}}</td>
             <td>{{$results->city}}</td>
             <td>{{$results->location}}</td>
             @if($results->property_type == 0)
             <td><label  id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Premium</label></td>
             @endif
             @if($results->property_type == 1)
             <td><label  id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Hot</label></td>
             @endif
             @if($results->property_type == 2)
             <td><label  id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Super Hot</label></td>
             @endif
             <td><a href="{{url('/')}}/realtor/home/edit/property/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/property/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/property/{{$results->pk_id}}" class="red">Delete</a></td>
           </tr>


                @endforeach
                @endif
              </tbody>
            </table>
          </div>
        </div>
      </div>

           <!-- Modal -->
           <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
  
        <div class="form-group">
                    <select class="form-control" id="status" name="status" >

                      <option value="0">Premium</option>
                      <option value="1">Hot</option>
                      <option value="2 ">Super Hot</option>
                      </select>
                      </div>
                      <button id="type" type="button" class="btn btnsubmit"> Submit</button>
      
      </div>
    </div>

  </div>
</div>



         <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">All Listing For Rent</h4>
        </div>
      </div>


      <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;
}">
            <table id="datatable-responsive2" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Price</th>
                  <th>Purpose</th>
                  <th>Area</th>
                  <th>Unit</th>
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($rent)>0)
             @foreach($rent as $results)
             <tr>
                  <td>{{$results->pk_id}}</td>
                  <td>{{$results->property_title}}</td>
                  <td>{{number_format($results->price)}}</td>
                  <td>For Rent</td>
                  <td>{{$results->area}}</td>
                  <td>{{$results->unit}}</td>
                  <td>{{$results->city}}</td>
                  <td>{{$results->location}}</td>
                  @if($results->property_type == 0)
             <td><label  id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Premium</label></td>
             @endif
             @if($results->property_type == 1)
             <td><label  id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Hot</label></td>
             @endif
             @if($results->property_type == 2)
             <td><label  id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Super Hot</label></td>
             @endif  
             <td><a href="{{url('/')}}/realtor/home/edit/property/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/property/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/property/{{$results->pk_id}}" class="red">Delete</a></td>
           </tr>

 
                @endforeach
                @endif
         
              </tbody>
            </table>
          </div>
        </div>
      </div>




         <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">All Listing For Super Hot</h4>
        </div>
      </div>


      <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;
}">
            <table id="datatable-responsive3"  class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Price</th>
                  <th>Purpose</th>
                  <th>Area</th>
                  <th>Unit</th>
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($superhot)>0)
             @foreach($superhot as $results)
             <tr>
             <td>{{$results->pk_id}}</td>
             <td>{{$results->property_title}}</td>
             <td>{{number_format($results->price)}}</td>
             <td>For Sale</td>
             <td>{{$results->area}}</td>
             <td>{{$results->unit}}</td>
             <td>{{$results->city}}</td>
             <td>{{$results->location}}</td>
             <td><label class="label label-success">Super Hot</label></td>
             <td><a href="{{url('/')}}/realtor/home/edit/property/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/property/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/property/{{$results->pk_id}}" class="red">Delete</a></td>
             </tr>
           @endforeach
           @endif
        
              </tbody>
            </table>
          </div>
        </div>
      </div>





         <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">All Listing For Hot</h4>
        </div>
      </div>


      <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;
}">
            <table id="datatable-responsive4" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Price</th>
                  <th>Purpose</th>
                  <th>Area</th>
                  <th>Unit</th>
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($hot)>0)
              @foreach($hot as $results)
              <tr>
              <td>{{$results->pk_id}}</td>
              <td>{{$results->property_title}}</td>
              <td>{{number_format($results->price)}}</td>
              <td>For Sale</td>
              <td>{{$results->area}}</td>
              <td>{{$results->unit}}</td>
              <td>{{$results->city}}</td>
              <td>{{$results->location}}</td>
              <td><label class="label label-success">Hot</label></td>
              <td><a href="{{url('/')}}/realtor/home/edit/property/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/property/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/property/{{$results->pk_id}}" class="red">Delete</a></td>
          
           </tr>
            @endforeach
            @endif
         
              </tbody>
            </table>
          </div>
        </div>
      </div>






                </div>
              <div class="tab-pane fade in" id="tab_default_2">

                <div class="row mt-20">
    <div class="col-md-12 col-sm-12 col-xs-12">
          <h4 style="text-align:center;font-weight:bold;">All Project</h4>
        </div>
         </div>


         <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
        <a href="{{url('/')}}/realtor/home/add/project"><button type="button" class="btn btnnav" style="float:left;">Add Project</button></a>
      
       </div>
      </div>





      <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Listing project For Sale</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;
}">
            <table id="datatable-responsive5" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Purpose</th>
           
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($sales)>0)
              @foreach($sales as $results)
              <tr>
              <td>{{$results->pk_id}}</td>
              <td>{{$results->property_title}}</td>
       
              <td>For Sale</td>
         
              <td>{{$results->city}}</td>
              <td>{{$results->location}}</td>
              @if($results->property_type == 0)
              <td><label  id="{{$results->pk_id}}" onclick="getProjectId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModals">Premium</label></td>
              @endif
              @if($results->property_type == 1)
              <td><label  id="{{$results->pk_id}}" onclick="getProjectId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModals">Hot</label></td>
              @endif
              @if($results->property_type == 2)
              <td><label  id="{{$results->pk_id}}" onclick="getProjectId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModals">Super Hot</label></td>
              @endif
              <td><a href="{{url('/')}}/realtor/home/edit/project/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/project/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/project/{{$results->pk_id}}" class="red">Delete</a></td>
            </tr>
 
 
                 @endforeach
                 @endif
              </tbody>
            </table>
          </div>
        </div>
      </div>


        <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Listing project For Rent</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;
}">
            <table id="datatable-responsive6" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
           
                  <th>Purpose</th>
          
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($rents)>0)
             @foreach($rents as $results)
             <tr>
                  <td>{{$results->pk_id}}</td>
                  <td>{{$results->property_title}}</td>
             
                  <td>For Rent</td>
              
          
                  <td>{{$results->city}}</td>
                  <td>{{$results->location}}</td>
                  @if($results->property_type == 0)
             <td><label  id="{{$results->pk_id}}" onclick="getProjectId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModals">Premium</label></td>
             @endif
             @if($results->property_type == 1)
             <td><label  id="{{$results->pk_id}}" onclick="getProjectId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModals">Hot</label></td>
             @endif
             @if($results->property_type == 2)
             <td><label  id="{{$results->pk_id}}" onclick="getProjectId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModals">Super Hot</label></td>
             @endif  
             <td><a href="{{url('/')}}/realtor/home/edit/project/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/project/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/project/{{$results->pk_id}}" class="red">Delete</a></td>
           </tr>

 
                @endforeach
                @endif
              </tbody>
            </table>
          </div>
        </div>
      </div>




        <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Listing project For Super Hot</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;
}">
            <table id="datatable-responsive7" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Purpose</th>
            
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($superhots)>0)
             @foreach($superhots as $results)
             <tr>
             <td>{{$results->pk_id}}</td>
             <td>{{$results->property_title}}</td>
             <td>For Sale</td>
 
             <td>{{$results->city}}</td>
             <td>{{$results->location}}</td>
             <td><label class="label label-success">Super Hot</label></td>
             <td><a href="{{url('/')}}/realtor/home/edit/project/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/project/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/project/{{$results->pk_id}}" class="red">Delete</a></td>
             </tr>
           @endforeach
           @endif
              </tbody>
            </table>
          </div>
        </div>
      </div>





        <div class="row mt-20">
        <div class="col-lg-6">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="search" class="form-control" id="" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>

      <div class="row mt-20">
        <div class="col-lg-3 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Filter by Type :</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <select class="form-control" name="">
                <option value="">All</option>
                <option value="">All</option>
                <option value="">All</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-12 col-sm-12 col-form-label" style="text-align:center;">Date Range:</label>

          </div>
        </div>
        <div class="col-lg-2 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">From:</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <input type="" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-3 col-sm-12 col-form-label" style="text-align:center;">To:</label>
            <div class="col-lg-4 col-sm-12 col-xs-12">
              <input type="" class="form-control" id="" placeholder="">
            </div>
            <div class="col-lg-5 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 100%;">Filter Results</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
          <h4 style="font-weight:bold;">My Listing project For Hot</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content" style="box-shadow: 1px 0px 10px 0 rgba(0,0,0,.2), 0 6px 4px 0 rgba(0,0,0,.19);padding:2rem;}">
            <table id="datatable-responsive8" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Title</th>
                  <th>Purpose</th>
               
                  <th>City</th>
                  <th>Location</th>
                  <th>Listing Type</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
              @if(count($hots)>0)
              @foreach($hots as $results)
              <tr>
              <td>{{$results->pk_id}}</td>
              <td>{{$results->property_title}}</td>
              <td>For Sale</td>
       
              <td>{{$results->city}}</td>
              <td>{{$results->location}}</td>
              <td><label class="label label-success">Hot</label></td>
              <td><a href="{{url('/')}}/realtor/home/edit/project/{{$results->pk_id}}" class="green">Edit</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/view/project/detail/{{$results->pk_id}}" class="green">View</a>&nbsp;&nbsp; <a href="{{url('/')}}/realtor/home/delete/project/{{$results->pk_id}}" class="red">Delete</a></td>
          
           </tr>
            @endforeach
            @endif
              </tbody>
            </table>
          </div>
        </div>
      </div>

                </div>

       <!-- Modal -->
       <div id="myModals" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Modal Header</h4>
      </div>
      <div class="modal-body">
  
        <div class="form-group">
                    <select class="form-control" id="status" name="status" >

                      <option value="0">Premium</option>
                      <option value="1">Hot</option>
                      <option value="2 ">Super Hot</option>
                      </select>
                      </div>
                      <button id="project" type="button" class="btn btnsubmit"> Submit</button>
      
      </div>
    </div>

  </div>
</div>


            </div>
          </div>
        </div>
    </div>
    <!-- /page content -->


  </div>

@endsection
