@extends('adminRealtor.layout.appAdminRealtor')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="container">
          <div class="row mt-30">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="textcen" style="margin-top:0px !important;">
                <h4 style="margin:0px;">Post Listing</h4>
              </div>
            </div>
          </div>
          <form method="post" action = "{{url('/')}}/realtor/home/edit/project/{{$result[0]->pk_id}}" class="login-form" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            @if($errors->any())

<div class="alert alert-danger">
  <strong></strong> {{$errors->first()}}
</div>
@endif
          <div class="row mt-30">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="listingheads">
                <h4>Property Type & Location</h4>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Purpose:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="rent"  class="custom-control-input" id="defaultChecked91" @if($result[0]->rent == 1) checked @endif>
                    <label class="custom-control-label" for="defaultChecked91">For Rent</label>
                  </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="sale" class="custom-control-input" id="defaultChecked92" @if($result[0]->sale == 1) checked @endif>
                    <label class="custom-control-label" for="defaultChecked92">For Sale</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Property Type:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="home" @if($result[0]->home == 1) checked @endif class="custom-control-input" id="defaultChecked93">
                    <label class="custom-control-label" for="defaultChecked93">Homes</label>
                  </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="plot" @if($result[0]->plots == 1) checked @endif class="custom-control-input" id="defaultChecked94">
                    <label class="custom-control-label" for="defaultChecked94">Plots</label>
                  </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="commercial" @if($result[0]->commercial == 1) checked @endif class="custom-control-input" id="defaultChecked95">
                    <label class="custom-control-label" for="defaultChecked95">Commercial</label>
                  </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="land" @if($result[0]->land == 1) checked @endif class="custom-control-input" id="defaultChecked96">
                    <label class="custom-control-label" for="defaultChecked96">Agriculture Land</label>
                  </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="flat" @if($result[0]->flats == 1) checked @endif class="custom-control-input" id="defaultChecked97">
                    <label class="custom-control-label" for="defaultChecked97">Flats</label>
                  </div>
                </div>
                <div class="col-lg-4 col-sm-12 col-xs-12">
                  <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="office" @if($result[0]->offices == 1) checked @endif class="custom-control-input" id="defaultChecked98">
                    <label class="custom-control-label" for="defaultChecked98">Offices</label>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>City:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-10 col-sm-12 col-xs-12">
                  <div class="form-group text-left signinlabelssets">
                    <select class="form-control" name="city"  style="background-color:#D2D6DB;width:100%;">

                      <option value="Ahmadpur East">Ahmadpur East</option>
                      <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                      <option value="Alipur">Alipur</option>
                      <option value="Arifwala">Arifwala</option>
                      <option value="Attock City">Attock City</option>
                      <option value="Baddomalhi">Baddomalhi</option>
                      <option value="Bahawalnagar">Bahawalnagar</option>
                      <option value="Bahawalpur">Bahawalpur</option>
                      <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                      <option value="Basirpur">Basirpur</option>
                      <option value="Basti Dosa">Basti Dosa</option>
                      <option value="Begowala">Begowala</option>
                      <option value="Bhai Pheru">Bhai Pheru</option>
                      <option value="Bhakkar">Bhakkar</option>
                      <option value="Bhalwal">Bhalwal</option>
                      <option value="Bhawana">Bhawana</option>
                      <option value="Bhera">Bhera</option>
                      <option value="Bhopalwala">Bhopalwala</option>
                      <option value="Burewala">Burewala</option>
                      <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                      <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                      <option value="Chakwal">Chakwal</option>
                      <option value="Chawinda">Chawinda</option>
                      <option value="Chichawatni">Chichawatni</option>
                      <option value="Chiniot">Chiniot</option>
                      <option value="Chishtian Mandi">Chishtian Mandi</option>
                      <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                      <option value="Chuhar Kana">Chuhar Kana</option>
                      <option value="Chunian">Chunian</option>
                      <option value="Daira Din Panah">Daira Din Panah</option>
                      <option value="Dajal">Dajal</option>
                      <option value="Dandot RS">Dandot RS</option>
                      <option value="Darya Khan">Darya Khan</option>
                      <option value="Daska">Daska</option>
                      <option value="Daud Khel">Daud Khel</option>
                      <option value="Daultala">Daultala</option>
                      <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                      <option value="Dhanot">Dhanot</option>
                      <option value="Dhaunkal">Dhaunkal</option>
                      <option value="Dijkot">Dijkot</option>
                      <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                      <option value="Dinga">Dinga</option>
                      <option value="Dipalpur">Dipalpur</option>
                      <option value="Dullewala">Dullewala</option>
                      <option value="Dunga Bunga">Dunga Bunga</option>
                      <option value="Dunyapur">Dunyapur</option>
                      <option value="Eminabad">Eminabad</option>
                      <option value="Faisalabad">Faisalabad</option>
                      <option value="Faqirwali">Faqirwali</option>
                      <option value="Faruka">Faruka</option>
                      <option value="Fazilpur">Fazilpur</option>
                      <option value="Fort Abbas">Fort Abbas</option>
                      <option value="Garh Maharaja">Garh Maharaja</option>
                      <option value="Gojra">Gojra</option>
                      <option value="Gujar Khan">Gujar Khan</option>
                      <option value="Gujranwala">Gujranwala</option>
                      <option value="Gujrat">Gujrat</option>
                      <option value="Hadali">Hadali</option>
                      <option value="Hafizabad">Hafizabad</option>
                      <option value="Harnoli">Harnoli</option>
                      <option value="Haru Zbad">Haru Zbad</option>
                      <option value="Hasan Abdal">Hasan Abdal</option>
                      <option value="Hasilpur">Hasilpur</option>
                      <option value="Haveli">Haveli</option>
                      <option value="Hazro City">Hazro City</option>
                      <option value="Hujra">Hujra</option>
                      <option value="Jahanian Shah">Jahanian Shah</option>
                      <option value="Jalalpur">Jalalpur</option>
                      <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                      <option value="Jampur">Jampur</option>
                      <option value="Jand">Jand</option>
                      <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                      <option value="Jaranwala">Jaranwala</option>
                      <option value="Jatoi Shimali">Jatoi Shimali</option>
                      <option value="Jauharabad">Jauharabad</option>
                      <option value="Jhang City">Jhang City</option>
                      <option value="Jhang Sadr">Jhang Sadr</option>
                      <option value="Jhawarian">Jhawarian</option>
                      <option value="Jhelum">Jhelum</option>
                      <option value="Jhumra">Jhumra</option>
                      <option value="Kabirwala">Kabirwala</option>
                      <option value="Kahna">Kahna</option>
                      <option value="Kahuta">Kahuta</option>
                      <option value="Kalabagh">Kalabagh</option>
                      <option value="Kalaswala">Kalaswala</option>
                      <option value="Kaleke Mandi">Kaleke Mandi</option>
                      <option value="Kallar Kahar">Kallar Kahar</option>
                      <option value="Kalur Kot">Kalur Kot</option>
                      <option value="Kamalia">Kamalia</option>
                      <option value="Kamar Mushani">Kamar Mushani</option>
                      <option value="Kamir">Kamir</option>
                      <option value="Kamoke">Kamoke</option>
                      <option value="Kamra">Kamra</option>
                      <option value="Kanganpur">Kanganpur</option>
                      <option value="Karor">Karor</option>
                      <option value="Kasur">Kasur</option>
                      <option value="Keshupur">Keshupur</option>
                      <option value="Khairpur">Khairpur</option>
                      <option value="Khanewal">Khanewal</option>
                      <option value="Khangah Dogran">Khangah Dogran</option>
                      <option value="Khangarh">Khangarh</option>
                      <option value="Khanpur">Khanpur</option>
                      <option value="Kharian">Kharian</option>
                      <option value="Khewra">Khewra</option>
                      <option value="Khurrianwala">Khurrianwala</option>
                      <option value="Khushab">Khushab</option>
                      <option value="Kohror Pakka">Kohror Pakka</option>
                      <option value="Kot Addu">Kot Addu</option>
                      <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                      <option value="Kot Mumin">Kot Mumin</option>
                      <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                      <option value="Kot Samaba">Kot Samaba</option>
                      <option value="Kot Sultan">Kot Sultan</option>
                      <option value="Kotli Loharan">Kotli Loharan</option>
                      <option value="Kundian">Kundian</option>
                      <option value="Kunjah">Kunjah</option>
                      <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                      <option value="Lahore">Lahore</option>
                      <option value="Lala Musa">Lala Musa</option>
                      <option value="Lalian">Lalian</option>
                      <option value="Layyah">Layyah</option>
                      <option value="Liliani">Liliani</option>
                      <option value="Lodhran">Lodhran</option>
                      <option value="Mailsi">Mailsi</option>
                      <option value="Malakwal">Malakwal</option>
                      <option value="Malakwal City">Malakwal City</option>
                      <option value="Mamu Kanjan">Mamu Kanjan</option>
                      <option value="Mananwala">Mananwala</option>
                      <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                      <option value="Mangla">Mangla</option>
                      <option value="Mankera">Mankera</option>
                      <option value="Mehmand Chak">Mehmand Chak</option>
                      <option value="Mian Channun">Mian Channun</option>
                      <option value="Mianwali">Mianwali</option>
                      <option value="Minchinabad">Minchinabad</option>
                      <option value="Mitha Tiwana">Mitha Tiwana</option>
                      <option value="Moza Shahwala">Moza Shahwala</option>
                      <option value="Multan">Multan</option>
                      <option value="Muridke">Muridke</option>
                      <option value="Murree">Murree</option>
                      <option value="Mustafabad">Mustafabad</option>
                      <option value="Muzaffargarh">Muzaffargarh</option>
                      <option value="Nankana Sahib">Nankana Sahib</option>
                      <option value="Narang">Narang</option>
                      <option value="Narowal">Narowal</option>
                      <option value="Naushahra Virkan">Naushahra Virkan</option>
                      <option value="Nazir Town">Nazir Town</option>
                      <option value="Okara">Okara</option>
                      <option value="Pakpattan">Pakpattan</option>
                      <option value="Pasrur">Pasrur</option>
                      <option value="Pattoki">Pattoki</option>
                      <option value="Phalia">Phalia</option>
                      <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                      <option value="Pindi Bhattian">Pindi Bhattian</option>
                      <option value="Pindi Gheb">Pindi Gheb</option>
                      <option value="Pir Mahal">Pir Mahal</option>
                      <option value="Qadirpur Ran">Qadirpur Ran</option>
                      <option value="Rabwah">Rabwah</option>
                      <option value="Raiwind">Raiwind</option>
                      <option value="Raja Jang">Raja Jang</option>
                      <option value="Rajanpur">Rajanpur</option>
                      <option value="Rasulnagar">Rasulnagar</option>
                      <option value="Rawalpindi">Rawalpindi</option>
                      <option value="Renala Khurd">Renala Khurd</option>
                      <option value="Rojhan">Rojhan</option>
                      <option value="Sadiqabad">Sadiqabad</option>
                      <option value="Sahiwal">Sahiwal</option>
                      <option value="Sambrial">Sambrial</option>
                      <option value="Sangla Hill">Sangla Hill</option>
                      <option value="Sanjwal">Sanjwal</option>
                      <option value="Sarai Alamgir">Sarai Alamgir</option>
                      <option value="Sarai Sidhu">Sarai Sidhu</option>
                      <option value="Sargodha">Sargodha</option>
                      <option value="Shahkot">Shahkot</option>
                      <option value="Shahpur">Shahpur</option>
                      <option value="Shahr Sultan">Shahr Sultan</option>
                      <option value="Shakargarh">Shakargarh</option>
                      <option value="Sharqpur">Sharqpur</option>
                      <option value="Sheikhupura">Sheikhupura</option>
                      <option value="Shujaabad">Shujaabad</option>
                      <option value="Sialkot">Sialkot</option>
                      <option value="Sillanwali">Sillanwali</option>
                      <option value="Sodhra">Sodhra</option>
                      <option value="Sukheke Mandi">Sukheke Mandi</option>
                      <option value="Surkhpur">Surkhpur</option>
                      <option value="Talagang">Talagang</option>
                      <option value="Talamba">Talamba</option>
                      <option value="Tandlianwala">Tandlianwala</option>
                      <option value="Taunsa">Taunsa</option>
                      <option value="Toba Tek Singh">Toba Tek Singh</option>
                      <option value="Vihari">Vihari</option>
                      <option value="Warburton">Warburton</option>
                      <option value="Wazirabad">Wazirabad</option>
                      <option value="Yazman">Yazman</option>
                      <option value="Zafarwal">Zafarwal</option>
                      <option value="Zahir Pir">Zahir Pir</option>
                      <option value="Adilpur">Adilpur</option>
                      <option value="Badin">Badin</option>
                      <option value="Bagarji">Bagarji</option>
                      <option value="Bandhi">Bandhi</option>
                      <option value="Berani">Berani</option>
                      <option value="Bhan">Bhan</option>
                      <option value="Bhiria">Bhiria</option>
                      <option value="Bhit Shah">Bhit Shah</option>
                      <option value="Bozdar">Bozdar</option>
                      <option value="Bulri">Bulri</option>
                      <option value="Chak">Chak</option>
                      <option value="Chambar">Chambar</option>
                      <option value="Chhor">Chhor</option>
                      <option value="Chuhar Jamali">Chuhar Jamali</option>
                      <option value="Dadu">Dadu</option>
                      <option value="Daro Mehar">Daro Mehar</option>
                      <option value="Darya Khan Marri">Darya Khan Marri</option>
                      <option value="Daulatpur">Daulatpur</option>
                      <option value="Daur">Daur</option>
                      <option value="Dhoro Naro">Dhoro Naro</option>
                      <option value="Digri">Digri</option>
                      <option value="Diplo">Diplo</option>
                      <option value="Dokri">Dokri</option>
                      <option value="Gambat">Gambat</option>
                      <option value="Garhi Yasin">Garhi Yasin</option>
                      <option value="Gharo">Gharo</option>
                      <option value="Ghauspur">Ghauspur</option>
                      <option value="Ghotki">Ghotki</option>
                      <option value="Goth Garelo">Goth Garelo</option>
                      <option value="Hala">Hala</option>
                      <option value="Hingorja">Hingorja</option>
                      <option value="Hyderabad">Hyderabad</option>
                      <option value="Islamkot">Islamkot</option>
                      <option value="Jacobabad">Jacobabad</option>
                      <option value="Jam Sahib">Jam Sahib</option>
                      <option value="Jamshoro">Jamshoro</option>
                      <option value="Jati">Jati</option>
                      <option value="Jhol">Jhol</option>
                      <option value="Johi">Johi</option>
                      <option value="Kadhan">Kadhan</option>
                      <option value="Kambar">Kambar</option>
                      <option value="Kandhkot">Kandhkot</option>
                      <option value="Kandiari">Kandiari</option>
                      <option value="Kandiaro">Kandiaro</option>
                      <option value="Karachi">Karachi</option>
                      <option value="Karaundi">Karaundi</option>
                      <option value="Kario">Kario</option>
                      <option value="Kashmor">Kashmor</option>
                      <option value="Keti Bandar">Keti Bandar</option>
                      <option value="Khadro">Khadro</option>
                      <option value="Khairpur">Khairpur</option>
                      <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                      <option value="Khanpur">Khanpur</option>
                      <option value="Kot Diji">Kot Diji</option>
                      <option value="Kotri">Kotri</option>
                      <option value="Kunri">Kunri</option>
                      <option value="Lakhi">Lakhi</option>
                      <option value="Larkana">Larkana</option>
                      <option value="Madeji">Madeji</option>
                      <option value="Malir Cantonment">Malir Cantonment</option>
                      <option value="Matiari">Matiari</option>
                      <option value="Matli">Matli</option>
                      <option value="Mehar">Mehar</option>
                      <option value="Miro Khan">Miro Khan</option>
                      <option value="Mirpur Batoro">Mirpur Batoro</option>
                      <option value="Mirpur Khas">Mirpur Khas</option>
                      <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                      <option value="Mirpur Sakro">Mirpur Sakro</option>
                      <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                      <option value="Mithi">Mithi</option>
                      <option value="Moro">Moro</option>
                      <option value="Nabisar">Nabisar</option>
                      <option value="Nasirabad">Nasirabad</option>
                      <option value="Naudero">Naudero</option>
                      <option value="Naukot">Naukot</option>
                      <option value="Naushahro Firoz">Naushahro Firoz</option>
                      <option value="Nawabshah">Nawabshah</option>
                      <option value="New Badah">New Badah</option>
                      <option value="Pad Idan">Pad Idan</option>
                      <option value="Pano Aqil">Pano Aqil</option>
                      <option value="Phulji">Phulji</option>
                      <option value="Pir Jo Goth">Pir Jo Goth</option>
                      <option value="Pithoro">Pithoro</option>
                      <option value="Radhan">Radhan</option>
                      <option value="Rajo Khanani">Rajo Khanani</option>
                      <option value="Ranipur">Ranipur</option>
                      <option value="Ratodero">Ratodero</option>
                      <option value="Rohri">Rohri</option>
                      <option value="Rustam">Rustam</option>
                      <option value="Sakrand">Sakrand</option>
                      <option value="Samaro">Samaro</option>
                      <option value="Sanghar">Sanghar</option>
                      <option value="Sann">Sann</option>
                      <option value="Sehwan">Sehwan</option>
                      <option value="Setharja Old">Setharja Old</option>
                      <option value="Shahdad Kot">Shahdad Kot</option>
                      <option value="Shahdadpur">Shahdadpur</option>
                      <option value="Shahpur Chakar">Shahpur Chakar</option>
                      <option value="Shikarpur">Shikarpur</option>
                      <option value="Sinjhoro">Sinjhoro</option>
                      <option value="Sita Road">Sita Road</option>
                      <option value="Sobhodero">Sobhodero</option>
                      <option value="Sukkur">Sukkur</option>
                      <option value="Talhar">Talhar</option>
                      <option value="Tando Adam">Tando Adam</option>
                      <option value="Tando Allahyar">Tando Allahyar</option>
                      <option value="Tando Bago">Tando Bago</option>
                      <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                      <option value="Tando Jam">Tando Jam</option>
                      <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                      <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                      <option value="Tangwani">Tangwani</option>
                      <option value="Tharu Shah">Tharu Shah</option>
                      <option value="Thatta">Thatta</option>
                      <option value="Thul">Thul</option>
                      <option value="Ubauro">Ubauro</option>
                      <option value="Umarkot">Umarkot</option>
                      <option value="Warah">Warah</option>
                      <option value="Abbottabad">Abbottabad</option>
                      <option value="Akora">Akora</option>
                      <option value="Alpurai">Alpurai</option>
                      <option value="Aman Garh">Aman Garh</option>
                      <option value="Amirabad">Amirabad</option>
                      <option value="Ashanagro Koto">Ashanagro Koto</option>
                      <option value="Baffa">Baffa</option>
                      <option value="Bannu">Bannu</option>
                      <option value="Bat Khela">Bat Khela</option>
                      <option value="Battagram">Battagram</option>
                      <option value="Charsadda">Charsadda</option>
                      <option value="Cherat Cantonement">Cherat Cantonement</option>
                      <option value="Chitral">Chitral</option>
                      <option value="Daggar">Daggar</option>
                      <option value="Dasu">Dasu</option>
                      <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                      <option value="Doaba">Doaba</option>
                      <option value="Hangu">Hangu</option>
                      <option value="Haripur">Haripur</option>
                      <option value="Havelian">Havelian</option>
                      <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                      <option value="Karak">Karak</option>
                      <option value="Khalabat">Khalabat</option>
                      <option value="Kohat">Kohat</option>
                      <option value="Kulachi">Kulachi</option>
                      <option value="Lachi">Lachi</option>
                      <option value="Lakki Marwat">Lakki Marwat</option>
                      <option value="Malakand">Malakand</option>
                      <option value="Mansehra">Mansehra</option>
                      <option value="Mardan">Mardan</option>
                      <option value="Mingora">Mingora</option>
                      <option value="Noorabad">Noorabad</option>
                      <option value="Nowshera">Nowshera</option>
                      <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                      <option value="Pabbi">Pabbi</option>
                      <option value="Paharpur">Paharpur</option>
                      <option value="Peshawar">Peshawar</option>
                      <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                      <option value="Saidu Sharif">Saidu Sharif</option>
                      <option value="Sarai Naurang">Sarai Naurang</option>
                      <option value="Shabqadar">Shabqadar</option>
                      <option value="Shingli Bala">Shingli Bala</option>
                      <option value="Shorko">Shorko</option>
                      <option value="Swabi">Swabi</option>
                      <option value="Tal">Tal</option>
                      <option value="Tangi">Tangi</option>
                      <option value="Tank">Tank</option>
                      <option value="Timargara">Timargara</option>
                      <option value="Topi">Topi</option>
                      <option value="Upper Dir">Upper Dir</option>
                      <option value="Utmanzai">Utmanzai</option>
                      <option value="Zaida">Zaida</option>
                      <option value="Islamabad">Islamabad</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Location:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-10 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <input type="text" class="form-control blueborder" value="{{$result[0]->location}}" id="" placeholder="" name="location" style="width:100%;">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-20">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="listingheads">
                <h4>Property Details</h4>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Project Title:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-10 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <input type="text" class="form-control blueborder" id="" placeholder="" value="{{$result[0]->property_title}}" name="title" style="width:100%;">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Description:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-10 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <textarea rows="3" cols="50" name="description" style="border:1px solid #ced4da;background-color:white;">{{$result[0]->description}}
</textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Add Document File:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-3 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <input type="file" value="{{$result[0]->document_file}}" class="form-control blueborder" id="" placeholder="" name="document_file" style="width:100%;">
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Add Payment Plan Img:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-12 col-sm-12 col-xs-12">
                  <input type="file" value="{{$result[0]->payment_plan_image}}" name="payment_plan" onchange="readURL(this);">
           <img id="blah" src="{{url('/')}}/storage/images/{{$result[0]->payment_plan_image}}" alt="yourimage" width="180px;"  height="180px;">
                </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Add Features:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-12 col-sm-12 col-xs-12"> <a href="#open-modals" title="Quick view" data-toggle="modal" class="btn submitbtn  btn-responsive" aria-expanded="false" style="margin:0px !important;font-size:12px !important;padding:6px 8px;">Add Features</a> </div>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="listingheads">
                <label>Expires After:*</label>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-8 col-sm-12 col-xs-12">
                  <div class="form-group text-left signinlabelssets">
                    <select class="form-control" name="expiry_date"  style="background-color:#D2D6DB;width:100%;">
                      <option value="6 Months" @if($result[0]->expiry_date) == "6 Months" selected @endif >6 Months</option>
                      <option value="1 Year" @if($result[0]->expiry_date) == "1 Year" selected @endif >1 Year</option>
                      <option value="2 Years" @if($result[0]->expiry_date) == "2 Years" selected @endif >2 Years</option>
                      <option value="3 Years" @if($result[0]->expiry_date) == "3 Years" selected @endif >3 Years</option>
                      <option value="4 years" @if($result[0]->expiry_date) == "4 Years" selected @endif>4 years</option>
                      <option value="5 years" @if($result[0]->expiry_date) == "5 Years" selected @endif>5 years</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-20">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="listingheads">
                <h4>Add Images</h4>
              </div>
            </div>
          </div>
          <div class="row justify-content-center mt-20">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
           <input id="files" type="file" name="file[]" multiple/>
          <div class="row mt-20">
  <output id="result" />
  </div>

            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <div class="row">
                <div class="col-lg-12 col-sm-12 col-xs-12"> </div>
              </div>
            </div>
          </div>

          <div class="row mt-20 mb-40">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <button type="submit" class="btn submitbtn  btn-responsive" aria-expanded="false">SUBMIT PROPERTY</button>
            </div>
          </div>
        </div>
    </div>
    <!-- /page content -->

  </div>
  <div class="modal fade" id="open-modals" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width:63%;">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
        </div>
        <div class="modal-body">
          <div class="container">
            <div class="row mt-20">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="textcen" style="margin-top:0px !important;">
                  <h4 style="margin:0px;">Add Features</h4>
                </div>
              </div>
            </div>
            <div class="row mt-10">
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]" @if (strpos($result[0]->features, 'Built in year') == true)  checked @endif value="Built in year" class="custom-control-input" id="defaultChecked101">
                  <label class="custom-control-label" for="defaultChecked101">Built in year</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]" @if (strpos($result[0]->features, 'Parking Space') == true)  checked @endif   value="Parking Space" class="custom-control-input" id="defaultChecked102">
                  <label class="custom-control-label" for="defaultChecked102">Parking Space</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Double Glazed Window') == true)  checked @endif value="Double Glazed Window" class="custom-control-input" id="defaultChecked103">
                  <label class="custom-control-label" for="defaultChecked103">Double Glazed Window</label>
                </div>
              </div>
            </div>
            <div class="row mt-10">
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Central Air Conditioning') == true)  checked @endif value="Central Air Conditioning" class="custom-control-input" id="defaultChecked104">
                  <label class="custom-control-label" for="defaultChecked104">Central Air Conditioning</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'aCentral heating') == true)  checked @endif value="Central heating" class="custom-control-input" id="defaultChecked105">
                  <label class="custom-control-label" for="defaultChecked105">Central heating</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Flooring') == true)  checked @endif value="Flooring" class="custom-control-input" id="defaultChecked106">
                  <label class="custom-control-label" for="defaultChecked106">Flooring</label>
                </div>
              </div>
            </div>
            <div class="row mt-10">
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Electricity Backup') == true)  checked @endif value="Electricity Backup" class="custom-control-input" id="defaultChecked107">
                  <label class="custom-control-label" for="defaultChecked107">Electricity Backup</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Waste Disposal') == true)  checked @endif value="Waste Disposal" class="custom-control-input" id="defaultChecked108">
                  <label class="custom-control-label" for="defaultChecked108">Waste Disposal</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Floor 2') == true)  checked @endif value="Floor 2" class="custom-control-input" id="defaultChecked109">
                  <label class="custom-control-label" for="defaultChecked109">Floor 2</label>
                </div>
              </div>
            </div>
            <div class="row mt-10">
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="custom-control custom-checkbox mt-10">
                  <input type="checkbox" name="features[]"  @if (strpos($result[0]->features, 'Other Main Features') == true)  checked @endif  value="Other Main Features" class="custom-control-input" id="defaultChecked110">
                  <label class="custom-control-label" for="defaultChecked110">Other Main Features</label>
                </div>
              </div>
              <div class="col-md-4 col-sm-12 col-xs-12"> </div>
              <div class="col-md-4 col-sm-12 col-xs-12"> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </form>
  </div>
</div>
@endsection
