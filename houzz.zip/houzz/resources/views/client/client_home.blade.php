@extends('client.layout.appclient')
@section('content')
<style>
  /* Make the image fully responsive */
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
  </style>
<!--Slider Area Start-->
<div class="slider-area">
  <div class="hero-slider hero-slider-5 owl-carousel"> 
    <!--Single Slider Start-->
    <div class="single-slider-style-5" style="background-image: url({{url('/')}}/pic/sliderbackgound1.png)">
      <div class="slider-progress"></div>
      <div class="hero-slider-content hero-slider-content-6"> <img class="first-img" src="{{url('/')}}/pic/1sliderimg.png" alt="image"> </div>
    </div>
    <!--Single Slider End--> 
    <!--Single Slider Start-->
    <div class="single-slider-style-5" style="background-image: url({{url('/')}}/pic/sliderbackground2.png)">
      <div class="slider-progress"></div>
      <div class="hero-slider-content hero-slider-content-6"> <img class="first-img" src="{{url('/')}}/pic/2ndsliderimg.png" alt="image"> </div>
    </div>
    <!--Single Slider End--> 
    <!--Single Slider Start-->
    <div class="single-slider-style-5" style="background-image: url({{url('/')}}/pic/sliderBackground3.png)">
      <div class="slider-progress"></div>
      <div class="hero-slider-content hero-slider-content-6"> <img class="first-img" src="{{url('/')}}/pic/3rdsliderimg.png" alt="image"> </div>
    </div>
    <!--Single Slider End--> 
  </div>
</div>
<!--Slider Area End-->

<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="salogan mt-20">
        <h2 class="text-center font-weight-bold">Seller</h2>
        <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
      </div>
    </div>
  </div>
</div>

<!--Home Product Layout Area Start-->
<div class="container-fluid">
  <div class="row">
    <div class="col-lg-3">
      <div class="col-lg-12">
        <div class="main_image mt-10"> <img src="{{URL('/')}}/pic/f.png" alt="image"> </div>
      </div>
      <div class="col-lg-12">
        <div class="main_image mt-10"> <img src="{{URL('/')}}/pic/q.png" alt="image"> </div>
      </div>
      <div class="col-lg-12">
        <div class="main_image mt-10"> <img src="{{URL('/')}}/pic/w.png" alt="image"> </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="main_images mb-20"> <img src="{{URL('/')}}/pic/main.jpg" alt="image"> </div>
    </div>
    <div class="col-lg-3">
      <div class="col-lg-12">
        <div class="main_image mt-10"> <img src="{{URL('/')}}/pic/e.png" alt="image"> </div>
      </div>
      <div class="col-lg-12">
        <div class="main_image mt-10"> <img src="{{URL('/')}}/pic/r.png" alt="image"> </div>
      </div>
      <div class="col-lg-12">
        <div class="main_image mt-10"> <img src="{{URL('/')}}/pic/t.png" alt="image"> </div>
      </div>
    </div>
  </div>
</div>
<div class="">
  <div class="container-fluid">
    <div class="row justify-content-md-center">
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class="heading pt-15 pb-10 salogan text-center text-white mt-20">
          <h3 class="text-white">Top Rating Products</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bestseller-product mt-80">
  <div class="container">
    <div class="row">
      <div class="product-slider-active"> @if(count($res)>0)
        @foreach($res as $results)
        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12"> 
          <!--Single Product Start-->
          <div class="single-product mb-25">
            <div class="product-img img-full"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="{{$results->name}}"> </a> </div>
            <div class="product-content">
              <h2><a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">{{$results->name}}</a></h2>
              <div class="product-price">
                <div class="price-box"> <span class="regular-price">PKR {{number_format($results->price)}}</span> </div>
                <div class="add-to-cart"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">Add To Cart</a> </div>
              </div>
            </div>
          </div>
          <!--Single Product End--> 
        </div>
        @endforeach
        @endif </div>
    </div>
  </div>
</div>
<div class="">
  <div class="container-fluid">
    <div class="row justify-content-md-center">
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class=" heading pt-15 pb-10 salogan text-center text-white mt-20">
          <h3 class="text-white">Sale Products</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bestseller-product mt-80">
  <div class="container">
    <div class="row">
      <div class="product-slider-active"> @if(count($dis)>0)
        @foreach($dis as $results)
        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12"> 
          <!--Single Product Start-->
          <div class="single-product mb-25">
            <div class="product-img img-full"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="{{$results->name}}"> </a> </div>
            <div class="product-content">
              <h2><a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">{{$results->name}}</a></h2>
              <div class="single-product-price"> <span class="price new-price">PKR {{$results->price}}  Off {{$results->percentage}}%</span> <span class="regular-price">
                <h2 style="color:#689a29">PKR {{number_format($results->price - (($results->price*$results->percentage)/100))}}</h2>
                </span> </div>
              <div class="product-price">
                <div class="add-to-cart"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">Add To Cart</a> </div>
              </div>
            </div>
          </div>
          <!--Single Product End--> 
        </div>
        @endforeach
        @endif </div>
    </div>
  </div>
</div>
<div class="">
  <div class="container-fluid">
    <div class="row justify-content-md-center">
      <div class="col-lg-4 col-md-4 col-sm-12">
        <div class=" heading pt-15 pb-10 salogan text-center text-white mt-20">
          <h3 class="text-white">Most Viewed Products</h3>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="bestseller-product mt-80">
  <div class="container">
    <div class="row">
      <div class="product-slider-active"> @if(count($hot)>0)
        @foreach($hot as $results)
        <div class="col-md-3 col-lg-3 col-sm-4 col-xs-12"> 
          <!--Single Product Start-->
          <div class="single-product mb-25">
            <div class="product-img img-full"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="{{$results->name}}"> </a> </div>
            <div class="product-content">
              <h2><a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">{{$results->name}}</a></h2>
              <div class="product-price">
                <div class="price-box"> <span class="regular-price">PKR {{number_format($results->price)}}</span> </div>
                <div class="add-to-cart"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">Add To Cart</a> </div>
              </div>
            </div>
          </div>
          <!--Single Product End--> 
        </div>
        @endforeach
        @endif </div>
    </div>
  </div>
</div>

<!--Blog Area Start-->
<div class="blog-area ml-50 mr-50 mt-110">
  <div class="container">
    <div class="row"> 
      <!--Section Title Start-->
      <div class="col-12">
        <div class="section-title text-center mb-35"> <span>From The Blogs</span>
          <h3>Our Latest Posts</h3>
        </div>
      </div>
      <!--Section Title End--> 
    </div>
    <div class="row">
      <div class="blog-slider-active">
        <div class="col-md-4"> 
          <!--Single Blog Start-->
          <div class="single-blog">
            <div class="blog-img img-full"> <a href="#"> <img src="{{url('/')}}/images/blog/blog1.jpg" alt=""> </a> </div>
            <div class="blog-content">
              <div class="post-date">01/12/2018</div>
              <h3 class="post-title"><a href="#">Blog image post</a></h3>
              <p class="post-description">Donec vitae hendrerit arcu, sit amet faucibus nisl. Cras pretium arcu ex. Aenean posuere libero</p>
              <p class="post-author"> <img src="{{url('/')}}/images/icon/author.png" alt=""> <span>Posted by </span> <a href="#">admin </a> </p>
            </div>
          </div>
          <!--Single Blog End--> 
        </div>
        <div class="col-md-4"> 
          <!--Single Blog Start-->
          <div class="single-blog">
            <div class="blog-img img-full"> <a href="#"> <img src="{{url('/')}}/images/blog/blog2.jpg" alt=""> </a> </div>
            <div class="blog-content">
              <div class="post-date">01/12/2018</div>
              <h3 class="post-title"><a href="#">Post with Gallery</a></h3>
              <p class="post-description">Donec vitae hendrerit arcu, sit amet faucibus nisl. Cras pretium arcu ex. Aenean posuere libero</p>
              <p class="post-author"> <img src="{{url('/')}}/images/icon/author.png" alt=""> <span>Posted by </span> <a href="#">admin </a> </p>
            </div>
          </div>
          <!--Single Blog End--> 
        </div>
        <div class="col-md-4"> 
          <!--Single Blog Start-->
          <div class="single-blog">
            <div class="blog-img img-full"> <a href="#"> <img src="{{url('/')}}/images/blog/blog3.jpg" alt=""> </a> </div>
            <div class="blog-content">
              <div class="post-date">01/12/2018</div>
              <h3 class="post-title"><a href="#">Post with Audio</a></h3>
              <p class="post-description">Donec vitae hendrerit arcu, sit amet faucibus nisl. Cras pretium arcu ex. Aenean posuere libero</p>
              <p class="post-author"> <img src="{{url('/')}}/images/icon/author.png" alt=""> <span>Posted by </span> <a href="#">admin </a> </p>
            </div>
          </div>
          <!--Single Blog End--> 
        </div>
        <div class="col-md-4"> 
          <!--Single Blog Start-->
          <div class="single-blog">
            <div class="blog-img img-full"> <a href="#"> <img src="{{url('/')}}/images/blog/blog4.jpg" alt=""> </a> </div>
            <div class="blog-content">
              <div class="post-date">01/12/2018</div>
              <h3 class="post-title"><a href="#">Post with Video</a></h3>
              <p class="post-description">Donec vitae hendrerit arcu, sit amet faucibus nisl. Cras pretium arcu ex. Aenean posuere libero</p>
              <p class="post-author"> <img src="{{url('/')}}/images/icon/author.png" alt=""> <span>Posted by </span> <a href="#">admin </a> </p>
            </div>
          </div>
          <!--Single Blog End--> 
        </div>
        <div class="col-md-4"> 
          <!--Single Blog Start-->
          <div class="single-blog">
            <div class="blog-img img-full"> <a href="#"> <img src="{{url('/')}}/images/blog/blog5.jpg" alt=""> </a> </div>
            <div class="blog-content">
              <div class="post-date">01/12/2018</div>
              <h3 class="post-title"><a href="#">Maecenas ultricies</a></h3>
              <p class="post-description">Donec vitae hendrerit arcu, sit amet faucibus nisl. Cras pretium arcu ex. Aenean posuere libero</p>
              <p class="post-author"> <img src="{{url('/')}}/images/icon/author.png" alt=""> <span>Posted by </span> <a href="#">admin </a> </p>
            </div>
          </div>
          <!--Single Blog End--> 
        </div>
        <div class="col-md-4"> 
          <!--Single Blog Start-->
          <div class="single-blog">
            <div class="blog-img img-full"> <a href="#"> <img src="{{url('/')}}/images/blog/blog1.jpg" alt=""> </a> </div>
            <div class="blog-content">
              <div class="post-date">01/12/2018</div>
              <h3 class="post-title"><a href="#">Blog image post</a></h3>
              <p class="post-description">Donec vitae hendrerit arcu, sit amet faucibus nisl. Cras pretium arcu ex. Aenean posuere libero</p>
              <p class="post-author"> <img src="{{url('/')}}/images/icon/author.png" alt=""> <span>Posted by </span> <a href="#">admin </a> </p>
            </div>
          </div>
          <!--Single Blog End--> 
        </div>
      </div>
    </div>
  </div>
</div>
<!--Blog Area End--> 
<!--Home Product Layout Area End--> 
@endsection 