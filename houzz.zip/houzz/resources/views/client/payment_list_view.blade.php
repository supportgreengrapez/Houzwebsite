@extends('client.layout.appclient')
@section('content') 
  <!--Breadcrumb Tow Start-->
  <div class="gray-bg3">
    <div class="container">
      <div class="white-bg p-3">
        <div class="">
          <div class="page-title">
            <div class="row">
              <div class="col-10">
                <div class="salogan">
                  <h2 class="text-center font-weight-bold">Payment List</h2>
                </div>
              </div>
              <div class="col-md-2 col-sm-12 col-xs-12">
                <div class="title_left"> <a href="{{url('/')}}/client/add/payment/view" type="button" class="add-btns pull-right">Create Payment</a> </div>
              </div>
            </div>
          </div>
        </div>
        <form method="post" action = "{{url('/')}}/client/search/payment/by/id"   enctype="multipart/form-data" >
              {{ csrf_field() }}
              @if($errors->any())

<div class="alert alert-danger">
  <strong></strong> {{$errors->first()}}
</div>
@endif
        <div class="row">
          <div class="col-lg-6 mt-20">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label">Search by Payment Id :</label>
              <div class="col-lg-5 col-sm-12 col-xs-12">
                <input type="number" name="search" class="form-control" placeholder="Enter Invoice#">
              </div>
              <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
                <button type="submit" class="add-btns">Search</button>
              </div>
            </div>
          </div>
        </div>
        </form>
        <form method="post" action = "{{url('/')}}/client/search/payment/by/status"   enctype="multipart/form-data" >
              {{ csrf_field() }}
        <div class="row">
          <div class="col-lg-4 mt-20">
            <div class="row form-group">
              <label class="col-lg-6 col-sm-12 col-form-label">Filter by Status :</label>
              <div class="col-lg-6 col-sm-12 col-xs-12">
                <select class="form-control" name="status" >
                <option >Select Status</option>
                  <option value="0">Submitted</option>
                  <option value="1">Approved</option>
                  <option value="2">Rejected</option>
                  <option value="3">Pending</option>
                </select>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mt-20">
            <div class="row form-group">
              <label class="col-lg-5 col-sm-12 col-form-label">Date range :</label>
            
            </div>
          </div>
          <div class="col-lg-2 mt-20">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label">From</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="date" name="start_date" class="form-control">
              </div>
            </div>
          </div>
          <div class="col-lg-2 mt-20">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label">To</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="date" name="end_date" class="form-control">
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 ccol-sm-6 col-xs-6">
            <button type="submit" class="add-btns pull-right mb-20">Filter Results</button>
          </div>
        </div>

        </form>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <table id="myTable" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
              
                  <th>Invoice No</th>
                  <th>Payment Receipt</th>
                  <th>Payee</th>
                  <th>Payer</th>
                  <th>Date </th>
                  <th>Amount</th>
                  <th>Status </th>
                </tr>
              </thead>
              <tbody>
              @if(count($result)>0)
              @foreach($result as $results)
                <tr>
             
                  <td>{{$results->invoice_no}}</td>
                  <td><img src="{{url('/')}}/storage/images/{{$results->thumbnail}}" alt="img"></td>
                  <td>{{$results->payee}}</td>
                  <td>{{$results->payer}}</td>
                  <td>{{$results->date}}</td>
                  <td>{{number_format($results->amount)}}</td>
                  @if($results->status == 0)
                  <td><label class="label label-info">Submitted</label></td>
                  @elseif($results->status == 1)
                  <td><label class="label label-info">Approved</label></td>
                  @elseif($results->status == 2)
                  <td><label class="label label-info">Rejected</label></td>
                  @else
                  <td><label class="label label-info">Pending</label></td>
                  @endif

                </tr>
       @endforeach
       @endif
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
 @endsection