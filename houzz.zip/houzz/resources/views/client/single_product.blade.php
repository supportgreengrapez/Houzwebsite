@extends('client.layout.appclient')
@section('content')
  <!--Breadcrumb One Start-->
  <div class="container-fluid">
  <div class="breadcrumb-content breadcrumb-content-tow mt-20 mb-20">
                    <ul>
                      <li><a href="index.html">Home</a></li>
                      <li><a href="index.html">Shop</a></li>
                      <li class="active">Specific Product</li>
                    </ul>
                  </div>
                  </div>
  <!--Breadcrumb One End-->
  <!--Single Product Area Start-->
  <div class="single-product-area mb-20">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-5">
          <div class="product-details-img-tab">
            <!--Product Tab Content Start-->
            <div class="tab-content single-product-img">
              <div class="tab-pane fade show active" id="product1">
                <div class="product-large-thumb img-full">
                  <div class="easyzoom easyzoom--overlay"> <a href="img/single-product/large/single-product1.jpg"> <img src="img/single-product/large/single-product1.jpg" alt=""> </a> <a href="img/single-product/large/single-product1.jpg" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
                </div>
              </div>
              <div class="tab-pane fade" id="product2">
                <div class="product-large-thumb img-full">
                  <div class="easyzoom easyzoom--overlay"> <a href="img/single-product/large/single-product2.jpg"> <img src="img/single-product/large/single-product2.jpg" alt=""> </a> <a href="img/single-product/large/single-product2.jpg" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
                </div>
              </div>
              <div class="tab-pane fade" id="product3">
                <div class="product-large-thumb img-full">
                  <div class="easyzoom easyzoom--overlay"> <a href="img/single-product/large/single-product3.jpg"> <img src="img/single-product/large/single-product3.jpg" alt=""> </a> <a href="img/single-product/large/single-product3.jpg" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
                </div>
              </div>
              <div class="tab-pane fade" id="product4">
                <div class="product-large-thumb img-full">
                  <div class="easyzoom easyzoom--overlay"> <a href="img/single-product/large/single-product4.jpg"> <img src="img/single-product/large/single-product4.jpg" alt=""> </a> <a href="img/single-product/large/single-product4.jpg" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
                </div>
              </div>
              <div class="tab-pane fade" id="product5">
                <div class="product-large-thumb img-full">
                  <div class="easyzoom easyzoom--overlay"> <a href="img/single-product/large/single-product5.jpg"> <img src="img/single-product/large/single-product5.jpg" alt=""> </a> <a href="img/single-product/large/single-product5.jpg" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
                </div>
              </div>
              <div class="tab-pane fade" id="product6">
                <div class="product-large-thumb img-full">
                  <div class="easyzoom easyzoom--overlay"> <a href="img/single-product/large/single-product6.jpg"> <img src="img/single-product/large/single-product6.jpg" alt=""> </a> <a href="img/single-product/large/single-product6.jpg" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
                </div>
              </div>
            </div>
            <!--Product Tab Content End-->
            <!--Product Tab Menu Start-->
            <div class="product-menu">
              <div class="nav product-tab-menu">
                <div class="product-details-img"> <a class="active" data-toggle="tab" href="#product1"><img src="img/single-product/small/single-product1.jpg" alt=""></a> </div>
                <div class="product-details-img"> <a data-toggle="tab" href="#product2"><img src="img/single-product/small/single-product2.jpg" alt=""></a> </div>
                <div class="product-details-img"> <a data-toggle="tab" href="#product3"><img src="img/single-product/small/single-product3.jpg" alt=""></a> </div>
                <div class="product-details-img"> <a data-toggle="tab" href="#product4"><img src="img/single-product/small/single-product4.jpg" alt=""></a> </div>
                <div class="product-details-img"> <a data-toggle="tab" href="#product5"><img src="img/single-product/small/single-product5.jpg" alt=""></a> </div>
                <div class="product-details-img"> <a data-toggle="tab" href="#product6"><img src="img/single-product/small/single-product6.jpg" alt=""></a> </div>
              </div>
            </div>
            <!--Product Tab Menu End-->
          </div>
        </div>
        <div class="col-md-12 col-lg-7">
          <!--Product Details Content Start-->
          <div class="product-details-content">
            <h2>Sit voluptatem</h2>

            <div class="single-product-price"> <span class="price new-price">$66.00</span> <span class="regular-price"><h2 style="color:#689a29">$77.00</h2></span> </div>
            <div class="product-description">
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor. Donec non est at libero vulputate rutrum. Morbi ornare lectus quis justo gravida semper. Nulla tellus mi, vulputate adipiscing cursus eu, suscipit id nulla.</p>
            </div>
            <p class="stock in-stock">150 in stock</p>
            <div class="single-product-quantity">
              <form class="add-quantity" action="#">
              <div class="mb-10">
                      <select class="form-control">
                        <option value="color">Color</option>
                        <option value="Red">Red</option>
                        <option value="Blue">Blue</option>
                      </select>
                    </div>
                <div class="product-quantity">
                  <input value="1" type="number">
                </div>
                <div class="add-to-link">
                  <button class="product-btn" data-text="add to cart">add to cart</button>
                </div>
              </form>
            </div>
            <!--FAQ Accordin Start-->
            <div class="faq-accordion">
              <div id="accordion">
                <div class="card">
                  <div class="card-header" id="headingThree">
                    <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"> Product Description </a> </h5>
                  </div>
                  <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                    <div class="card-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header" id="headingTwo">
                    <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> Product Specifications </a> </h5>
                  </div>
                  <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                    <div class="card-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header" id="headingFour">
                    <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour"> Shipping & Returns </a> </h5>
                  </div>
                  <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                    <div class="card-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS. </div>
                  </div>
                </div>
              </div>
            </div>
            <!--FAQ Accordin Start-->
          </div>
          <!--Product Details Content End-->
        </div>
      </div>
    </div>
  </div>
  <!--Single Product Area End-->

  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="section-title text-center mb-20 mt-30"> <span>
          <h3>Shop Best Sale</h3>
          </span> </div>
      </div>
    </div>
  </div>
  <div class="home-product-layout-area mt-20">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div id="myCarousel2" class="carousel slide mb-20" data-ride="carousel" data-interval="0">
            <div class="carousel-inner">
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <span class="onsale">Sale!</span> <img src="img/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Dinning</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/5.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Dinning</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/10.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Kitchen</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item carousel-item active">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Home Accessories</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed Rooms</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/9.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Sofa</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale">Sale!</span> <img src="img/9.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Sofa</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Carousel controls -->
            <a class="carousel-control left carousel-control-prev" href="#myCarousel2" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel2" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="section-title text-center mb-20 mt-30"> <span>
          <h3>Shop Daily Sale</h3>
          </span> </div>
      </div>
    </div>
  </div>
  <div class="home-product-layout-area mt-20">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="0">
            <div class="carousel-inner">
              <div class="item carousel-item active">
                <div class="row">
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Home Accessories</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed Rooms</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/9.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Sofa</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/5.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Dinning</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/10.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Kitchen</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-3">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <img src="img/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Dinning</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Carousel controls -->
            <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="section-title text-center mb-20 mt-30"> <span>
          <h3>New Arrival</h3>
          </span> </div>
      </div>
    </div>
  </div>
  <div class="home-product-layout-area mt-20">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div id="myCarousel7" class="carousel slide mb-20" data-ride="carousel" data-interval="0">
            <div class="carousel-inner">
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/3.jpg" alt=""> </a>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/1.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/5.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                            <li><a href="#" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                </div>
              </div>
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/1.jpg" alt=""> </a>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/4.jpg" alt=""> </a>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/10.jpg" alt=""> </a>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                </div>
              </div>
              <div class="item carousel-item active">
                <div class="row">
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/3.jpg" alt=""> </a>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/1.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                  <div class="col-md-4">
                    <!--Single Product Start-->
                    <div class="single-product mb-25">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="img/5.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                        <div class="product-action">
                          <ul>
                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                            <li><a href="#" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                            <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                          </ul>
                        </div>
                      </div>
                      <div class="product-content">
                        <h2><a href="single-product.html">Eleifend quam</a></h2>
                        <p>$115.00</p>
                        <div class="product-price">
                          <div class="wishlist-compare-btn">
                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                        </div>
                      </div>
                    </div>
                    <!--Single Product End-->
                  </div>
                </div>
              </div>
            </div>
            <!-- Carousel controls -->
            <a class="carousel-control left carousel-control-prev" href="#myCarousel7" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel7" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
        </div>
      </div>
    </div>
  </div>
  @endsection
