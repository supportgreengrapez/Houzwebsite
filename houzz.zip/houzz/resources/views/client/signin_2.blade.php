@extends('client.layout.appclient')
@section('content')
<style>
    label {
    position: initial;
    }
</style>
  <!--Breadcrumb Tow Start-->
  <div class="gray-bg3 pb-70 pt-20">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-3 col-md-3 col-md-12 col-xs-12">
          <div class="signintophead mt-20">
            <h4>SIGNUP</h4>
          </div>
        </div>
      </div>

      <form method="post" action = "{{url('/')}}/signup/3/view">
               {{ csrf_field() }}

               @if($errors->any())
<br>
<div class="alert alert-danger">
  <strong></strong> {{$errors->first()}}
</div>
@endif
      <div class="row justify-content-center">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="bgmentorsign2">
           
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-key mentsignicons"></i></span>
                  <input type="password" class="form-control formpad" name="password"  placeholder="Create a Password" required>
                </div>
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-key mentsignicons"></i></span>
                  <input type="password" class="form-control formpad" name="cpassword" placeholder="Confirm Password" required>
                </div>
              </div>
            </div>
            <h4 style="margin-top:20px;" class="text-left">I Want To:</h4>
            <div class="row">
              <div class="col-lg-5 col-md-3 col-sm-12">
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="defaultGroupExample1" name="customer_type" value="buyer" checked>
                  <label class="custom-control-label" for="defaultGroupExample1">Buyer</label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="defaultGroupExample1111" name="customer_type" value="seller">
                  <label class="custom-control-label" for="defaultGroupExample1111">Seller</label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="defaultGroupExample2222" name="customer_type" value="realtor">
                  <label class="custom-control-label" for="defaultGroupExample2222">Realtor </label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="defaultGroupExample333" name="customer_type" value="professional">
                  <label class="custom-control-label" for="defaultGroupExample333">Professional</label>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="sign2bottom">
                  <div class="custom-control custom-checkbox mt-30 text-left">
                    <input type="checkbox" class="custom-control-input" name="terms" id="defaultChecked911" required>
                    <label class="custom-control-label" for="defaultChecked911">Yes,I understand and agree to the <a href="#">Houzz Terms of Services</a>,including the User <a href="#">Agreement <span>and </span>Privacy policy</a>.</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="submitbutton">
                <button type="submit" class="btn submitbtn btn-responsive"  aria-expanded="false">Get Start</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </form>
    </div>
  </div>
  <!--Blog Area End-->
  @endsection
