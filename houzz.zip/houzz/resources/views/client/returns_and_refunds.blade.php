@extends('client.layout.appclient')
@section('content')
<div class="container">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="paymentpolicy pt-20">
        <h2>Return and Refund</h2>
        <br>
        <h4>Conditions for Returns</h4>
        <ul>
          <li>The product must be unused, unworn, unwashed and without any flaws. If a product is returned to us in an inadequate condition, we reserve the right to send it back to you.</li>
          <li>The product must include the original tags, user manual, warranty cards, freebies and accessories.</li>
          <li>The product must be returned in the original and undamaged manufacturer packaging / box. It must be returned in the same condition with return shipping label attached. Do not put tape or stickers on the manufacturers box.</li>
        </ul>
        <p><strong>Note:&nbsp;</strong>It is important to print out and paste the return label on your return parcel to avoid any inconvenience/delay in process of your return</p>
        <p>&nbsp;</p>
        <p>Please read through our <a href="{{url('/')}}/returns/and/refunds">Return Policy</a> on this page to understand our return procedures and make sure your item is eligible for return.</p>
        <p><br />
          <br />
        </p>
        <p>You will have 7 days after an item is delivered to you to notify us that you want to return the item. This means if your item was delivered e.g. on the 5th of the month, you have till the 12th to initiate a return. If the item you wish to return meets the criteria mentioned below, your return can be initiated by emailing us at customer@houz.pk which is available 24/7</p>
        <p>&nbsp;</p>
        <p><strong>How to Request a Return?</strong></p>
        <p>You can request to initiate a return by contacting our helpline&nbsp;at <a class="mobilesOnly green" href="tel:+923094977766">0309-49-777-66</a> or <a href="https://mail.google.com/mail/u/0/#inbox" class="green">customer@houz.pk</a>  to confirm that your product is eligible for return. We will explain to you the return procedure, and We will explain to you the return procedure and confirm the nearest service provider location where you can drop-off the product. or confirm the nearest service provider location where you can drop-off the product.&nbsp;</p>
        <p><br />
          <br />
        </p>
        <p>Please be prepared to give the following pieces of information:&nbsp;</p>
        <ul>
          <li>Your order number.</li>
          <li>The reason for the return.</li>
          <li>The method of refund that you would like and the necessary information associated (bank account number, etc.)</li>
        </ul>
        <p><strong>Can I request a replacement rather than a refund?</strong></p>
        <p><br />
          <br />
        </p>
        <p>If you prefer to replace your product, just let our Customer Service executive know your choice and we will call you as soon as your initial product has been received, and we have looked into availability of the replacement product. If you choose a refund voucher, you can use it to buy a similar product or a different product on houz.pk yourself using the amount originally paid for the returned item.&nbsp;<br />
          <br />
          <br />
        </p>
        <p><strong>If my returned product is not validated for return, how am I informed?</strong></p>
        <p><br />
          <br />
        </p>
        <p>If your return does not meet the Quality Check criteria, then we will call you to explain the issue and send the item(s) back to you. We will arrange the delivery of the item.&nbsp;</p>
      </div>
    </div>
  </div>
</div>
@endsection