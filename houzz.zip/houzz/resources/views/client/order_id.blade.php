@extends('client.layout.appclient')
@section('content') 

<!--Breadcrumb Tow Start-->

<div class="container white-bg wrapp">
  <div class="row">
    <div class="col-lg-12 col-sm-12 col-xs-12">
      <div class="topheadordertracking">
        <h3>Order Tracking</h3>
      </div>
    </div>
  </div>
</div>
<div class="gray-bg3">
  <div class="container pt-40 pb-40">
    <div class="white-bg wrapp pt-30 pb-30">
      <form method="post" action = "{{url('/')}}/order/tracking" class="login100-form validate-form ">
        {{ csrf_field() }}
        @if($errors->any())
        <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
        @endif
        <div class="row justify-content-center mt-30">
          <div class="col-lg-7 col-sm-12 col-xs-12">
            <div class="form-group">
              <label for="usr">Order Tracking Id:</label>
              <input type="search" name ="orderid" class="form-control" id="usr">
            </div>
            <button type="submit" class="btn btnnav">Search</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
@if(count($orderdetail)>0)
	@foreach($orderdetail as $results)
    @php
        $order_id =   $results->pk_id;
        $orderdetailed = DB::select("select* from detail_table where order_id = '$order_id' ");
    @endphp
<div id="login" class="mb-30 mt-70">
  <div class="container">
    <div id="login-row" class="row align-items-center">
      <div id="login-column" class="col-md-12">
        <div id="login-box" class="col-md-6 shadow-lg p-3 mb-5 bg-white rounded">
          <div class="wishlist-area mb-20 mt-10">
            <div class="container">
              <div class="row">
                <div class="col-lg-6 col-sm-12 col-xs-12">
                  <div class="ordertrackingheadings"> <a href="{{url('/')}}/order/tracking/detail/{{$results->pk_id}}">Tracking ID<span> {{$results->tracking_id}} </span></a> </div>
                </div>
                <div class="col-md-6 ml-auto">
                  <div class="cart-page-total">
                    <ul>
                      <li>Total <span>PKR  {{number_format($results->amount)}}</span></li>
                    </ul>
                  </div>
                </div>
                <div class="col-12">
                  <div class="table-content table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th class="plantmore-product-thumbnail">images</th>
                          <th class="cart-product-name">Product</th>
                          <th class="plantmore-product-price">Size</th>
                          <th class="cart-product-name">QTY</th>
                          <th class="plantmore-product-price">Price</th>
                          <th class="plantmore-product-price">Total Price</th>
                          <th class="plantmore-product-price">Shipment Charges</th>
                          <th class="plantmore-product-price">Cancel Order</th>
                        </tr>
                      </thead>
                      <tbody>
                      
                      @if(count($orderdetailed)>0)
                      @foreach($orderdetailed as $results)
                      @php
                      
                      $id =  $results->product_id;
                      $thumbnail = DB::select("select* from product where  pk_id ='$id'");
                      
                      @endphp
                      <tr>
                        <td class="plantmore-product-thumbnail"><img src="{{URL('/')}}/storage/images/{{$thumbnail[0]->thumbnail}}" alt="odimg" style="width:100px;height:100px;"></td>
                        <td class="plantmore-product-name"><a href="#">{{$results->product_name}}</a></td>
                        <td class="plantmore-product-price"><span class="amount">{{$results->size}}</span></td>
                        <td class="plantmore-product-name">{{$results->quantity}}</td>
                        <td class="plantmore-product-price"><span class="amount">PKR {{number_format($results->price)}}</span></td>
                        <td class="plantmore-product-price"><span class="amount">PKR {{number_format($results->price * $results->quantity) }}</span></td>
                        <td class="plantmore-product-price"><span class="amount">PKR {{number_format($results->delivery_charges)}}</span></td>
                        
                        <td class="plantmore-product-price">
                        @if ($duration < $results->timeafter and $results->v_order_status =="0" and Carbon\Carbon::now()->diffInDays(Carbon\Carbon::parse($results->created_at)) < 1)
                        <button  type="button" class="btn btn-default" onclick="getId(this.id)"  data-toggle="modal" data-target="#myModal2{{$results->pk_id}}">Cancel</button>
                        @elseif (Carbon\Carbon::now()->diffInDays(Carbon\Carbon::parse($results->created_at)) < 7 and $results->v_order_status =="2")
                          <button  type="button" class="btn btn-default" onclick="getId(this.id)"  data-toggle="modal" data-target="#myModal{{$results->pk_id}}">Return</button>
                         
                            
                        @elseif($results->v_order_status =="2")
                         <p><span class="label label-success">Shipped</span></p>
                          @elseif($results->v_order_status =="0")
                         <p><span class="label label-success">Process</span></p>
                         @elseif($results->v_order_status =="4")
                         <p><span class="label label-danger">Cancel</span></p>
                         @elseif($results->v_order_status =="3")
                         <p><span class="label label-danger">Return</span></p>
                         @elseif($results->return_status =="2")
                         <p><span class="label label-danger">Shipped</span></p>
                         @endif
                        </td>
                      </tr>
                      
                      <!-- Modal -->
                      <div class="modal fade" id="myModal{{$results->pk_id}}" role="dialog">
                        <div class="modal-dialog"> 
                          
                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Confirmation Message</h4>
                            </div>
                            <form method="post" action = "{{url('/')}}/cancel_active_order/{{$results->order_id}}">
                              {{ csrf_field() }}
                              <div class="modal-body form-group">
                                <textarea class="form-control" rows="9" name="reason"></textarea>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-default" >submit</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                      
                      <!-- Modal -->
                      <div class="modal fade" id="myModal2{{$results->pk_id}}" role="dialog">
                        <div class="modal-dialog"> 
                          
                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Confirmation Message</h4>
                            </div>
                            <div class="modal-body">
                              <p>You are about to delete <b><i class="title"></i></b> record, this procedure is irreversible.</p>
                              <p>Do you want to proceed?</p>
                            </div>
                            <div class="modal-footer">
                        
                  
                  
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                              <a href="{{URL('/')}}/customer-cancel-active-order/{{$results->order_id}}" class="btn btn-danger">Yes</a> </div>
                          </div>
                        </div>
                      </div>
                      @endforeach
                      @endif
                        </tbody>
                      
                    </table>
                  </div>
        </div>
      </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
@endforeach
@endif
@endsection 