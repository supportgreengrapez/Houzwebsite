
@extends('client.layout.appclient')
@section('content')
<!--Shop Area Start-->
  <div class="gray-bg3">
    <div class="container">
      <div class="shop-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3">
              <!--Product Category Widget Start-->
              <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
                <div class="shop-sidebar">
                  <h4>Shop By categories</h4>
                  <div class="categori-checkbox">
                    <ul>
                      <h4 class="green">All Products</h4>
                      @foreach($sub_category as $results)
            <li> <a href="{{URL('/')}}/product/{{$results->sub_category}}">{{$results->main_category}}</a></i>
             @endforeach
                    </ul>
                  </div>
                  <hr class="green">
                  <h4>Shop Daily Sales</h4>
                  <div class="categori-checkbox">
                    <ul>
                      <li>Bar stool & counter stools 50</li>
                      <li>Off or more</li>
                      <li>Area rugs 70% or more</li>
                      <li>40% off</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-9">
              <div class="shop-layout">
                <div class="bg-white p-2">
                  <div class="breadcrumb-content breadcrumb-content-tow mt-20 mb-20">
                    <ul>
                      <li><a href="index.html">Home</a></li>
                      <li><a href="index.html">Shop</a></li>
                      <li class="active">Sub Category</li>
                    </ul>
                  </div>
                  <div class="shop-product">
                    <div id="myTabContent-2" class="tab-content">
                      <div id="grid" class="tab-pane fade show active">
                        <div class="product-grid-view">
                          <div class="row">
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="{{URL('/')}}/shop/products/list"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="{{URL('/')}}/shop/products/list">Kitchen Dinning</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">Bath Product</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">Bed</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">Living</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">Lighting</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">Furniture</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">Home Decore</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <div class="col-md-3">
                              <!--Single Product Start-->
                              <div class="single-product mb-25 greyyy">
                                <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2"> </a> </div>
                                <div class="product-content">
                                  <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                  <p class="grey text-justify">Bed</p>
                                  <p class="grey text-justify">Bedroom</p>
                                  <p class="grey text-justify">Bedset</p>
                                </div>
                              </div>
                              <!--Single Product End-->
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--Shop Product End-->
                  <div class="container-fluid">
                    <div class="row">
                      <div class="col-12">
                        <div class="section-title text-center mb-20 mt-30"> <span>
                          <h3>Shop Daily Sale</h3>
                          </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="home-product-layout-area mt-20">
                    <div class="container-fluid">
                      <div class="row">
                        <div class="col-md-12">
                          <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="0">
                            <div class="carousel-inner">
                              <div class="item carousel-item active">
                                <div class="row">
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Home Accessories</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Bed Rooms</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Chairs</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/9.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Sofa</h4>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="item carousel-item">
                                <div class="row">
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Chairs</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/5.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Dinning</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Stairs</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/10.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Kitchen</h4>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="item carousel-item">
                                <div class="row">
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Chairs</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Bed</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Table Set</h4>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="col-sm-3">
                                    <div class="thumb-wrapper">
                                      <div class="img-box"> <img src="{{URL('/')}}/pic/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                                      <div class="thumb-content">
                                        <h4>Dinning</h4>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- Carousel controls -->
                            <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="container-fluid">
                    <div class="row">
                      <div class="col-12">
                        <div class="section-title text-center mb-20 mt-30"> <span>
                          <h3>Shop Best Sale</h3>
                          </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="home-product-layout-area mt-20">
                    <div class="container-fluid">
                      <div class="row">
                        <div class="col-md-12">
                          <div id="myCarousel3" class="carousel slide" data-ride="carousel" data-interval="0">
                            <div class="carousel-inner">
                              <div class="item carousel-item active">
                                <div class="row">
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                </div>
                              </div>
                              <div class="item carousel-item">
                                <div class="row">
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                </div>
                              </div>
                              <div class="item carousel-item">
                                <div class="row">
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-3">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25 greyyy">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/2.jpg" alt="" class="p-2" style="position:relative;"> </a> </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">OutDoor Product</a></h2>
                                        <p class="grey text-justify">Bed</p>
                                        <p class="grey text-justify">Bedroom</p>
                                        <p class="grey text-justify">Bedset</p>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- Carousel controls -->
                            <a class="carousel-control left carousel-control-prev" href="#myCarousel3" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel3" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="container-fluid">
                    <div class="row">
                      <div class="col-12">
                        <div class="section-title text-center mb-20 mt-30"> <span>
                          <h3>New Arrival</h3>
                          </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="home-product-layout-area mt-20">
                    <div class="container-fluid">
                      <div class="row">
                        <div class="col-md-12">
                          <div id="myCarousel2" class="carousel slide" data-ride="carousel" data-interval="0">
                            <div class="carousel-inner">
                              <div class="item carousel-item active">
                                <div class="row">
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                </div>
                              </div>
                              <div class="item carousel-item">
                                <div class="row">
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                </div>
                              </div>
                              <div class="item carousel-item">
                                <div class="row">
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                  <div class="col-md-4">
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full"> <a href="shop-list.html"> <img src="{{URL('/')}}/pic/3.jpg" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><a href="shop-list.html">Eleifend quam</a></h2>
                                        <p>$115.00</p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <button type="submit" class="product-btn" data-text="add to cart">add to cart</button>
                                            <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End-->
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- Carousel controls -->
                            <a class="carousel-control left carousel-control-prev" href="#myCarousel2" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel2" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End-->
      </div>
    </div>
  </div>
   @endsection
