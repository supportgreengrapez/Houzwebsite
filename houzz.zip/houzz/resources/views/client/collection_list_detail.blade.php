
@extends('client.layout.appclient')
@section('content')
<!--Shop Area Start-->
<div class="greyyy">
    <div class="container">
      <div class="shop-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="shop-layout">
                
@if(count($result)>0)
                <div class="bg-white p-2">
                <div class="banner-area">
                      <!--Single Banner Area Start-->
                      <div class="single-banner  mt-40 mb-40">
                        <div class="banner-img"> <img src="{{URL('/')}}/storage/images/{{$result[0]->thumbnail}}" alt="" style="transform:none;transition:none;"> </div>
                      </div>
                </div>
                <div class="row">
      <div class="col-12">
        <div class="salogan">
          <h2 class="text-center">{{$result[0]->collection_name}}</h2>
          <p class="text-justify">{{$result[0]->description}}</p>
        </div>
      </div>
    </div>
                  <!--Shop Product End-->
                        <div class="section-title text-center mb-20 mt-30"> <span>
                          <h3>All Products</h3>
                          </span> </div>
                  
                  <div class="shop-area mb-70">
		    <div class="container">
		        <div class="row">
		            
		            <div class="col-12">
                    <div class="white-bg p-3">
		                <div class="shop-layout">
		                    <!--Grid & List View Start-->
		                  
		                    <!--Grid & List View End-->
		                    <!--Shop Product Start-->
		                    <div class="shop-product">
		                        <div id="myTabContent-2" class="tab-content">
		                            <div id="grid" class="tab-pane fade show active">
		                                <div class="product-grid-view">
		                                    <div class="row">
                                            @php
                                            $array = [];
                                            $str = $result[0]->products;
              
    $tok = strtok($str, ",");


    $skillset =$tok;
   $array = array_wrap($skillset);

    while ($tok !== false) {
        $tok = strtok(",");

       if(is_string($tok))
       $skillset= $tok;
     //  $array = array_prepend($array, $skillset);
     array_push($array, $skillset);

    }
    array_pop($array);
                                            @endphp
                                            
                                            @foreach($array as $arrays)
                                            @php
                                            $result1 = DB::select("select* from product where pk_id = '$arrays'");
                                            @endphp
                                             @foreach($result1 as $results)
		                                        <div class="col-md-2">
		                                            <!--Single Product Start-->
                                                    <div class="single-product mb-25">
                                                        <div class="product-img img-full">
                                                            <a href="single-product.html">
                                                                <img src="{{url('/')}}/storage/images/{{$results->thumbnail}}" alt="">
                                                            </a>
                                                        </div>
                                                        <div class="product-content">
                                                            <h4>{{$results->name}}</h4>															
                                                            <p>PKR {{number_format($results->price)}}</p>
                                                            <div class="product-price">
                                          <div class="wishlist-compare-btn">
                                            <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}" class="add-btn">add to cart</a>
                                            <a href="{{URL('/')}}/product/add/wishlist/{{$results->pk_id}}" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                                        </div>
                                                    </div>
                                                    <!--Single Product End-->
		                                        </div>
		                                       @endforeach
		                                      @endforeach
		                                    </div>
		                                </div>
		                            </div>
		                            
		                        
		                        </div>
		                    </div>
		                    <!--Shop Product End-->
		                </div>
                        </div>
		            </div>
		        </div>
		    </div>
		</div>
                </div>
                 @endif
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End-->
      </div>
    </div>
   
  </div>
  @endsection
