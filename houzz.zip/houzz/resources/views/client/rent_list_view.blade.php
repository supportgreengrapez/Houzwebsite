@extends('client.layout.appclient')
@section('content') 
<!--Shop Area Start-->
<div class="gray-bg3">
  <div class="shop-area mb-20">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-sm-12 col-xs-12 mt-20">
          <div class="dropdown">
            <button class="dropbtn">All Products <i class="fa fa-angle-down"></i></button>
            <div class="dropdown-content white-bg drpdwnstyle" style="z-index: 20;"> 
            <a href="{{url('/')}}/home">Homes</a> 
            <a href="{{url('/')}}/commercial">Commercial</a> 
            <a href="{{url('/')}}/plot">Plots</a>
             <a href="{{url('/')}}/flat">Apartments</a> 
            <a href="{{url('/')}}/land">Agriculture Land</a>
             <a href="{{url('/')}}/rent">Rent</a> 
            <a href="{{url('/')}}/sale/list">Sale</a> 
            <a href="{{url('/')}}/office">Offices</a> 
            <a href="{{url('/')}}/hot">Wanted</a>
            <a href="{{url('/')}}/agents">Agents</a> 
            <a href="#">New Projects</a>
            </div>
          </div>
        </div>
        <div class="col-lg-9 col-sm-12 col-xs-12 mt-20 white-bg">
         
        
          <div class="row">
            <div class="col-lg-12 col-sm-12 col-xs-12 mt-20">
              <h3>House for rent in all cities of Pakistan</h3>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-3 col-sm-3 col-xs-12 mt-20">
              <ul style="list-style:none;">
              @if(count($rent)>0)
                @foreach($rent as $results)
                <li><a href="{{url('/')}}/property/rent/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                @endforeach
                @endif
              </ul>
            </div>
      
         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--Shop Area End--> 
@endsection 