@extends('client.layout.appclient')
@section('content')
<div class="gray-bg2 pt-10">
  <div id="login" class="mb-50 mt-10">
    <div class="container">
      <div class="white-bg mb-20">
        <div class="row justify-content-center">
          <div class="col-3">
            <div class="billingtophead">
              <h4><span class="billingtopcircles" style="">1</span> Shipping</h4>
            </div>
          </div>
          <div class="col-3">
            <div class="billingtophead">
              <h4><span class="billingtopcircles" style="padding: 2px 8px 2px 8px; ">2</span> Order Review</h4>
            </div>
          </div>
          <div class="col-3">
            <div class="billingtophead">
              <h4><span class="billingtopcircles" style="padding: 2px 8px 2px 8px; background-color: #689a29;">3</span>Billing & Payment</h4>
            </div>
          </div>
        </div>
      </div>
      <div id="login-row" class="row justify-content-center align-items-center">
        <div id="login-column" class="col-md-8">
          <div id="login-box" class="col-md-12 shadow-lg p-3 mb-5 bg-white rounded">
            <div class="panel panel-default pnel">
              <div class="panel-heading panelhead">
                <h3 class="panel-title "> <strong>1 :</strong> EMAIL<span>{{Session::get('username')}}</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> NAME <span> @if(count($result)>0)
                  @foreach($result as $results)
                  {{$results->fname}} {{$results->lname}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> ADDRESS <span> @if(count($result)>0)
                  @foreach($result as $results)
                  {{$results->address}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> CITY <span> @if(count($result)>0)
                  @foreach($result as $results)
                  {{$results->city}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> PHONE <span> @if(count($result)>0)
                  @foreach($result as $results)
                  {{$results->phone}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>3 :</strong> Billing & Payment </h3>
                @if(Session::has('cart'))
                @if($commission == 'COMMISSION')
                <div class="row">
                  <div class="col-12">
                    <form method="post" action = "{{url('/')}}/cart/checkout/address/view/order/complete/order">
                      {{ csrf_field() }}
                      <div class="row">
                          
                        <div class="col-md-5 ml-auto">
                            
                            
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" name="payment" value="cod" checked/>
                  <label class="custom-control-label" for="Seller">Cash On Delivery</label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" name="payment" value="Jazz Cash" disabled>
                  <label class="custom-control-label" for="defaultGroupExample2222">Jazz Cash </label>
                </div>
                
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" name="payment" value="Easy Paisa" disabled>
                  <label class="custom-control-label" for="defaultGroupExample2222">Easy Paisa</label>
                </div>
                
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" name="payment" value="Bank Transfer" disabled>
                  <label class="custom-control-label" for="defaultGroupExample2222">Bank Transfer </label>
                </div>
                
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" name="payment" value="Card Payment" disabled>
                  <label class="custom-control-label" for="defaultGroupExample2222">Card Payment </label>
                </div>
                            
                            </div>
                        <div class="col-md-5 ml-auto">
                          <div class="cart-page-total mb-20">
                            <h2>Cart totals</h2>
                            <ul>
                              @if(Session::has('pro'))
                              <li>Total <span>PKR {{number_format(Session::get('pro'))}}</span></li>
                              @elseif(Session::has('promoPrice'))
                              <li>Total <span>PKR {{number_format(Session::get('promoPrice'))}}</span></li>
                              @else
                              <li>Total <span>PKR {{number_format($totalPrice)}}</span></li>
                              @endif
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-5 ml-auto">
                          <input type="hidden" name="prod" value="{{ json_encode($array) }}">
                          <button type="submit" name = "submit" class="btn btn-block">confirm order</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                @endif
                @endif
                
                @if(Session::has('cart'))
                @if($subscription == 'SUBSCRIPTION')
                @php
                $seller_id = [];
                $seller_pkid= [];
                
                @endphp
                @foreach($products as $product)
                @if($product['package'] == 'SUBSCRIPTION')
                @php
                $seller_pkid = $product['item']->vendor_id;
                
                @endphp
                @if(!in_array($seller_pkid,$seller_id))
                @php
                array_push($seller_id,$product['item']->vendor_id);
                $vendor_id = $product['item']->vendor_id;
                $amount = 0;
                $array = [];
                @endphp
                <div class="row">
                  <div class="col-12">
                    <form method="post" action = "{{url('/')}}/cart/checkout/address/view/order/complete/order">
                      {{ csrf_field() }}
                      
                      <div class="row">
                        <div class="col-md-5 ml-auto">
                          <div class="cart-page-total mb-20">
                            <h2>Cart totals</h2>
                            <ul>
                              @if(Session::has('pro'))
                              <li>Total <span>PKR {{number_format(Session::get('pro'))}}</span></li>
                              @elseif(Session::has('promoPrice'))
                              <li>Total <span>PKR {{number_format(Session::get('promoPrice'))}}</span></li>
                              @else
                              <li>Total <span>PKR {{number_format($totalPrice)}}</span></li>
                              @endif
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-5 ml-auto">
                          <input type="hidden" name="prod" value="{{ json_encode($array) }}">
                          <button type="submit" name = "submit" class="btn btn-block">confirm orders</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                @endif
                @endif
                @endforeach
                @endif
                @endif <br>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection 