@extends('client.layout.appclient')
@section('content') 
<!-- Nice Select CSS-->

<div class="gray-bg3">
  <div class="shop-area mb-20">
    <div class="container-fluid">
      <div class="white-bg p-3"> 

        <!--Breadcrumb One Start-->
        <div class="breadcrumb-content breadcrumb-content-tow mt-20 mb-20">
          <ul>
            <li><a href="{{url('/')}}/">Home</a></li>
            <li class="active">Search</li>
          </ul>
        </div>
        <!--Breadcrumb One End-->
      </div>
    </div>
  </div>
  <div class="shop-area">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="white-bg p-3">
            <div class="shop-layout">
              <div class="shop-topbar-wrapper mt-20">
                <div class="row">
                  <!--<div class="col-lg-2 mt-10"> <a href="#open-modals" title="Quick view" data-toggle="modal" class="btn filterbutton"><i class="fa fa-sliders mr-10"></i>All Filters </a> </div>-->
                  <div class="col-lg-2 mt-10">
                    <select class="form-control" name="style" id="style">
                        <option value="" disable="true" selected="true" >---Select Style---</option>
                    @if($style>0)
                    @foreach($style as $results)
                        <option value="{{urlencode($results->pk_id)}}">{{$results->style}}</option>
                    @endforeach
                    @endif
                    </select>
                  </div>
                  <div class="col-lg-2 mt-10">
                    <select class="form-control" name="brand" id="brand">
                        <option value="" disable="true" selected="true" >---Select Brand---</option>
                        @if($brand>0)
                        @foreach($brand as $results)
                            <option value="{{urlencode($results->SKU)}}">{{$results->brand_name}}</option>
                        @endforeach
                        @endif
                    </select>
                  </div>
                  <div class="col-lg-2 mt-10">
                      
                    <select class="form-control"  name="price" id="price">
                        <option value="" disable="true" selected="true" >---Select Price---</option>
                      <option value="1">Low to High</option>
                      <option value="2">High to Low</option>
                    </select>
                  </div>
                  <div class="col-lg-2 mt-10">
                    <select class="form-control" name="material" id="material">
                        <option value="" disable="true" selected="true" >---Select Material---</option>
                        @if($material>0)
                        @foreach($material as $results)
                            <option value="{{urlencode($results->pk_id)}}">{{$results->material}}</option>
                        @endforeach
                        @endif
                    </select>
                  </div>
                  
                <div class="col-lg-2 text-right mt-10">
                  <div class="grid-list-option">
                    <ul class="nav">
                      <li> <a  class="active"  data-toggle="tab" href="#grid"><i class="fa fa-th-large"></i></a> </li>
                      <li> <a data-toggle="tab" href="#list"><i class="fa fa-th-list"></i></a> </li>
                    </ul>
                  </div>
                </div>
                </div>
              </div>
              <!--Shop Product Start-->
              <div class="shop-product">
                <div id="myTabContent-2" class="tab-content">
                  <div id="grid" class="tab-pane fade show active">
                    <div class="product-grid-view">
                          
                      <div class="row" style="display: flow-root;">
                          
                          <div id="subCategory">
                              
                              
                          
                           @if(count($result)>0)
                        @foreach($result as $results)
                        
                        <div class="col-md-3" style="float:left;"> 
                          <!--Single Product Start-->
                          <div class="single-product mb-25">
                                       
                            <div class="product-img img-full img-size"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="" style=" position: relative;"> </a>
                              <div class="product-action">
                                <ul>
                                  <li><a href="#open-modal{{$results->pk_id}}" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                </ul>
                              </div>
                            </div>
                            <div class="product-content">
                              <h2><a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">{{$results->name}}</a></h2>
                              <p>PKR {{number_format($results->price)}}</p>
                              <div class="product-price">
                                <div class="wishlist-compare-btn"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}" class="add-btn">add to cart</a> <a href="{{URL('/')}}/product/add/wishlist/{{$results->pk_id}}" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                              </div>
                            </div>
                          </div>
                          <!--Single Product End--> 
                        </div>
                        @endforeach
                        @endif
                        </div>
                         @if(count($result)>0)
                        @foreach($result as $results)
                        <!-- Modal Area Strat -->
                          <div class="modal fade" id="open-modal{{$results->pk_id}}" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                </div>
                                <div class="modal-body">
                                  <div class="row"> 
                                    <!--Modal Img-->
                                    <div class="col-md-5"> 
                                      <!--Modal Tab Content Start-->
                                      <div class="tab-content product-details-large" id="myTabContent">
                                        <div class="tab-pane fade show active" id="single-slide1" role="tabpanel" aria-labelledby="single-slide-tab-1"> 
                                          <!--Single Product Image Start-->
                                          <div class="single-product-img img-full"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt=""> </div>
                                          <!--Single Product Image End--> 
                                        </div>
                                        <div class="tab-pane fade" id="single-slide2" role="tabpanel" aria-labelledby="single-slide-tab-2"> 
                                          <!--Single Product Image Start-->
                                          <div class="single-product-img img-full"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail2}}" alt=""> </div>
                                          <!--Single Product Image End--> 
                                        </div>
                                        <div class="tab-pane fade" id="single-slide3" role="tabpanel" aria-labelledby="single-slide-tab-3"> 
                                          <!--Single Product Image Start-->
                                          <div class="single-product-img img-full"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail3}}" alt=""> </div>
                                          <!--Single Product Image End--> 
                                        </div>
                                      </div>
                                      <!--Modal Content End--> 
                                      <!--Modal Tab Menu Start-->
                                      <div class="single-product-menu">
                                        <div class="nav single-slide-menu owl-carousel" role="tablist">
                                          <div class="single-tab-menu img-full"> <a class="active" data-toggle="tab" id="single-slide-tab-1" href="#single-slide1"><img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt=""></a> </div>
                                          <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-2" href="#single-slide2"><img src="{{URL('/')}}/storage/images/{{$results->thumbnail2}}" alt=""></a> </div>
                                          <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-3" href="#single-slide3"><img src="{{URL('/')}}/storage/images/{{$results->thumbnail3}}" alt=""></a> </div>
                                        </div>
                                      </div>
                                      <!--Modal Tab Menu End--> 
                                    </div>
                                    <!--Modal Img--> 
                                    <!--Modal Content-->
                                    <div class="col-md-7">
                                      <div class="modal-product-info">
                                        <h1>{{$results->name}}</h1>
                                        <div class="modal-product-price"><span class="new-price">PKR {{number_format($results->price)}}</span> </div>
                                        <div class="mb-10">
                                          <lable>Color</lable>
                                          <div class="color-choose"> @if(count($result)>0) <a href="{{URL('/')}}/products/details/{{$result[0]->pk_id}}/{{$result[0]->sku}}">
                                            <input id="black" type="button" name="color">
                                            <label><span style="background-color:{{$result[0]->color}} "></span></label>
                                            </a>
                                            @endif </div>
                                        </div>
                                        <div>
                                          <div class="form-group">
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Urgent Delivery">
                                                <span class="label-text">Urgent Delivery PKR{{$results->urgent_charges}} {{$result[0]->urgent_time}} Days</span> </label>
                                            </div>
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Express Delivery">
                                                <span class="label-text">Express Delivery PKR{{$results->express_charges}} {{$result[0]->express_time}} Days</span> </label>
                                            </div>
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Normal Delivery" checked>
                                                <span class="label-text">Normal Delivery PKR{{$results->normal_charges}} {{$result[0]->normal_time}} Days</span> </label>
                                            </div>
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Free Delivery">
                                                <span class="label-text">Free Delivery {{$results->free_delivery}}</span> </label>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="add-to-cart quantity">
                                          <div class="add-to-link">
                                            <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"  class="add-btn text-center">add to cart</a>
                                          </div>
                                        </div>
                                        <div class="faq-accordion">
                                          <div id="accordion">
                                            <div class="card">
                                              <div class="card-header" id="headingThree">
                                                <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"> Product Description </a> </h5>
                                              </div>
                                              <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                                <div class="card-body"> {{$results->description}}</div>
                                              </div>
                                            </div>
                                            <div class="card">
                                              <div class="card-header" id="headingTwo">
                                                <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> Product Specifications </a> </h5>
                                              </div>
                                              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                                <div class="card-body"> {{$results->material}} {{$results->style}}</div>
                                              </div>
                                            </div>
                                            <div class="card">
                                              <div class="card-header" id="headingFour">
                                                <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour"> Shipping & Returns </a> </h5>
                                              </div>
                                              <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                                <div class="card-body"> {{$results->return_policy}} </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Modal Content--> 
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        <!-- Modal Area End --> 
                        @endforeach
                        @endif 
                        
                        
                        </div>
                    </div>
                  </div>
                  <div id="list" class="tab-pane fade">
                    <div class="product-list-view"> @if(count($result)>0)
                      @foreach($result as $results)
                      <div class="product-list-item mb-40">
                        <div class="row"> 
                          <!--Single List Product Start-->
                          <div class="col-md-2">
                            <div class="single-product">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"> <img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt=""> </a> </div>
                            </div>
                          </div>
                          <div class="col-md-8">
                            <div class="product-content shop-list">
                              <h1><a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">{{$results->name}}</a></h1>
                              <div class="product-description">
                                <p class="text-justify">{{$results->description}}</p>
                              </div>
                              <div class="product-price">
                                <div class="price-box">
                                  <h4 class="regular-price">PKR {{number_format($results->price)}}</h4>
                                </div>
                              </div>
                              <div class="product-list-action">
                                <div class="add-btn"> <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}">Add To Cart</a> </div>
                              </div>
                            </div>
                          </div>
                          <!--Single List Product End--> 
                        </div>
                      </div>
                      @endforeach
                      @endif </div>
                  </div>
                </div>
              </div>
              <!--Shop Product End--> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  @endsection 
</div>