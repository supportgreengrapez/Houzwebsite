
@extends('client.layout.appclient')
@section('content')

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="//geodata.solutions/includes/countrystatecity.js"></script>
<body>
    <div class="container">
    <div class="row">
        <div class="col-lg-8 col-md-12 col-sm-12 col-lg-offset-2">

            <div class="panel panel-default">

                <div class="panel-heading">
                    <h3 class="panel-title">
                       1: YOUR EMAIL &nbsp;&nbsp;&nbsp;&nbsp; {{session::get('username')}}               </h3>
                </div>


                <div class="panel-heading">
                    <h3 class="panel-title">
                       2: YOUR ADDRESS          </h3>
                </div>

                    <div class="row">
                      <div class="col-md-12">
                        <div id="mainContentWrapper">
                          <div class="col-md-12">
                             <div class="shopping_cart">
                            <form  role="form" action="{{url('/')}}/cart/checkout/add/address" method="post" id="payment-form">
                              {{ csrf_field() }}

                                <div class="panel">
                                  <div class="">
                                    <div class="panel-body">
                                      <table class="table" style="font-weight: bold;">

                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_first_name">First name:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_first_name" name="fname" value= "{{session::get('fname')}}  "
                                                                             type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_last_name">Last name:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_last_name" name="lname" value= "{{session::get('lname')}}  "
                                                                              type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_address_line_1">Address:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_address_line_1"
                                                                             name="address"  type="text"/></td>
                                        </tr>


                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_phone">Phone:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_phone" name="phone" type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_phone">Zip Code:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_phone" name="zip" type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;">

                    <label for="id_phone">Country*</label></td>

               <td style="border-top: 0px;"> <select name="country" class="countries form-control" id="countryId">
                    <option value="">Select Country</option>
                </select></td>
                </tr>
                <tr>
                    <td style="width: 175px; border-top: 0px;"><label for="text">State*</label></td>
                    <td style="border-top: 0px;"><select name="state" class="states form-control" id="stateId">

                     <option value="">Select State</option>
                </select></td>
                </tr>
                <tr>

                <td style="width: 175px; border-top: 0px;"><label for="text">City*</label></td>
                <td style="border-top: 0px;"><select name="city"  class="cities form-control" id="cityId">
                          <option value="">Select City</option>
                </select></td>
                </tr>
             </div>

                                          </td>
                                        </tr>


                                      </table>
                                          <button name="submit" type="submit" class="btn login-button">Save Address</button>
                                    </div>
                                  </div>
                                </div>


                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                <div class="panel-heading panelhead">
                    <h3 class="panel-title">
                        3:ORDER SUMMERY                    </h3>
                </div>
                <div class="panel-heading panelhead">
                    <h3 class="panel-title">
                       4: PAYMENT                    </h3>
                </div>

            </div>

            <br/>
        </div>
    </div>
  </div>
</body>
@endsection
