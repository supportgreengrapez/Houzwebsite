@extends('client.layout.appclient')
@section('content')
<div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <div class="pagetophead">
          <h4>Advertise with us</h4>
        </div>
      </div>
    </div>
  </div>
  <div class="gray-bg3">
    <div class="container">
    
    
   
              <div class="row justify-content-center">
    
        <div class="col-lg-3">
        
       
          <div class="advertisetabs">
           <button data-toggle="tab" data-tabs=".gtabs" data-tab=".tab-1" class="btn btn-info tabbtnstyl" >
            <h4>Sellers</h4>
            <i class="fa fa-cart-arrow-down"></i>
         </button> </div>
           
           </div>
        
          
        <div class="col-lg-3">
        
       
          <div class="advertisetabs">
           <button data-toggle="tab" data-tabs=".gtabs" data-tab=".tab-2" class="btn btn-info tabbtnstyl" >
            <h4>Professionals</h4>
            <i class="fa fa-laptop"></i>
         </button> </div>
          
          </div>
         
         
        <div class="col-lg-3">
      
          <div class="advertisetabs">
           <button data-toggle="tab" data-tabs=".gtabs" data-tab=".tab-3" class="btn btn-info tabbtnstyl" >
            <h4>Realtor</h4>
           <i class="fa fa-building"></i>
         </button> </div>
        
          </div>
         
         
      </div>
                  
                  
                    <!--Store Tab Content Start-->
                  
                    
                   <div class="gtabs" >
                       <div class="gtab active tab-1">
                        <div class="row">
            <div class="col-lg-4">
              <div class="nav-side-menu mt-20">
                <div class="brand">Sellers</div>
                <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
                <div class="menu-list">
                  <ul id="menu-content" class="menu-content collapse out">
                    <li  data-toggle="collapse" data-target="#products" class="collapsed"> <a href="#"> Banner Advertising<span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse" id="products">
                      <li class=""><a href="#">Splash Banner</a></li>
                    </ul>
                    <li data-toggle="collapse" data-target="#service" class="collapsed"> <a href="#"> Project Advertising <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse" id="service">
                      <li><a href="#">Featured Projects</a></li>
                    </ul>
                    <li data-toggle="collapse" data-target="#new" class="collapsed"> <a href="#"> Featured Sellers <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse" id="new">
                      <li><a href="#">Featured Sellers</a></li>
                    </ul>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-8">
              <div class="row">
                <div class="col-lg-12">
                  <div class="brand2">Description</div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <div class="descriptiontabs">
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                  </div>
                </div>
              </div>
            </div>
            
             </div>
              </div>
         
         <div class="gtab tab-2">
          <div class="row">
            <div class="col-lg-4">
              <div class="nav-side-menu mt-20">
                <div class="brand">Sellers</div>
                <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
                <div class="menu-list">
                  <ul class="menu-content collapse out">
                    <li  data-toggle="collapse" data-target="#products" class="collapsed"> <a href="#"> Banner Advertising<span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse">
                      <li class=""><a href="#">Splash Banner</a></li>
                    </ul>
                    <li data-toggle="collapse" data-target="#service" class="collapsed"> <a href="#"> Project Advertising <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse">
                      <li><a href="#">Featured Projects</a></li>
                    </ul>
                    <li data-toggle="collapse" data-target="#new" class="collapsed"> <a href="#"> Featured Sellers <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse">
                      <li><a href="#">Featured Sellers</a></li>
                    </ul>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-8">
              <div class="row">
                <div class="col-lg-12">
                  <div class="brand2">Description</div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <div class="descriptiontabs">
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting,</p>
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
           </div>
       
         <div class="gtab tab-3">
         <div class="row">
            <div class="col-lg-4">
              <div class="nav-side-menu mt-20">
                <div class="brand">Brand Logo</div>
                <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
                <div class="menu-list">
                  <ul id="" class="menu-content collapse out">
                    <li  data-toggle="collapse" data-target="#products" class="collapsed active"> <a href="#"><i class="fa fa-gift fa-lg"></i> UI Elements <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse" id="">
                      <li class="active"><a href="#">CSS3 Animation</a></li>
                      <li><a href="#">General</a></li>
                      <li><a href="#">Buttons</a></li>
                    </ul>
                    <li data-toggle="collapse" data-target="#service" class="collapsed"> <a href="#"><i class="fa fa-globe fa-lg"></i> Services <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse" id="">
                      <li>New Service 1</li>
                      <li>New Service 2</li>
                      <li>New Service 3</li>
                    </ul>
                    <li data-toggle="collapse" data-target="#new" class="collapsed"> <a href="#"><i class="fa fa-car fa-lg"></i> New <span class="arrow"></span></a> </li>
                    <ul class="sub-menu collapse" id="">
                      <li>New New 1</li>
                      <li>New New 2</li>
                      <li>New New 3</li>
                    </ul>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-8">
              <div class="row">
                <div class="col-lg-12">
                  <div class="brand2">Brand Logo</div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <div class="descriptiontabs">
                    <p>Seller
                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
         </div>

    </div>
  </div>
@endsection