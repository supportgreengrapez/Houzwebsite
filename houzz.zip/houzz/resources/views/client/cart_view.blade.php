@extends('client.layout.appclient')
@section('content')
		<!--Breadcrumb Tow Start-->
		<div class="breadcrumb-tow mb-20">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="{{url('/')}}/">Home</a></li>
                                <li class="active">Shopping Cart</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
        @if(Session::has('cart'))
		<!--Shopping Cart Area Strat-->
		<div class="Shopping-cart-area mb-110">
		    <div class="container">
		        <div class="row">
		            <div class="col-12">
		                <form action="#">
		                    <div class="table-content table-responsive">
		                        <table class="table">
		                            <thead>
		                                <tr>
		                                    <th class="plantmore-product-remove">remove</th>
		                                    <th class="plantmore-product-thumbnail">images</th>
		                                    <th class="cart-product-name">Product</th>
                                            <th class="cart-product-name">Size</th>
		                                    <th class="plantmore-product-price">Unit Price</th>
		                                    <th class="plantmore-product-quantity">Quantity</th>
		                                    <th class="plantmore-product-subtotal">Total</th>
		                                </tr>
		                            </thead>
		                            <tbody>
                                    @foreach($products as $product)
		                                <tr>
		                                    <td class="plantmore-product-remove"><a href="{{URL('/')}}/remove/item/cart/{{$product['item']->pk_id}}/{{$product['qty']}}/{{$product['delivery_charges']}}"><i class="fa fa-times"></i></a></td>
		                                    <td class="plantmore-product-thumbnail"><img src="{{URL('/')}}/storage/images/{{$product['item']->thumbnail}}" alt="" style="width:150px; height:150px;"></td>
		                                    <td class="plantmore-product-name">{{$product['item']->name}}</td>
                                            <td class="plantmore-product-name">{{$product['size']}}</td>
		                                    <td class="plantmore-product-price"><span class="amount">{{number_format($product['item']->price)}}
        @if($product['save']>0) saving - {{number_format($product['save'])}}@endif</span></td>
		                                    <td class="plantmore-product-price"><span class="amount">{{$product['qty']}}</span></td>
		                                    <td class="product-subtotal"><span class="amount">{{number_format($product['price'])}}</span></td>
		                                </tr>
                                        @endforeach
		                            </tbody>
		                        </table>
		                    </div>

		                    <div class="row">
		                        <div class="col-md-5 ml-auto">
		                            <div class="cart-page-total">
		                                <h2>Cart totals</h2>
		                                <ul>
										@foreach($products as $product)
											
											<li>Delivery Charges <span>PKR {{$product['delivery_charges']}}</span></li>
											@endforeach
		                                    <li>Subtotal <span>PKR {{number_format($totalPrice)}}</span></li>
		                                    <li>Total <span>PKR {{number_format($totalPrice)}}</span></li>
		                                </ul>
		                                <a href="{{url('/')}}/cart/checkout">Proceed to checkout</a>
		                            </div>
		                        </div>
		                    </div>
		                </form>
		            </div>
		        </div>
		    </div>
		</div>
		<!--Shopping Cart Area End-->
        @endif
@endsection

