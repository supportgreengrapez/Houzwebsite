
@extends('client.layout.app')
@section('content')
    <div class="container">
    <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12">
        	<div class="men-img">
            	<img src="{{url('/')}}/pic/menbanner.png"  alt="men">
                	<h2><a href="ACCESSORIES.html">ACCESSORIES</a></h2>
            </div>
            </div>
            </div>
            <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
        	<div class="men-img">
            	<img src="{{url('/')}}/pic/8.png"  alt="men">
                </div>	
            </div>
            <div class="col-lg-4 col-md-4col-sm-12">
        	<div class="men-img">
            	<img src="{{url('/')}}/pic/shoes1.png"  alt="men">
         </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
        	<div class="men-img">
            	<img src="{{url('/')}}/pic/10.png"  alt="men">
               </div> 	
            </div>
            </div>
        </div> 
         
    @endsection