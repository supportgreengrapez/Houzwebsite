@extends('client.layout.app')
@section('content')
<!----//End-bottom-header----> 
<form method="post" action = "{{url('/')}}/cart/guest/checkout/address/view/order/complete/order" class="login100-form validate-form p-l-55 p-r-55 p-t-50">
    {{ csrf_field() }}

    <div class="container">
    <div class="row">
        <div class="col-lg-8 col-md-12 col-sm-12 col-lg-offset-2">
            <div class="panel panel-default pnel">
                <div class="panel-heading" style="border-bottom:none;">
                    <h3 class="panel-title" >
                       1: YOUR EMAIL &nbsp;&nbsp;&nbsp;&nbsp; {{session()->get('email')}}                   </h3>
                </div>
                
                <div class="panel-heading" style="border-bottom:none;">
                    <h3 class="panel-title">
                       2: YOUR ADDRESS :  &nbsp;&nbsp;&nbsp;&nbsp; {{session()->get('fname')}} {{session()->get('lname')}} : {{session()->get('phone')}} :
                       {{session()->get('address')}} , {{session()->get('city')}} </h3>
                </div>
                
      				
                <div class="panel-heading" style="border-bottom:none;">
                    <h3 class="panel-title">
                        3:ORDER SUMMERY                    </h3>
                        
                          @if(Session::has('cart'))
    <div class="row">
        <div class="col-sm-12 col-md-10 col-md-offset-1">
        <div class="table-responsive">
        	<table class="table table-bordered">
                <thead style="background-color:#f6f6f6;">
                
                    <tr>
                  
                    	    <th class="text-center">Image</th>
                    <th class="text-center">Name</th>
                       <th class="text-center">Size</th>
    <th class="text-center">Quantity</th>
    <th class="text-center">Unit Price</th>
    <th class="text-center">Amount</th>
 
                    </tr>
                </thead>
                  @foreach($products as $product) 
                <tbody>
                    <tr>
                
                        <td class="col-sm-1 col-md-1">
                        <div class="media">
                         <img class="media-object" src="{{URL('/')}}/storage/images/{{$product['item']->thumbnail}}" style="width: 72px; height: 72px;">
                        </div></td>
                                 
                        <td class="col-sm-1 col-md-1 text-center"><strong>{{$product['item']->name}}</strong></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>{{$product['size']}}</strong></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>{{$product['qty']}}</strong></td>
                        <td class="col-sm-1 col-md-1 text-center"><strong>{{$product['item']->price}} 
        @if($product['save']>0) saving -{{$product['save']}}@endif</strong></td>
          <td class="col-sm-1 col-md-1 text-center"><strong>{{$product['price']}}</strong></td>

                    </tr>
           
                </tbody>
                   @endforeach
            </table>
        
        </div>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-12 col-md-4 col-lg-4 col-lg-offset-7">
            	<table class="table table-bordered">
                <label style="color:#ed6c71;">Subtotal</label>
                <tr>
                        <td><h5>Subtotal</h5></td>
                        <td class="text-right"><h5><strong>{{$totalPrice}}</strong></h5></td>
                    </tr>
                    <tr>
                        <td><h5>Total Amount</h5></td>
                        <td class="text-right"><h5><strong>{{$totalPrice}}</strong></h5></td>
                    </tr>
                    <tr>
                    </tr>
            </table>
        
        </div>
    </div>
       @endif
                </div>
                
                <div class="panel-heading" style="border-bottom:none;">
                    <h3 class="panel-title">
                       4: PAYMENT                    </h3>
                </div>
                <div class="payment">
        <div class="col-lg-12 col-md-5 col-sm-8  bhoechie-tab-container">
            <div class="col-lg-3 col-md-3 col-sm-3  bhoechie-tab-menu">
              <div class="list-group">
         
                <a href="#" class="list-group-item text-center active">
                  <h4 class="far fa-money-bill-alt active"></h4><br>Cash on delivery
                </a>
             
                
              </div>
            </div>
            <div class="col-lg-9 col-md-9 col-sm-9 col-xs-9 bhoechie-tab">
                <!-- flight section -->
                <div class="bhoechie-tab-content active">
                    <p class="textwrite">Pay in cash to the courier at the time of the delivery</p>
                    <button type="submit" name = "submit" class="btn cnfmorder">Confirm Order</button>
                </div>
                <!-- train section -->
                
    
                <!-- hotel search -->
                
            </div>
            
            </div>
            </div>
            </div>
            <br/>
        </div>
    </div>
</div>
</form>
		@endsection
