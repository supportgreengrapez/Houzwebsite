@extends('client.layout.appclient')
@section('content')
  <!--Breadcrumb Tow Start-->
  <div class="gray-bg3 pb-70 pt-20">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-3 col-md-3 col-md-12 col-xs-12">
          <div class="signintophead mt-20">
            <h4>Buyer</h4>
          </div>
        </div>
      </div>

      <form method="post" action = "{{url('/')}}/signup">
               {{ csrf_field() }}

               @if($errors->any())
<br>
<div class="alert alert-danger">
  <strong>Danger!</strong> {{$errors->first()}}
</div>
@endif
      <div class="row justify-content-center">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="bgmentorsign2">
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="form-group text-left signinlabelssets">
                  <label for="phone">Phone</label>
                  <input  class="form-control formpad" name="phone" placeholder="Phone" required>
                 </div>
              </div>

            </div>
            <div class="row">
              <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <div class="form-group text-left signinlabelssets">
                  <label for="zip code">Zip Code</label>
                  <input type="number" class="form-control blueborder" id="" placeholder="Zip Code" name="zip">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="form-group text-left">
                  <div class="form-group text-left signinlabelssets">
                    <label for="gender">Age</label>
                    <input type="number" class="form-control blueborder" id="" placeholder="Age" name="age">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                 <div class="form-group text-left signinlabelssets">
                  <label for="gender">Gender</label>
                  <select class="form-control  blueborder" name="gender">
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="submitbutton">
                  <button type="submit" class="btn submitbtn  btn-responsive"  aria-expanded="false">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      </form>
    </div>
  </div>
  <!--Blog Area End-->
  @endsection
