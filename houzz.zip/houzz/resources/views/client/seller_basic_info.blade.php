<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" type="image/x-icon" href="{{url('/')}}/pic/favicon.png">
<title>Houzz</title>

<!-- Bootstrap -->
<link href="{{url('/')}}/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{url('/')}}/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="{{url('/')}}/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="{{url('/')}}/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="{{url('/')}}/css/custom.min.css" rel="stylesheet">
<link href="{{url('/')}}/css/style2.css" rel="stylesheet">
</head>

<body>
<div class="container" style="width:85% !important;">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
      <div class="textcen" style="margin-top:0px !important;">
        <h4 style="margin:0px;">Basic Seller Info</h4>
      </div>
    </div>
  </div>
  <form method="post" action="{{url('/')}}/signup/seller/basic"  enctype="multipart/form-data" >
    {{ csrf_field() }}
    
    @if($errors->any()) <br>
    <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
    @endif
    <div class="row">
      <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 col-lg-offset-1 mt-20">
        <div class="topsellermsg">
          <p>(Change will be reflected in your professional profile)</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Business Name</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="business_name" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Seller Introduction</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
          <textarea class="form-control" rows="9" name="intro"></textarea>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Account Type</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="radio" name="account_t" value="Individual" onclick="show1();" />
            Individual
            <input type="radio" name="account_t" value="Business" onclick="show2();" />
            Business </div>
        </div>
        <div id="div1" class="hide">
          <div class="form-group row mt-20">
            <label class="col-lg-4 col-sm-12 col-xs-12 f-16">CNIC</label>
            <div class="col-lg-8 col-sm-12 col-xs-12">
              <input type="text" name="cnic" class="form-control" >
            </div>
          </div>
        </div>
        <div id="div2" class="hide">
          <div class="form-group row mt-20">
            <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Seller Category</label>
            <div class="col-lg-8 col-sm-12 col-xs-12">
              <select class="form-control" name="vendor_cat">
                <option value="">Select Seller Category</option>
                <option value="Manufacture">Manufacture</option>
                <option value="Wholeseller">Wholeseller</option>
                <option value="Retailer">Retailer</option>
              </select>
            </div>
          </div>
          <div class="form-group row mt-20">
            <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Bussiness Certificate</label>
            <div class="col-lg-8 col-sm-12 col-xs-12">
              <input type="file" name="certificate" class="form-control" onchange="readURL2(this);"/>
              <img id="blah2" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:150px; height:170px;" /> </div>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Payment Package</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="radio" name="p_package" value="Subscription"/>
            Subscription package
            <input type="radio" name="p_package" value="Commission"/>
            Commission Package </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Address</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="address" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Zip/Postal Code</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="zip" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Country</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <select name="country" class="countries order-alpha form-control" id="countryId">
              <option value="">Select country</option>
            </select>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">State/County/Province</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <select name="state" class="states order-alpha form-control" id="stateId">
              <option value="">Select state</option>
            </select>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">City</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <select name="city" class="cities order-alpha form-control" id="cityId">
              <option value="">Select City</option>
            </select>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Phone</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="tel" name="phone" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Fax</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="tel" name="fax" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Website Url</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="url" name="url" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Upload logo</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
            <img id="blah" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:150px; height:170px;" /> </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="bsbottom">
          <h6>Performance Standards</h6>
          <p>In participating in the Houzz Marketplace, Seller will work to achieve a level of customer service that adheres to the following performance standards:</p>
          <ul class="bsbottomul">
            <li><b>On-Time Fulfillment</b> : at least 98% are fullfilled with in a specified lead times for each product</li>
            <li><b>Damage Rates</b> : less than 2% of all orders</li>
            <li><b>Cancellations</b> : No greater than 2% of all orders</li>
            <li><b>Order Defect Rate</b> : less than 2% of all orders (this includes backorders, seller-faulted returns, and chargebacks)</li>
            <li><b>Contact Response Time</b> : within 24 hours, 7 days a week</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 col-lg-offset-3 mt-20">
        <div class="bottombtn">
          <button type="submit" class="btn btnupdate">Save & Continue</button>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </form>
</div>
<!-- /page content --> 

<!-- footer content -->
<footer> 
  
  <!--Footer Copyright Start-->
  <div class="footer-copyright">
    <p>Copyright © <a href="http://general.greengrapez.com/houzz/public/">Houzz.pk</a> All Rights Reserved</p>
  </div>
  <div class="footer-copyright">
    <p>Powered By <a href="https://greengrapez.com/"><img src="{{url('/')}}/pic/greengrapez.png" alt="Green Grapez"></a></p>
  </div>
  <!--Footer Copyright End--> 
</footer>
<!-- /footer content --> 

<script src="{{url('/')}}/js1/vendor/jquery-1.12.4.min.js"></script> 
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//geodata.solutions/includes/countrystatecity.js"></script> 
<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	function readURL2(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah2')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
	
	function show1(){
  document.getElementById('div2').style.display ='none';
  document.getElementById('div1').style.display ='block';
  
  $("#div2 input[type=file]").val(''); 
}
function show2(){
  document.getElementById('div2').style.display = 'block';
  document.getElementById('div1').style.display = 'none';
  $("#div1 input[type=file]").val('');
}
</script>
</body>
</html>
