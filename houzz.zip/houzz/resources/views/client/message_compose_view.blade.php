@extends('client.layout.appclient')
@section('content')
      <div class="page-title">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="title_left m-2">
            <h3>Message Management</h3>
            <h4>New Message List</h4>
          </div>
        </div>
      </div>
        <div class="clearfix"></div>
        <div class="wrap">
      
      <div class="row">
      <div class="col-lg-12">
      <form method="post" action = "{{url('/')}}/client/compose/message" enctype="multipart/form-data" class="login-form">
                            {{ csrf_field() }}
                            @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
    <strong></strong> {{$errors->first()}}
    <button type="button" class="close" data-dismiss="alert">&times;</button>
</div>
@endif
      
      <div class="form-group">
      <label>Seller/Admin Name</label>
      <select class="form-control" name="seller_name">
      @if(count($result)>0)
      @foreach($result as $results)
      <option value="{{$results->pk_id}}"><b style="float:left;">{{$results->fname}} {{$results->lname}}</b> <b style="float:right;">{{$results->business_name}}</b></option>
      @endforeach
      @endif
      </select>
      </div>
   
      <div class="form-group">
      <label>Message</label>
      <textarea class="form-control" rows="9" name="message"></textarea>
      <h6 class="pull-right red">Character Limit 1000</h6>
      </div>
      <div class="form-group">
      <button type="submit" class="btn btn-success">Submit Answered</button>
      </div>
      </form>
      </div>
      </div>
      </div>
</div>
@endsection