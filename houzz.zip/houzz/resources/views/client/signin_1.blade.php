@extends('client.layout.appclient')
@section('content') 
<div class="gray-bg3 pb-70 pt-20">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-3 col-md-3 col-md-12 col-xs-12">
        <div class="signintophead mt-20">
          <h4>SIGNUP</h4>
        </div>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <form method="post" action = "{{url('/')}}/create_account" enctype="multipart/form-data" >
          {{ csrf_field() }}
          
          @if($errors->any()) <br>
          <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
          @endif
          <div class="bgmentorsign2">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-user mentsignicons"></i></span>
                  <input type="text" class="form-control formpad" name="fname" placeholder="First Name">
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-user mentsignicons"></i></span>
                  <input type="text" class="form-control formpad" name="lname" placeholder="Last Name">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-envelope mentsignicons"></i></span>
                  <input type="email" class="form-control formpad" name="username" placeholder="Email Address">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-key mentsignicons"></i></span>
                  <input type="password" class="form-control formpad" name="password"  placeholder="Create a Password" required>
                </div>
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-key mentsignicons"></i></span>
                  <input type="password" class="form-control formpad" name="cpassword" placeholder="Confirm Password" required>
                </div>
              </div>
            </div>
            <h4 style="margin-top:20px;" class="text-left">I Want To:</h4>
            <div class="row">
              <div class="col-lg-5 col-md-3 col-sm-12">
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="Buyer" name="customer_type" value="buyer" onclick="show2();"/>
                  <label class="custom-control-label" for="Buyer">Buyer</label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="Seller" name="customer_type" value="seller" onclick="show1();"/>
                  <label class="custom-control-label" for="Seller">Seller</label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="defaultGroupExample2222" name="customer_type" value="realtor" disabled>
                  <label class="custom-control-label" for="defaultGroupExample2222">Realtor </label>
                </div>
                <div class="custom-control custom-radio mt-10 text-left">
                  <input type="radio" class="custom-control-input" id="defaultGroupExample333" name="customer_type" value="professional" disabled>
                  <label class="custom-control-label" for="defaultGroupExample333">Professional</label>
                </div>
              </div>
            </div>
            <div id="div1" class="hide">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                 <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-phone mentsignicons"></i></span>
                  <input type="tel" class="form-control formpad" name="phone" placeholder="Phone">
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-file mentsignicons"></i></span>
                  <input type="text" class="form-control formpad" name="zip" placeholder="Zip Code">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-adn mentsignicons"></i></span>
                  <input type="text" class="form-control formpad" name="age" placeholder="Age">
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="input-group top"> <span class="input-group-addon"><i class="fa fa-venus-double mentsignicons"></i></span>
                  <select class="form-control formpad" name="gender">
                    <option>Male</option>
                    <option>Female</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="sign2bottom">
                  <div class="custom-control custom-checkbox mt-30 text-left">
                    <input type="checkbox" class="custom-control-input" name="terms" id="defaultChecked911">
                    <label class="custom-control-label" for="defaultChecked911">Yes,I understand and agree to the <a href="#">Houzz Terms of Services</a>,including the User <a href="#">Agreement <span>and </span>Privacy policy</a>.</label>
                  </div>
                </div>
              </div>
            </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="submitbutton">
                  <button type="submit" class="btn submitbtn btn-responsive">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection 