@extends('client.layout.appclient')
@section('content')
<style>
  /* Make the image fully responsive */
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
  </style>
<div class="gray-bg3">
  <div class="shop-area">
    <div class="container">
      <div class="row white-bg">
        <div class="col-lg-9 col-sm-12 col-xs-12 mt-20 "> @if(count($result)>0)
          @foreach($result as $results)
          <div class="mb-20 border-bottom pb-20">
            <div class="row">
              <div class="col-lg-4 col-md-3 col0sm-12 col-xs-12"> 
                <!--Carousel Wrapper--> 
                <!--Single Banner Area Start-->
                <div id="carouselExampleControls{{$results->user_id}}" class="carousel slide" data-ride="carousel">
                  <div class="carousel-inner">
                    <div class="carousel-item active"> <img class="d-block w-100" src="{{URL('/')}}/storage/images/{{$results->slide}}" alt="First slide" style="height:126.98px;"> </div>
                    <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/storage/images/{{$results->slide2}}" alt="Second slide" style="height:126.98px;"> </div>
                    <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/storage/images/{{$results->slide3}}" alt="Third slide" style="height:126.98px;"> </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleControls{{$results->user_id}}" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls{{$results->user_id}}" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
                <!--Single Banner Area End--> 
                <!--/.Carousel Wrapper--> 
              </div>
              <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="col-lg-12 col-md-12 col0sm-12 col-xs-12">
                    <div class="leftboxagencyname">
                      <h3><img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="logo" style="width:100px;hight:100px;"> <strong>{{$results->fname}} {{$results->lname}}</strong></h3>
                      
                      <p class="text-justify">{{$results->intro}}</p>
                      <a href="{{url('/')}}/seller_detail/{{$results->user_id}}"><strong> Read More</strong></a> </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="sidebar-layout mb-35"> <a href="#" class="message-btn" data-toggle="modal" data-target="#myModal{{$results->user_id}}"><i class="fa fa-envelope"></i> Send Message</a> <a class="mobilesOnly" href="tel:{{$results->phone}}" data-toggle="modal" data-target="#number{{$results->user_id}}"><i class="fa fa-phone"></i> View Number</a> </div>
              </div>
              @if(Session::has('username'))
              <div class="modal fade" id="number{{$results->user_id}}">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                    </div>
                    <div class="modal-body">
                      <h2 class="font-weight-bold text-center">{{$results->phone}}</h2>
                      <a href="tel:+92{{$results->phone}}" class="mobilsOnly"><strong>Call Now</strong></a> </div>
                  </div>
                </div>
              </div>
              @else
              <div class="modal" id="number{{$results->user_id}}">
                <div class="modal-dialog">
                  <div class="modal-content"> 
                    
                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">View Number</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    
                    <!-- Modal body -->
                    <div class="modal-body">
                      <p>Please login before View Number</p>
                    </div>
                    
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              @endif
              @if(Session::has('username'))
              <div class="modal" id="myModal{{$results->user_id}}">
                <div class="modal-dialog">
                  <div class="modal-content"> 
                    
                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Compose Message</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    
                    <!-- Modal body -->
                    <div class="modal-body">
                      <form method="post" action = "{{url('/')}}/client/compose/message" enctype="multipart/form-data" class="login-form">
                        {{ csrf_field() }}
                        @if($errors->any())
                        <div class="alert alert-danger alert-dismissible fade show"> <strong></strong> {{$errors->first()}}
                          <button type="button" class="close" data-dismiss="alert">&times;</button>
                        </div>
                        @endif
                        <div class="form-group">
                          <label>Seller/Admin Name</label>
                          <input type="text" class="form-control" name="" value="{{$results->fname}} {{$results->lname}}"readonly>
                          <input type="hidden" class="form-control" name="seller_name" value="{{$results->user_id}}">
                        </div>
                        <div class="form-group">
                          <label>Message</label>
                          <textarea class="form-control" rows="9" name="message"></textarea>
                          <h6 class="pull-right red">Character Limit 1000</h6>
                        </div>
                        <div class="form-group">
                          <button type="submit" class="btn btn-success">Submit Answered</button>
                        </div>
                      </form>
                    </div>
                    
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              @else
              <div class="modal" id="myModal{{$results->user_id}}">
                <div class="modal-dialog">
                  <div class="modal-content"> 
                    
                    <!-- Modal Header -->
                    <div class="modal-header">
                      <h4 class="modal-title">Compose Message</h4>
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    
                    <!-- Modal body -->
                    <div class="modal-body">
                      <p>Please login before send message</p>
                    </div>
                    
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              @endif </div>
          </div>
          @endforeach
          @endif </div>
        <div class="col-lg-3 col-sm-12 col-xs-12 mt-20 ">
          <div class="permotions_ad mb-20"> <img src="{{URL('/')}}/pic/e.png" alt="permotion"> </div>
          <div class="permotions_ad mb-20"> <img src="{{URL('/')}}/pic/f.png" alt="permotion"> </div>
          <div class="permotions_ad mb-20"> <img src="{{URL('/')}}/pic/q.png" alt="permotion"> </div>
          <div class="permotions_ad mb-20"> <img src="{{URL('/')}}/pic/w.png" alt="permotion"> </div>
          <div class="permotions_ad mb-20"> <img src="{{URL('/')}}/pic/t.png" alt="permotion"> </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection