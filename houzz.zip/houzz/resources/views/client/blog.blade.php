 @extends('client.layout.appclient')
@section('content')
		<!--Breadcrumb Tow Start-->
        <div class="gray-bg3">
        <div class="container">
		<div class="breadcrumb-tow mb-20 p-2">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-content breadcrumb-content-tow">
                            <ul>
                                <li><a href="{{url('/')}}/">Home</a></li>
                                <li class="active">Blog</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<!--Breadcrumb Tow End-->
		<!--Blog Area Start-->
		<div class="blog-area white-bg pt-1 pb-1">
		    <div class="container">
		        <div class="row">
                    <!--Blog Post Start-->
		            <div class="col-lg-9">
		                <div class="blog_area">
		                    @if(count($result)>0)
		                    @foreach($result as $results)
                            <article class="blog_single">
                                <header class="entry-header">
                                    <span class="post-category">
                                        <a href="#"> Fashion</a>,<a href="#">WordPress</a>
                                    </span>
                                    <h2 class="entry-title">
                                        <a href="single-blog.html">{{$results->title}}</a>
                                    </h2>
                                    <span class="post-author">
                                    <span class="post-by"> Posts by : </span> admin </span>
                                    <span class="post-separator">|</span>
                                    <span class="blog-post-date"><i class="fas fa-calendar-alt"></i>On March 10, 2018 </span>
                                </header>
                                <div class="post-thumbnail img-full">
                                    <a href="single-blog.html">
                                        <img src="{{URL('/')}}/storage/images/{{$results->post}}" alt="">
                                    </a>
                                </div>
                                <div class="postinfo-wrapper">
                                    <div class="post-info">
                                        <div class="entry-summary">
                                            <p>{{$results->body}}</p>
                                            <a href="single-blog.html" class="form-button">Read More</a>
                                            <div class="social-sharing">
                                                <div class="widget widget_socialsharing_widget">
                                                    <h3 class="widget-title">Share this post</h3>
                                                    <ul class="blog-social-icons">
                                                        <li>
                                                            <a target="_blank" title="Facebook" href="#" class="facebook social-icon">
                                                                <i class="fa fa-facebook"></i>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a target="_blank" title="twitter" href="#" class="twitter social-icon">
                                                                <i class="fa fa-twitter"></i>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a target="_blank" title="pinterest" href="#" class="pinterest social-icon">
                                                                <i class="fa fa-pinterest"></i>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a target="_blank" title="linkedin" href="#" class="linkedin social-icon">
                                                                <i class="fa fa-linkedin"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            @endforeach
                            @endif
                        </div>
                        
		            </div>
		            <!--Blog Post End-->
		            <!--Blog Sidebar Start-->
		            <div class="col-lg-3">
		                <div class="blog_sidebar">
                            <div class="row_products_side">
                                <div class="product_left_sidbar">
                                    <div class="product-filter mt-20  mb-35">
                                      <h5>Search </h5>
                                      <div class="search__sidbar">
                                         <div class="input_form">
                                            <input id="search_input" name="s" value="Search..." class="input_text" type="text">
                                            <button id="blogsearchsubmit" type="submit" class="button">
                                                <i class="fa fa-search"></i>
                                            </button>
                                         </div>
                                      </div>
                                    </div>
                                    <div class="product-filter  mb-35">
                                      <h5>Blog Archives </h5>
                                        <div class="blog_Archives__sidbar">
                                            <ul>
                                                <li>
                                                    <a href="#">March 2015</a>&nbsp;(1)</li>
                                                <li>
                                                    <a href="#">December 2014</a>&nbsp;(3)</li>
                                                <li>
                                                    <a href="#">November 2014</a>&nbsp;(4)</li>
                                                <li>
                                                    <a href="#">September 2014</a>&nbsp;(1)</li>
                                                <li>
                                                    <a href="#">August 2014</a>&nbsp;(1)</li>
                                            </ul>
                                      </div>
                                    </div>
                                    <div class="product-filter mb-35">
                                        <h5>tags</h5>
                                       <div class="product-tag blog-tag">
                                            <ul>
                                                <li><a href="#">brand</a></li>
                                                <li><a href="#">black</a></li>
                                                <li><a href="#">white</a></li>
                                                <li><a href="#">chire</a></li>
                                                <li><a href="#">table</a></li>
                                                <li><a href="#">Lorem</a></li>
                                                <li><a href="#">ipsum</a></li>
                                                <li><a href="#">dolor</a></li>
                                                <li><a href="#">sit</a></li>
                                                <li><a href="#">amet</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
		            </div>
		            <!--Blog Sidebar End-->
		        </div>
		    </div>
		</div>
        </div>
        </div>
		<!--Blog Area End-->
	@endsection