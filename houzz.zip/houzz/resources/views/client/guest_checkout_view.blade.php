
@extends('client.layout.app')
@section('content')
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//geodata.solutions/includes/countrystatecity.js"></script>

<div class="container"> 
          <!-- row -->
          <div class="content-wrapper"> 
    <!-- Content Header (Page header) -->
    			@if($errors->any())
<div class="alert alert-danger">
  <strong>Danger!</strong> {{$errors->first()}}
</div>
@endif
    <section class="content-header">
              <h3> Checkout </h3>
            </section>
    <tbody class="nDividerBlockOuter">
              <tr>
        <td class="nDividerBlockInner" style="padding: 18px;"><table class="nDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top-width: 5px;border-top-style: solid;border-top-color: #ed6c71;">
            <tbody>
              <tr>
                <td><span></span></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
            </tbody>
    
    <!-- Main content --> 
    <!-- /.content --> 
  </div>
          <!-- /row -->
          <div class="row">
                <form method="post" action = "{{url('/')}}/cart/guest/checkout" class="login100-form validate-form">
					{{ csrf_field() }}
    
              <div class="col-lg-7 col-md-7 col-sm-12">
        <div class="boxcheck1">
                  <div class="form-group">
            <label for="text">First name</label>
            <input type="text" name ="fname" class="form-control" >
          </div>
                  <div class="form-group">
            <label for="txt">Last name</label>
            <input type="text" name ="lname" class="form-control" >
          </div>
                </div>
        <div class="newbox">
               
                <div class="form-group">
                        <label for="text">Email*</label>
                        <input type="email" name ="email" class="form-control" >
                      </div>
                  <div class="form-group">
            <label for="text">Address*</label>
            <input type="text" name ="address" class="form-control" >
          </div>
                  <div class="form-group">
            <label for="text">Phone no*</label>
            <input type="text" name ="phone" class="form-control" >
          </div>
             <div class="form-group">
            <label for="text">Zip Code*</label>
            <input type="text" name ="zip" class="form-control" >
          </div>
               <div class="form-group">
                    <label for="text">Country*</label>
                <select name="country" class="countries form-control" id="countryId">
                    <option value="">Select country</option>
                </select>
                </div>
                <div class="form-group">
                    <label for="text">State*</label>
                <select name="state" class="states form-control" id="stateId">
                     <option value="">Select state</option>
                </select>
                </div>
                <div class="form-group">
                <label for="text">City*</label>
                <select name="city"  class="cities form-control" id="cityId">
                          <option value="">Select City</option>
                </select>
                </div>
             </div>
            <div class="row">
                      <div class="col-sm-12 form-group">
                        <input type="checkbox" id="myCheck"  onclick="myFunction()">
                       Creat as Account?
                        <div id="text" style="display:none">
                        <div class="form-group">
    <label for="text">Password*</label>
    <input type="password" name="password" class="form-control" >
  </div>
  <div class="form-group">
    <label for="text">Confirm Password*</label>
    <input type="password" name="confirm" class="form-control" >
  </div>
                        </div>
                      </div>
                    </div>
                  <div class="checkbox">
            <button type="submit" class="btn btn-default btn1">Proceed to Checkout</button>
          </div>
                  <br>
                </div>
      </div>
            </form>
   
  </div>
        </div>


@endsection