@extends('client.layout.appclient')
@section('content')
		<!--Login Register Area Strat-->
        
        <div id="login" class="mb-50 mt-70">
  <div class="container">
    <div id="login-row" class="row justify-content-center align-items-center">
      <div id="login-column" class="col-md-6">
        <div id="login-box" class="col-md-12 shadow-lg p-3 mb-5 bg-white rounded">
                        <form method="post" action="{{url('/')}}/login" class="login100-form validate-form p-l-55 p-r-55 p-t-178">
					{{ csrf_field() }}
                                @if($errors->any())
                                <div class="alert alert-danger alert-dismissible fade show">
    <strong></strong> {{$errors->first()}}
    <button type="button" class="close" data-dismiss="alert">&times;</button>
</div>
@endif

@if(session()->has('message'))
<div class="alert alert-success alert-dismissible fade show">
    <strong></strong>{{ session()->get('message') }}
    <button type="button" class="close" data-dismiss="alert">&times;</button>
</div>
@endif
            <h3 class="text-center text-success pt-20 pb-20">Login</h3>
            <div class="form-group has-search">
              <input type="text" name="username" placeholder="Username" id="username" class="form-control">
            </div>
            <div class="form-group has-search">
              <input type="password" name="password" placeholder=" Password" id="password" class="form-control">
            </div>
            <div class="text-right p-t-13 p-b-23">
              </div>
            <div class="form-group">
              <div id="register-link" class="text-right"> <a href="{{url('/')}}/signup" class="text-success">Create an account?</a> </div>
            </div>
            <div class="form-group">
              <input type="submit" name="submit" class="btn button btn-md" value="submit">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
		<!--Login Register Area End-->
        @endsection
		