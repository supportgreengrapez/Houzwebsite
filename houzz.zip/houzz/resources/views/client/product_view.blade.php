@extends('client.layout.appclient')
@section('content')
<style>
  /* Make the image fully responsive */
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
  </style>
<div class="gray-bg3">
<div class="container">
  <div class="bg-white p-2">
    <div class="row">
      <div class="col-lg-3"> 
        <!--Product Category Widget Start-->
        <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
          <div class="shop-sidebar">
            <h4>By categoriesSS</h4>
            <div class="categori-checkbox">
              <ul>
                @if(count($category)>0)
                @foreach($category as $results)
                <li> <img src="{{URL('/')}}/images/dott.png" alt=""> <a href="{{URL('/')}}/product/{{$results->main_category}}">{{$results->main_category}}</a></i> @endforeach
                  @endif
              </ul>
            </div>
          </div>
        </div>
        <div class="sidebar-layout mb-35">
          <div class="sidebar-banner single-banner">
            <div class="banner-img"> <a href="#"><img src="{{URL('/')}}/pic/adding_1.jpg" alt="image"></a> </div>
          </div>
        </div>
      </div>
      <div class="col-lg-9"> 
        
        <!--Carousel Wrapper--> 
        
        <!--Single Banner Area Start-->
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active"> <img class="d-block w-100" src="{{URL('/')}}/images/slider1.jpg" alt="First slide"> </div>
            <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider2.jpg" alt="Second slide"> </div>
            <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider3.jpg" alt="Third slide"> </div>
            <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider4.jpg" alt="Fourth slide"> </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
        <!--Single Banner Area End--> 
        <!--/.Carousel Wrapper-->
        <div class="clearfix"></div>
        <div class="shop-product">
          <h1>{{$main}}</h1>
          <div class="row"> @if(count($main_category)>0)
            @foreach($main_category as $results)
            <div class="col-md-3"> 
              <!--Single Product Start-->
              <div class="single-product mb-25 greyyy">
                <div class="product-img img-full"> <a href="{{URL('/')}}/product/{{$results->main_category}}/{{$results->sub_category}}"> <img src="{{URL('/')}}/pic/31.png" alt="" class="p-2"> </a> </div>
                <div class="product-content">
                  <h2><a href="{{URL('/')}}/product/{{$results->main_category}}/{{$results->sub_category}}">{{$results->sub_category}}</a></h2>
                </div>
                <!--Single Product End--> 
              </div>
            </div>
            @endforeach
            @endif </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection 