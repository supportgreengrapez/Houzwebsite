@extends('client.layout.appclient')
@section('content') 
<!--Shop Area Start-->
<div class="gray-bg3">
  <div class="shop-area mb-20">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-sm-12 col-xs-12 mt-20">
            
            <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
                <div class="shop-sidebar">
                  <h4>By categories</h4>
                  <div class="categori-checkbox">
                    <ul>
                      <h4 class="green">All Products</h4>
            
            <li><a href="{{url('/')}}/home">Homes</a> </li>
            <li><a href="{{url('/')}}/commercial">Commercial</a> </li>
            <li><a href="{{url('/')}}/plot">Plots</a></li>
             <li><a href="{{url('/')}}/flat">Apartments</a> </li>
           <li> <a href="{{url('/')}}/land">Agriculture Land</a></li>
            <li> <a href="{{url('/')}}/rent">Rent</a> </li>
           <li> <a href="{{url('/')}}/sale">Sale</a></li> 
            <li><a href="{{url('/')}}/office">Offices</a> </li>
            <li><a href="{{url('/')}}/hot">Wanted</a></li>
            <li><a href="{{url('/')}}/agents">Agents</a> </li>

                    </ul>
                  </div>
                </div>
              </div>
        </div>

        <div class="col-lg-9 col-sm-12 col-xs-12 mt-20">
            <div class="realterhomebg">
              <div class="row justify-content-center">
                <div class="col-12">
                  <div class="salogan text-center text-white pt-50 pb-50">
                    <h3 class="text-black">Search properties to sell in pakistan</h3>
                  </div>
                </div>
                <div class="col-lg-12"> 
                  <!--Store Tab Menu Start-->
                  <div class="store-product-menu">
                    <ul class="nav justify-content-center mb-45">
                      <li>
                        <button class="active show tab-button" data-toggle="tab" href="#buy">Buy</button>
                      </li>
                      <li>
                        <button data-toggle="tab" href="#rent" class="tab-button">Rent</button>
                      </li>
                      <li>
                        <button data-toggle="tab" href="#wanted" class="tab-button">Wanted</button>
                      </li>
                      <li>
                        <button data-toggle="tab" href="#projects" class="tab-button">Project</button>
                      </li>
                    </ul>
                  </div>
                  <!--Store Tab Menu End--> 
                </div>
                <div class="col-9 pb-100"> 
                  <!--Store Tab Content Start-->
                  <div class="tab-content">
                    <div id="buy" class="tab-pane fade active show">
                      <div class="black-bg p-3 ">
                        <div class="row">
                          <div class="col-md-3">
                            <div class="checkout-form-list">
                              <select class="form-control" style="height:42px;border: none;">
                                <option value="">City</option>
                                <option value="Ahmadpur East">Ahmadpur East</option>
                                <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                                <option value="Alipur">Alipur</option>
                                <option value="Arifwala">Arifwala</option>
                                <option value="Attock City">Attock City</option>
                                <option value="Baddomalhi">Baddomalhi</option>
                                <option value="Bahawalnagar">Bahawalnagar</option>
                                <option value="Bahawalpur">Bahawalpur</option>
                                <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                                <option value="Basirpur">Basirpur</option>
                                <option value="Basti Dosa">Basti Dosa</option>
                                <option value="Begowala">Begowala</option>
                                <option value="Bhai Pheru">Bhai Pheru</option>
                                <option value="Bhakkar">Bhakkar</option>
                                <option value="Bhalwal">Bhalwal</option>
                                <option value="Bhawana">Bhawana</option>
                                <option value="Bhera">Bhera</option>
                                <option value="Bhopalwala">Bhopalwala</option>
                                <option value="Burewala">Burewala</option>
                                <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                                <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                                <option value="Chakwal">Chakwal</option>
                                <option value="Chawinda">Chawinda</option>
                                <option value="Chichawatni">Chichawatni</option>
                                <option value="Chiniot">Chiniot</option>
                                <option value="Chishtian Mandi">Chishtian Mandi</option>
                                <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                                <option value="Chuhar Kana">Chuhar Kana</option>
                                <option value="Chunian">Chunian</option>
                                <option value="Daira Din Panah">Daira Din Panah</option>
                                <option value="Dajal">Dajal</option>
                                <option value="Dandot RS">Dandot RS</option>
                                <option value="Darya Khan">Darya Khan</option>
                                <option value="Daska">Daska</option>
                                <option value="Daud Khel">Daud Khel</option>
                                <option value="Daultala">Daultala</option>
                                <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                                <option value="Dhanot">Dhanot</option>
                                <option value="Dhaunkal">Dhaunkal</option>
                                <option value="Dijkot">Dijkot</option>
                                <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                                <option value="Dinga">Dinga</option>
                                <option value="Dipalpur">Dipalpur</option>
                                <option value="Dullewala">Dullewala</option>
                                <option value="Dunga Bunga">Dunga Bunga</option>
                                <option value="Dunyapur">Dunyapur</option>
                                <option value="Eminabad">Eminabad</option>
                                <option value="Faisalabad">Faisalabad</option>
                                <option value="Faqirwali">Faqirwali</option>
                                <option value="Faruka">Faruka</option>
                                <option value="Fazilpur">Fazilpur</option>
                                <option value="Fort Abbas">Fort Abbas</option>
                                <option value="Garh Maharaja">Garh Maharaja</option>
                                <option value="Gojra">Gojra</option>
                                <option value="Gujar Khan">Gujar Khan</option>
                                <option value="Gujranwala">Gujranwala</option>
                                <option value="Gujrat">Gujrat</option>
                                <option value="Hadali">Hadali</option>
                                <option value="Hafizabad">Hafizabad</option>
                                <option value="Harnoli">Harnoli</option>
                                <option value="Haru Zbad">Haru Zbad</option>
                                <option value="Hasan Abdal">Hasan Abdal</option>
                                <option value="Hasilpur">Hasilpur</option>
                                <option value="Haveli">Haveli</option>
                                <option value="Hazro City">Hazro City</option>
                                <option value="Hujra">Hujra</option>
                                <option value="Jahanian Shah">Jahanian Shah</option>
                                <option value="Jalalpur">Jalalpur</option>
                                <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                                <option value="Jampur">Jampur</option>
                                <option value="Jand">Jand</option>
                                <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                                <option value="Jaranwala">Jaranwala</option>
                                <option value="Jatoi Shimali">Jatoi Shimali</option>
                                <option value="Jauharabad">Jauharabad</option>
                                <option value="Jhang City">Jhang City</option>
                                <option value="Jhang Sadr">Jhang Sadr</option>
                                <option value="Jhawarian">Jhawarian</option>
                                <option value="Jhelum">Jhelum</option>
                                <option value="Jhumra">Jhumra</option>
                                <option value="Kabirwala">Kabirwala</option>
                                <option value="Kahna">Kahna</option>
                                <option value="Kahuta">Kahuta</option>
                                <option value="Kalabagh">Kalabagh</option>
                                <option value="Kalaswala">Kalaswala</option>
                                <option value="Kaleke Mandi">Kaleke Mandi</option>
                                <option value="Kallar Kahar">Kallar Kahar</option>
                                <option value="Kalur Kot">Kalur Kot</option>
                                <option value="Kamalia">Kamalia</option>
                                <option value="Kamar Mushani">Kamar Mushani</option>
                                <option value="Kamir">Kamir</option>
                                <option value="Kamoke">Kamoke</option>
                                <option value="Kamra">Kamra</option>
                                <option value="Kanganpur">Kanganpur</option>
                                <option value="Karor">Karor</option>
                                <option value="Kasur">Kasur</option>
                                <option value="Keshupur">Keshupur</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khanewal">Khanewal</option>
                                <option value="Khangah Dogran">Khangah Dogran</option>
                                <option value="Khangarh">Khangarh</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kharian">Kharian</option>
                                <option value="Khewra">Khewra</option>
                                <option value="Khurrianwala">Khurrianwala</option>
                                <option value="Khushab">Khushab</option>
                                <option value="Kohror Pakka">Kohror Pakka</option>
                                <option value="Kot Addu">Kot Addu</option>
                                <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                                <option value="Kot Mumin">Kot Mumin</option>
                                <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                                <option value="Kot Samaba">Kot Samaba</option>
                                <option value="Kot Sultan">Kot Sultan</option>
                                <option value="Kotli Loharan">Kotli Loharan</option>
                                <option value="Kundian">Kundian</option>
                                <option value="Kunjah">Kunjah</option>
                                <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                                <option value="Lahore">Lahore</option>
                                <option value="Lala Musa">Lala Musa</option>
                                <option value="Lalian">Lalian</option>
                                <option value="Layyah">Layyah</option>
                                <option value="Liliani">Liliani</option>
                                <option value="Lodhran">Lodhran</option>
                                <option value="Mailsi">Mailsi</option>
                                <option value="Malakwal">Malakwal</option>
                                <option value="Malakwal City">Malakwal City</option>
                                <option value="Mamu Kanjan">Mamu Kanjan</option>
                                <option value="Mananwala">Mananwala</option>
                                <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                                <option value="Mangla">Mangla</option>
                                <option value="Mankera">Mankera</option>
                                <option value="Mehmand Chak">Mehmand Chak</option>
                                <option value="Mian Channun">Mian Channun</option>
                                <option value="Mianwali">Mianwali</option>
                                <option value="Minchinabad">Minchinabad</option>
                                <option value="Mitha Tiwana">Mitha Tiwana</option>
                                <option value="Moza Shahwala">Moza Shahwala</option>
                                <option value="Multan">Multan</option>
                                <option value="Muridke">Muridke</option>
                                <option value="Murree">Murree</option>
                                <option value="Mustafabad">Mustafabad</option>
                                <option value="Muzaffargarh">Muzaffargarh</option>
                                <option value="Nankana Sahib">Nankana Sahib</option>
                                <option value="Narang">Narang</option>
                                <option value="Narowal">Narowal</option>
                                <option value="Naushahra Virkan">Naushahra Virkan</option>
                                <option value="Nazir Town">Nazir Town</option>
                                <option value="Okara">Okara</option>
                                <option value="Pakpattan">Pakpattan</option>
                                <option value="Pasrur">Pasrur</option>
                                <option value="Pattoki">Pattoki</option>
                                <option value="Phalia">Phalia</option>
                                <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                                <option value="Pindi Bhattian">Pindi Bhattian</option>
                                <option value="Pindi Gheb">Pindi Gheb</option>
                                <option value="Pir Mahal">Pir Mahal</option>
                                <option value="Qadirpur Ran">Qadirpur Ran</option>
                                <option value="Rabwah">Rabwah</option>
                                <option value="Raiwind">Raiwind</option>
                                <option value="Raja Jang">Raja Jang</option>
                                <option value="Rajanpur">Rajanpur</option>
                                <option value="Rasulnagar">Rasulnagar</option>
                                <option value="Rawalpindi">Rawalpindi</option>
                                <option value="Renala Khurd">Renala Khurd</option>
                                <option value="Rojhan">Rojhan</option>
                                <option value="Sadiqabad">Sadiqabad</option>
                                <option value="Sahiwal">Sahiwal</option>
                                <option value="Sambrial">Sambrial</option>
                                <option value="Sangla Hill">Sangla Hill</option>
                                <option value="Sanjwal">Sanjwal</option>
                                <option value="Sarai Alamgir">Sarai Alamgir</option>
                                <option value="Sarai Sidhu">Sarai Sidhu</option>
                                <option value="Sargodha">Sargodha</option>
                                <option value="Shahkot">Shahkot</option>
                                <option value="Shahpur">Shahpur</option>
                                <option value="Shahr Sultan">Shahr Sultan</option>
                                <option value="Shakargarh">Shakargarh</option>
                                <option value="Sharqpur">Sharqpur</option>
                                <option value="Sheikhupura">Sheikhupura</option>
                                <option value="Shujaabad">Shujaabad</option>
                                <option value="Sialkot">Sialkot</option>
                                <option value="Sillanwali">Sillanwali</option>
                                <option value="Sodhra">Sodhra</option>
                                <option value="Sukheke Mandi">Sukheke Mandi</option>
                                <option value="Surkhpur">Surkhpur</option>
                                <option value="Talagang">Talagang</option>
                                <option value="Talamba">Talamba</option>
                                <option value="Tandlianwala">Tandlianwala</option>
                                <option value="Taunsa">Taunsa</option>
                                <option value="Toba Tek Singh">Toba Tek Singh</option>
                                <option value="Vihari">Vihari</option>
                                <option value="Warburton">Warburton</option>
                                <option value="Wazirabad">Wazirabad</option>
                                <option value="Yazman">Yazman</option>
                                <option value="Zafarwal">Zafarwal</option>
                                <option value="Zahir Pir">Zahir Pir</option>
                                <option value="Adilpur">Adilpur</option>
                                <option value="Badin">Badin</option>
                                <option value="Bagarji">Bagarji</option>
                                <option value="Bandhi">Bandhi</option>
                                <option value="Berani">Berani</option>
                                <option value="Bhan">Bhan</option>
                                <option value="Bhiria">Bhiria</option>
                                <option value="Bhit Shah">Bhit Shah</option>
                                <option value="Bozdar">Bozdar</option>
                                <option value="Bulri">Bulri</option>
                                <option value="Chak">Chak</option>
                                <option value="Chambar">Chambar</option>
                                <option value="Chhor">Chhor</option>
                                <option value="Chuhar Jamali">Chuhar Jamali</option>
                                <option value="Dadu">Dadu</option>
                                <option value="Daro Mehar">Daro Mehar</option>
                                <option value="Darya Khan Marri">Darya Khan Marri</option>
                                <option value="Daulatpur">Daulatpur</option>
                                <option value="Daur">Daur</option>
                                <option value="Dhoro Naro">Dhoro Naro</option>
                                <option value="Digri">Digri</option>
                                <option value="Diplo">Diplo</option>
                                <option value="Dokri">Dokri</option>
                                <option value="Gambat">Gambat</option>
                                <option value="Garhi Yasin">Garhi Yasin</option>
                                <option value="Gharo">Gharo</option>
                                <option value="Ghauspur">Ghauspur</option>
                                <option value="Ghotki">Ghotki</option>
                                <option value="Goth Garelo">Goth Garelo</option>
                                <option value="Hala">Hala</option>
                                <option value="Hingorja">Hingorja</option>
                                <option value="Hyderabad">Hyderabad</option>
                                <option value="Islamkot">Islamkot</option>
                                <option value="Jacobabad">Jacobabad</option>
                                <option value="Jam Sahib">Jam Sahib</option>
                                <option value="Jamshoro">Jamshoro</option>
                                <option value="Jati">Jati</option>
                                <option value="Jhol">Jhol</option>
                                <option value="Johi">Johi</option>
                                <option value="Kadhan">Kadhan</option>
                                <option value="Kambar">Kambar</option>
                                <option value="Kandhkot">Kandhkot</option>
                                <option value="Kandiari">Kandiari</option>
                                <option value="Kandiaro">Kandiaro</option>
                                <option value="Karachi">Karachi</option>
                                <option value="Karaundi">Karaundi</option>
                                <option value="Kario">Kario</option>
                                <option value="Kashmor">Kashmor</option>
                                <option value="Keti Bandar">Keti Bandar</option>
                                <option value="Khadro">Khadro</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kot Diji">Kot Diji</option>
                                <option value="Kotri">Kotri</option>
                                <option value="Kunri">Kunri</option>
                                <option value="Lakhi">Lakhi</option>
                                <option value="Larkana">Larkana</option>
                                <option value="Madeji">Madeji</option>
                                <option value="Malir Cantonment">Malir Cantonment</option>
                                <option value="Matiari">Matiari</option>
                                <option value="Matli">Matli</option>
                                <option value="Mehar">Mehar</option>
                                <option value="Miro Khan">Miro Khan</option>
                                <option value="Mirpur Batoro">Mirpur Batoro</option>
                                <option value="Mirpur Khas">Mirpur Khas</option>
                                <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                                <option value="Mirpur Sakro">Mirpur Sakro</option>
                                <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                                <option value="Mithi">Mithi</option>
                                <option value="Moro">Moro</option>
                                <option value="Nabisar">Nabisar</option>
                                <option value="Nasirabad">Nasirabad</option>
                                <option value="Naudero">Naudero</option>
                                <option value="Naukot">Naukot</option>
                                <option value="Naushahro Firoz">Naushahro Firoz</option>
                                <option value="Nawabshah">Nawabshah</option>
                                <option value="New Badah">New Badah</option>
                                <option value="Pad Idan">Pad Idan</option>
                                <option value="Pano Aqil">Pano Aqil</option>
                                <option value="Phulji">Phulji</option>
                                <option value="Pir Jo Goth">Pir Jo Goth</option>
                                <option value="Pithoro">Pithoro</option>
                                <option value="Radhan">Radhan</option>
                                <option value="Rajo Khanani">Rajo Khanani</option>
                                <option value="Ranipur">Ranipur</option>
                                <option value="Ratodero">Ratodero</option>
                                <option value="Rohri">Rohri</option>
                                <option value="Rustam">Rustam</option>
                                <option value="Sakrand">Sakrand</option>
                                <option value="Samaro">Samaro</option>
                                <option value="Sanghar">Sanghar</option>
                                <option value="Sann">Sann</option>
                                <option value="Sehwan">Sehwan</option>
                                <option value="Setharja Old">Setharja Old</option>
                                <option value="Shahdad Kot">Shahdad Kot</option>
                                <option value="Shahdadpur">Shahdadpur</option>
                                <option value="Shahpur Chakar">Shahpur Chakar</option>
                                <option value="Shikarpur">Shikarpur</option>
                                <option value="Sinjhoro">Sinjhoro</option>
                                <option value="Sita Road">Sita Road</option>
                                <option value="Sobhodero">Sobhodero</option>
                                <option value="Sukkur">Sukkur</option>
                                <option value="Talhar">Talhar</option>
                                <option value="Tando Adam">Tando Adam</option>
                                <option value="Tando Allahyar">Tando Allahyar</option>
                                <option value="Tando Bago">Tando Bago</option>
                                <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                                <option value="Tando Jam">Tando Jam</option>
                                <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                                <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                                <option value="Tangwani">Tangwani</option>
                                <option value="Tharu Shah">Tharu Shah</option>
                                <option value="Thatta">Thatta</option>
                                <option value="Thul">Thul</option>
                                <option value="Ubauro">Ubauro</option>
                                <option value="Umarkot">Umarkot</option>
                                <option value="Warah">Warah</option>
                                <option value="Abbottabad">Abbottabad</option>
                                <option value="Akora">Akora</option>
                                <option value="Alpurai">Alpurai</option>
                                <option value="Aman Garh">Aman Garh</option>
                                <option value="Amirabad">Amirabad</option>
                                <option value="Ashanagro Koto">Ashanagro Koto</option>
                                <option value="Baffa">Baffa</option>
                                <option value="Bannu">Bannu</option>
                                <option value="Bat Khela">Bat Khela</option>
                                <option value="Battagram">Battagram</option>
                                <option value="Charsadda">Charsadda</option>
                                <option value="Cherat Cantonement">Cherat Cantonement</option>
                                <option value="Chitral">Chitral</option>
                                <option value="Daggar">Daggar</option>
                                <option value="Dasu">Dasu</option>
                                <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                <option value="Doaba">Doaba</option>
                                <option value="Hangu">Hangu</option>
                                <option value="Haripur">Haripur</option>
                                <option value="Havelian">Havelian</option>
                                <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                                <option value="Karak">Karak</option>
                                <option value="Khalabat">Khalabat</option>
                                <option value="Kohat">Kohat</option>
                                <option value="Kulachi">Kulachi</option>
                                <option value="Lachi">Lachi</option>
                                <option value="Lakki Marwat">Lakki Marwat</option>
                                <option value="Malakand">Malakand</option>
                                <option value="Mansehra">Mansehra</option>
                                <option value="Mardan">Mardan</option>
                                <option value="Mingora">Mingora</option>
                                <option value="Noorabad">Noorabad</option>
                                <option value="Nowshera">Nowshera</option>
                                <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                                <option value="Pabbi">Pabbi</option>
                                <option value="Paharpur">Paharpur</option>
                                <option value="Peshawar">Peshawar</option>
                                <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                                <option value="Saidu Sharif">Saidu Sharif</option>
                                <option value="Sarai Naurang">Sarai Naurang</option>
                                <option value="Shabqadar">Shabqadar</option>
                                <option value="Shingli Bala">Shingli Bala</option>
                                <option value="Shorko">Shorko</option>
                                <option value="Swabi">Swabi</option>
                                <option value="Tal">Tal</option>
                                <option value="Tangi">Tangi</option>
                                <option value="Tank">Tank</option>
                                <option value="Timargara">Timargara</option>
                                <option value="Topi">Topi</option>
                                <option value="Upper Dir">Upper Dir</option>
                                <option value="Utmanzai">Utmanzai</option>
                                <option value="Zaida">Zaida</option>
                                <option value="Islamabad">Islamabad</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="checkout-form-list">
                              <input placeholder="Enter Location" type="text">
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div id="mc-form" class="mc-form subscribe-form">
                              <button>Find</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="rent" class="tab-pane fade">
                      <div class="black-bg p-3 ">
                        <div class="row">
                          <div class="col-md-3">
                            <div class="checkout-form-list">
                              <select class="form-control" style="height:42px;border: none;">
                                <option value="">City</option>
                                <option value="Ahmadpur East">Ahmadpur East</option>
                                <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                                <option value="Alipur">Alipur</option>
                                <option value="Arifwala">Arifwala</option>
                                <option value="Attock City">Attock City</option>
                                <option value="Baddomalhi">Baddomalhi</option>
                                <option value="Bahawalnagar">Bahawalnagar</option>
                                <option value="Bahawalpur">Bahawalpur</option>
                                <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                                <option value="Basirpur">Basirpur</option>
                                <option value="Basti Dosa">Basti Dosa</option>
                                <option value="Begowala">Begowala</option>
                                <option value="Bhai Pheru">Bhai Pheru</option>
                                <option value="Bhakkar">Bhakkar</option>
                                <option value="Bhalwal">Bhalwal</option>
                                <option value="Bhawana">Bhawana</option>
                                <option value="Bhera">Bhera</option>
                                <option value="Bhopalwala">Bhopalwala</option>
                                <option value="Burewala">Burewala</option>
                                <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                                <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                                <option value="Chakwal">Chakwal</option>
                                <option value="Chawinda">Chawinda</option>
                                <option value="Chichawatni">Chichawatni</option>
                                <option value="Chiniot">Chiniot</option>
                                <option value="Chishtian Mandi">Chishtian Mandi</option>
                                <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                                <option value="Chuhar Kana">Chuhar Kana</option>
                                <option value="Chunian">Chunian</option>
                                <option value="Daira Din Panah">Daira Din Panah</option>
                                <option value="Dajal">Dajal</option>
                                <option value="Dandot RS">Dandot RS</option>
                                <option value="Darya Khan">Darya Khan</option>
                                <option value="Daska">Daska</option>
                                <option value="Daud Khel">Daud Khel</option>
                                <option value="Daultala">Daultala</option>
                                <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                                <option value="Dhanot">Dhanot</option>
                                <option value="Dhaunkal">Dhaunkal</option>
                                <option value="Dijkot">Dijkot</option>
                                <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                                <option value="Dinga">Dinga</option>
                                <option value="Dipalpur">Dipalpur</option>
                                <option value="Dullewala">Dullewala</option>
                                <option value="Dunga Bunga">Dunga Bunga</option>
                                <option value="Dunyapur">Dunyapur</option>
                                <option value="Eminabad">Eminabad</option>
                                <option value="Faisalabad">Faisalabad</option>
                                <option value="Faqirwali">Faqirwali</option>
                                <option value="Faruka">Faruka</option>
                                <option value="Fazilpur">Fazilpur</option>
                                <option value="Fort Abbas">Fort Abbas</option>
                                <option value="Garh Maharaja">Garh Maharaja</option>
                                <option value="Gojra">Gojra</option>
                                <option value="Gujar Khan">Gujar Khan</option>
                                <option value="Gujranwala">Gujranwala</option>
                                <option value="Gujrat">Gujrat</option>
                                <option value="Hadali">Hadali</option>
                                <option value="Hafizabad">Hafizabad</option>
                                <option value="Harnoli">Harnoli</option>
                                <option value="Haru Zbad">Haru Zbad</option>
                                <option value="Hasan Abdal">Hasan Abdal</option>
                                <option value="Hasilpur">Hasilpur</option>
                                <option value="Haveli">Haveli</option>
                                <option value="Hazro City">Hazro City</option>
                                <option value="Hujra">Hujra</option>
                                <option value="Jahanian Shah">Jahanian Shah</option>
                                <option value="Jalalpur">Jalalpur</option>
                                <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                                <option value="Jampur">Jampur</option>
                                <option value="Jand">Jand</option>
                                <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                                <option value="Jaranwala">Jaranwala</option>
                                <option value="Jatoi Shimali">Jatoi Shimali</option>
                                <option value="Jauharabad">Jauharabad</option>
                                <option value="Jhang City">Jhang City</option>
                                <option value="Jhang Sadr">Jhang Sadr</option>
                                <option value="Jhawarian">Jhawarian</option>
                                <option value="Jhelum">Jhelum</option>
                                <option value="Jhumra">Jhumra</option>
                                <option value="Kabirwala">Kabirwala</option>
                                <option value="Kahna">Kahna</option>
                                <option value="Kahuta">Kahuta</option>
                                <option value="Kalabagh">Kalabagh</option>
                                <option value="Kalaswala">Kalaswala</option>
                                <option value="Kaleke Mandi">Kaleke Mandi</option>
                                <option value="Kallar Kahar">Kallar Kahar</option>
                                <option value="Kalur Kot">Kalur Kot</option>
                                <option value="Kamalia">Kamalia</option>
                                <option value="Kamar Mushani">Kamar Mushani</option>
                                <option value="Kamir">Kamir</option>
                                <option value="Kamoke">Kamoke</option>
                                <option value="Kamra">Kamra</option>
                                <option value="Kanganpur">Kanganpur</option>
                                <option value="Karor">Karor</option>
                                <option value="Kasur">Kasur</option>
                                <option value="Keshupur">Keshupur</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khanewal">Khanewal</option>
                                <option value="Khangah Dogran">Khangah Dogran</option>
                                <option value="Khangarh">Khangarh</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kharian">Kharian</option>
                                <option value="Khewra">Khewra</option>
                                <option value="Khurrianwala">Khurrianwala</option>
                                <option value="Khushab">Khushab</option>
                                <option value="Kohror Pakka">Kohror Pakka</option>
                                <option value="Kot Addu">Kot Addu</option>
                                <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                                <option value="Kot Mumin">Kot Mumin</option>
                                <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                                <option value="Kot Samaba">Kot Samaba</option>
                                <option value="Kot Sultan">Kot Sultan</option>
                                <option value="Kotli Loharan">Kotli Loharan</option>
                                <option value="Kundian">Kundian</option>
                                <option value="Kunjah">Kunjah</option>
                                <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                                <option value="Lahore">Lahore</option>
                                <option value="Lala Musa">Lala Musa</option>
                                <option value="Lalian">Lalian</option>
                                <option value="Layyah">Layyah</option>
                                <option value="Liliani">Liliani</option>
                                <option value="Lodhran">Lodhran</option>
                                <option value="Mailsi">Mailsi</option>
                                <option value="Malakwal">Malakwal</option>
                                <option value="Malakwal City">Malakwal City</option>
                                <option value="Mamu Kanjan">Mamu Kanjan</option>
                                <option value="Mananwala">Mananwala</option>
                                <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                                <option value="Mangla">Mangla</option>
                                <option value="Mankera">Mankera</option>
                                <option value="Mehmand Chak">Mehmand Chak</option>
                                <option value="Mian Channun">Mian Channun</option>
                                <option value="Mianwali">Mianwali</option>
                                <option value="Minchinabad">Minchinabad</option>
                                <option value="Mitha Tiwana">Mitha Tiwana</option>
                                <option value="Moza Shahwala">Moza Shahwala</option>
                                <option value="Multan">Multan</option>
                                <option value="Muridke">Muridke</option>
                                <option value="Murree">Murree</option>
                                <option value="Mustafabad">Mustafabad</option>
                                <option value="Muzaffargarh">Muzaffargarh</option>
                                <option value="Nankana Sahib">Nankana Sahib</option>
                                <option value="Narang">Narang</option>
                                <option value="Narowal">Narowal</option>
                                <option value="Naushahra Virkan">Naushahra Virkan</option>
                                <option value="Nazir Town">Nazir Town</option>
                                <option value="Okara">Okara</option>
                                <option value="Pakpattan">Pakpattan</option>
                                <option value="Pasrur">Pasrur</option>
                                <option value="Pattoki">Pattoki</option>
                                <option value="Phalia">Phalia</option>
                                <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                                <option value="Pindi Bhattian">Pindi Bhattian</option>
                                <option value="Pindi Gheb">Pindi Gheb</option>
                                <option value="Pir Mahal">Pir Mahal</option>
                                <option value="Qadirpur Ran">Qadirpur Ran</option>
                                <option value="Rabwah">Rabwah</option>
                                <option value="Raiwind">Raiwind</option>
                                <option value="Raja Jang">Raja Jang</option>
                                <option value="Rajanpur">Rajanpur</option>
                                <option value="Rasulnagar">Rasulnagar</option>
                                <option value="Rawalpindi">Rawalpindi</option>
                                <option value="Renala Khurd">Renala Khurd</option>
                                <option value="Rojhan">Rojhan</option>
                                <option value="Sadiqabad">Sadiqabad</option>
                                <option value="Sahiwal">Sahiwal</option>
                                <option value="Sambrial">Sambrial</option>
                                <option value="Sangla Hill">Sangla Hill</option>
                                <option value="Sanjwal">Sanjwal</option>
                                <option value="Sarai Alamgir">Sarai Alamgir</option>
                                <option value="Sarai Sidhu">Sarai Sidhu</option>
                                <option value="Sargodha">Sargodha</option>
                                <option value="Shahkot">Shahkot</option>
                                <option value="Shahpur">Shahpur</option>
                                <option value="Shahr Sultan">Shahr Sultan</option>
                                <option value="Shakargarh">Shakargarh</option>
                                <option value="Sharqpur">Sharqpur</option>
                                <option value="Sheikhupura">Sheikhupura</option>
                                <option value="Shujaabad">Shujaabad</option>
                                <option value="Sialkot">Sialkot</option>
                                <option value="Sillanwali">Sillanwali</option>
                                <option value="Sodhra">Sodhra</option>
                                <option value="Sukheke Mandi">Sukheke Mandi</option>
                                <option value="Surkhpur">Surkhpur</option>
                                <option value="Talagang">Talagang</option>
                                <option value="Talamba">Talamba</option>
                                <option value="Tandlianwala">Tandlianwala</option>
                                <option value="Taunsa">Taunsa</option>
                                <option value="Toba Tek Singh">Toba Tek Singh</option>
                                <option value="Vihari">Vihari</option>
                                <option value="Warburton">Warburton</option>
                                <option value="Wazirabad">Wazirabad</option>
                                <option value="Yazman">Yazman</option>
                                <option value="Zafarwal">Zafarwal</option>
                                <option value="Zahir Pir">Zahir Pir</option>
                                <option value="Adilpur">Adilpur</option>
                                <option value="Badin">Badin</option>
                                <option value="Bagarji">Bagarji</option>
                                <option value="Bandhi">Bandhi</option>
                                <option value="Berani">Berani</option>
                                <option value="Bhan">Bhan</option>
                                <option value="Bhiria">Bhiria</option>
                                <option value="Bhit Shah">Bhit Shah</option>
                                <option value="Bozdar">Bozdar</option>
                                <option value="Bulri">Bulri</option>
                                <option value="Chak">Chak</option>
                                <option value="Chambar">Chambar</option>
                                <option value="Chhor">Chhor</option>
                                <option value="Chuhar Jamali">Chuhar Jamali</option>
                                <option value="Dadu">Dadu</option>
                                <option value="Daro Mehar">Daro Mehar</option>
                                <option value="Darya Khan Marri">Darya Khan Marri</option>
                                <option value="Daulatpur">Daulatpur</option>
                                <option value="Daur">Daur</option>
                                <option value="Dhoro Naro">Dhoro Naro</option>
                                <option value="Digri">Digri</option>
                                <option value="Diplo">Diplo</option>
                                <option value="Dokri">Dokri</option>
                                <option value="Gambat">Gambat</option>
                                <option value="Garhi Yasin">Garhi Yasin</option>
                                <option value="Gharo">Gharo</option>
                                <option value="Ghauspur">Ghauspur</option>
                                <option value="Ghotki">Ghotki</option>
                                <option value="Goth Garelo">Goth Garelo</option>
                                <option value="Hala">Hala</option>
                                <option value="Hingorja">Hingorja</option>
                                <option value="Hyderabad">Hyderabad</option>
                                <option value="Islamkot">Islamkot</option>
                                <option value="Jacobabad">Jacobabad</option>
                                <option value="Jam Sahib">Jam Sahib</option>
                                <option value="Jamshoro">Jamshoro</option>
                                <option value="Jati">Jati</option>
                                <option value="Jhol">Jhol</option>
                                <option value="Johi">Johi</option>
                                <option value="Kadhan">Kadhan</option>
                                <option value="Kambar">Kambar</option>
                                <option value="Kandhkot">Kandhkot</option>
                                <option value="Kandiari">Kandiari</option>
                                <option value="Kandiaro">Kandiaro</option>
                                <option value="Karachi">Karachi</option>
                                <option value="Karaundi">Karaundi</option>
                                <option value="Kario">Kario</option>
                                <option value="Kashmor">Kashmor</option>
                                <option value="Keti Bandar">Keti Bandar</option>
                                <option value="Khadro">Khadro</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kot Diji">Kot Diji</option>
                                <option value="Kotri">Kotri</option>
                                <option value="Kunri">Kunri</option>
                                <option value="Lakhi">Lakhi</option>
                                <option value="Larkana">Larkana</option>
                                <option value="Madeji">Madeji</option>
                                <option value="Malir Cantonment">Malir Cantonment</option>
                                <option value="Matiari">Matiari</option>
                                <option value="Matli">Matli</option>
                                <option value="Mehar">Mehar</option>
                                <option value="Miro Khan">Miro Khan</option>
                                <option value="Mirpur Batoro">Mirpur Batoro</option>
                                <option value="Mirpur Khas">Mirpur Khas</option>
                                <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                                <option value="Mirpur Sakro">Mirpur Sakro</option>
                                <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                                <option value="Mithi">Mithi</option>
                                <option value="Moro">Moro</option>
                                <option value="Nabisar">Nabisar</option>
                                <option value="Nasirabad">Nasirabad</option>
                                <option value="Naudero">Naudero</option>
                                <option value="Naukot">Naukot</option>
                                <option value="Naushahro Firoz">Naushahro Firoz</option>
                                <option value="Nawabshah">Nawabshah</option>
                                <option value="New Badah">New Badah</option>
                                <option value="Pad Idan">Pad Idan</option>
                                <option value="Pano Aqil">Pano Aqil</option>
                                <option value="Phulji">Phulji</option>
                                <option value="Pir Jo Goth">Pir Jo Goth</option>
                                <option value="Pithoro">Pithoro</option>
                                <option value="Radhan">Radhan</option>
                                <option value="Rajo Khanani">Rajo Khanani</option>
                                <option value="Ranipur">Ranipur</option>
                                <option value="Ratodero">Ratodero</option>
                                <option value="Rohri">Rohri</option>
                                <option value="Rustam">Rustam</option>
                                <option value="Sakrand">Sakrand</option>
                                <option value="Samaro">Samaro</option>
                                <option value="Sanghar">Sanghar</option>
                                <option value="Sann">Sann</option>
                                <option value="Sehwan">Sehwan</option>
                                <option value="Setharja Old">Setharja Old</option>
                                <option value="Shahdad Kot">Shahdad Kot</option>
                                <option value="Shahdadpur">Shahdadpur</option>
                                <option value="Shahpur Chakar">Shahpur Chakar</option>
                                <option value="Shikarpur">Shikarpur</option>
                                <option value="Sinjhoro">Sinjhoro</option>
                                <option value="Sita Road">Sita Road</option>
                                <option value="Sobhodero">Sobhodero</option>
                                <option value="Sukkur">Sukkur</option>
                                <option value="Talhar">Talhar</option>
                                <option value="Tando Adam">Tando Adam</option>
                                <option value="Tando Allahyar">Tando Allahyar</option>
                                <option value="Tando Bago">Tando Bago</option>
                                <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                                <option value="Tando Jam">Tando Jam</option>
                                <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                                <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                                <option value="Tangwani">Tangwani</option>
                                <option value="Tharu Shah">Tharu Shah</option>
                                <option value="Thatta">Thatta</option>
                                <option value="Thul">Thul</option>
                                <option value="Ubauro">Ubauro</option>
                                <option value="Umarkot">Umarkot</option>
                                <option value="Warah">Warah</option>
                                <option value="Abbottabad">Abbottabad</option>
                                <option value="Akora">Akora</option>
                                <option value="Alpurai">Alpurai</option>
                                <option value="Aman Garh">Aman Garh</option>
                                <option value="Amirabad">Amirabad</option>
                                <option value="Ashanagro Koto">Ashanagro Koto</option>
                                <option value="Baffa">Baffa</option>
                                <option value="Bannu">Bannu</option>
                                <option value="Bat Khela">Bat Khela</option>
                                <option value="Battagram">Battagram</option>
                                <option value="Charsadda">Charsadda</option>
                                <option value="Cherat Cantonement">Cherat Cantonement</option>
                                <option value="Chitral">Chitral</option>
                                <option value="Daggar">Daggar</option>
                                <option value="Dasu">Dasu</option>
                                <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                <option value="Doaba">Doaba</option>
                                <option value="Hangu">Hangu</option>
                                <option value="Haripur">Haripur</option>
                                <option value="Havelian">Havelian</option>
                                <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                                <option value="Karak">Karak</option>
                                <option value="Khalabat">Khalabat</option>
                                <option value="Kohat">Kohat</option>
                                <option value="Kulachi">Kulachi</option>
                                <option value="Lachi">Lachi</option>
                                <option value="Lakki Marwat">Lakki Marwat</option>
                                <option value="Malakand">Malakand</option>
                                <option value="Mansehra">Mansehra</option>
                                <option value="Mardan">Mardan</option>
                                <option value="Mingora">Mingora</option>
                                <option value="Noorabad">Noorabad</option>
                                <option value="Nowshera">Nowshera</option>
                                <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                                <option value="Pabbi">Pabbi</option>
                                <option value="Paharpur">Paharpur</option>
                                <option value="Peshawar">Peshawar</option>
                                <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                                <option value="Saidu Sharif">Saidu Sharif</option>
                                <option value="Sarai Naurang">Sarai Naurang</option>
                                <option value="Shabqadar">Shabqadar</option>
                                <option value="Shingli Bala">Shingli Bala</option>
                                <option value="Shorko">Shorko</option>
                                <option value="Swabi">Swabi</option>
                                <option value="Tal">Tal</option>
                                <option value="Tangi">Tangi</option>
                                <option value="Tank">Tank</option>
                                <option value="Timargara">Timargara</option>
                                <option value="Topi">Topi</option>
                                <option value="Upper Dir">Upper Dir</option>
                                <option value="Utmanzai">Utmanzai</option>
                                <option value="Zaida">Zaida</option>
                                <option value="Islamabad">Islamabad</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="checkout-form-list">
                              <input placeholder="Enter Location" type="text">
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="mc-form subscribe-form">
                              <button>Find</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="wanted" class="tab-pane fade">
                      <div class="black-bg p-3 ">
                        <div class="row">
                          <div class="col-md-3">
                            <div class="checkout-form-list">
                              <select class="form-control" style="height:42px;border: none;">
                                <option value="">City</option>
                                <option value="Ahmadpur East">Ahmadpur East</option>
                                <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                                <option value="Alipur">Alipur</option>
                                <option value="Arifwala">Arifwala</option>
                                <option value="Attock City">Attock City</option>
                                <option value="Baddomalhi">Baddomalhi</option>
                                <option value="Bahawalnagar">Bahawalnagar</option>
                                <option value="Bahawalpur">Bahawalpur</option>
                                <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                                <option value="Basirpur">Basirpur</option>
                                <option value="Basti Dosa">Basti Dosa</option>
                                <option value="Begowala">Begowala</option>
                                <option value="Bhai Pheru">Bhai Pheru</option>
                                <option value="Bhakkar">Bhakkar</option>
                                <option value="Bhalwal">Bhalwal</option>
                                <option value="Bhawana">Bhawana</option>
                                <option value="Bhera">Bhera</option>
                                <option value="Bhopalwala">Bhopalwala</option>
                                <option value="Burewala">Burewala</option>
                                <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                                <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                                <option value="Chakwal">Chakwal</option>
                                <option value="Chawinda">Chawinda</option>
                                <option value="Chichawatni">Chichawatni</option>
                                <option value="Chiniot">Chiniot</option>
                                <option value="Chishtian Mandi">Chishtian Mandi</option>
                                <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                                <option value="Chuhar Kana">Chuhar Kana</option>
                                <option value="Chunian">Chunian</option>
                                <option value="Daira Din Panah">Daira Din Panah</option>
                                <option value="Dajal">Dajal</option>
                                <option value="Dandot RS">Dandot RS</option>
                                <option value="Darya Khan">Darya Khan</option>
                                <option value="Daska">Daska</option>
                                <option value="Daud Khel">Daud Khel</option>
                                <option value="Daultala">Daultala</option>
                                <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                                <option value="Dhanot">Dhanot</option>
                                <option value="Dhaunkal">Dhaunkal</option>
                                <option value="Dijkot">Dijkot</option>
                                <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                                <option value="Dinga">Dinga</option>
                                <option value="Dipalpur">Dipalpur</option>
                                <option value="Dullewala">Dullewala</option>
                                <option value="Dunga Bunga">Dunga Bunga</option>
                                <option value="Dunyapur">Dunyapur</option>
                                <option value="Eminabad">Eminabad</option>
                                <option value="Faisalabad">Faisalabad</option>
                                <option value="Faqirwali">Faqirwali</option>
                                <option value="Faruka">Faruka</option>
                                <option value="Fazilpur">Fazilpur</option>
                                <option value="Fort Abbas">Fort Abbas</option>
                                <option value="Garh Maharaja">Garh Maharaja</option>
                                <option value="Gojra">Gojra</option>
                                <option value="Gujar Khan">Gujar Khan</option>
                                <option value="Gujranwala">Gujranwala</option>
                                <option value="Gujrat">Gujrat</option>
                                <option value="Hadali">Hadali</option>
                                <option value="Hafizabad">Hafizabad</option>
                                <option value="Harnoli">Harnoli</option>
                                <option value="Haru Zbad">Haru Zbad</option>
                                <option value="Hasan Abdal">Hasan Abdal</option>
                                <option value="Hasilpur">Hasilpur</option>
                                <option value="Haveli">Haveli</option>
                                <option value="Hazro City">Hazro City</option>
                                <option value="Hujra">Hujra</option>
                                <option value="Jahanian Shah">Jahanian Shah</option>
                                <option value="Jalalpur">Jalalpur</option>
                                <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                                <option value="Jampur">Jampur</option>
                                <option value="Jand">Jand</option>
                                <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                                <option value="Jaranwala">Jaranwala</option>
                                <option value="Jatoi Shimali">Jatoi Shimali</option>
                                <option value="Jauharabad">Jauharabad</option>
                                <option value="Jhang City">Jhang City</option>
                                <option value="Jhang Sadr">Jhang Sadr</option>
                                <option value="Jhawarian">Jhawarian</option>
                                <option value="Jhelum">Jhelum</option>
                                <option value="Jhumra">Jhumra</option>
                                <option value="Kabirwala">Kabirwala</option>
                                <option value="Kahna">Kahna</option>
                                <option value="Kahuta">Kahuta</option>
                                <option value="Kalabagh">Kalabagh</option>
                                <option value="Kalaswala">Kalaswala</option>
                                <option value="Kaleke Mandi">Kaleke Mandi</option>
                                <option value="Kallar Kahar">Kallar Kahar</option>
                                <option value="Kalur Kot">Kalur Kot</option>
                                <option value="Kamalia">Kamalia</option>
                                <option value="Kamar Mushani">Kamar Mushani</option>
                                <option value="Kamir">Kamir</option>
                                <option value="Kamoke">Kamoke</option>
                                <option value="Kamra">Kamra</option>
                                <option value="Kanganpur">Kanganpur</option>
                                <option value="Karor">Karor</option>
                                <option value="Kasur">Kasur</option>
                                <option value="Keshupur">Keshupur</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khanewal">Khanewal</option>
                                <option value="Khangah Dogran">Khangah Dogran</option>
                                <option value="Khangarh">Khangarh</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kharian">Kharian</option>
                                <option value="Khewra">Khewra</option>
                                <option value="Khurrianwala">Khurrianwala</option>
                                <option value="Khushab">Khushab</option>
                                <option value="Kohror Pakka">Kohror Pakka</option>
                                <option value="Kot Addu">Kot Addu</option>
                                <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                                <option value="Kot Mumin">Kot Mumin</option>
                                <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                                <option value="Kot Samaba">Kot Samaba</option>
                                <option value="Kot Sultan">Kot Sultan</option>
                                <option value="Kotli Loharan">Kotli Loharan</option>
                                <option value="Kundian">Kundian</option>
                                <option value="Kunjah">Kunjah</option>
                                <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                                <option value="Lahore">Lahore</option>
                                <option value="Lala Musa">Lala Musa</option>
                                <option value="Lalian">Lalian</option>
                                <option value="Layyah">Layyah</option>
                                <option value="Liliani">Liliani</option>
                                <option value="Lodhran">Lodhran</option>
                                <option value="Mailsi">Mailsi</option>
                                <option value="Malakwal">Malakwal</option>
                                <option value="Malakwal City">Malakwal City</option>
                                <option value="Mamu Kanjan">Mamu Kanjan</option>
                                <option value="Mananwala">Mananwala</option>
                                <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                                <option value="Mangla">Mangla</option>
                                <option value="Mankera">Mankera</option>
                                <option value="Mehmand Chak">Mehmand Chak</option>
                                <option value="Mian Channun">Mian Channun</option>
                                <option value="Mianwali">Mianwali</option>
                                <option value="Minchinabad">Minchinabad</option>
                                <option value="Mitha Tiwana">Mitha Tiwana</option>
                                <option value="Moza Shahwala">Moza Shahwala</option>
                                <option value="Multan">Multan</option>
                                <option value="Muridke">Muridke</option>
                                <option value="Murree">Murree</option>
                                <option value="Mustafabad">Mustafabad</option>
                                <option value="Muzaffargarh">Muzaffargarh</option>
                                <option value="Nankana Sahib">Nankana Sahib</option>
                                <option value="Narang">Narang</option>
                                <option value="Narowal">Narowal</option>
                                <option value="Naushahra Virkan">Naushahra Virkan</option>
                                <option value="Nazir Town">Nazir Town</option>
                                <option value="Okara">Okara</option>
                                <option value="Pakpattan">Pakpattan</option>
                                <option value="Pasrur">Pasrur</option>
                                <option value="Pattoki">Pattoki</option>
                                <option value="Phalia">Phalia</option>
                                <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                                <option value="Pindi Bhattian">Pindi Bhattian</option>
                                <option value="Pindi Gheb">Pindi Gheb</option>
                                <option value="Pir Mahal">Pir Mahal</option>
                                <option value="Qadirpur Ran">Qadirpur Ran</option>
                                <option value="Rabwah">Rabwah</option>
                                <option value="Raiwind">Raiwind</option>
                                <option value="Raja Jang">Raja Jang</option>
                                <option value="Rajanpur">Rajanpur</option>
                                <option value="Rasulnagar">Rasulnagar</option>
                                <option value="Rawalpindi">Rawalpindi</option>
                                <option value="Renala Khurd">Renala Khurd</option>
                                <option value="Rojhan">Rojhan</option>
                                <option value="Sadiqabad">Sadiqabad</option>
                                <option value="Sahiwal">Sahiwal</option>
                                <option value="Sambrial">Sambrial</option>
                                <option value="Sangla Hill">Sangla Hill</option>
                                <option value="Sanjwal">Sanjwal</option>
                                <option value="Sarai Alamgir">Sarai Alamgir</option>
                                <option value="Sarai Sidhu">Sarai Sidhu</option>
                                <option value="Sargodha">Sargodha</option>
                                <option value="Shahkot">Shahkot</option>
                                <option value="Shahpur">Shahpur</option>
                                <option value="Shahr Sultan">Shahr Sultan</option>
                                <option value="Shakargarh">Shakargarh</option>
                                <option value="Sharqpur">Sharqpur</option>
                                <option value="Sheikhupura">Sheikhupura</option>
                                <option value="Shujaabad">Shujaabad</option>
                                <option value="Sialkot">Sialkot</option>
                                <option value="Sillanwali">Sillanwali</option>
                                <option value="Sodhra">Sodhra</option>
                                <option value="Sukheke Mandi">Sukheke Mandi</option>
                                <option value="Surkhpur">Surkhpur</option>
                                <option value="Talagang">Talagang</option>
                                <option value="Talamba">Talamba</option>
                                <option value="Tandlianwala">Tandlianwala</option>
                                <option value="Taunsa">Taunsa</option>
                                <option value="Toba Tek Singh">Toba Tek Singh</option>
                                <option value="Vihari">Vihari</option>
                                <option value="Warburton">Warburton</option>
                                <option value="Wazirabad">Wazirabad</option>
                                <option value="Yazman">Yazman</option>
                                <option value="Zafarwal">Zafarwal</option>
                                <option value="Zahir Pir">Zahir Pir</option>
                                <option value="Adilpur">Adilpur</option>
                                <option value="Badin">Badin</option>
                                <option value="Bagarji">Bagarji</option>
                                <option value="Bandhi">Bandhi</option>
                                <option value="Berani">Berani</option>
                                <option value="Bhan">Bhan</option>
                                <option value="Bhiria">Bhiria</option>
                                <option value="Bhit Shah">Bhit Shah</option>
                                <option value="Bozdar">Bozdar</option>
                                <option value="Bulri">Bulri</option>
                                <option value="Chak">Chak</option>
                                <option value="Chambar">Chambar</option>
                                <option value="Chhor">Chhor</option>
                                <option value="Chuhar Jamali">Chuhar Jamali</option>
                                <option value="Dadu">Dadu</option>
                                <option value="Daro Mehar">Daro Mehar</option>
                                <option value="Darya Khan Marri">Darya Khan Marri</option>
                                <option value="Daulatpur">Daulatpur</option>
                                <option value="Daur">Daur</option>
                                <option value="Dhoro Naro">Dhoro Naro</option>
                                <option value="Digri">Digri</option>
                                <option value="Diplo">Diplo</option>
                                <option value="Dokri">Dokri</option>
                                <option value="Gambat">Gambat</option>
                                <option value="Garhi Yasin">Garhi Yasin</option>
                                <option value="Gharo">Gharo</option>
                                <option value="Ghauspur">Ghauspur</option>
                                <option value="Ghotki">Ghotki</option>
                                <option value="Goth Garelo">Goth Garelo</option>
                                <option value="Hala">Hala</option>
                                <option value="Hingorja">Hingorja</option>
                                <option value="Hyderabad">Hyderabad</option>
                                <option value="Islamkot">Islamkot</option>
                                <option value="Jacobabad">Jacobabad</option>
                                <option value="Jam Sahib">Jam Sahib</option>
                                <option value="Jamshoro">Jamshoro</option>
                                <option value="Jati">Jati</option>
                                <option value="Jhol">Jhol</option>
                                <option value="Johi">Johi</option>
                                <option value="Kadhan">Kadhan</option>
                                <option value="Kambar">Kambar</option>
                                <option value="Kandhkot">Kandhkot</option>
                                <option value="Kandiari">Kandiari</option>
                                <option value="Kandiaro">Kandiaro</option>
                                <option value="Karachi">Karachi</option>
                                <option value="Karaundi">Karaundi</option>
                                <option value="Kario">Kario</option>
                                <option value="Kashmor">Kashmor</option>
                                <option value="Keti Bandar">Keti Bandar</option>
                                <option value="Khadro">Khadro</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kot Diji">Kot Diji</option>
                                <option value="Kotri">Kotri</option>
                                <option value="Kunri">Kunri</option>
                                <option value="Lakhi">Lakhi</option>
                                <option value="Larkana">Larkana</option>
                                <option value="Madeji">Madeji</option>
                                <option value="Malir Cantonment">Malir Cantonment</option>
                                <option value="Matiari">Matiari</option>
                                <option value="Matli">Matli</option>
                                <option value="Mehar">Mehar</option>
                                <option value="Miro Khan">Miro Khan</option>
                                <option value="Mirpur Batoro">Mirpur Batoro</option>
                                <option value="Mirpur Khas">Mirpur Khas</option>
                                <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                                <option value="Mirpur Sakro">Mirpur Sakro</option>
                                <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                                <option value="Mithi">Mithi</option>
                                <option value="Moro">Moro</option>
                                <option value="Nabisar">Nabisar</option>
                                <option value="Nasirabad">Nasirabad</option>
                                <option value="Naudero">Naudero</option>
                                <option value="Naukot">Naukot</option>
                                <option value="Naushahro Firoz">Naushahro Firoz</option>
                                <option value="Nawabshah">Nawabshah</option>
                                <option value="New Badah">New Badah</option>
                                <option value="Pad Idan">Pad Idan</option>
                                <option value="Pano Aqil">Pano Aqil</option>
                                <option value="Phulji">Phulji</option>
                                <option value="Pir Jo Goth">Pir Jo Goth</option>
                                <option value="Pithoro">Pithoro</option>
                                <option value="Radhan">Radhan</option>
                                <option value="Rajo Khanani">Rajo Khanani</option>
                                <option value="Ranipur">Ranipur</option>
                                <option value="Ratodero">Ratodero</option>
                                <option value="Rohri">Rohri</option>
                                <option value="Rustam">Rustam</option>
                                <option value="Sakrand">Sakrand</option>
                                <option value="Samaro">Samaro</option>
                                <option value="Sanghar">Sanghar</option>
                                <option value="Sann">Sann</option>
                                <option value="Sehwan">Sehwan</option>
                                <option value="Setharja Old">Setharja Old</option>
                                <option value="Shahdad Kot">Shahdad Kot</option>
                                <option value="Shahdadpur">Shahdadpur</option>
                                <option value="Shahpur Chakar">Shahpur Chakar</option>
                                <option value="Shikarpur">Shikarpur</option>
                                <option value="Sinjhoro">Sinjhoro</option>
                                <option value="Sita Road">Sita Road</option>
                                <option value="Sobhodero">Sobhodero</option>
                                <option value="Sukkur">Sukkur</option>
                                <option value="Talhar">Talhar</option>
                                <option value="Tando Adam">Tando Adam</option>
                                <option value="Tando Allahyar">Tando Allahyar</option>
                                <option value="Tando Bago">Tando Bago</option>
                                <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                                <option value="Tando Jam">Tando Jam</option>
                                <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                                <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                                <option value="Tangwani">Tangwani</option>
                                <option value="Tharu Shah">Tharu Shah</option>
                                <option value="Thatta">Thatta</option>
                                <option value="Thul">Thul</option>
                                <option value="Ubauro">Ubauro</option>
                                <option value="Umarkot">Umarkot</option>
                                <option value="Warah">Warah</option>
                                <option value="Abbottabad">Abbottabad</option>
                                <option value="Akora">Akora</option>
                                <option value="Alpurai">Alpurai</option>
                                <option value="Aman Garh">Aman Garh</option>
                                <option value="Amirabad">Amirabad</option>
                                <option value="Ashanagro Koto">Ashanagro Koto</option>
                                <option value="Baffa">Baffa</option>
                                <option value="Bannu">Bannu</option>
                                <option value="Bat Khela">Bat Khela</option>
                                <option value="Battagram">Battagram</option>
                                <option value="Charsadda">Charsadda</option>
                                <option value="Cherat Cantonement">Cherat Cantonement</option>
                                <option value="Chitral">Chitral</option>
                                <option value="Daggar">Daggar</option>
                                <option value="Dasu">Dasu</option>
                                <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                <option value="Doaba">Doaba</option>
                                <option value="Hangu">Hangu</option>
                                <option value="Haripur">Haripur</option>
                                <option value="Havelian">Havelian</option>
                                <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                                <option value="Karak">Karak</option>
                                <option value="Khalabat">Khalabat</option>
                                <option value="Kohat">Kohat</option>
                                <option value="Kulachi">Kulachi</option>
                                <option value="Lachi">Lachi</option>
                                <option value="Lakki Marwat">Lakki Marwat</option>
                                <option value="Malakand">Malakand</option>
                                <option value="Mansehra">Mansehra</option>
                                <option value="Mardan">Mardan</option>
                                <option value="Mingora">Mingora</option>
                                <option value="Noorabad">Noorabad</option>
                                <option value="Nowshera">Nowshera</option>
                                <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                                <option value="Pabbi">Pabbi</option>
                                <option value="Paharpur">Paharpur</option>
                                <option value="Peshawar">Peshawar</option>
                                <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                                <option value="Saidu Sharif">Saidu Sharif</option>
                                <option value="Sarai Naurang">Sarai Naurang</option>
                                <option value="Shabqadar">Shabqadar</option>
                                <option value="Shingli Bala">Shingli Bala</option>
                                <option value="Shorko">Shorko</option>
                                <option value="Swabi">Swabi</option>
                                <option value="Tal">Tal</option>
                                <option value="Tangi">Tangi</option>
                                <option value="Tank">Tank</option>
                                <option value="Timargara">Timargara</option>
                                <option value="Topi">Topi</option>
                                <option value="Upper Dir">Upper Dir</option>
                                <option value="Utmanzai">Utmanzai</option>
                                <option value="Zaida">Zaida</option>
                                <option value="Islamabad">Islamabad</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="checkout-form-list">
                              <input placeholder="Enter Location" type="text">
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="mc-form subscribe-form">
                              <button>Find</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div id="projects" class="tab-pane fade">
                      <div class="black-bg p-3 ">
                        <div class="row">
                          <div class="col-md-3">
                            <div class="checkout-form-list">
                              <select class="form-control" style="height:42px;border: none;">
                                <option value="">City</option>
                                <option value="Ahmadpur East">Ahmadpur East</option>
                                <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                                <option value="Alipur">Alipur</option>
                                <option value="Arifwala">Arifwala</option>
                                <option value="Attock City">Attock City</option>
                                <option value="Baddomalhi">Baddomalhi</option>
                                <option value="Bahawalnagar">Bahawalnagar</option>
                                <option value="Bahawalpur">Bahawalpur</option>
                                <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                                <option value="Basirpur">Basirpur</option>
                                <option value="Basti Dosa">Basti Dosa</option>
                                <option value="Begowala">Begowala</option>
                                <option value="Bhai Pheru">Bhai Pheru</option>
                                <option value="Bhakkar">Bhakkar</option>
                                <option value="Bhalwal">Bhalwal</option>
                                <option value="Bhawana">Bhawana</option>
                                <option value="Bhera">Bhera</option>
                                <option value="Bhopalwala">Bhopalwala</option>
                                <option value="Burewala">Burewala</option>
                                <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                                <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                                <option value="Chakwal">Chakwal</option>
                                <option value="Chawinda">Chawinda</option>
                                <option value="Chichawatni">Chichawatni</option>
                                <option value="Chiniot">Chiniot</option>
                                <option value="Chishtian Mandi">Chishtian Mandi</option>
                                <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                                <option value="Chuhar Kana">Chuhar Kana</option>
                                <option value="Chunian">Chunian</option>
                                <option value="Daira Din Panah">Daira Din Panah</option>
                                <option value="Dajal">Dajal</option>
                                <option value="Dandot RS">Dandot RS</option>
                                <option value="Darya Khan">Darya Khan</option>
                                <option value="Daska">Daska</option>
                                <option value="Daud Khel">Daud Khel</option>
                                <option value="Daultala">Daultala</option>
                                <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                                <option value="Dhanot">Dhanot</option>
                                <option value="Dhaunkal">Dhaunkal</option>
                                <option value="Dijkot">Dijkot</option>
                                <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                                <option value="Dinga">Dinga</option>
                                <option value="Dipalpur">Dipalpur</option>
                                <option value="Dullewala">Dullewala</option>
                                <option value="Dunga Bunga">Dunga Bunga</option>
                                <option value="Dunyapur">Dunyapur</option>
                                <option value="Eminabad">Eminabad</option>
                                <option value="Faisalabad">Faisalabad</option>
                                <option value="Faqirwali">Faqirwali</option>
                                <option value="Faruka">Faruka</option>
                                <option value="Fazilpur">Fazilpur</option>
                                <option value="Fort Abbas">Fort Abbas</option>
                                <option value="Garh Maharaja">Garh Maharaja</option>
                                <option value="Gojra">Gojra</option>
                                <option value="Gujar Khan">Gujar Khan</option>
                                <option value="Gujranwala">Gujranwala</option>
                                <option value="Gujrat">Gujrat</option>
                                <option value="Hadali">Hadali</option>
                                <option value="Hafizabad">Hafizabad</option>
                                <option value="Harnoli">Harnoli</option>
                                <option value="Haru Zbad">Haru Zbad</option>
                                <option value="Hasan Abdal">Hasan Abdal</option>
                                <option value="Hasilpur">Hasilpur</option>
                                <option value="Haveli">Haveli</option>
                                <option value="Hazro City">Hazro City</option>
                                <option value="Hujra">Hujra</option>
                                <option value="Jahanian Shah">Jahanian Shah</option>
                                <option value="Jalalpur">Jalalpur</option>
                                <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                                <option value="Jampur">Jampur</option>
                                <option value="Jand">Jand</option>
                                <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                                <option value="Jaranwala">Jaranwala</option>
                                <option value="Jatoi Shimali">Jatoi Shimali</option>
                                <option value="Jauharabad">Jauharabad</option>
                                <option value="Jhang City">Jhang City</option>
                                <option value="Jhang Sadr">Jhang Sadr</option>
                                <option value="Jhawarian">Jhawarian</option>
                                <option value="Jhelum">Jhelum</option>
                                <option value="Jhumra">Jhumra</option>
                                <option value="Kabirwala">Kabirwala</option>
                                <option value="Kahna">Kahna</option>
                                <option value="Kahuta">Kahuta</option>
                                <option value="Kalabagh">Kalabagh</option>
                                <option value="Kalaswala">Kalaswala</option>
                                <option value="Kaleke Mandi">Kaleke Mandi</option>
                                <option value="Kallar Kahar">Kallar Kahar</option>
                                <option value="Kalur Kot">Kalur Kot</option>
                                <option value="Kamalia">Kamalia</option>
                                <option value="Kamar Mushani">Kamar Mushani</option>
                                <option value="Kamir">Kamir</option>
                                <option value="Kamoke">Kamoke</option>
                                <option value="Kamra">Kamra</option>
                                <option value="Kanganpur">Kanganpur</option>
                                <option value="Karor">Karor</option>
                                <option value="Kasur">Kasur</option>
                                <option value="Keshupur">Keshupur</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khanewal">Khanewal</option>
                                <option value="Khangah Dogran">Khangah Dogran</option>
                                <option value="Khangarh">Khangarh</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kharian">Kharian</option>
                                <option value="Khewra">Khewra</option>
                                <option value="Khurrianwala">Khurrianwala</option>
                                <option value="Khushab">Khushab</option>
                                <option value="Kohror Pakka">Kohror Pakka</option>
                                <option value="Kot Addu">Kot Addu</option>
                                <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                                <option value="Kot Mumin">Kot Mumin</option>
                                <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                                <option value="Kot Samaba">Kot Samaba</option>
                                <option value="Kot Sultan">Kot Sultan</option>
                                <option value="Kotli Loharan">Kotli Loharan</option>
                                <option value="Kundian">Kundian</option>
                                <option value="Kunjah">Kunjah</option>
                                <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                                <option value="Lahore">Lahore</option>
                                <option value="Lala Musa">Lala Musa</option>
                                <option value="Lalian">Lalian</option>
                                <option value="Layyah">Layyah</option>
                                <option value="Liliani">Liliani</option>
                                <option value="Lodhran">Lodhran</option>
                                <option value="Mailsi">Mailsi</option>
                                <option value="Malakwal">Malakwal</option>
                                <option value="Malakwal City">Malakwal City</option>
                                <option value="Mamu Kanjan">Mamu Kanjan</option>
                                <option value="Mananwala">Mananwala</option>
                                <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                                <option value="Mangla">Mangla</option>
                                <option value="Mankera">Mankera</option>
                                <option value="Mehmand Chak">Mehmand Chak</option>
                                <option value="Mian Channun">Mian Channun</option>
                                <option value="Mianwali">Mianwali</option>
                                <option value="Minchinabad">Minchinabad</option>
                                <option value="Mitha Tiwana">Mitha Tiwana</option>
                                <option value="Moza Shahwala">Moza Shahwala</option>
                                <option value="Multan">Multan</option>
                                <option value="Muridke">Muridke</option>
                                <option value="Murree">Murree</option>
                                <option value="Mustafabad">Mustafabad</option>
                                <option value="Muzaffargarh">Muzaffargarh</option>
                                <option value="Nankana Sahib">Nankana Sahib</option>
                                <option value="Narang">Narang</option>
                                <option value="Narowal">Narowal</option>
                                <option value="Naushahra Virkan">Naushahra Virkan</option>
                                <option value="Nazir Town">Nazir Town</option>
                                <option value="Okara">Okara</option>
                                <option value="Pakpattan">Pakpattan</option>
                                <option value="Pasrur">Pasrur</option>
                                <option value="Pattoki">Pattoki</option>
                                <option value="Phalia">Phalia</option>
                                <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                                <option value="Pindi Bhattian">Pindi Bhattian</option>
                                <option value="Pindi Gheb">Pindi Gheb</option>
                                <option value="Pir Mahal">Pir Mahal</option>
                                <option value="Qadirpur Ran">Qadirpur Ran</option>
                                <option value="Rabwah">Rabwah</option>
                                <option value="Raiwind">Raiwind</option>
                                <option value="Raja Jang">Raja Jang</option>
                                <option value="Rajanpur">Rajanpur</option>
                                <option value="Rasulnagar">Rasulnagar</option>
                                <option value="Rawalpindi">Rawalpindi</option>
                                <option value="Renala Khurd">Renala Khurd</option>
                                <option value="Rojhan">Rojhan</option>
                                <option value="Sadiqabad">Sadiqabad</option>
                                <option value="Sahiwal">Sahiwal</option>
                                <option value="Sambrial">Sambrial</option>
                                <option value="Sangla Hill">Sangla Hill</option>
                                <option value="Sanjwal">Sanjwal</option>
                                <option value="Sarai Alamgir">Sarai Alamgir</option>
                                <option value="Sarai Sidhu">Sarai Sidhu</option>
                                <option value="Sargodha">Sargodha</option>
                                <option value="Shahkot">Shahkot</option>
                                <option value="Shahpur">Shahpur</option>
                                <option value="Shahr Sultan">Shahr Sultan</option>
                                <option value="Shakargarh">Shakargarh</option>
                                <option value="Sharqpur">Sharqpur</option>
                                <option value="Sheikhupura">Sheikhupura</option>
                                <option value="Shujaabad">Shujaabad</option>
                                <option value="Sialkot">Sialkot</option>
                                <option value="Sillanwali">Sillanwali</option>
                                <option value="Sodhra">Sodhra</option>
                                <option value="Sukheke Mandi">Sukheke Mandi</option>
                                <option value="Surkhpur">Surkhpur</option>
                                <option value="Talagang">Talagang</option>
                                <option value="Talamba">Talamba</option>
                                <option value="Tandlianwala">Tandlianwala</option>
                                <option value="Taunsa">Taunsa</option>
                                <option value="Toba Tek Singh">Toba Tek Singh</option>
                                <option value="Vihari">Vihari</option>
                                <option value="Warburton">Warburton</option>
                                <option value="Wazirabad">Wazirabad</option>
                                <option value="Yazman">Yazman</option>
                                <option value="Zafarwal">Zafarwal</option>
                                <option value="Zahir Pir">Zahir Pir</option>
                                <option value="Adilpur">Adilpur</option>
                                <option value="Badin">Badin</option>
                                <option value="Bagarji">Bagarji</option>
                                <option value="Bandhi">Bandhi</option>
                                <option value="Berani">Berani</option>
                                <option value="Bhan">Bhan</option>
                                <option value="Bhiria">Bhiria</option>
                                <option value="Bhit Shah">Bhit Shah</option>
                                <option value="Bozdar">Bozdar</option>
                                <option value="Bulri">Bulri</option>
                                <option value="Chak">Chak</option>
                                <option value="Chambar">Chambar</option>
                                <option value="Chhor">Chhor</option>
                                <option value="Chuhar Jamali">Chuhar Jamali</option>
                                <option value="Dadu">Dadu</option>
                                <option value="Daro Mehar">Daro Mehar</option>
                                <option value="Darya Khan Marri">Darya Khan Marri</option>
                                <option value="Daulatpur">Daulatpur</option>
                                <option value="Daur">Daur</option>
                                <option value="Dhoro Naro">Dhoro Naro</option>
                                <option value="Digri">Digri</option>
                                <option value="Diplo">Diplo</option>
                                <option value="Dokri">Dokri</option>
                                <option value="Gambat">Gambat</option>
                                <option value="Garhi Yasin">Garhi Yasin</option>
                                <option value="Gharo">Gharo</option>
                                <option value="Ghauspur">Ghauspur</option>
                                <option value="Ghotki">Ghotki</option>
                                <option value="Goth Garelo">Goth Garelo</option>
                                <option value="Hala">Hala</option>
                                <option value="Hingorja">Hingorja</option>
                                <option value="Hyderabad">Hyderabad</option>
                                <option value="Islamkot">Islamkot</option>
                                <option value="Jacobabad">Jacobabad</option>
                                <option value="Jam Sahib">Jam Sahib</option>
                                <option value="Jamshoro">Jamshoro</option>
                                <option value="Jati">Jati</option>
                                <option value="Jhol">Jhol</option>
                                <option value="Johi">Johi</option>
                                <option value="Kadhan">Kadhan</option>
                                <option value="Kambar">Kambar</option>
                                <option value="Kandhkot">Kandhkot</option>
                                <option value="Kandiari">Kandiari</option>
                                <option value="Kandiaro">Kandiaro</option>
                                <option value="Karachi">Karachi</option>
                                <option value="Karaundi">Karaundi</option>
                                <option value="Kario">Kario</option>
                                <option value="Kashmor">Kashmor</option>
                                <option value="Keti Bandar">Keti Bandar</option>
                                <option value="Khadro">Khadro</option>
                                <option value="Khairpur">Khairpur</option>
                                <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                                <option value="Khanpur">Khanpur</option>
                                <option value="Kot Diji">Kot Diji</option>
                                <option value="Kotri">Kotri</option>
                                <option value="Kunri">Kunri</option>
                                <option value="Lakhi">Lakhi</option>
                                <option value="Larkana">Larkana</option>
                                <option value="Madeji">Madeji</option>
                                <option value="Malir Cantonment">Malir Cantonment</option>
                                <option value="Matiari">Matiari</option>
                                <option value="Matli">Matli</option>
                                <option value="Mehar">Mehar</option>
                                <option value="Miro Khan">Miro Khan</option>
                                <option value="Mirpur Batoro">Mirpur Batoro</option>
                                <option value="Mirpur Khas">Mirpur Khas</option>
                                <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                                <option value="Mirpur Sakro">Mirpur Sakro</option>
                                <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                                <option value="Mithi">Mithi</option>
                                <option value="Moro">Moro</option>
                                <option value="Nabisar">Nabisar</option>
                                <option value="Nasirabad">Nasirabad</option>
                                <option value="Naudero">Naudero</option>
                                <option value="Naukot">Naukot</option>
                                <option value="Naushahro Firoz">Naushahro Firoz</option>
                                <option value="Nawabshah">Nawabshah</option>
                                <option value="New Badah">New Badah</option>
                                <option value="Pad Idan">Pad Idan</option>
                                <option value="Pano Aqil">Pano Aqil</option>
                                <option value="Phulji">Phulji</option>
                                <option value="Pir Jo Goth">Pir Jo Goth</option>
                                <option value="Pithoro">Pithoro</option>
                                <option value="Radhan">Radhan</option>
                                <option value="Rajo Khanani">Rajo Khanani</option>
                                <option value="Ranipur">Ranipur</option>
                                <option value="Ratodero">Ratodero</option>
                                <option value="Rohri">Rohri</option>
                                <option value="Rustam">Rustam</option>
                                <option value="Sakrand">Sakrand</option>
                                <option value="Samaro">Samaro</option>
                                <option value="Sanghar">Sanghar</option>
                                <option value="Sann">Sann</option>
                                <option value="Sehwan">Sehwan</option>
                                <option value="Setharja Old">Setharja Old</option>
                                <option value="Shahdad Kot">Shahdad Kot</option>
                                <option value="Shahdadpur">Shahdadpur</option>
                                <option value="Shahpur Chakar">Shahpur Chakar</option>
                                <option value="Shikarpur">Shikarpur</option>
                                <option value="Sinjhoro">Sinjhoro</option>
                                <option value="Sita Road">Sita Road</option>
                                <option value="Sobhodero">Sobhodero</option>
                                <option value="Sukkur">Sukkur</option>
                                <option value="Talhar">Talhar</option>
                                <option value="Tando Adam">Tando Adam</option>
                                <option value="Tando Allahyar">Tando Allahyar</option>
                                <option value="Tando Bago">Tando Bago</option>
                                <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                                <option value="Tando Jam">Tando Jam</option>
                                <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                                <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                                <option value="Tangwani">Tangwani</option>
                                <option value="Tharu Shah">Tharu Shah</option>
                                <option value="Thatta">Thatta</option>
                                <option value="Thul">Thul</option>
                                <option value="Ubauro">Ubauro</option>
                                <option value="Umarkot">Umarkot</option>
                                <option value="Warah">Warah</option>
                                <option value="Abbottabad">Abbottabad</option>
                                <option value="Akora">Akora</option>
                                <option value="Alpurai">Alpurai</option>
                                <option value="Aman Garh">Aman Garh</option>
                                <option value="Amirabad">Amirabad</option>
                                <option value="Ashanagro Koto">Ashanagro Koto</option>
                                <option value="Baffa">Baffa</option>
                                <option value="Bannu">Bannu</option>
                                <option value="Bat Khela">Bat Khela</option>
                                <option value="Battagram">Battagram</option>
                                <option value="Charsadda">Charsadda</option>
                                <option value="Cherat Cantonement">Cherat Cantonement</option>
                                <option value="Chitral">Chitral</option>
                                <option value="Daggar">Daggar</option>
                                <option value="Dasu">Dasu</option>
                                <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                                <option value="Doaba">Doaba</option>
                                <option value="Hangu">Hangu</option>
                                <option value="Haripur">Haripur</option>
                                <option value="Havelian">Havelian</option>
                                <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                                <option value="Karak">Karak</option>
                                <option value="Khalabat">Khalabat</option>
                                <option value="Kohat">Kohat</option>
                                <option value="Kulachi">Kulachi</option>
                                <option value="Lachi">Lachi</option>
                                <option value="Lakki Marwat">Lakki Marwat</option>
                                <option value="Malakand">Malakand</option>
                                <option value="Mansehra">Mansehra</option>
                                <option value="Mardan">Mardan</option>
                                <option value="Mingora">Mingora</option>
                                <option value="Noorabad">Noorabad</option>
                                <option value="Nowshera">Nowshera</option>
                                <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                                <option value="Pabbi">Pabbi</option>
                                <option value="Paharpur">Paharpur</option>
                                <option value="Peshawar">Peshawar</option>
                                <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                                <option value="Saidu Sharif">Saidu Sharif</option>
                                <option value="Sarai Naurang">Sarai Naurang</option>
                                <option value="Shabqadar">Shabqadar</option>
                                <option value="Shingli Bala">Shingli Bala</option>
                                <option value="Shorko">Shorko</option>
                                <option value="Swabi">Swabi</option>
                                <option value="Tal">Tal</option>
                                <option value="Tangi">Tangi</option>
                                <option value="Tank">Tank</option>
                                <option value="Timargara">Timargara</option>
                                <option value="Topi">Topi</option>
                                <option value="Upper Dir">Upper Dir</option>
                                <option value="Utmanzai">Utmanzai</option>
                                <option value="Zaida">Zaida</option>
                                <option value="Islamabad">Islamabad</option>
                              </select>
                            </div>
                          </div>
                          <div class="col-md-6">
                            <div class="checkout-form-list">
                              <input placeholder="Enter Location" type="text">
                            </div>
                          </div>
                          <div class="col-md-3">
                            <div class="mc-form subscribe-form">
                              <button>Find</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--Store Tab Content End--> 
                </div>
              </div>
            </div>
            <div class="row mt-10">
              <div class="col-12 text-center">
              <a href="{{url('/')}}/add/property"  class="btn bg-blue fs-it-btn"> <i class="fa fa-plus" aria-hidden="true"></i> Add Property</a>
              </div>
            </div>
            <div class="white-bg">
              <div class="container-fluid">
                <div class="row mt-20">
                  <div class="col-12 mt-20">
                    <div class="salogan text-center">
                      <h3 class="text-black">Titanium Agencies Slider</h3>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="brand-active"> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/Homegoods.jpg" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/mobile_logo.png" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/nookkar-com-delhi-online-shopping-websites-yq4ja.jpg" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/Zameen.com_-_Logo.png" alt=""></a> </div>
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/Homegoods.jpg" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/hg_final-signature_hor_tag2-final.png" alt=""></a> </div>
                      <!--Single Brand End-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/Homegoods.jpg" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/mobile_logo.png" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/nookkar-com-delhi-online-shopping-websites-yq4ja.jpg" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/Zameen.com_-_Logo.png" alt=""></a> </div>
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/Homegoods.jpg" alt=""></a> </div>
                      <!--Single Brand End--> 
                      <!--Single Brand Start-->
                      <div class="single-brand img-full"> <a href="#"><img src="{{url('/')}}/images/hg_final-signature_hor_tag2-final.png" alt=""></a> </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/1 (1)...png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Homes</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($home)>0)
                @foreach($home as $results)
                <li><a href="{{url('/')}}/property/home/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                @endforeach
                @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/2..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Commercials</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($commercial)>0)
                        @foreach($commercial as $results)
                        <li><a href="{{url('/')}}/property/commercial/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                        @endforeach
                        @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/3..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Plots</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($plots)>0)
                        @foreach($plots as $results)
                        <li><a href="{{url('/')}}/property/plot/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                        @endforeach
                        @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/4..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Apartments</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($flats)>0)
                        @foreach($flats as $results)
                        <li><a href="{{url('/')}}/property/flat/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                        @endforeach
                        @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/5..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Rents</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($rent)>0)
                @foreach($rent as $results)
                <li><a href="{{url('/')}}/property/rent/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                @endforeach
                @endif
                        </ul>
                      </div>
                      
                      <!--Single Product End--> 
                    </div>
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/6..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Buy</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($sale)>0)
                        @foreach($sale as $results)
                        <li><a href="{{url('/')}}/property/sale/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                        @endforeach
                        @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/7..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Agriculture Land</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($land)>0)
                        @foreach($land as $results)
                        <li><a href="{{url('/')}}/property/land/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                        @endforeach
                        @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                  <div class="col-md-3"> 
                    <!--Single Product Start-->
                    <div class="single-product mb-25 gray-bgnew">
                      <div class="product-img img-full"> <a href="single-product.html"> <img src="{{url('/')}}/images/8..png" alt="" class="p-2"> </a> </div>
                      <div class="product-content" style="padding: 0px 0px 5px 5px!important;">
                        <h4 style="margin-bottom:20px;">Offices</h4>
                        <ul style="list-style:none;" class="text-left">
                        @if(count($offices)>0)
                        @foreach($offices as $results)
                        <li><a href="{{url('/')}}/property/office/{{$results->city}}">{{$results->city}} <span>({{$results->count}})</span></a></li>
                        @endforeach
                        @endif
                        </ul>
                      </div>
                    </div>
                    <!--Single Product End--> 
                  </div>
                </div>
                <div class="row mt-20">
                  <div class="col-12 mt-20">
                    <div class="salogan text-center">
                      <h4 class="text-black">Discover New Projects</h4>
                    </div>
                  </div>
                </div>
                <div class="home-product-layout-area mt-20">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div id="myCarousel5" class="carousel slide mb-20" data-ride="carousel" data-interval="0">
            <div class="carousel-inner">
              <div class="item carousel-item active">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"> <span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Dinning</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/4.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/5.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Dinning</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/10.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Kitchen</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Table Set</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item carousel-item">
                <div class="row">
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/1.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Home Accessories</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/2.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Bed Rooms</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/3.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Chairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/9.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Sofa</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/6.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Stairs</h4>
                      </div>
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="thumb-wrapper">
                      <div class="img-box"><span class="onsale" style="background-color: white;border: 1px solid #e3000f;color: #e3000f;">Sale!</span> <img src="http://general.greengrapez.com/houzz/public/images/9.jpg" class="img-responsive img-fluid" alt=""> </div>
                      <div class="thumb-content">
                        <h4>Sofa</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Carousel controls -->
            <a class="carousel-control left carousel-control-prev" href="#myCarousel5" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel5" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
        </div>
      </div>
    </div>
  </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<!--Shop Area End--> 
@endsection 