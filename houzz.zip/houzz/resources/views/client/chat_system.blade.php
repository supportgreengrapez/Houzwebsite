<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from d29u17ylf1ylz9.cloudfront.net/plantmore-v3/login-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Oct 2018 12:38:42 GMT -->
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Houzz</title>
<meta name="description" content="">
<meta name="robots" content="noindex, follow" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow" />
<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="{{url('/')}}/pic/favicon.png">
<!--All Css Here-->

<!-- Bootstrap CSS-->
<link rel="stylesheet" href="{{URL('/')}}/css1/bootstrap.min.css">
<!-- Linearicon CSS-->
<link rel="stylesheet" href="{{URL('/')}}/css1/linearicons.min.css">
<!-- Font Awesome CSS-->
<link rel="stylesheet" href="{{URL('/')}}/css1/font-awesome.min.css">
<!-- Meanmenu CSS-->
<link rel="stylesheet" href="{{URL('/')}}/css1/meanmenu.min.css">
<!-- Style CSS -->
<link rel="stylesheet" href="{{URL('/')}}/css1/style.css">

<link rel="stylesheet" href="{{URL('/')}}/css1/normalize.css">

<link rel="stylesheet" href="{{URL('/')}}/css1/demo.css">

<link rel="stylesheet" href="{{URL('/')}}/css1/component.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="{{URL('/')}}/css1/responsive.css">
<link href="{{URL('/')}}/css1/chat.css" type="text/css" rel="stylesheet">

		<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>
</head>
<body>
<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
<div class="wrapper"> 
  <!--Header Area Start-->
  <header>
    <div class="header-container"> 
      <!--Header Top Area Start-->
      <div class="header-top-area black-bg">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-8"> 
              <!--Header Top Left Start-->
              <div class="header-top-left">
                <div class="header-top-language-currency">
                  <div class="switcher">
                    <p>Free Deliver <strong style="color:#689a29;">Applies on more then 50$ and return is always free</strong> </p>
                  </div>
                </div>
              </div>
              <!--Header Top Left End--> 
            </div>
            <div class="col-lg-4 col-md-4"> 
              <!--Header Top Right Start-->
              <div class="header-top-right">
                <ul class="menu-top-menu text-md-right">
                  <li><a href=""><i class="fa fa-facebook"></i></a></li>
                  <li><a href=""><i class="fa fa-twitter"></i></a></li>
                  <li><a href=""><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <!--Header Top Right End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Header Top Area End--> 
      <!--Header Middle Area Start-->
      <div class="header-middle-area">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-lg-3 col-md-4"> 
              <!--Header Logo Start-->
              <div class="header-logo"> <a href="{{url('/')}}/"><img src="{{url('/')}}/pic/logo.png" alt=""></a> </div>
              <!--Header Logo End--> 
            </div>
            <div class="col-xl-4 col-lg-3 col-md-10"> 
              <!--Header Search Area-->
              <div class="header-search-area">
                <form  role="form" action="{{url('/')}}/search" method="post" id="payment-form">
                  {{ csrf_field() }}
                  <div class="form-input">
                    <input name="search" id="search" placeholder="Search ...." type="text">
                    <button type="submit" class="header-search-btn"><i class="fa fa-search"></i></button>
                  </div>
                </form>
              </div>
              <!--Header Search Area--> 
            </div>
            <div class="col-xl-4 col-lg-3 col-md-4">
              <div class="header-top-right">
                <ul class="nav justify-content-center">
                  <li class="nav-item"> <a class="nav-link" href="#">Forums</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#">Maps</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="{{url('/')}}/blog">Blog</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#">Propert ID Search</a> </li>
                </ul>
              </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-4">
              <div class="mini-cart"> <a href="#"> <span class="cart-icon"> <span class="cart-quantity">{{Session::has('cart') ? Session::get('cart')->totalQty : '0'}}</span> </span> <span class="cart-title">Your cart <br>
                <strong>PKR {{number_format($totalPrice)}}</strong></span> </a> 
                <!--Cart Dropdown Start--> 
                @if(Session::has('cart'))
                <div class="cart-dropdown">
                  <ul>
                    @foreach($products as $product)
                    <li class="single-cart-item">
                      <div class="cart-img"> <img src="{{URL('/')}}/storage/images/{{$product['item']->thumbnail}}" alt=""> </div>
                      <div class="cart-content">
                        <h5 class="product-name">{{$product['item']->name}}</h5>
                        <span class="cart-price">{{$product['qty']}} × PKR {{number_format($product['item']->price)}}
                        @if($product['save']>0) saving -{{$product['save']}}@endif</span> </div>
                      <div class="cart-remove"> <a title="Remove" href="{{URL('/')}}/remove/item/cart/{{$product['item']->pk_id}}/{{$product['size']}}/{{$product['qty']}}"><i class="fa fa-times"></i></a> </div>
                    </li>
                    @endforeach
                  </ul>
                  <p class="cart-subtotal"><strong>Subtotal:</strong> <span class="float-right">PKR {{number_format($totalPrice)}}</span></p>
                  <p class="cart-btn"> <a href="{{url('/')}}/cart">View cart</a> <a href="{{url('/')}}/cart/checkout">Checkout</a> </p>
                </div>
                @endif 
                <!--Cart Dropdown End--> 
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Header Middle Area End--> 
      <!--Header Bottom Area Start-->
      <div class="header-bottom-area header-sticky">
        <div class="header-boxshadow">
          <div class="header-inner">
            <div class="container">
              <div class="row">
                <div class="col-12"> 
                  <!--Logo Sticky Start-->
                  <div class="logo-sticky"> <a href="{{url('/')}}/"><img src="{{url('/')}}/pic/logo2.png" alt=""></a> </div>
                  <!--Logo Sticky End--> 
                  <!--Main Menu Area Start-->
                  <div class="header-menu text-center">
                    <nav>
                      <ul class="main-menu">
                        <li><a href="{{url('/')}}/">home</a></li>
                        <li><a href="{{url('/')}}/shop">Shop</a></li>
                        <li><a href="{{url('/')}}/sale/view">Sale</a></li>
                        <li><a href="{{url('/')}}/seller/list/view">Seller</a></li>
                        <li><a href="#">Find Professional</a></li>
                        <li><a href="{{url('/')}}/properties">Properties</a></li>
                        <li><a href="{{url('/')}}/collection">Collections</a></li>
                        <li><a href="bedroomproducts.html">Galleries</a></li>
                        @if(Session::has('username')) 
                        <!--                   <li><a href="{{url('/')}}/login">{{session::get('name')}}</a></li>--> 
                        <!--                   <li><a href="{{URL('/')}}/logout">logout</a></li>--> 
                        
                        <!--<li><a href="{{URL('/')}}/order/tracking/view">Order Tracking</a></li>-->
                        <li>
                          <div class="header-option">
                            <div class="mini-cart-search">
                              <div class="currency">
                                <div class="currency-box"> <a href="#">{{session::get('name')}}</a>
                                  <div class="currency-dropdown">
                                    <ul class="menu-top-menu">
                                      <li><a href="{{URL('/')}}/order/tracking/view">Order Tracking</a></li>
                                      <li><a href="{{URL('/')}}/client/payment/list/view/{{session::get('pk_id')}}">Payment List</a></li>
                                      <li><a href="{{URL('/')}}/realtor/dashboard">Switch to My Account</a></li>
                                      <li><a href="{{URL('/')}}/client/send/message">Compose Message</a></li>
                                      <li><a href="{{URL('/')}}/client/chat/{{session::get('pk_id')}}">Chat</a></li>
                                      <li><a href="{{URL('/')}}/logout">Logout</a></li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </li>
                        @else
                        <li><a href="{{url('/')}}/login">Login</a></li>
                        <li><a href="{{url('/')}}/signup">Signup</a></li>
                        @endif
                      </ul>
                    </nav>
                  </div>
                  <!--Main Menu Area End--> 
                </div>
              </div>
              <div class="row">
                <div class="col-12"> 
                  <!--Mobile Menu Area Start-->
                  <div class="mobile-menu d-lg-none"></div>
                  <!--Mobile Menu Area End--> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Header Bottom Area End--> 
    </div>
  </header>
  <!--Header Area End--> 
  <!--Breadcrumb Tow Start-->
  <div class="gray-bg3">
    <div class="container">
      <div class="breadcrumb-tow mb-20">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="breadcrumb-title">
                <h1>Chat</h1>
              </div>
              <div class="breadcrumb-content breadcrumb-content-tow">
                <ul>
                  <li><a href="{{url('/')}}/">Home</a></li>
                  <li class="active">Chat</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Breadcrumb Tow End--> 
      <!--Login Register Area Strat-->
      <div class="">
        <div class="login-register-area">
        <input type="text" hidden id="admin_id" value="{{session('pk_id')}}">
          <div class="container">
            <div class="row"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_content">
          <div id="frame">
            <div id="sidepanel">
              <div id="profile">
                <div class="wrap"> <img id="profile-img" src="http://emilcarlsson.se/assets/mikeross.png" alt="" />
                  <p>Fahad Maqsood</p>
                </div>
              </div>
              <div id="search">
                <label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
                <input type="text" placeholder="Search contacts..." />
              </div>
              <div id="contacts">
              <ul id="userlist">
              @php
              $count = 0;
              @endphp
          @if(count($user)>0)
         @foreach($user as $users)
         
         @if($count==0)
         <li onclick="getMessage(this.id)" id="{{$users->pk_id}}" class="contact active">
     
             @else
         <li onclick="getMessage(this.id)" id="{{$users->pk_id}}" class="contact">
             @endif
             @php
             $count++;
             @endphp
                    <div class="wrap"><img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />
                      <div class="meta">
                      <p id="username" class="name">{{$users->fname}} {{$users->lname}}</p>
                      <p class="preview">{{$users->lastmessage}}</p>
                      </div>
                    </div>
                  </li>
                  @endforeach
                       @endif
                </ul>
              </div>
            </div>
            <div class="content">
              <div class="contact-profile"> <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
              <p class="asd">{{$user[0]->fname}} {{$user[0]->lname}}</p>
              </div>
              <div id="msg" class="messages" >
      
		<li class="replies">
					<img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" style="width:100px;height:100px;" />
				</li>
		
		</div>
              <div class="message-input">
                <div class="wrap">
                  <input type="text" placeholder="Write your message..." />
                  
                  <div class="box">
					<input type="file" name="file-5[]" id="file-5" class="inputfile inputfile-4" data-multiple-caption="{count} files selected" multiple />
					<label for="file-5"><figure><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><i class="fa fa-paperclip" aria-hidden="true"></i></svg></figure> <span>Choose a file&hellip;</span></label>
				
			<button class="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
				</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
            </div>
          </div>
        </div>
      </div>
      <!--Login Register Area End--> 
    </div>
  </div>
  <!--Footer Area Start-->
  <footer>
    <div class="footer-container"> 
      <!--Footer Top Area Start-->
      <div class="footer-top-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="Faq.html">Faqs</a></li>
                  <li><a href="termscondition.html">Terms & Condition</a></li>
                  <li><a href="privcy.html">Privacy Policy</a></li>
                  <li><a href="privcy.html">Houzz Policy</a></li>
                  <li><a href="#">Be a Realtor</a></li>
                  <li><a href="#">Advertise with us</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End--> 
            </div>
            <div class="col-lg-3 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="about.html">About Us</a></li>
                  <li><a href="contact.html">Contact Us</a></li>
                  <li><a href="contact.html">Payment Information</a></li>
                  <li><a href="blog.html">Blog</a></li>
                  <li><a href="{{url('/')}}/vendor/login">Seller Login</a></li>
                  <li><a href="">Be a Professional</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End--> 
            </div>
            <div class="col-lg-6 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="text-center"> <a href="" target="_blank" class="btn-social btn-facebook"><i class="fa fa-facebook"></i></a> <a href="" target="_blank" class="btn-social btn-instagram"><i class="fa fa-instagram"></i></a> <a href="" target="_blank" class="btn-social btn-twitter"><i class="fa fa-twitter"></i></a> </div>
              <div class="footer-title mt-40">
                <h3>Contact Us</h3>
              </div>
              <div class="single-footer-widget mb-40">
                <div class="news-letter-form mb-10">
                  <form class="popup-subscribe-form validate" target="_blank" novalidate>
                    <div id="mc_embed_signup_scroll">
                      <div id="mc-form" class="mc-form subscribe-form " style=" border-top: 1px solid white;border-bottom: 1px solid white;
    padding: 1%;">
                        <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email here">
                        <button type="button" class="btn btn-serach">Login</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!--Single Footer Widget End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Footer Top Area End--> 
      <!--Footer Bottom Area Start-->
      <div class="footer-bottom-area pt-50 pb-50">
        <div class="container">
          <div class="row">
            <div class="col-md-12"> 
              <!--Footer Copyright Start-->
              <div class="footer-copyright">
                <p>Copyright © <a href="#">Houzz.pk</a> All Rights Reserved</p>
              </div>
              <div class="footer-copyright">
                <p>Powered By <a href="https://greengrapez.com/"><img src="{{url('/')}}/images/greengrapez.png" alt="Green Grapez" style="width:75px; height:50px;"></a></p>
              </div>
              <!--Footer Copyright End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Footer Bottom Area End--> 
    </div>
  </footer>
  <!--Footer Area End--> 
</div>
<!--All Js Here--> 

<!--Jquery 1.12.4--> 
<script src="{{url('/')}}/js1/vendor/jquery-1.12.4.min.js"></script> 
<!--Bootstrap--> 
<script src="{{url('/')}}/js1/bootstrap.min.js"></script> 
<!--Meanmenu--> 
<script src="{{url('/')}}/js1/jquery.meanmenu.min.js"></script> 
<!--Main Js--> 
<script src="{{url('/')}}/js1/main.js"></script>  

<script src="{{url('/')}}/js1/custom-file-input.js"></script>  
<script src="https://js.pusher.com/5.0/pusher.min.js"></script> 
<script >

var pusher = new Pusher('a12fe1bfb7e5bbca358e', {
              cluster: 'ap2',
              authEndpoint: './auth-pusher'
            
            });
            
            var userId = document.getElementById('admin_id').value;
            var selectedUser=$('#userlist li.active').attr('id');
            var socketId = null;
            pusher.connection.bind('connected', function() {
              socketId = pusher.connection.socket_id;
              console.log(socketId);
            });
            
            var channel = pusher.subscribe('private-admin-channel');
            console.log(channel);
            channel.bind('my-event', function(data) {
                  console.log('working');
                  if(data.from == $('#userlist li.active').attr('id'))
              {
                  var ul = document.getElementById("receive");

              $('<li class="replies"><p>' + data.message + '</p> <span> 6:05Am </span></li>').appendTo($('.messages ul'));
              $(".messages").animate({ scrollTop: document.getElementById("msg").scrollHeight }, "fast");
              }
              
            });

/*  getting very first message of user*/

            

url = "../vendor/get-messages/"+$('#userlist li.active').attr('id');
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                 var data = this.responseText;
  document.getElementById("msg").innerHTML = data;
  $(".messages").animate({ scrollTop: document.getElementById("msg").scrollHeight }, "fast");
  //$(".messages").animate({ scrollTop: $(document).height() }, "fast");
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
  
  // End of getting first message of user

  function getMessage($id)
            {
               
                var a = $('#userlist li.active').hasClass('active');
                
                if(a)
                {
                    $('#userlist li.active').removeClass('active');
                }
              
                var a = document.getElementById($id).classList.add("active");
             
              var username = $('#userlist li.active #username').html();
         
               
             //   var username = $('#userlist li.active #name')[0].html();
                console.log(username);
                
             //    var name = $('#userlist li.active #profileImage').html();
               
                 document.getElementsByClassName("asd")[0].innerHTML = username;
             //   document.getElementById('inchatname').innerHTML = username;

          
                selectedUser = $id;
                console.log(selectedUser);
        url = "../vendor/get-messages/"+$id;
      
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                 var data = this.responseText;
document.getElementById("msg").innerHTML = data;
$(".messages").animate({ scrollTop: document.getElementById("msg").scrollHeight }, "fast");
                 
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
      
            }

       //     $(".messages").animate({ scrollTop: $(document).height() }, "fast");


function newMessage() {
	message = $(".message-input input").val();
	file = $('#file-5').val();
	if($.trim(message) == '') {
		return false;
  }
  var xmlhttp = new XMLHttpRequest();

xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
     console.log( this.responseText);
  }
};
var data = new FormData();
data.append('message', message);
data.append('selected_user',selectedUser);
data.append('file',file);

var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
message = message;

  // xmlhttp.open("POST", "/../send-customer-message", true);
    
  //     xmlhttp.send(data,CSRF_TOKEN);
  console.log(file);
$.ajax({
      /* the route pointing to the post function */
      url: "{{url('/')}}/client/send-admin-message",
      type: 'POST',
      /* send the csrf-token and the input to the controller */
      data: {_token: CSRF_TOKEN, message:message, selected_user:selectedUser, file:file,

    },
      /* remind that 'data' is the response of the AjaxController */
      success: function (data) { 
        window.location.href = data;
      }
      
  }); 

var today = new Date();
var time = today.getHours() + ":" + today.getMinutes();

	$('<li class="sent"><p>' + message + '</p> <span> ' + time + ' </span></li>').appendTo($('.messages ul'));
	$('.message-input input').val(null);
	$('.contact.active .preview').html('<span>You: </span>' + message);
  $(".messages").animate({ scrollTop: $(document).height() }, "fast");
  window.stop();
};


$('.submit').click(function() {
event.preventDefault();
newMessage();
window.stop();
});

$(window).on('keydown', function(e) {
if (e.which == 13) {
  event.preventDefault();
newMessage();
window.stop();
}
});
</script>
</body>

<!-- Mirrored from d29u17ylf1ylz9.cloudfront.net/plantmore-v3/login-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Oct 2018 12:38:42 GMT -->
</html>
