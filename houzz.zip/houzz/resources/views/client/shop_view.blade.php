@extends('client.layout.appclient')
@section('content')
<style>
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
</style>
<div class="greyyy">
  <div class="container">
    <div class="shop-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-3"> 
            <!--Product Category Widget Start-->
            <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
              <div class="shop-sidebar">
                <h4>By categories</h4>
                <div class="categori-checkbox">
                  <ul>
                    @if(count($main_category)>0)
                    @foreach($main_category as $results)
                    <li><img src="{{URL('/')}}/images/dott.png" alt=""><a href="{{URL('/')}}/product/{{$results->main_category}}">{{$results->main_category}}</a></i> @endforeach
                      @endif
                  </ul>
                </div>
              </div>
            </div>
            <div class="sidebar-layout mb-35">
              <div class="sidebar-banner single-banner">
                <div class="banner-img"> <a href="#"><img src="{{URL('/')}}/pic/adding_2.jpg" alt="image"></a> </div>
              </div>
              <div class="sidebar-banner single-banner">
                <div class="banner-img"> <a href="#"><img src="{{URL('/')}}/pic/adding_1.jpg" alt="image"></a> </div>
              </div>
            </div>
          </div>
          @if($errors->any())
          <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
          @endif
          <div class="col-lg-9">
            <div class="shop-layout">
              <div class="row">
                <div class="col-md-12"> 
                  <!--Single Banner Area Start-->
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel"> @if(count($slider)>0)
                    <div class="carousel-inner">
                      <div class="carousel-item active"> <img class="d-block w-100" src="{{URL('/')}}/images/slider1.jpg" alt="First slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider2.jpg" alt="Second slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider3.jpg" alt="Third slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider4.jpg" alt="Fourth slide"> </div>
                    </div>
                    @endif <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
                  <!--Single Banner Area End--> 
                </div>
              </div>
              <div class="bg-white p-2">
                <div class="shop-product">
                  <div id="myTabContent-2" class="tab-content">
                    <div id="grid" class="tab-pane fade show active">
                      <div class="product-grid-view">
                        <div class="row">
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Kitchen and Dining"> <img src="{{URL('/')}}/pic/31.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Kitchen and Dining">Kitchen and Dining</a></h2>
                                @if(count($kitchen)>0)
                                @foreach($kitchen as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Kitchen and Dining">
                                <p class="grey">See All</p>
                                </a> </div>
                              <!--Single Product End--> 
                            </div>
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Bath"> <img src="{{URL('/')}}/pic/36.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Bath">Bath</a></h2>
                                @if(count($bath)>0)
                                @foreach($bath as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Bath">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Bedroom"> <img src="{{URL('/')}}/pic/34.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Bedroom">Bedroom</a></h2>
                                @if(count($bed)>0)
                                @foreach($bed as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Bedroom">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Living"> <img src="{{URL('/')}}/pic/35.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Living">Living</a></h2>
                                @if(count($living)>0)
                                @foreach($living as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Living">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Lighting"> <img src="{{URL('/')}}/pic/36.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Lighting">Lighting</a></h2>
                                @if(count($lighting)>0)
                                @foreach($lighting as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Lighting">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Furniture"> <img src="{{URL('/')}}/pic/37.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Furniture">Furniture</a></h2>
                                @if(count($furniture)>0)
                                @foreach($furniture as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Furniture">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Home Decor"> <img src="{{URL('/')}}/pic/38.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Home Decor">Home Decor</a></h2>
                                @if(count($decore)>0)
                                @foreach($decore as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Home Decor">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="{{URL('/')}}/product/Outdoor"> <img src="{{URL('/')}}/pic/39.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="{{URL('/')}}/product/Outdoor">OutDoor Product</a></h2>
                                @if(count($outdoor)>0)
                                @foreach($outdoor as $kitchens) <a href="{{URL('/')}}/product/{{$kitchens->main_category}}/{{$kitchens->sub_category}}">
                                <p class="grey">{{$kitchens->sub_category}}</p>
                                </a> @endforeach
                                @endif <a href="{{URL('/')}}/product/Outdoor">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End--> 
      </div>
    </div>
  </div>
</div>
@endsection 