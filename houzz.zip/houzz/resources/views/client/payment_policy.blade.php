@extends('client.layout.app')
@section('content')
<!----//End-bottom-header----> 

<!---//End-header----> 
                
           <div class="container">
			  <div class="row">
			  <div class="col-lg-12 col-md-12 col-sm-12">
				  <div class="paymentpolicy">
				  <h1>Payment Information</h1>
					  <p>Fashion Factory accepts the following payment methods:</p>
				  <ul>
					  <li>COD (Cash on Delivery)</li>
					  <li>Visa</li>
					  <li>MasterCard</li>
					  <li>Paypal </li>
					  <li>EasyPaisa</li>
					  <li>Online Bank Transfer</li>
				</ul>
				  
				  </div>
				  </div>
				  </div>
				  </div>
		
		<!--- //End-content---->
		
@endsection