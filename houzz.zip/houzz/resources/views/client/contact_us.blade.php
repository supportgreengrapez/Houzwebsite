@extends('client.layout.appclient')
@section('content')

        <!--Contact Address Area Start-->
        <div class="contact-address-area pt-20 pb-80">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title2 bl-color mb-70">
		                    <h3>CONTACT US</h3>
		                </div>
                    </div>
                </div>
                <div class="row">
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-4">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Address Street</h2>
                                <p>Lahore, Punjab, Pakistan</p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-4">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Number Phone</h2>
                                <p>Phone: +92 309- 49 777 66 </p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                    <!--Single Contact Address Start-->
                    <div class="col-md-6 col-lg-4">
                        <div class="single-contact-address text-center mb-35">
                            <div class="contact-icon">
                                <i class="fa fa-envelope-o"></i>
                            </div>
                            <div class="contact-info">
                                <h2>Address email</h2>
                                <p>customer@houz.pk</p>
                            </div>
                        </div>
                    </div>
                    <!--Single Contact Address End-->
                </div>
            </div>
        </div>
        <!--Contact Address Area End-->
        <!--Contact Area Start-->
        <div class="contact-area gray-bg pt-110 pb-105">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="contact-form-area">
                            <div class="contact-form-title">
                                <h2>TELL US YOUR PROJECT</h2>
                            </div>
                            <form id="contact-form" action="" method="post">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="contact-form-style mb-20">
                                            <input name="fname" placeholder="First Name*" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="contact-form-style mb-20">
                                            <input name="lname" placeholder="Last Name*" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="contact-form-style mb-20">
                                            <input name="email" placeholder="Email*" type="email">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="contact-form-style mb-20">
                                            <input name="subject" placeholder="Subject*" type="text">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="contact-form-style form-style-2">
                                            <textarea name="note" placeholder="Type your message here.."></textarea>
                                            <button class="form-button btn-style-2" type="submit"><span>Send Email</span></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <p class="form-messege"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Contact Area End-->
@endsection