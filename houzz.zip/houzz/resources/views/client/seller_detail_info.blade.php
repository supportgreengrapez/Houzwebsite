<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" type="image/x-icon" href="{{url('/')}}/pic/favicon.png">
<title>Houzz</title>

<!-- Bootstrap -->
<link href="{{url('/')}}/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{url('/')}}/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="{{url('/')}}/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="{{url('/')}}/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="{{url('/')}}/css/custom.min.css" rel="stylesheet">
<link href="{{url('/')}}/css/style2.css" rel="stylesheet">
</head>

<body>
<div class="container" style="width:85% !important;">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-40">
      <div class="textcen" style="margin-top:0px !important;">
        <h4 style="margin:0px;">Houz Seller Agreement</h4>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
      <div class="topsellermsg">
        <p>Thank you for registering as a Seller<br>
          You're almost done! please fill in the following additional information:</p>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="editsellertext">
        <h4>Additional Seller Info</h4>
      </div>
    </div>
  </div>
  <form method="post" action="{{url('/')}}/signup/seller/detail"  enctype="multipart/form-data">
    {{ csrf_field() }}
    
    @if($errors->any()) <br>
    <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
    @endif
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Company Registration Number</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="number" name="federal_tax" class="form-control">
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Name of Primary Contact</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="primary_contact" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Name of Payee <span style="color:#669a25;font-size:12px;font-style:italic;"> More</span></label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="payee" class="form-control" >
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
        <div class="textcen" style="margin-top:0px !important;"> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="editsellertext">
          <h4>Customer Service</h4>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Same as primary?</label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <input type="checkbox" name="checkboxes" id="ckbx1" class="a11y-checkbox">
            <label for="ckbx1" class="a11y-checkbox-label"></label>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Phone</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="tel" name="phone1" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Fax</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="tel" name="fax1" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Email</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="email" name="email1" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Support Hours<span style="color:#669a25;font-size:12px;font-style:italic;"> More</span></label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="number" name="support_hourz" class="form-control" >
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
        <div class="textcen" style="margin-top:0px !important;"> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="editsellertext">
          <h4>Return & Damage Policies</h4>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
          <p class="mt-40">1. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
          <p>2.  Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          <p>3.  Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          <p>4. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
          <h6 class="mt-40" style="font-size: 18px;">NOTE:</h6>
          <p class="mt-40">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
        <div class="textcen" style="margin-top:0px !important;"> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="editsellertext">
          <h4>Shipping & Handling</h4>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Ship To </label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <select class="form-control">
              <option></option>
              <option>Days</option>
              <option>Weeks</option>
              <option>Months</option>
              <option>Years</option>
            </select>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Standard Shipping<br>
            Time (days)<span style="color:#669a25;font-size:12px;font-style:italic;"> More</span></label>
          <div class="col-lg-3 col-sm-12 col-xs-12">
            <div class="row form-group">
              <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Min</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="number" class="form-control"  placeholder="">
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-12 col-xs-12">
            <div class="row form-group">
              <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Max</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="number" class="form-control"  placeholder="">
              </div>
            </div>
          </div>
        </div>
        <div class="form-group row mt-20">
          <div class="col-lg-3 col-sm-12 col-xs-12">
            <select class="form-control" name="">
              <option value="Days">Days</option>
              <option>Weeks</option>
              <option value="Months">Months</option>
              <option value="Years">Years</option>
            </select>
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
        <div class="textcen" style="margin-top:0px !important;"> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="editsellertext">
          <h4>Warehouse Info</h4>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Address</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="warehouse_address" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Country</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            
            <input type="text" name="warehouse_country" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">State/Province</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            
            <input type="text" name="warehouse_state" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">City</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            
            <input type="text" name="warehouse_city" class="form-control" >
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
        <div class="textcen" style="margin-top:0px !important;"> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="editsellertext">
          <h4>Order & Returns</h4>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Is RMA required?</label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <input type="checkbox" name="checkboxes" id="ckbx3" class="a11y-checkbox">
            <label for="ckbx3" class="a11y-checkbox-label"></label>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Same as primary?</label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <input type="checkbox" name="checkboxes" id="ckbx2" class="a11y-checkbox">
            <label for="ckbx2" class="a11y-checkbox-label"></label>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Address</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="return_address" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Country</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <select name="country" class="countries order-alpha form-control" id="countryId">
              <option value="">Select country</option>
            </select>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">State/Province</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <select name="state" class="states order-alpha form-control" id="stateId">
              <option value="">Select state</option>
            </select>
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">City</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <select name="city" class="cities order-alpha form-control" id="cityId">
              <option value="">Select City</option>
            </select>
          </div>
        </div>
        
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Zip/Postal Code</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="return_zip" class="form-control" >
          </div>
        </div>
        
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Phone</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="tel" name="return_phone" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Fax</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="tel" name="return_fax" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Order Notification Email</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="email" name="notification_email" class="form-control" >
          </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-20">
        <div class="textcen" style="margin-top:0px !important;"> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="editsellertext">
          <h4>Bank Info</h4>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 mt-20">
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Bank Name</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="bank_name" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Account No</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="account_no" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Account Type</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text" name="account_type" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Routing No.</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="text"  name="routing_no" class="form-control" >
          </div>
        </div>
        <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Upload cheque</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
            <img id="blah" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:150px; height:170px;" /> </div>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Slider Image 1</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="file" name="slide" class="form-control" onchange="preview_image(this);"/>
            <img id="blah1" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:300px; height:300px;"/> </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Slider Image 2</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="file" name="slide2" class="form-control" onchange="preview_img(this);"/>
            <img id="blah2" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:300px; height:300px;" /> </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
          <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16">Slider Image 3</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="file" name="slide3" class="form-control" onchange="preview_imgs(this);"/>
            <img id="blah3" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:300px; height:300px;"/> </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 bgbot mt-20">
        <div class="row">
          <div class="col-lg-1 col-md-1 col-sm-1 col-xs-2 mt-20">
            <input type="checkbox" name="checkboxes" id="ckbx4" class="a11y-checkbox">
            <label for="ckbx4" class="a11y-checkbox-label"></label>
          </div>
          <div class="col-lg-11 col-md-11 col-sm-11 col-xs-12 mt-20">
            <div class="sellerbottombg">
              <p>I agree to be beyond by all of the<span style="color:#669a25;font-size:16px;"> terms and conditions </span>of this Agreement</p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 col-md-8 col-sm-12 col-xs-12">
            <div class="bottombtn">
              <button type="submit" class="btn btnupdate">Save</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
  <div class="clearfix"></div>
</div>
<!-- /page content --> 

<!-- footer content -->
<footer> 
  
  <!--Footer Copyright Start-->
  <div class="footer-copyright">
    <p>Copyright © <a href="http://general.greengrapez.com/houzz/public/">Houzz.pk</a> All Rights Reserved</p>
  </div>
  <div class="footer-copyright">
    <p>Powered By <a href="https://greengrapez.com/"><img src="{{url('/')}}/pic/greengrapez.png" alt="Green Grapez"></a></p>
  </div>
  <!--Footer Copyright End--> 
</footer>
<!-- /footer content --> 

<!-- jQuery --> 
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//geodata.solutions/includes/countrystatecity.js"></script> 
<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    
    
    function preview_image(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah1')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        function preview_img(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah2')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function preview_imgs(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah3')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>


</body>
</html>
