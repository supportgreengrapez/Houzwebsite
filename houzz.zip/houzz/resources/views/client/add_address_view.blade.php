
@extends('client.layout.appclient')
@section('content')

  <!--Header Area End-->
  <!--Checkout Area Strat-->
  <div class="gray-bg2 pt-10">
    <div class="checkout-area">
      <div class="container">
        <div class="white-bg mb-20">
          <div class="row justify-content-center">
            <div class="col-3">
              <div class="billingtophead">
                <h4><span class="billingtopcircles" style="background-color: #689a29;">1</span> Shipping</h4>
              </div>
            </div>
            <div class="col-3">
              <div class="billingtophead">
                <h4><span class="billingtopcircles" style="padding: 2px 8px 2px 8px;">2</span> Order Review</h4>
              </div>
            </div>
            <div class="col-3">
              <div class="billingtophead">
                <h4><span class="billingtopcircles" style="padding: 2px 8px 2px 8px;">3</span> Billing & Payment</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="white-bg p-5">
        <form  role="form" action="{{url('/')}}/cart/checkout/add/new/address" method="post" id="payment-form">
                  {{ csrf_field() }}
            <div class="row">
              <div class="col-lg-8 col-12">
              <div class="checkbox-form checkbox-form container pt-20 pb-20">
                  <h3>Enter Your Shipping Address</h3>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="checkout-form-list">
                        <label>Fisrt Name <span class="required">*</span></label>
                        <input placeholder="First Name" name="fname" value= "{{session::get('fname')}}" type="text">
                      </div>
                    </div>
                    <div class="col-md-12">
                      <div class="checkout-form-list">
                        <label>Last Name <span class="required">*</span></label>
                        <input placeholder="Last Name" name="lname" value= "{{session::get('lname')}}" type="text">
                      </div>
                    </div>

                    <div class="col-md-12">
                      <div class="checkout-form-list">
                        <label> Address<span class="required">*</span></label>
                        <input type="text" name="address"  >
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="checkout-form-list">
                        <label>Phone <span class="required">*</span></label>
                        <input type="text" name="phone" >
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="checkout-form-list">
                        <label>Postcode / Zip <span class="required">*</span></label>
                        <input placeholder="" type="text" name="zip" >
                      </div>
                    </div>
                    <div class="col-md-6">
                      <label>Country</label>
                      <select name="country" class="countries order-alpha" id="countryId">
                        <option value="">Select Country</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label>State</label>
                      <select name="state" class="states order-alpha" id="stateId">
                        <option value="">Select State</option>
                      </select>
                    </div>
                    <div class="col-md-6">
                      <label>City</label>
                      <select name="city" class="cities order-alpha" id="cityId">
                        <option value="">Select City</option>
                      </select>
                    </div>

                  </div>
                </div>
              </div>

              <div class="col-lg-4 col-12">
                <div class="your-order">
                  <h3>Order Detail</h3>
                  <div class="your-order-table table-responsive">
                  @if(Session::has('cart'))
                    <table class="table">

                      <thead>
                        <tr>
                          <th class="cart-product-name">Product</th>
                          <th class="cart-product-total">Total</th>
                        </tr>
                      </thead>
                      <tbody>

                      @foreach($products as $product)
                        <tr class="cart_item">
                          <td class="cart-product-name">{{$product['item']->name}}<strong class="product-quantity"> </strong></td>
                          <td class="cart-product-total"><span class="amount">{{$product['qty']}} × PKR {{number_format($product['item']->price)}}
        @if($product['save']>0) saving -{{$product['save']}}@endif</span></td>
                        </tr>
                        @endforeach
                      </tbody>
                      <tfoot>
                        <tr class="cart-subtotal">
                          <th>Cart Subtotal</th>
                          <td><span class="amount">PKR {{number_format($totalPrice)}}</span></td>
                        </tr>
                        <tr class="order-total gray-bg2">
                          <th>Order Total</th>
                          <td><strong><span class="amount">PKR {{number_format($totalPrice)}}</span></strong></td>
                        </tr>
                      </tfoot>
                    </table>
                    @endif
                  </div>
                  <div class="order-button-payment">
                    <button type="submit" class="btn btn-block">Continue</button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!--Checkout Area End-->
  <!--Footer Area Start-->


@endsection
