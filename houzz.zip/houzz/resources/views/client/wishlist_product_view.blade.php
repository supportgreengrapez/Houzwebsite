

@extends('client.layout.app')
@section('content')
<body>



  
<div class="container-fluid">
    <div class="row">
      <div class="col-lg-3">
        <div class="menu">
          <div class="mini-menu">
            <ul>
              <li class="sub"> <a href="{{URL('/')}}/product/garments">GARMENTS</a>
                <ul>
                  <li><a href="{{URL('/')}}/product/garments/garments category/tshirts">T-Shirts</a></li>
                  <li><a href="{{URL('/')}}/product/garments/garments category/hoodies">Hoodies</a></li>
                  <li><a href="{{URL('/')}}/product/garments/garments category/trouser">Trouser</a></li>
                  <li><a href="{{URL('/')}}/product/garments/garments category/abaya">Abaya</a></li>
                  <li><a href="{{URL('/')}}/product/garments/garments category/scarfs">Scarfs</a></li>
                  <li><a href="{{URL('/')}}/product/garments/garments category/printed lawn">Printed Lawn</a></li>
                  <li><a href="{{URL('/')}}/product/garments/garments category/embroidery fabrics">Embroidery Fabrics</a></li>
                  <li><a href="{{URL('/')}}/product/garments/kids category/children">Children Garments</a></li>
                  <li><a href="{{URL('/')}}/product/garments/leather category/leather garments">Leather Garments</a></li>
              
                </ul>
              </li>
              <li> <a href="{{URL('/')}}/product/shoes">SHOES</a>
            
              </li>
              <li class="sub"> <a href="{{URL('/')}}/product/accessories">ACCESSORIES</a>
                <ul>
                  <li><a href="{{URL('/')}}/product/accessories/accessories/car accessories">Car Accessories</a></li>
                  <li><a href="{{URL('/')}}/product/accessories/accessories/general accessories">General Accessories</a></li>
                  <li><a href="{{URL('/')}}/product/accessories/accessories/bags and wallets">Bags and Wallet</a></li>
               
                </ul>
              </li>
              <li class="sub"> <a href="{{URL('/')}}/product/home textile">Home Textile</a>
                <ul>
                  <li><a href="{{URL('/')}}/product/home textile/bed sheets/fitted bed sheets">Fitted bed sheets</a></li>
                  <li><a href="{{URL('/')}}/product/home textile/bed sheets/knitted bed sheets">Knitted bed sheets</a></li>
                
                </ul>
              </li>
          
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-9">
          <div class="col-lg-4">
          <div class="items">

              @if(count($result)>0)
              @foreach($result as $results)
            
            <div data-price="674" class="item">  <a href="{{URL('/')}}/products/details/{{$results->pk_id}}/{{$results->sku}}"><img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="jacket" class="img-item"></a>
              <div class="info">
                  <h3>{{$results->name}}</h3>
                  <p class="descroption">{{$results->description}}</p>
                  <h5> PKR {{$results->price}}</h5>
              </div>
            </div>
       @endforeach

            @endif

     
             
          </div></div>
        </div>
    </div>
  </div>
  


        



</body>

 
@endsection
	