@extends('client.layout.appclient')
@section('content')
<div class="gray-bg3 pb-70 pt-20">
    <div class="container">
      <div class="breadcrumb-tow mb-20">
        <div class="container">
          <div class="row">
            <div class="col-12">
              <div class="breadcrumb-title">
                <h1>About Us</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Breadcrumb Tow End--> 
      <!--Blog Area Start-->
      <div class="blog-area white-bg pt-1 pb-1">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-10">
              <div class="aboutuscontent">
                <p>Seller
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                <p>Seller
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                <h4>The Diverse World Of Michael Kors.</h4>
                <p>Seller
                  Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection