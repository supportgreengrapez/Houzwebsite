@extends('client.layout.appclient')
@section('content')
<style>
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
.slide img {
    height: 306px;
}
</style>
<div class="greyyy">
  <div class="container">
    <div class="shop-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-3"> 
            <!--Product Category Widget Start-->
            <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
              <div class="shop-sidebar">
                <h4>By categories</h4>
                <div class="categori-checkbox">
                  <ul>
                    @if(count($main_category)>0)
                    @foreach($main_category as $results)
                    <li><img src="{{URL('/')}}/images/dott.png" alt=""><a href="{{URL('/')}}/product/{{$results->main_category}}">{{$results->main_category}}</a></i> @endforeach
                      @endif
                  </ul>
                </div>
              </div>
            </div>
          </div>
          @if($errors->any())
          <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
          @endif
          <div class="col-lg-9">
            <div class="shop-layout">
              <div class="row">
                <div class="col-md-12"> 
                  <!--Single Banner Area Start-->
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel"> @if(count($slider)>0)
                    <div class="carousel-inner">
                      <div class="carousel-item active"> <img class="d-block w-100" src="{{URL('/')}}/images/slider1.jpg" alt="First slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider2.jpg" alt="Second slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider3.jpg" alt="Third slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="{{URL('/')}}/images/slider4.jpg" alt="Fourth slide"> </div>
                    </div>
                    @endif <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
                  <!--Single Banner Area End--> 
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <div class="shop-layout">
              <div class="bg-white p-2">
                <div class="shop-product">
                  <div id="myTabContent-2" class="tab-content">
                    <div id="grid" class="tab-pane fade show active">
                      <div class="product-grid-view">
                        <div class="row"> @if(count($sale_category)>0)
                          @foreach($sale_category as $results)
                          
                          @php

                          $main = $results->main_category;
                          

                          $image = DB::select("select * from main_category where main_category ='$main'");


                          @endphp



                          <div class="col-md-4"> 
                            <!--Single Product Start-->
                            <div class="sale_img"> 
                            <a href="{{URL('/')}}/sale/products/{{$results->main_category}}"> <img src="{{URL('/')}}/storage/images/{{$image[0]->thumbnail}}" alt="Sale Image" class="p-2"> </a> 
                            <span class="hz-badge hz-badge--urgent weekly-deal__title">UP TO 10% OFF</span>
                            <h2><a href="{{URL('/')}}/sale/products/{{$results->main_category}}">{{$results->main_category}}</a></h2>
                            
                            </div>
                            <!--Single Product End--> 
                          </div>
                          @endforeach
                          @endif </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End--> 
      </div>
    </div>
  </div>
</div>
@endsection 