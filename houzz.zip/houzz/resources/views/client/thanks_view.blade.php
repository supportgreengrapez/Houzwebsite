
@extends('client.layout.appclient')
@section('content')


<div class="container">
	<div class="row">
    	<div class="col-lg-12 col-md-12 col-sm-12">
        	<div class="box1border">
				<div class="box1">
					<h2 styles="color:white;">Confirm</h2>
				</div>
			</div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12">
        	<div class="thanku">
            	<h2>Thank You</h2><br>
                <p>Thank you for buy a product from <strong>Houzz.coms</strong></p>
                @if(count($result)>0)
  <p class="lead"><strong>{{$result[0]->tracking_id}}</strong> is your tracking ID.</p>
  @endif
            </div>
        </div>
    </div>
</div>

@endsection
