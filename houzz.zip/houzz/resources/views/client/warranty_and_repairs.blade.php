@extends('client.layout.appclient')
@section('content')
<div class="container">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
      <div class="paymentpolicy pt-20">
        <h2>WARRANTY policy</h2>
        <p>As a general rule, houz does not offer any product warranties as these are provided by the manufacturers or brands of products. However, our Customer Service will assist you in any way possible to figure out how to claim your warranty from the company, or warranty provider.</p>
        <p><br />
          <br />
        </p>
        <p><strong>How do I know if my product has a warranty?</strong></p>
        <p><br />
          <br />
        </p>
        <p>Different products are covered under different warranty policies. To confirm the warranty type of a particular item, please note the following steps</p>
        <ul>
          <li>On the Product Page, under the product description, you will see details for warranty.</li>
          <li>If the product has a warranty coverage, this field will identify the duration of the warranty and how the warranty is covered.</li>
        </ul>
        <p><strong><br />
          How can I claim warranty?</strong></p>
        <p><br />
          <br />
        </p>
        <p>Warranty claims are subject to the warranty coverage of the item you have purchased, if the product has a warranty from the brand, a warranty card will be included in the packaging. Please follow the following steps to initiate a warranty claim.</p>
        <p><br />
          <br />
        </p>
        <ul>
          <li>If your product is non-functional or broken on arrival, you can call the houz.pk helpline at 0309-49-777-66 within 1 day of delivery to initiate an exchange or return of the product.</li>
          <li>If your product produces a fault post the initial 7 days of delivery but is within warranty timeline, you can call the houz.pk helpline at 0309-49-777-66and provide the following information from your receipt and warranty card to initiate a warranty claim
            <ul>
              <li>Order Number</li>
              <li>Order Date</li>
              <li>Item Details</li>
              <li>Warranty Period (on warranty card)</li>
              <li>Nature of fault</li>
            </ul>
          </li>
          <li>To claim warranty directly from the brand, please contact the authorized service center using the details stated on the warranty card provided with the item.</li>
        </ul>
        <p><strong>Note: We urge you to save the invoice and warranty card together to ease warranty claim process.</strong></p>
        <p><br />
          <br />
          <br />
        </p>
        <p>If you have any questions, you can contact us at any time by&nbsp;either a call <a class="mobilesOnly green" href="tel:+923094977766">0309-49-777-66</a> or <a href="https://mail.google.com/mail/u/0/#inbox" class="green">customer@houz.pk</a></p>
      </div>
    </div>
  </div>
</div>
@endsection