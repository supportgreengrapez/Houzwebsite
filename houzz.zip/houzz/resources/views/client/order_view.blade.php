@extends('client.layout.appclient')
@section('content')
<div class="gray-bg2 pt-10">
  <div id="login" class="mb-50 mt-10">
    <div class="container">
      <div class="white-bg mb-20">
        <div class="row justify-content-center">
          <div class="col-3">
            <div class="billingtophead">
              <h4><span class="billingtopcircles" style="">1</span> Shipping</h4>
            </div>
          </div>
          <div class="col-3">
            <div class="billingtophead">
              <h4><span class="billingtopcircles" style="padding: 2px 8px 2px 8px; background-color: #689a29;">2</span> Order Review</h4>
            </div>
          </div>
          <div class="col-3">
            <div class="billingtophead">
              <h4><span class="billingtopcircles" style="padding: 2px 8px 2px 8px;">3</span>Billing & Payment</h4>
            </div>
          </div>
        </div>
      </div>
      <div id="login-row" class="row justify-content-center align-items-center">
        <div id="login-column" class="col-md-8">
          <div id="login-box" class="col-md-12 shadow-lg p-3 mb-5 bg-white rounded">
            <div class="panel panel-default pnel">
              <div class="panel-heading panelhead">
                <h3 class="panel-title "> <strong>1 :</strong> EMAIL<span>{{Session::get('username')}}</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> NAME <span> @if(count($result1)>0)
                  @foreach($result1 as $results)
                  {{$results->fname}} {{$results->lname}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> ADDRESS <span> @if(count($result1)>0)
                  @foreach($result1 as $results)
                  {{$results->address}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> CITY <span> @if(count($result1)>0)
                  @foreach($result1 as $results)
                  {{$results->city}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading panelhead">
                <h3 class="panel-title"> <strong>2 :</strong> PHONE <span> @if(count($result1)>0)
                  @foreach($result1 as $results)
                  {{$results->phone}}
                  @endforeach
                  @endif</span> </h3>
              </div>
              <div class="panel-heading">
                <h3 class="panel-title"> <strong>3 :</strong> ORDER SUMMERY </h3>
                <div class="row">
                  <div class="col-12">
                    <div class="table-content table-responsive">
                    <table class="table">
                    <thead>
                      <tr>
                        <th class="plantmore-product-thumbnail">images</th>
                        <th class="cart-product-name">Product</th>
                        <th class="cart-product-name">Category</th>
                        <th class="cart-product-name">Size</th>
                        <th class="plantmore-product-price">Unit Price</th>
                        <th class="plantmore-product-quantity">Quantity</th>
                        <th class="plantmore-product-subtotal">Total</th>
                        <th class="plantmore-product-remove">Promo</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                    @foreach($products as $product)
                    <tr>
                      <td class="plantmore-product-thumbnail"><img src="{{URL('/')}}/storage/images/{{$product['item']->thumbnail}}" alt="" style="width:150px; height:150px;"></td>
                      <td class="plantmore-product-name">{{$product['item']->name}}</td>
                      <td class="plantmore-product-name">{{$product['sub_cat']}}</td>
                      <td class="plantmore-product-name">{{$product['size']}}</td>
                      <td class="plantmore-product-price"><span class="amount">{{number_format($product['item']->price)}}
                        @if($product['save']>0) saving -{{number_format($product['save'])}}@endif</span></td>
                      <td class="plantmore-product-price"><span class="amount">{{$product['qty']}}</span></td>
                      <td class="product-subtotal"><span class="amount">{{number_format($product['price'])}}</span></td>
                      <td>
                    <form method="post" action ="{{url('/')}}/cart/checkout/address/view/order/complete/order/add/promo/{{$product['item']->sku}}/{{$product['sub_cat']}}/{{($product['price'])}}">
                      {{ csrf_field() }}
                      <div class="panel-body">
                        <input class="form-control" name="promo"  type="text"/>
                        <br>
                        <button type="submit" name = "submit" class="btn cnfmorder">Add Promo Code</button>
                      </div>
                    </form>
                    </td>
                    </tr>
                    @endforeach
                    </tbody>
                    </table>
                  </div>
                  <div class="row">
                    <div class="col-md-5 ml-auto">
                      <div class="cart-page-total">
                        <h2>Cart totals</h2>
                        <ul>
                        @if(Session::has('pro'))
                        <li>Total <span>PKR {{number_format(Session::get('pro'))}}</span></li>
                @elseif(Session::has('promoPrice'))
                <li>Total <span>PKR {{number_format(Session::get('promoPrice'))}}</span></li>
                @else
                          <li>Total <span>PKR {{number_format($totalPrice)}}</span></li>
                          @endif
                        </ul>
                        <a href="{{url('/')}}/cart/checkout/address/view/order/complete/order/{{$results->pk_id}}">Proceed to checkout</a> </div>
                    </div>
                  </div>
                </div>
              </div>
              <br>
            </div>
            <div class="panel-heading panelhead">
              <h3 class="panel-title"> <strong>4 :</strong> PAYMENT </h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection 