@extends('admin.layout.appadmin')
@section('content')
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Message Management</h3>
            <h4>Answered List</h4>
          </div>
        </div>
      </div>
        <div class="clearfix"></div>
        <div class="wrap" style="border:1px solid #ededed;padding:1rem;">
      <div class="row">
      <div class="page-title">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Messages</h3>
          </div>
        </div>
      </div>
      <div class="col-lg-12 col-md-12 col-sm-12">
           
         @if(count($result)>0)
            <div class="dbparahs">
              <p>{{$result[0]->message}}</p>
            </div>
            @endif
          </div>
      </div>
      
      <div class="row">
      <div class="col-lg-12">
      @if(count($result)>0)
      <form method="post" action = "{{url('/')}}/admin/home/send/message/{{$result[0]->pk_id}}" enctype="multipart/form-data" class="login-form">
                            {{ csrf_field() }}
                            @if($errors->any())

<div class="alert alert-danger">
  <strong></strong> {{$errors->first()}}
</div>
@endif
      <div class="form-group">
      <textarea class="form-control" rows="9" name="reply"></textarea>
      <h6 class="pull-right red">Character Limit 1000</h6>
      </div>
      <div class="form-group">
      <button type="submit" class="btn btn-success">Submit Answer</button>
      </div>
      </form>
      @endif
      </div>
      </div>
      </div>
    </div>
    <!-- /page content --> 
    
  @endsection