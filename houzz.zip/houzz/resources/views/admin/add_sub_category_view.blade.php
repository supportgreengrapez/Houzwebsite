@extends('admin.layout.appadmin')
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management</h3>
        <h4 style="display: block;">Add Sub Category</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
          <form method="post" action = "{{url('/')}}/admin/home/add/sub/category" class="login-form" enctype="multipart/form-data">
            {{ csrf_field() }}
            
            @if($errors->any())
            <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
            @endif
            <div class="row">
              <div class="col-lg-5">
                <div class="row">
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label>Main Category Name</label>
                    <select class="form-control" name="mainCategory" id="maincat">
                      <option value="">Select Main Category</option>
                      
                @if($result>0)
                @foreach($result as $results)
                       
                      <option value="{{$results->main_category}}">{{$results->main_category}}</option>
                      
                       @endforeach
       @endif
                   
                    </select>
                  </div>
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label>Category Sub Type</label>
                    <input type="text" class="form-control" name="subCategory"  placeholder="Category Sub Type" required>
                  </div>
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label> Category Image</label>
                    <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                    <img id="blah" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> 
                  </div>
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label>Commission</label>
                    <input type="number" class="form-control" name="commission" id="commission"  placeholder="Commission" >
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 