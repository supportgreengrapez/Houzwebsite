<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" href="{{url('/')}}/images/favicon.png"/>
<title>Houzz</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="{{url('/')}}/css/style2.css" rel="stylesheet">
</head>

<body class="nav-md">
<div id="invoice">
  <div class="invoice overflow-auto">
    <div style="min-width: 600px">
      <header>
        <div class="row">
          <div class="col"> <a href="{{URL('/')}}/admin/home"> <img src="{{url('/')}}/images/logo.png" data-holder-rendered="true" /> </a> </div>
          <div class="col company-details">
            <h2 class="name"> Houzz.pk </h2>
            <div>455 Foggy Heights, AZ 85004, US</div>
            <div>(123) 456-789</div>
            <div>support@houzz.com</div>
          </div>
        </div>
      </header>
      <main>
        <div class="row contacts"> @if(count($result)>0)
          @foreach($result as $results)
          <div class="col invoice-to">
            <div class="text-gray-light">INVOICE TO:</div>
            <h2 class="to">{{$results->fname}} {{$results->lname}}</h2>
            <div class="address">{{$results->address}}</div>
            <div class="email">{{$results->username}}</div>
          </div>
          <div class="col invoice-details">
            <h1 class="invoice-id">INVOICE # :{{$results->pk_id}}</h1>
            <div class="date">Date of Invoice: {{$results->created_at}}</div>
          </div>
          @endforeach
          @endif </div>
        <table border="0" cellspacing="0" cellpadding="0">
          <thead>
            <tr>
              <th class="text-left">Package Name</th>
              <th class="text-right">Bussiness Name</th>
              <th class="text-right">Account Type</th>
              <th class="text-right">Subscription</th>
            </tr>
          </thead>
          <tbody>
          
          @if(count($result)>0)
          @foreach($result as $results)
          <tr>
            <td class="no">{{$results->package_name}}</td>
            <td class="unit">{{$results->business_name}}</td>
            <td class="qty">{{$results->account_t}}</td>
            <td class="total">{{$results->subscription}}</td>
          </tr>
          @endforeach
          @endif
            </tbody>
          
          <tfoot>
          
          @if(count($result)>0)
          @foreach($result as $results)
          <tr>
            <td colspan="2"></td>
            <td colspan="2">Total</td>
            <td>PKR {{number_format($results->amount)}}</td>
          </tr>
          @endforeach
          @endif
            </tfoot>
          
        </table>
      </main>
    </div>
    <div></div>
  </div>
</div>
</body>
</html>