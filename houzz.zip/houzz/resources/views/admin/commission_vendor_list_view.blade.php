@extends('admin.layout.appadmin') 
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Seller Management</h3>
          <h4>Commission Seller</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>Seller ID</th>
              <th> Name</th>
              <th>Email</th>
              <th>Package</th>
              <th>No. of Products</th>
              <th>No. of orders</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          
          @if($result>0)
          @foreach($result as $results)
          @php
          $user_id = $results->vendor_id;
          $user = DB::select("select* from client_details where pk_id ='$user_id'");
          $product = DB::select("select* from product where vendor_id ='$user_id'");
          $order = DB::select("select DISTINCT(order_id) from detail_table where vendor_id ='$user_id'");
          
          @endphp
          <tr>
            <td>{{$results->vendor_id}}</td>
            <td>{{$user[0]->fname}} {{$user[0]->lname}}</td>
            <td>{{$user[0]->username}}</td>
            <td>Commission</td>
            <td>{{count($product)}}</td>
            <td>{{count($order)}}</td>
            <td><a href="{{url('/')}}/admin/home/view/vendor/{{$results->vendor_id}}" class="green">View</a> | <a href="{{url('/')}}/admin/home/view/vendor/orders/{{$results->vendor_id}}">Order View</a></td>
          </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 