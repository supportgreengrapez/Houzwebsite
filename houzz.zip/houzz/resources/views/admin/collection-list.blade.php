@extends('admin.layout.appadmin')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Product Management</h3>
            <h4>Collection List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{url('/')}}/admin/add/collection/view" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Collection</a>
          </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                         <th>Collection set Id</th>
                      <th>Collection category</th>
                      <th>Collection Name</th>
                      <th>Description</th>
                        <th>Image</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                         @if(count($result)>0)
                        @foreach($result as $results)
                    <tr>
                     @php
                     $id = "$results->collection_id";
                         $collection = DB::select("select* from collection where pk_id ='$id'");
                     @endphp
                       <td>{{$results->pk_id}}</td>
                      <td>{{$results->collection_id}}</td>
                      <td>{{$results->collection_name}}</td>
                      <td>{{$collection[0]->description}}</td>
                           <td><img src="{{URL('/')}}/storage/images{{$collection[0]->thumbnail}}" alt="img" style="width:150px; height:100px;"></td>
                            <td><a href="{{URL('/')}}/admin/collection/set/view/{{$results->pk_id}}">view collection set</a>
    <td><a href="{{URL('/')}}/admin/edit/collection/view/{{$results->pk_id}}">Edit</a>
                              <a href="{{URL('/')}}/admin/delete/collection/{{$results->pk_id}}" class="red">Delete</a></td>
                  
                    </tr>
                        @endforeach
                      @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

    @endsection
