@extends('admin.layout.appadmin')
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="page-title">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="title_left">
        <h3>Message Management</h3>
        <h4>Message List</h4>
      </div>
    </div>
  </div>
  <div id="exTab1" class="container">
    <ul  class="nav nav-pills" style="border-bottom: 2px solid #6d9b25;">
      <li class="active"> <a  href="#1a" data-toggle="tab">New Message</a> </li>
      <li><a href="#2a" data-toggle="tab">Delivered Message</a> </li>
    </ul>
    <div class="tab-content clearfix">
      <div class="tab-pane active" id="1a"> @if(count($result)>0)
        @foreach($result as $results)
        <div class="messg"><a href="{{url('/')}}/admin/home/send/message/{{$results->pk_id}}"> @php
          $seller = DB::select("select* from client_details where pk_id ='$results->customer_name'");
          @endphp
          <div class="row borderbotm">
            <div class="col-lg-3 col-md-3 col-sm-12">
              <div class="dbicon">
                <h3><span>{{$results->date}}</span><br>
                  @if(count($seller)>0) {{$seller[0]->fname}} {{$seller[0]->lname}} @endif</h3>
              </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
              <div class="dbparahs">
                <p>{{$results->message}}</p>
                <h6>{{$results->reply}}</h6>
              </div>
            </div>
          </div>
          </a></div>
        @endforeach
        @endif </div>
      <div class="tab-pane" id="2a">@if(count($result1)>0)
        @foreach($result1 as $results)
        <div class="messg"><a href="{{url('/')}}/admin/home/send/message/{{$results->pk_id}}"> @php
          $seller = DB::select("select* from client_details where pk_id ='$results->customer_name'");
          @endphp
          <div class="row borderbotm">
            <div class="col-lg-3 col-md-3 col-sm-12">
              <div class="dbicon">
                <h3><span>{{$results->date}}</span><br>
                  @if(count($seller)>0) {{$seller[0]->fname}} {{$seller[0]->lname}} @endif</h3>
              </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
              <div class="dbparahs">
                <p>{{$results->message}}</p>
                <h6>{{$results->reply}}</h6>
              </div>
            </div>
          </div>
          </a></div>
        @endforeach
        @endif </div>
    </div>
  </div>
</div>
<!-- /page content --> 
@endsection