@extends('admin.layout.appadmin')
@section('content')

@if(count($result)>0)
@foreach($result as $results)
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Seller Management</h3>
            <h4 style="display:block;">Seller Detail</h4>
        </div>
      </div>
      <div class="wrap">
      <div class="page-title">
            <h4><b>Seller Information</b></h4>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Bussiness Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->business_name}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Address</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p>{{$results->address}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Country</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->country}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>City</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->city}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>State/Provience</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->state}}</p>

          </div>
        </div>
      </div>

      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Zip/Postal Code</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->zip}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Phone No</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->phone}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Fax</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->fax}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Account Type</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->account_t}}</p>

          </div>
        </div>
      </div>
      @if($results->account_t == "Business")
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Category</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->vendor_cat}}</p>

          </div>
        </div>
      </div>
      
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Payment Duration</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            
            <p>{{$results->payment_duration}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Certificate</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><img src="{{URL('/')}}/storage/images/{{$results->certificate}}" alt="img" style="width:50%"></p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Company Logo</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><img src="{{URL('/')}}/storage/images/{{$results->thumbnail}}" alt="img" style="width:50%"></p>

          </div>
        </div>
      </div>
      @endif
      @if($results->account_t == "Individual")
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>CNIC</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->cnic}}</p>

          </div>
        </div>
      </div>
      @endif

      </div>
      <div class="row">
      <div class="col-lg-12 col-sm-10 col-md-12 col-xs-12">
      <div class="dividers"></div>
      </div>
      </div>
      <div class="wrap">
      <div class="page-title">
            <h4><b>Bank Info</b></h4>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Bank Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->bank_name}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Account Number</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p>{{$results->account_no}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Acoount Type</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->account_type}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Routing Number</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->routing_no}}</p>

          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Check</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><img src="{{URL('/')}}/storage/images/{{$results->cheque}}" alt="img" style="width:50%"></p>

          </div>
        </div>
      </div>
      </div>
      <div class="row">
      <div class="col-lg-12 col-sm-10 col-md-12 col-xs-12">
      <div class="dividers"></div>
      </div>
      </div>
      <div class="wrap">
      <div class="page-title">
            <h4><b>Additonal Seller Info</b></h4>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Federal Tex Id No</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->federal_tax}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Name Of Primary Contact</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p>{{$results->primary_contact}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Name Of Payee</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p>{{$results->payee}}</p>
          </div>
        </div>
      </div>
      </div>
      <div class="row">
      <div class="col-lg-12 col-sm-10 col-md-12 col-xs-12">
      <div class="dividers"></div>
      </div>
      </div>
      <div class="wrap">
      <div class="page-title">
            <h4><b>Banners</b></h4>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>First Image</label><br>
            <img src="{{URL('/')}}/storage/images/{{$results->slide}}" alt="img">
           </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>Second Image</label><br>
            <img src="{{URL('/')}}/storage/images/{{$results->slide2}}" alt="img">
           </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>Third Image</label><br>
            <img src="{{URL('/')}}/storage/images/{{$results->slide3}}" alt="img">
           </div>
        </div>
      </div>
      </div>
    </div>
    <!-- /page content -->
@endforeach
@endif
     @endsection
