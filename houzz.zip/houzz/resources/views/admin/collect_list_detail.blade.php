@extends('admin.layout.appadmin')

@section('content')

    <!-- page content -->
   
    <div class="right_col" role="main">
         @if(count($result)>0)
      <div class="page-title">
        <div class="title_left">
          <h3>Product Management</h3>
            <h4 style="display:block;">Collection View</h4>
        </div>
      </div>
        <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{URL('/')}}/admin/edit/collection/set/view/{{$result[0]->pk_id}}" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i>Edit Collection Set</a>
          </div>
          </div>
          @endif
           @if($result1>0)
      <div class="wrap">
      <div class="page-title">
            <h4><b>About Collection</b></h4>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Collection Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result1[0]->collection_name}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Description</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p>{{$result1[0]->description}}</p>
          </div>
        </div>
      </div>
      </div>
      <div class="row">
      <div class="col-lg-12 col-sm-10 col-md-12 col-xs-12">
      <div class="dividers"></div>
      </div>
      </div>
      <div class="wrap">
      <div class="page-title">
            <h4><b>Images</b></h4>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
          <div class="dbicons">
          <label>Cover Image</label><br>
            <img src="{{url('/')}}/storage/images/{{$result1[0]->thumbnail}}" alt="img">
           </div>
        </div>
      </div>
      </div>
       @endif
       
       
       <div class="row">
      <div class="col-lg-12 col-sm-10 col-md-12 col-xs-12">
      <div class="dividers"></div>
      </div>
      </div>
      <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>SKU</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Category</th>
                      <th>Sub Category</th>
                    
                      <th>description</th>
                    </tr>
                  </thead>
                  <tbody>

                  @if(count($product_array)>0)
                  
                  @foreach($product_array as $results)
                  
                    <tr>
                    <td>{{$results[0]->sku}}</td>
                      <td>{{$results[0]->name}}</td>
                      <td>{{number_format($results[0]->price)}}</td>
                      <td>{{$results[0]->category}}</td>
                      <td>{{$results[0]->sub_category}}</td>
                        <td>{{$results[0]->description}}</td>
                
                    </tr>
                         @endforeach
                     @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
    </div>
       
    <!-- /page content -->
    @endsection
