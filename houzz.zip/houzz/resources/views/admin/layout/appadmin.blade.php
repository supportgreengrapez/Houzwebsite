<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" href="{{url('/')}}/images/favicon.png"/>
<title>Houzz</title>

<!-- Bootstrap -->

<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<link href="{{url('/')}}/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{url('/')}}/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="{{url('/')}}/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="{{url('/')}}/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="{{url('/')}}/css/custom.min.css" rel="stylesheet">
<!-- Datatables -->
<link href="{{url('/')}}/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="{{url('/')}}/css/responsive.bootstrap.min.css" rel="stylesheet">
<link href="{{url('/')}}/css/scroller.bootstrap.min.css" rel="stylesheet">
<link href="{{url('/')}}/css/bootstrap-colorpicker.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title"> <a href="{{URL('/')}}/admin/home" class="site_title"><i><img src="{{url('/')}}/images/favicon.png" alt="logo"></i> <span>Houzz</span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
          <ul class="nav side-menu">
              <li><a href="{{URL('/')}}/admin/home"><i class="fa fa-tachometer"></i> Home </a> </li>

              <li><a href="{{url('/')}}/admin/home/view/admin"><i class="fa fa-user"></i> Admin & permissions </a> </li>


              <li><a><i class="fa fa-table"></i> Product Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/product">All Products</a></li>
                  <li><a href="{{URL('/')}}/admin/home/add/product">Add Products</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/product/type">Product Type</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/main/category">Categories</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/sub/category">Sub Categories</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/brand">Brand</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/material">Material</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/style">Style</a></li>
                  <li><a href="{{URL('/')}}/admin/collection/list/view">Manage Collection</a></li>
                  <li><a href="{{URL('/')}}/admin/import/product/view">Import New Product</a></li>
                  <li><a href="{{URL('/')}}/admin/slider/list/view">Top Page Image Slider</a></a></li>
                </ul>
              </li>

              <li><a><i class="fa fa-table"></i> Seller Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/vendor">All Seller</a></li>
                  <li><a href="{{URL('/')}}/admin/home/create/seller">Add Seller</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/pending/products">Seller Products</a></li>
                  
                  <li><a href="{{URL('/')}}/admin/home/view/approved/products">Seller Approved Products</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/seller/rating">Seller Rating & Reviews</a></li>
                  <li><a href="seller_collection_list.html">Seller Collection</a></li>
                <li><a href="{{URL('/')}}/admin/home/view/package/invoice">Package Invoice</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/package/payment">Package Payment</a></li>
                  <!--<li><a href="seller_commision_invoice_list.html">Commision Seller Invoice</a></li>-->
                  <!--<li><a href="seller_commision_payments_list.html">Commision Seller Payments</a></li>-->
                </ul>
              </li>
              
              <li><a><i class="fa fa-table"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/active/orders">All Orders</a></li>
                  <li><a href="{{URL('/')}}/admin/payment/list/view">Payments</a></li>
                  <li><a href="{{URL('/')}}/admin/invoice/list/view">Invoice</a></li>
                </ul>
              </li>


              <li><a href="{{URL('/')}}/admin/home/view/return/orders"><i class="fa fa-table"></i> Return Management </a> </li>
              <li><a href="{{URL('/')}}/admin/home/view/discount"><i class="fa fa-table"></i> Promotion Management</a></li>
              <li><a href="{{URL('/')}}/admin/home/view/promo"><i class="fa fa-table"></i> Coupons Management</a></li>
              <li><a><i class="fa fa-table"></i> Package Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    
                  <li><a href="{{URL('/')}}/admin/home/view/package">Seller Packages</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/package/invoice">Package Invoice</a></li>
                  
                  <li><a href="{{URL('/')}}/admin/home/view/custom/package">Custom Package</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Reporting Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/commission/vendor">Seller Information</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/reporting/by/products">By Product</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/reporting/by/sale">By Sales</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/reporting/by/sale/vendor">Seller Payment</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/houzz/earning">Houzz Earning</a></li>
                </ul>
              </li>
              <li><a href="{{URL('/')}}/admin/home/view/rating"><i class="fa fa-table"></i> Rating & Reviews</a></li>
              <li><a><i class="fa fa-table"></i> Photo Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/photo/category">Categories</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/photo/sub/category">Sub Categories</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/idea/list">Idea</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Forum Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/forum/category">Categories</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/forum/topic">Topics</a></li>
                  <li><a href="{{URL('/')}}/admin/home/view/forum/post">Post</a></li>
                </ul>
              </li>

               <li><a><i class="fa fa-table"></i> Partner Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{route('partner.list')}}">All Partners</a></li>
                  <li><a href="{{route('partner.catgory')}}">Partner Category</a></li>
                    <li><a href="{{route('partner.sub.catgory')}}">Sub Category
</a></li>

                  <li><a href="{{route('titanium.partner.list')}}">Titanium Partner List
                  <li><a href="{{route('slider.image')}}">Slider Image Option
</a></li>

                </ul>
              </li>

               <li><a><i class="fa fa-table"></i> Blog Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="{{URL('/')}}/admin/home/view/blog/category">Categories</a></li>
                  <li><a href="{{URL('/')}}/admin-blog">Blog</a></li>
                </ul>
              </li>
              <li><a href="{{URL('/')}}/admin/home/view/message"><i class="fa fa-tachometer"></i> Message </a> </li>
                 <li><a href="{{URL('/')}}/admin/home/view/chat"><i class="fa fa-tachometer"></i> Live Chat </a> </li>
            </ul>
          </div>
        </div>
        <!-- /sidebar menu -->
      </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="{{url('/')}}/images/vendorprofile.png" alt="">{{Session::get('name')}} <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="{{URL('/')}}/admin/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
            <li role="presentation" class="dropdown">
<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
<i class="fa fa-bell"></i>
@php

$noti = DB::select("select* from notification ORDER BY pk_id DESC");

@endphp
<span class="badge bg-green">{{count($noti)}}</span>
</a>
<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
@if(count($noti)>0)
@foreach($noti as $results)

@if($results->type == 'new vendor created')
@php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

@endphp
<li>
<a>
<span>
@if(count($name)>0)<span>{{$name[0]->fname}} {{$name[0]->lname}}</span>@endif
<span class="time">{{ Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()}}</span>
</span>
<span class="message">
New Seller is Waiting for Approval
</span>
</a>
</li>
@endif


@if($results->type == 'new product created')
@php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

@endphp
<li>
<a>
<span>
@if(count($name)>0)<span>{{$name[0]->fname}} {{$name[0]->lname}}</span>@endif
<span class="time">{{ Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()}}</span>
</span>
<span class="message">
Seller is Waiting for Product Approval
</span>
</a>
</li>
@endif

@if($results->type == 'COMMISSION')
@php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

@endphp
<li>
<a>
<span>
@if(count($name)>0)<span>{{$name[0]->fname}} {{$name[0]->lname}}</span>@endif
<span class="time">{{ Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()}}</span>
</span>
<span class="message">
@if(count($name)>0){{$name[0]->fname}} {{$name[0]->lname}}@endif is Subscribed to COMMISSION Based Package
</span>
</a>
</li>
@endif

@if($results->type == 'BASIC')
@php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

@endphp
<li>
<a>
<span>
@if(count($name)>0)<span>{{$name[0]->fname}} {{$name[0]->lname}}</span>@endif
<span class="time">{{ Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()}}</span>
</span>
<span class="message">
@if(count($name)>0){{$name[0]->fname}} {{$name[0]->lname}}@endif is Subscribed to BASIC Package
</span>
</a>
</li>
@endif

@endforeach
@endif

<li>
<div class="text-center">
<a>
<strong>See All Alerts</strong>
<i class="fa fa-angle-right"></i>
</a>
</div>
</li>
</ul>
</li>
          </ul>
        </nav>
      </div>
    </div>

      @yield('content')


 <!-- footer content -->
 <footer>
      <div class="pull-right"> Copyright © 2017-2018 Houzz.com. All rights reserved.<br> Powered By <a href="https://greengrapez.com">Green Grapez <img src="{{url('/')}}/images/greengrapez.png" alt="green grapez"></a> </div>

      <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
  </div>
</div>

<!-- jQuery -->
<script src="{{url('/')}}/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="{{url('/')}}/js/bootstrap.min.js"></script>
<!-- DateJS -->
<script src="{{url('/')}}/js/build/date.js"></script>
<!-- bootstrap-progressbar -->
<script src="{{url('/')}}/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="{{url('/')}}/js/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="{{url('/')}}/js/moment.min.js"></script>
<script src="{{url('/')}}/js/daterangepicker.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="{{url('/')}}/js/custom.min.js"></script>
<!-- Datatables -->
<script src="{{url('/')}}/js/jquery.dataTables.min.js"></script>
<script src="{{url('/')}}/js/dataTables.bootstrap.min.js"></script>
<script src="{{url('/')}}/js/dataTables.responsive.min.js"></script>
<script src="{{url('/')}}/js/responsive.bootstrap.js"></script>
<script src="{{url('/')}}/js/dataTables.scroller.min.js"></script>
<script src="{{url('/')}}/js/bootstrap-colorpicker.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
<script src="{{url('/')}}/js/jquery.printPage.js"></script>

<script>
$(".my-colorpicker2").colorpicker();

$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});
</script>

    <!-- page script -->
    <script>
      $("#order_status").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/order/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>

 <!-- page script -->
    <script>
      $("#b2").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/order/update/amount/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>


     <script>
     
     
      $("#return").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/confirm/return",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
     
  </script>


     <script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/vendor/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
    
          $("#hot").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/product/hot/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

    $("#payment").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/payment/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>


 <script type="text/javascript">
    $("#photo_category").on('change',function(e){

      console.log(e);

      var cat_id = e.target.value;

      $.get('{{URL('/')}}/ajax-photocat?cat_id='+ cat_id,function(data){
        console.log(data);
        $('#photo_sub_category').empty();
        $('#photo_sub_category').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

        $.each(data,function(create,subcatObj){

          $('#photo_sub_category').append('<option value ="'+subcatObj.SKU+'">'+subcatObj.photo_sub_category+'</option>');
      });



      });


  });
  </script>
  <script type="text/javascript">
    $("#mainCategory").on('change',function(e){

      console.log(e);

      var cat_id = e.target.value;

      $.get('{{URL('/')}}/ajax-subcat?cat_id='+ cat_id,function(data){
        console.log(data);
        $('#SubCategory').empty();
        $('#SubCategory').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

        $.each(data,function(create,subcatObj){

          $('#SubCategory').append('<option value ="'+subcatObj.SKU+'">'+subcatObj.sub_category+'</option>');
      });



      });


  });

    $("#SubCategory").on('change',function(e){

      console.log(e);

      var type_id = e.target.value;

      $.get('{{URL('/')}}/ajax-product-type?type_id='+ type_id,function(data){
        console.log(data);
      $('#ProductType').empty();
        $('#ProductType').append('<option value="" disable="true" selected="true" >---Add Product Type---</option>');
        $.each(data,function(create,typeObj){

          $('#ProductType').append('<option value ="'+typeObj.product_type+'">'+typeObj.product_type+'</option>');
      });



      });


  });
</script>

<script>
    $("#b1").click(function(){
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var status = $('#status').val();
      $.ajax({
        /* the route pointing to the post function */
        url: "{{URL('/')}}/admin/home/vendor/order/update/status",
        type: 'POST',
        /* send the csrf-token and the input to the controller */
        data: {_token: CSRF_TOKEN, status:status,
        id: OrgID,
      },
        /* remind that 'data' is the response of the AjaxController */
        success: function (data) {
          window.location.href = data;
        }
    });

  });
</script>

<script>


   $("#button_1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        console.log(status);
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/vendor/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

        $("#update_payment").click(function(){
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var status = $('#status').val();
      $.ajax({
        /* the route pointing to the post function */
        url: "{{URL('/')}}/admin/home/update/payment/status",
        type: 'POST',
        /* send the csrf-token and the input to the controller */
        data: {_token: CSRF_TOKEN, status:status,
        id: OrgID,
      },
        /* remind that 'data' is the response of the AjaxController */
        success: function (data) {
          window.location.href = data;
        }
    });

  });

  $("#invoice_package").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/invoice/package/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

        $("#update_invoice").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/payment/invoice/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  $("#pp").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "{{URL('/')}}/admin/home/product/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

    
</script>
   <script type="text/javascript">
      $("#MainCategory").on('change',function(e){

        console.log(e);

        var cat_id =  e.target.value;

        $.get('{{URL('/')}}/ajax-subcat?cat_id='+ cat_id,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<option value ="'+subcatObj.sub_category+'">'+subcatObj.sub_category+'</option>');
        });



        });


    });

  </script>
  <script>
      $(document).ready(function() {
	
	$(".js-example-tokenizer").select2({
    tags: true,
    tokenSeparators: [',', ' ']
})
});
  </script>
  <script>
function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("text");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>

<script>
function myFunctions() {
  var checkBox = document.getElementById("myChecked");
  var text = document.getElementById("texts");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>
<script>
function myFunctionss() {
  var checkBox = document.getElementById("myChecks");
  var text = document.getElementById("textss");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>
<script>
$(document).ready(function(){
   var maxField = 10; //Input fields increment limitation
   var addButton = $('.add_button2'); //Add button selector
   var wrapper = $('.field_wrapper'); //Input field wrapper
   var fieldHTML = '<div class="opendiv"><div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2"><div class="boxborder"><div class="form-group nomargin contform2"><label>Product ID</label><input type="text" class="form-control" name="product_id[]"></div><div class="form-group nomargin contform2"><label>Product Name</label><input type="text" class="form-control" name="product_name[]"></div><div class="form-group contform2"><label>Product Description</label><textarea class="form-control" rows="5" name="product_description[]"></textarea></div><div class="row"><div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><div class="form-group nomargin contform2"><label>Quantity</label><input type="number" class="form-contro" name="quantity[]"></div></div></div><div class="row"><div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><div class="form-group nomargin contform2"><label>Price</label><input type="number" class="form-control" name="price[]"></div></div></div><div class="form-group nomargin contform2"><label>Size</label><input type="text" class="form-control" name="size[]"></div><div class="form-group nomargin contform2"><label>Promotion</label><input type="text" class="form-control" name="promotion"></div></div></div><a href="javascript:void(0);" class="remove_button minusbtn col-lg-1 col-sm-12"><span class="glyphicon glyphicon-minus marginsets"></span></a></div>'; //New input field html
   var x = 1; //Initial field counter is 1
   //Once add button is clicked
   $(addButton).click(function(){
       //Check maximum number of input fields
       if(x < maxField){
           x++; //Increment field counter
           $(wrapper).append(fieldHTML); //Add field html
       }
   });
   //Once remove button is clicked
   $(wrapper).on('click', '.remove_button', function(e){
       e.preventDefault();
       $(this).parent('div').remove(); //Remove field html
       x--; //Decrement field counter
   });
});
</script>
<script>
@php
  $result = DB::select("select* from client_details ");
  @endphp
  $(document).ready(function() {
  var max_field      = 10; //maximum input boxes allowed
  var wrappers         = $(".promoinput"); //Fields wrapper
  var add_buttons      = $(".promobtn"); //Add button ID
  
  var x = 1; //initlal text box count
  $(add_buttons).click(function(e){ //on add input button click
      e.preventDefault();
      if(x < max_field){ //max input box allowed
          x++; //text box increment
          $(wrappers).append('<div><div class="form-group"><label> Promo Code for Specific Person</label><select class="selectpicker form-control" data-show-subtext="true" name="promoinput[]" data-live-search="true"><option class="form-control"></option>@foreach($result as $results)<option class="form-control" value="{{$results->username}}">{{$results->username}}</option>@endforeach</select></div><a href="#" class="remove_field">Remove</a></div>'); //add input box
      }
  });
  
  $(wrappers).on("click",".remove_field", function(e){ //user click on remove text
      e.preventDefault(); $(this).parent('div').remove(); x--;
  })
});
</script>
 <script>
$(document).ready(function() {
  var max_field_img      = 10; //maximum input boxes allowed
  var wrap_img         = $(".input_field_wrap_img"); //Fields wrapper
  var add_button_img     = $(".add_field_button_img"); //Add button ID
  
  var x = 1; //initlal text box count
  $(add_button_img).click(function(e){ //on add input button click
      e.preventDefault();
      if(x < max_field_img){ //max input box allowed
          x++; //text box increment
          $(wrap_img).append('<div><div class="form-group"><input type="file" name="file[]" class="form-control" onchange="readURL(this);"/><img id="blah" src="{{url('images/demo.png')}}" alt="Product Image" style="width:252px;" /></div><a href="#" class="remove_field">Remove</a></div>'); //add input box
      }
  });
  
  $(wrap_img).on("click",".remove_field", function(e){ //user click on remove text
      e.preventDefault(); $(this).parent('div').remove(); x--;
  })
});


    function slider(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#slider')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

<script>  
$("#maincat").on('change',function(e){

      console.log(e);
      
      var commission = e.target.value;
    //   alert (commission);
    
      $.get('{{URL('/')}}/client/commission?commission='+ commission,function(data){
        console.log(data);
        if(data != 0 )
{
      
    $("#commission").attr("disabled", true);
}
else{
    $("#commission").attr("disabled", false);
}

      });


  });
  </script>

  <script>
$(function() {
  $('input:text').keydown(function(e){
    if(e.keyCode==191)
    return false;
  });
});
</script>
<script >
$(document).ready(function(){
$('.btb').printPage();
});
</script>
  </body>
</html>
