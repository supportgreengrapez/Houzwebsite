@extends('admin.layout.appadmin')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">


            <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Report Management</h3>
            <h4>Houzz Earning</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">

          </div>
          </div>
        </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                  <th>O_ID</th>
                  <th>Total Earning</th>
                  </tr>
                </thead>
                <tbody>

                  @if(count($houzz_earning)>0)
                        @foreach($houzz_earning as $results)
                        <tr>
                          <td>{{$results->pk_id}}</td>
                          <td>{{$results->houzz_earning}}</td>
                  </tr>
                  @endforeach
                        @endif
                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->
</div>
     @endsection
