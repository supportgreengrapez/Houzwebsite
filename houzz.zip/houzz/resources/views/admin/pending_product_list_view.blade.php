@extends('admin.layout.appadmin') 
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }



  </script> 
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Product Management</h3>
          <h4>Product</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12"> </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
          <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog"> 
              
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Status Change</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Update Status</label>
                    <select id="status" name="status" class="form-control">
                      <option>Select status</option>
                      <option value="2">Approved</option>
                      <option value="3">Unapproved</option>
                    </select>
                  </div>
                  <button id="pp" type="submit" class="btn btn-submmit">Submit</button>
                </div>
              </div>
            </div>
          </div>
          <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>SKU</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Categoty</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
            
            @if(count($result)>0)
            @foreach($result as $results)
            <tr>
              <td>{{$results->sku}}</td>
              <td>{{$results->name}}</td>
              <td><div class="sparkbar" data-color="#00a65a" data-height="20">{{$results->price}}</div></td>
              <td>{{$results->category}}</td>
              <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Pending</span></td>
              <td><a href="{{url('/')}}/admin/home/view/pending/products/view/detail/product/{{$results->pk_id}}">View</a></td>
            </tr>
            @endforeach
            @endif
              </tbody>
            
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 