@extends('admin.layout.appadmin')
@section('content')
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Coupon Management</h3>
        <h4 style="display: block;">Add Coupon</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
          <form method="post" action = "{{url('/')}}/admin/home/add/promo" class="login-form" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"> @if($errors->any())
                <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
                @endif
                <div class="row">
                  <div class="form-group">
                    <label>Coupon Code</label>
                    <input type="text" class="form-control" name="promo" placeholder="Coupon Code" required>
                  </div>
                  <div class="form-group">
                    <label>Promo Use Time</label>
                    <input type="text" class="form-control" name="use_time" value="1" placeholder="Promo Use Time" required>
                  </div>
                  <div class="form-group">
                    <label>Discount Type</label>
                    <div class="radio">
                      <label>
                        <input type="radio" value="1" name="radio" checked>
                        Fixed</label>
                    </div>
                    <div class="radio">
                      <label>
                        <input type="radio" value="2" name="radio">
                        Pecentage</label>
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Discount Amount</label>
                    <input type="number" class="form-control" name="discount" placeholder="Discount Amount" required>
                  </div>
                  <div class="form-group">
                    <label>Start Date</label>
                    <input type="date" class="form-control" name="start_date" placeholder="Start Date" required>
                  </div>
                  <div class="form-group">
                    <label>End Date</label>
                    <input type="date" class="form-control" name="end_date" placeholder="End Date" required>
                  </div>
                  <div class="form-group">
                    <label>Min Sub Total</label>
                    <input type="number" class="form-control" name="min" placeholder="Min Sub Total">
                  </div>
                  <div class="form-group">
                    <label>Max Sub Total</label>
                    <input type="number" class="form-control" name="max" placeholder="Max Sub Total">
                  </div>
                  <div class="form-group">
                    <label>Promo Code for Specific Person</label>
                    <div class="promoinput">
                      <select class="selectpicker form-control" data-show-subtext="true" name="promoinput[]"  data-live-search="true">
                        
                        <option value=""> Select User Mail</option>
                        <option value="All Customer">All Customer</option>
                            
                          
                  @if(count($result)>0)
                        @foreach($result as $results )
        
                          
                            
                            
                        <option  class="form-control"  value="{{$results->username}}" >{{$results->username}}</option>
                        
                            
                            
                          
           @endforeach
                  @endif
       
      
                        
                          
                          
                      </select>
                    </div>
                    <button class="promobtn btn btn-success">Add More Fields</button>
                    <br>
                    <br>
                    <label>Promo Code for Specific Category</label>
                    <select class="selectpicker form-control" data-show-subtext="true" name="category" id=""  data-live-search="true">
                      <option value=""> Select Category</option>
                      
                          
                          
                        
                  @if(count($result1)>0)
                        @foreach($result1 as $results )
        
                        
                          
                          
                      <option  class="form-control"  value="{{$results->sub_category}}" >{{$results->sub_category}}</option>
                      
                          
                          
                        
           @endforeach
                  @endif
                        
                        
                    </select>
                    </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-12 col-xs-12">
                <div class="togglebutn">
                  <div id="wrapper">
                    <p>In Active?</p>
                    <div id="check">
                      <input type="checkbox" id="ch" name="status">
                      <div id="cadre"></div>
                      <div id="bulle"></div>
                    </div>
                  </div>
                </div>
              </div>
            
            </div>
            <div class="row">
            <div class="col-md-12">
              <button type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
            </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection