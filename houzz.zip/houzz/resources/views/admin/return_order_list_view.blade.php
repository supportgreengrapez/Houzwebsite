@extends('admin.layout.appadmin') 
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }



  </script> 
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Customer Management</h3>
          <h4>Order Management</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12"> </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-6 mt-20">
      <div class="row form-group">
      <form method="post" action = "{{url('/')}}/admin/home/search/by/order/id" class="login-form">
        {{ csrf_field() }}
        <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by order Id :</label>
        <div class="col-lg-5 col-sm-12 col-xs-12">
          <input type="text" name="search" class="form-control" id="inputPassword" placeholder="1234-1234-">
        </div>
        <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
          <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
        </div>
        </div>
      </form>
    </div>
  </div>
  <form method="post" action = "{{url('/')}}/admin/home/search/by/order/status" class="login-form">
    {{ csrf_field() }}
    <div class="row">
      <div class="col-lg-4 mt-20">
        <div class="row form-group">
          <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">Filter by Order Status :</label>
          <div class="col-lg-7 col-sm-12 col-xs-12">
            <select class="form-control" name="order_status">
              <option value="5">All</option>
              <option value="0">Processing</option>
              <option value="1">On Hold</option>
              <option value="2">Shipped Product</option>
              <option value="3">Return</option>
              <option value="4">Cancel</option>
            </select>
          </div>
        </div>
      </div>
      <div class="col-lg-2 mt-20">
        <div class="row form-group">
          <label  class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">Date range :</label>
        </div>
      </div>
      <div class="col-lg-3 mt-20">
        <div class="row form-group">
          <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">From</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="date" name="from" class="form-control">
          </div>
        </div>
      </div>
      <div class="col-lg-3 mt-20">
        <div class="row form-group">
          <label  class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">To</label>
          <div class="col-lg-8 col-sm-12 col-xs-12">
            <input type="date" name="to" class="form-control">
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-3 ccol-sm-6 col-xs-6 mt-20">
        <button type="submit" class="btn btnsubmit" style="width: 80% !important;">Filter Results</button>
      </div>
    </div>
  </form>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <div id="myModal" class="modal fade" role="dialog">
          <div class="modal-dialog"> 
            
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Status Change</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Update Status</label>
                  <select id="status" name="status" class="form-control">
                    <option>Select status</option>
                    <option value="3">Confirmed</option>
                    <option value="2">Shipped Product</option>
                  </select>
                </div>
                <button id="return" type="button" class="btn btn-submmit">Submit</button>
              </div>
            </div>
          </div>
        </div>
        <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>O_ID</th>
              <th>Customer Name</th>
              <th>Phone</th>
              <th>Amount</th>
              <th> Date</th>
              <th> Reason</th>
              <th>Status </th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          
          @if(count($result)>0)
          @foreach($result as $results)
          <tr>
            <td>{{$results->pk_id}}</td>
            <td>{{$results->fname}} {{$results->lname}}</td>
            <td>{{$results->phone}}</td>
            @if($results->promo_amount == "")
            <td><div class="sparkbar" data-color="#00a65a" data-height="20">PKR {{number_format($results->amount)}}</div></td>
            @else
            <td><div class="sparkbar" data-color="#00a65a" data-height="20">PKR {{number_format($results->promo_amount)}}</div></td>
            @endif
            <td>{{$results->date}}</td>
            <td>{{$results->reason}}</td>
            @if($results->return_status == 2)
            <td><span class="label label-primary">Return Confirmed</span></td>
            @elseif($results->return_status == 3)
            <td><span id="{{$results->order_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Return</span></td>
            @endif
            <td><a href="{{url('/')}}/admin/home/view/return/order/view/specific/order/{{$results->pk_id}}">View</a></td>
          </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 