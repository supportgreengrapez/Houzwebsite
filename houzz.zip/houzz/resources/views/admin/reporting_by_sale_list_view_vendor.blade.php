@extends('admin.layout.appadmin') 
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Reporting Management</h3>
        <h4>By Sale Vendor</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
          <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>Payment Id</th>
                <th>Vendor Name</th>
                <th>Email</th>
                <th>Total Earning</th>
                <th>Amount Pay</th>
                <th>Remaining</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
            
            @if($result>0)
            @foreach($result as $results)
            <tr>
              <td>{{$results->payment_id}}</td>
              <td>{{$results->fname}}  {{$results->lname}}</td>
              <td>{{$results->username}}</td>
              <td>PKR {{number_format($results->total_earned)}}</td>
              <td>PKR {{number_format($results->payment)}}</td>
              <td>PKR {{number_format($results->remaining)}}</td>
              <td>{{$results->created_at}}</td>
              <td>
                  @if($results->remaining =="0")
                  <a href="{{url('/')}}/admin/home/print/invoice/view/{{$results->payment_id}}">Print Invoice</a> 
              
                  
                  @else
                  <a href="{{url('/')}}/admin/home/create/payment/view/{{$results->payment_id}}">Create Payment</a> <br> <a href="{{url('/')}}/admin/home/print/invoice/view/{{$results->payment_id}}">Print Invoice</a> 
              
              @endif
              </td>
            </tr>
            @endforeach
            @endif
              </tbody>
            
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 