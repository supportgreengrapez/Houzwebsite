@extends('admin.layout.appadmin')
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Order Management</h3>
          <h4>Order Detail</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12"> </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table  class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>SKU</th>
              <th>Product Name</th>
              <th>Image</th>
              <th>Total Price</th>
              <th>Discounted Price</th>
              <th>Discount</th>
              <th> Size</th>
              <th>Quantity</th>
              <th>Vendor</th>
              <th>Order Status</th>
            </tr>
          </thead>
          <tbody>
          
          @if(count($result1)>0)
          @foreach($result1 as $results)
          @php 
          $product = DB::select("select* from product where pk_id ='$results->product_id'");
          $seller = DB::select("select* from client_details where pk_id ='$results->vendor_id' and customer_type='seller'");
          @endphp
          <tr>
            <td>{{$results->sku}}</td>
            <td><a href="{{url('/')}}/admin/home/view/product/{{$product[0]->pk_id}}">{{$results->product_name}}</a></td>
            @if(count($product)>0)
            <td><a href="{{url('/')}}/admin/home/view/product/{{$product[0]->pk_id}}"><img src="{{url('/')}}/storage/images/{{$product[0]->thumbnail}}"></a></td>
            @else
            <td> ---</td>
            @endif
            <td>{{number_format($results->price)}}</td>
            @if(empty($results->discount_price))
            <td> ---</td>
            @else
            <td>{{$results->discount_price}}</td>
            @endif
            @if($results->percentage > 0)
            <td>{{$results->percentage}}%</td>
            @else
            <td> ---</td>
            @endif
            <td>{{$results->size}}</td>
            <td>{{$results->quantity}}</td>
            @if(count($seller)>0)
            <td><a href="{{url('/')}}/admin/home/view/vendor/{{$seller[0]->pk_id}}">{{$seller[0]->fname}} {{$seller[0]->lname}}</a></td>
            @else
            <td> ---</td>
            @endif
            
            @if($results->v_order_status == 0)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Processing</span></td>
            @elseif($results->v_order_status == 1)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">On Hold</span></td>
            @elseif($results->v_order_status == 2)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Shipped Product</span></td>
            @elseif($results->v_order_status == 3)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Return</span></td>
            @elseif($results->v_order_status == 4)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Cancel</span></td>
            @endif </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      <div class="title_left">
        <a href="{{url('/')}}/admin/home/print_invoice/{{$id}}" target="_blank" class="btn btn-success">Print Invoice</a>
      </div>
    </div>
    @if(count($result)>0)
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Order ID</h4>
          </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$id}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Tracking ID</h4>
          </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->tracking_id}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Customer Name</h4>
          </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->fname}} {{$result[0]->lname}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Amount</h4>
          </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>PKR {{number_format($result[0]->amount)}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Shipment</h4>
          </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->address}}</p>
          </div>
        </div>
      </div>
    </div>
    @endif </div>
</div>
<!-- /page content --> 

@endsection 