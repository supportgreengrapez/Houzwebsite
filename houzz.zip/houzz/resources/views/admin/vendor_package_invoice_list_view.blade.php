@extends('admin.layout.appadmin') 
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }

  </script> 
@section('content')
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog"> 
    
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Status Change</h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>Update Status</label>
          <select id="status" name="status" class="form-control">
            <option>Select status</option>
            <option value="1">Approved</option>
            <option value="2">Pending</option>
            <option value="3">Rejected</option>
          </select>
        </div>
        <button id="update_invoice" type="button" class="btn btn-submmit">Submit</button>
      </div>
    </div>
  </div>
</div>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Seller Management</h3>
        <h4>Package Invoice List</h4>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-6 mt-20">
      <div class="row form-group">
        <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
        <div class="col-lg-5 col-sm-12 col-xs-12">
          <input type="password" class="form-control" id="inputPassword" placeholder="1234-1234-">
        </div>
        <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
          <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
        </div>
      </div>
    </div>
    <div class="col-lg-6 mt-20">
      <div class="row form-group">
        <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Type :</label>
        <div class="col-lg-5 col-sm-12 col-xs-12">
          <input type="password" class="form-control" placeholder="1234-1234-">
        </div>
        <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
          <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>Invoice No</th>
              <th>Package Name</th>
              <th>Bill From</th>
              <th>Date </th>
              <th>Expiry Date </th>
              <th>Packages </th>
              <th>Amount</th>
              <th>Status </th>
              <th>Print</th>
            </tr>
          </thead>
          <tbody>
          
          @if(count($result)>0)
          @foreach($result as $results)
          <tr>
            <td>{{$results->invoice_no}}</td>
            <td>{{$results->package_name}}</td>
            @php
            
            $vendor = DB::select("select* from client_details where pk_id = '$results->vendor_id' ");
            @endphp
            <td>{{$vendor[0]->fname}} {{$vendor[0]->lname}}</td>
            <td>{{$results->created_at}}</td>
            <td>{{$results->expiry_date}}</td>
            <td>{{$results->subscription}}</td>
            <td>{{number_format($results->amount)}}</td>
            @if($results->status == 0)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Submitted</span></td>
            @elseif($results->status == 1)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Approved</span></td>
            @elseif($results->status == 2)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-info" data-toggle="modal" data-target="#myModal">Pending</span></td>
            @elseif($results->status == 3)
            <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-danger" data-toggle="modal" data-target="#myModal">Rejected</span></td>
            @endif 
            
            <td><a href="{{URL('/')}}/printinvoice/{{$results->pk_id}}">Print Invoice</a></td>
            </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 