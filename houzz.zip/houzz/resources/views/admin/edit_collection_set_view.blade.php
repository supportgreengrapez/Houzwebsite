@extends('admin.layout.appadmin')
@section('content') 
    @if(count($result1)>0)
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Product Management</h3>
            <h4 style="display:block;">Manage Collection</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          <form method="post" action = "{{url('/')}}/admin/edit/collection/{{$result1[0]->pk_id}}" class="login-form" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        @if($errors->any())

<div class="alert alert-danger">
  <strong></strong> {{$errors->first()}}
</div>
@endif
              <div class="x_content">
                      <div class="form-group">
                        <label>Choose Collection</label>
                        <select class="form-control" name="category">
                          @if(count($result)>0)
                    @foreach($result as $results)
                           <option value="{{$results->pk_id}}" @if($result1[0]->pk_id == $results->pk_id ) selected @endif >{{$results->collection_name}}</option>
                           @endforeach
           @endif
                        </select>
                      </div>
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                <div class="form-group">
                        <label>SKU</label>
                        <select  class="js-example-tokenizer form-control" name="sku[]" multiple="multiple" required>
                                                   @if(count($result1)>0)
                 @php
                 $array = [];
                 $str = $result1[0]->products;
    $tok = strtok($str, ",");


    $skillset =$tok;
   $array = array_wrap($skillset);

    while ($tok !== false) {
        $tok = strtok(",");

       if(is_string($tok))
       $skillset= $tok;
     //  $array = array_prepend($array, $skillset);
     array_push($array, $skillset);

    }
    array_pop($array);
                 @endphp
                  @if(count($array)>0) 
                  
                  @if(count($product)>0)
                    @foreach($product as $products)
                    
                   
                  
               
                           <option value="{{$products->pk_id}}"  @foreach($array as $arrays) @if($products->pk_id == $arrays) selected @endif  @endforeach>{{$products->name}}</option>
                    
                
                        @endforeach
                      @endif
                      
                      @else
                        
                  @if(count($product)>0)
                    @foreach($product as $products)
                     <option value="{{$products->pk_id}} @if($products->pk_id == $arrays) selected @endif">{{$products->name}}</option>
                      @endforeach
                      @endif
                      @endif
           @endif
                    </select>
                </div>
      
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                                
                <div class="col-md-6">
                        <button type="submit" class="btn btn-success btn-lg">Edit Collection</button>
                        
                </div>
              </div>
              </form>
          </div>
          
         
        </div>
        <div class="clearfix"></div>
        
      </div>
    </div>
    @endif
    <!-- /page content --> 
@endsection