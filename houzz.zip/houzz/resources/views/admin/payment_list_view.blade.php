@extends('admin.layout.appadmin')
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }

  </script>
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Order Management</h3>
            <h4>Payments</h4>
          </div>
          </div>
     
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                   <div id="myModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Status Change</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Update Status</label>
                                    <select id="status" name="status" class="form-control">
                                        <option>Select status</option>
                                        <option value="0">Submitted</option>
                                        <option value="1">Approved</option>
                                        <option value="2">Rejected</option>
                                        <option value="3">Pending</option>
                            
                                    </select>
                             </div>
                             <button id="payment" type="button" class="btn btn-submmit">Submit</button>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </div>

                        </div>
                      </div>
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>Invoice No</th>
                  <th>Payment Receipt</th>
                  <th>Payee</th>
                  <th>Payer</th>
                  <th>Date </th>
                  <th>Amount</th>
                  <th>Status </th>
                    </tr>
                  </thead>
                  <tbody>

                  @if(count($result)>0)
                    @foreach($result as $results)
                    <tr>
                    <td>{{$results->invoice_no}}</td>
                    <td><img src="{{url('/')}}/storage/images/{{$results->thumbnail}}" alt="img"></td>
                    <td>{{$results->payee}}</td>
                    <td>{{$results->payer}}</td>
                    <td>{{$results->date}}</td>
                    <td>PKR {{number_format($results->amount)}}</td>

                            @if($results->status == 0)
                          <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Submitted</span></td>
                          @elseif($results->status == 1)
                          <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Approved</span></td>
                          @elseif($results->status == 2)
                          <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Rejected</span></td>
                          @else
                          <td><span id="{{$results->pk_id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Pending</span></td>
                          @endif
                   
                    </tr>
                    @endforeach
                    @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

    @endsection
 
