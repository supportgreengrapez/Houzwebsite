@extends('admin.layout.appadmin')

@section('content')
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management</h3>
        <h4 style="display: block;">Add Product</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <form method="post" action = "{{url('/')}}/admin/home/add/product" class="login-form" enctype="multipart/form-data">
          {{ csrf_field() }}
          @if($errors->any())
          <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
          @endif
          <div class="x_content">
            <div class="row">
              <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>About this Item</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Product Name" maxlength="100" required>
                  </div>
                  <div class="form-group">
                    <label>Product Description</label>
                    <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" maxlength="1000"></textarea>
                  </div>
                  <div class="form-group" >
                    <label>Category Name</label>
                    <select class="form-control" name="mainCategory" id="mainCategory" required>
                      <option value="" disable="true" selected="true" >---Select Category---</option>
                      
                      
                      
                      
                      
                        @if($result2>0)
                    @foreach($result2 as $results)
                            
                      
                      
                      
                      
                      <option value="{{urlencode($results->main_category)}}">{{$results->main_category}}</option>
                      
                      
                      
                      
                      
                            @endforeach
                            @endif

                        
                    
                    
                    
                    
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Category Type</label>
                    <select class="form-control" name="SubCategory" id="SubCategory">
                      <option value="" disable="true" selected="true" >---Select Sub Category---</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Product Type</label>
                    <select class="form-control" name="ProductType"  id="ProductType">
                      <option value="" disable="true" selected="true" >---Select Product Type---</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Brand Name</label>
                    <select class="form-control" name="BrandName">
                      
                      
                      
                      
                      
                        @if($result1>0)
                        @foreach($result1 as $results)

                                         
                      
                      
                      
                      
                      <option value="{{$results->brand_name}}">{{$results->brand_name}}</option>
                      
                      
                      
                      
                      
                         @endforeach
                         @endif
                        
                    
                    
                    
                    
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Product Tags</label>
                    <select  class="js-example-tokenizer form-control" name="tags[]" multiple="multiple" required>
                      <option value="">Write Tags</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-12 col-xs-12">
                <div class="togglebutn">
                  <div id="wrapper">
                    <p>In Active?</p>
                    <div id="check">
                      <input type="checkbox" id="ch" name="status">
                      <div id="cadre"></div>
                      <div id="bulle"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Pricing</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>SKU</label>
                    <input type="text" class="form-control" name="sku" placeholder="Sku" maxlength="50" required>
                  </div>
                </div>
                <div class="row"> </div>
                <div class="row">
                  <div class="form-group">
                    <label>Pricing</label>
                    <input type="number" class="form-control" name="price" placeholder="Pricing" maxlength="50" required>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Detail</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Material</label>
                    <select class="form-control" name="material">
                      
                      
                      
                      
                      

                        @if($material>0)
                                 @foreach($material as $results)

                                         
                      
                      
                      
                      
                      <option value="{{$results->material}}">{{$results->material}}</option>
                      
                      
                      
                      
                      
                                         @endforeach
                         @endif
                        
                    
                    
                    
                    
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Style</label>
                    <select class="form-control" name="style">
                      
                      
                      
                      
                      

                     @if($style>0)
                              @foreach($style as $results)

                                      
                      
                      
                      
                      
                      <option value="{{$results->style}}">{{$results->style}}</option>
                      
                      
                      
                      
                      
                                      @endforeach
                      @endif
                     
                    
                    
                    
                    
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Color</label>
                    <div class="input-group my-colorpicker2 colorpicker-element">
                      <input type="text" name = "_color" class="form-control">
                      <div class="input-group-addon"> <i style="background-color: rgb(0, 0, 0);"></i> </div>
                    </div>
                    <!-- /.input group --> 
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Unit</label>
                    <select class="form-control" name="unit">
                      <option value="Feet">Feet</option>
                      <option value="Meter">Meter</option>
                      <option value="Yard">Yard</option>
                      <option value="inchs">Inches</option>
                      <option value="Centimeter">Centimeter</option>
                      <option value="Kilogram">Kilogram</option>
                      <option value="Gram">Gram</option>
                      <option value="Litre">Litre</option>
                      <option value="Mililitre">Mililitre</option>
                      <option value="Watt">Watt</option>
                      <option value="Volt-ampere">Volt-ampere</option>
                      <option value="Horse-power">Horse-power</option>
                      <option value="Cubic centimeter">Cubic centimeter</option>
                      <option value="Radian">Radian</option>
                      <option value="Degree">Degree</option>
                      <option value="Bit">Bit</option>
                      <option value="Byte">Byte</option>
                      <option value="Kilobyte">Kilobyte</option>
                      <option value="Megabyte">Megabyte</option>
                      <option value="GigaByte">GigaByte</option>
                      <option value="Terabyte">Terabyte</option>
                      <option value="Pixel">Pixel</option>
                      <option value="Density per pixel">Density per pixel</option>
                      <option value="pieces">Pieces</option>
                      <option value="packs">Packs</option>
                      <option value="pairs">Pairs</option>
                      <option value="dozen">Dozen</option>
                      <option value="Vol">Vol</option>
                      <option value="percent">Percent</option>
                    </select>
                  </div>
                </div>
                <div class="input_field_wrap">
                  <div class="row">
                      
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Quantity in Hand</label>
                        <input type="text" class="form-control" name="mytextt[]" placeholder="Quantity in Hand"  value="1" min="1" required>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="text">Size</label>
                        <input type="text" value="" name="mytextt[]" class="form-control" placeholder="Size" required>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <button class="add_fields_button btn btn-success"><i class="fa fa-plus"></i> Add More Size</button>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Urgent Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Charges</label>
                    <input type="number" name ="urgent_charges" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" name ="urgent_time" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Express Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Charges</label>
                    <input type="number" name ="express_charges" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" name ="express_time" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Normal Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Charges</label>
                    <input type="number" name ="normal_charges" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" name ="normal_time" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Free Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" name ="free_delivery" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Add Return/Refund Policy</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <textarea class="form-control" name="return_policy" rows="9"></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="page-title">
                <h5><b>Images</b></h5>
              </div>
              <div class="col-lg-12">
                <div class="alert alert-info"> <strong>Info!</strong> Please Upload 500*500 pixel image. </div>
                <div class="row">
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                    <img id="blah" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images2" class="form-control" onchange="preview_image(this);"/>
                    <img id="blah2" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images3" class="form-control" onchange="preview_img(this);"/>
                    <img id="blah3" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images4" class="form-control" onchange="preview_imgs(this);"/>
                    <img id="blah4" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images5" class="form-control" onchange="preview_img5(this);"/>
                    <img id="blah5" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images6" class="form-control" onchange="preview_img6(this);"/>
                    <img id="blah6" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images7" class="form-control" onchange="preview_img7(this);"/>
                    <img id="blah7" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="col-md-6 pull-right">
              <button id="send" type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection 