@extends('admin.layout.appadmin') 
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }
  </script> 
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Seller Management</h3>
          <h4>Seller</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
        <div class="title_left"> <a href="{{url('/')}}/admin/home/create/seller" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Seller</a> </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <div id="myModal" class="modal fade" role="dialog">
          <div class="modal-dialog"> 
            
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Status Change</h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label>Update Status</label>
                  <select id="status" name="status" class="form-control">
                    <option>Select status</option>
                    <option value="0">Active</option>
                    <option value="1">Blocked</option>
                  </select>
                </div>
                <button id="button_1" type="button" class="btn btn-submmit">Submit</button>
              </div>
            </div>
          </div>
        </div>
        <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Account Type</th>
              <th>Category</th>
              <th>CNIC</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          
          @if($result>0)
          @foreach($result as $results)
          <tr>
            <td>{{$results->fname}} {{$results->lname}}</td>
            <td>{{$results->username}}</td>
            
            <td>{{$results->account_t}}</td>
          @if($results->account_t == "Business")
            <td>{{$results->vendor_cat}}</td>
          @else
          
          <td>----</td>
          @endif
          @if($results->account_t == "Individual")
            <td>{{$results->cnic}}</td>
          @else
          
          <td>----</td>
          @endif
            @php
            $user_id = $results->pk_id;
            $status = DB::select("select* from vendors where user_id ='$user_id'");
            
            @endphp
            @if($status[0]->vendor_status == 1)
            <td><span id="{{$status[0]->id}}" onclick="getId(this.id)" class="label label-danger" data-toggle="modal" data-target="#myModal">Blocked</span></td>
            @elseif($status[0]->vendor_status == 0)
            <td><span id="{{$status[0]->id}}" onclick="getId(this.id)" class="label label-success" data-toggle="modal" data-target="#myModal">Active</span></td>
            @else
            <td><span id="{{$status[0]->id}}" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Pending</span></td>
            @endif
            <td><a href="{{url('/')}}/admin/home/view/vendor/{{$results->pk_id}}" class="green">View</a></td>
          </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 