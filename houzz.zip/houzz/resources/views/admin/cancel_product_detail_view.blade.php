@extends('admin.layout.appadmin')
@section('content')

     <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
          Product Detail view
          </h1>
                  </section>

        <!-- Main content -->
        <section class="content">
          <!-- Info boxes -->
          <div class="row">			 
            <!-- fix for small devices only -->
            <div class="clearfix visible-sm-block"></div>
          </div><!-- /.row -->

          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <div class="col-md-12">
              <!-- TABLE: LATEST ORDERS -->
              <div class="box box-info">
                <div class="box-header with-border table-responsive">
                  
                <div class="box-body">
                         <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
  
      
    </div>
  </div>
  <div class="row">
                 <div class="productbox">
                     @if(count($result)>0)
                     @foreach($result as $results)
        <div class=" col-md-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                    <div itemscope="">
                                        <h2> <span itemprop="name"></span></h2>
                                        <p>SKU</p>
                                        <p>Name</p>
                                        <p> Price</p>
                                        <p> color</p>
                                        <p>Category</p>
                                        <p>Sub Category</p>
                                        <p>Product Type</p>
                                        <p>Brand Name</p>
                                        <p>Size</p>
                                              <p>Unit</p>
                                        <p>Discription</p>
                                        
                                        
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-6">
                                    <div itemscope="">
                                    	<h2><span></span></h2>
                                        <p>{{$results->sku}}</p>
                                        <p>{{$results->name}}</p>
                                        <p>{{$results->price}}</p>
                                        <p>{{$results->color}}</p>
                                        <p>{{$results->category}}</p>
                                        <p>{{$results->sub_category}}</p>
                               			<p>{{$results->product_type}}</p>
                                        <p>{{$results->brand_name}}</p>
                                        <p>{{$results->size}}</p>
                                            <p>{{$results->unit}}</p>
                                    
                            
                                        
                                       <div class="form-group">
  <p>{{$results->description}}</p>
</div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        <div class=" col-md-6">
        <form>
        	<label for="text">Image</label>
     
        <img id="blah" src="{{URL('/')}}/storage/images/{{$result[0]->thumbnail}}" alt="your image" />
                <img id="blah" src="{{URL('/')}}/storage/images/{{$result[0]->thumbnail2}}" alt="your image" />
              <img id="blah" src="{{URL('/')}}/storage/images/{{$result[0]->thumbnail3}}" alt="your image" />
        </form>
        @endforeach
        @endif
        <br><br>

        @if(count($result1)>0)
        @foreach($result1 as $results)

            <div class="panel panel-default">
            <h3 style="text-align:center; color:#ab0f23;">Busniess Information</h3>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="row">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                    <div itemscope="">
                                        <h2> <span itemprop="name"></span></h2>
                                        <p>Full Name</p>

                                        <p> Store Name</p>
                                        <p>Email</p>
                                        
                                        <p>Phone</p>
                                        <p>City</p>
                                        
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-6">
                                    <div itemscope="">
                                    	<h2><span></span></h2>
                                        <p>{{$results->fname}}  {{$results->lname}}</p>
                                
                                        <p>{{$results->store_name}}</p>
                                        <p>{{$results->email}}</p>
                                        <p>{{$results->phone}}</p>
                                        <p>{{$results->city}}</p>
                          
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            @endforeach
            @endif
            
        </div>
       
    </div>
    </div>
                    <!-- /.table-responsive -->
                </div><!-- /.box-body -->
               
                </div><!-- /.box-header -->
                <!-- /.box-footer -->
                <!-- /.box-footer add button next/previus
                
               
                
                
                 -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->

     @endsection