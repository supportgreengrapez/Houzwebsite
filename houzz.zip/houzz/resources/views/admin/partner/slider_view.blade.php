 
@extends('admin.layout.appadmin')
@section('content')



   <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Partner Management</h3>
            <h4 style="display:block;">Slider View</h4>
        </div>
      </div>
      <div class="wrap">
      @php $images = array(); $images = explode(',',  $data[0]->slider_image);   @endphp
      <div class="page-title">
            <h4><b>Slider Image</b></h4>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>First Image</label><br>
      @if(isset($images[0]) && !empty($images))
            <img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[0];  @endphp" alt="img">
        @else
            <img src="images/2.png" alt="img">

        @endif

           </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>Second Image</label><br>
          @if(isset($images[1]) && !empty($images))
            <img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[0];  @endphp" alt="img">
            @else
            <img src="images/2.png" alt="img">

            @endif
           </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>Third Image</label><br>
            @if(isset($images[2]) && !empty($images))
            <img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[2];  @endphp" alt="img">
               @else
            <img src="images/2.png" alt="img">
            @endif
           </div>
        </div>
      </div>


      </div>
    </div>

 @endsection