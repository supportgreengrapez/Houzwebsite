@extends('admin.layout.appadmin')
@section('content')

    
    <!-- page content -->
                         @if (Session::has('success'))
      
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <h4 class="alert-heading">Success!</h4>
        <p>{{ Session::get('success') }}</p>

        <button type="button" class="close" data-dismiss="alert aria-label="Close>
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">


          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">


           <h3>Partner Management</h3>
            <h4>Partner List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{url('admin/create-partner')}}" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Partner</a>
          </div>
          </div>
        </div>
        <div class="clearfix"></div>
       
        <div class="row">
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
         <form action="{{url('admin-partner-search-name')}}" method="POST">
          @csrf
            <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Name:</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="text" class="form-control"  name="name" value="">
              <input type="hidden" class="form-control" value="" name="category">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </form>
          </div>
        </div>


   
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
          <form action="{{url('admin-partner-search-category')}}" method="POST">
            @csrf
            <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Category:</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="text" class="form-control" placeholder="1234-1234-" value="" name="category">
              <input type="hidden" class="form-control" placeholder="1234-1234-" value="" name="name">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </form>
          </div>
        </div>
       
      </div>
      <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Category</th>
             
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
    
                      @if(!empty($data))
                      @foreach($data as $val)
                      <td>{{$val->id}}</td>
                      <td>{{$val->business_name}}</td>
                      <td>{{$val->email}}m</td>
                      <td>{{$val->category_name}}</td>
               
                      <td>
                      <a href="{{url('admin/partner-view/'.$val->id)}}">View</a>
                      <a href="{{url('admin/partner-edit/'.$val->id)}}">Edit</a>
                      <a href="{{url('admin/partner-delete/'.$val->id)}}" class="red">Delete</a>
                      <a href="{{url('admin/add-partner-product/'.$val->id)}}" class="green">Add product</a>
                      </td>
                    </tr>
                      @endforeach
                      @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
    <!-- footer content -->
    <footer>
      <div class=""> Copyright © 2017-2018 Houzz.com. All rights reserved. </div>
      <div class="pull-right"> Powered By <a href="https://greengrapez.com">Green Grapez <img src="images/greengrapez.png" alt="green grapez" style="width:5%;"></a> </div>
      
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content --> 
  </div>
</div>

@endsection