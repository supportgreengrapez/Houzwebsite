@extends('admin.layout.appadmin')
@section('content')


  <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Partner Management</h3>
            <h4>Partner Slider List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{route('add.slider.image')}}" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Partner Slider Icon</a>
          </div>
          </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Slider Image 1</th>
                      <th>Slider Image 2</th>
                      <th>Slider Image 3</th>
                      <th>Slider Image 4</th>
                      <th>Date</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
          
                    @if(isset($data) && !empty($data[0]))
                    @foreach($data as $value)
                    <tr>
                 
                      <td>{{$value->id}}</td>

                      @php $images = array(); $images = explode(',',  $value->slider_image);   @endphp
                      @if(isset($images[0]) && !empty($images))

        
                      <td><img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[0];  @endphp" alt="icon" style="width:50px;height:50px;"></td>



                      @else
                       <td><img src="images/2.png" alt="icon" style="width:50px;height:50px;"></td>
                      @endif




                         @if(isset($images[1]) && !empty($images))
                      <td><img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[1];  @endphp" alt="icon" style="width:50px;height:50px;"></td>

                      @else
                       <td><img src="images/2.png" alt="icon" style="width:50px;height:50px;"></td>
                      @endif

                         @if(isset($images[2]) && !empty($images))
                      <td><img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[2];  @endphp" alt="icon" style="width:50px;height:50px;"></td>

                      @else
                       <td><img src="images/2.png" alt="icon" style="width:50px;height:50px;"></td>
                      @endif

                       @if(isset($images[3]) && !empty($images))
                      <td><img src="{{url('assets/admin/partner_slider/')}}@php echo '/'; echo $images[3];  @endphp" alt="icon" style="width:50px;height:50px;"></td>

                      @else
                       <td><img src="images/2.png" alt="icon" style="width:50px;height:50px;"></td>
                      @endif

                     
                      
                      <td>{{$value->created_at}}</td>
                      <td>
                      <a href="edit_partner_slider.html">Edit</a>
                      <a href="{{url('admin/slider-image-delete/').'/'.$value->id}}" class="red">Delete</a>
                      
                      <a href="{{url('admin/slider-image-view/').'/'.$value->id}}" class="green">View</a>
                      </td>
                    </tr>
                    @endforeach
                    @endif
                    
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>


@endsection