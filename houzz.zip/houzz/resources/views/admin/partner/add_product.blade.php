@extends('admin.layout.appadmin')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Product Management</h3>
            <h4 style="display: block;">Add Product</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
              <div class="row">
              <div class="col-md-3 col-sm-12 col-xs-12">
              <div class="page-title">
                        <h5><b>About this Item</b></h5>
                </div>
                </div>

                <form action="{{route('add.product.post')}}"  method="POST" enctype="multipart/form-data">
                	@csrf
                	<input type="hidden" name="partner_id" value="{{request()->segment(count(request()->segments()))}}">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                      <div class="form-group">
                        <label>Product Name</label>
                        <input type="text" class="form-control" name="name" placeholder="Product Name" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      <div class="form-group">
                        <label>Product Description</label>
                        <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000"></textarea>
                      </div>
                       
                      <div class="form-group">
                        <label>Category Name</label>
                        <select class="form-control" name="category_id">
                        <option value="">Select Category</option>
                        @if(isset($main_category) && !empty($main_category))
                        @foreach($main_category as $value)
                    
                        <option value="{{$value->SKU}}">{{$value->main_category}}</option>
                  		@endforeach
                        @endif
                        </select>
                      </div>
                      
                      <div class="form-group">
                        <label>Sub Category</label>
                        <select class="form-control" name="sub_category_id">
                          @if(isset($sub_category) && !empty($sub_category))
                        @foreach($sub_category as $value)
                    
                        <option value="{{$value->SKU}}">{{$value->sub_category}}</option>
                      @endforeach
                        @endif
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Product Type</label>
                          <select class="form-control" name="product_type_id">
                           @if(isset($product_type) && !empty($product_type))
                        @foreach($product_type as $value)
                    
                        <option value="{{$value->pk_id}}">{{$value->product_type}}</option>
                      @endforeach
                        @endif
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Brand Name</label>
                         <select class="form-control" name="brand_name_id">
                        @if(isset($brand) && !empty($brand))
                        @foreach($brand as $value)
                    
                        <option value="{{$value->SKU}}">{{$value->brand_name}}</option>
                      @endforeach
                        @endif
                        </select>
                      </div>
                      
                    </div>
                </div>
                <div class="col-lg-3 col-sm-12 col-xs-12">
        <div class="togglebutn">
        <div id="wrapper">
		<p>In Active?</p>
		<div id="check">
			<input type="checkbox" name="status" id="ch">
			<div id="cadre"></div>
			<div id="bulle"></div>
		</div>
	</div>
        </div>
      </div>
      </div>
      
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                        <h5><b>Pricing</b></h5>
                </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                      <div class="form-group">
                        <label>SKU</label>
                        <input type="text" class="form-control" name="sku" placeholder="Sku" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      </div>
                      <div class="row">
                      <div class="form-group">
                        <label>Quantity in Hand</label>
                        <input type="text" class="form-control" name="qty" placeholder="Quantity in Hand" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      </div>
                      <div class="row">
                      <div class="form-group">
                        <label>Pricing</label>
                        <input type="number" class="form-control" name="price" placeholder="Pricing" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                    </div>
                </div>
                </div>
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                
                <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                        <h5><b>Detail</b></h5>
                </div>
                </div>
          
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="row">
                      <div class="form-group">

                        <label>Material</label>
                           <select class="form-control" name="material_id">
                        @if(isset($material) && !empty($material))
                        @foreach($material as $value)
                    
                        <option value="{{$value->pk_id}}">{{$value->material}}</option>
                      @endforeach
                        @endif
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Style</label>
                           <select class="form-control" name="style_id">
                         @if(isset($style) && !empty($style))
                        @foreach($style as $value)
                    
                        <option value="{{$value->pk_id}}">{{$value->style}}</option>
                      @endforeach
                        @endif
                        </select>
                      </div>
                      <div class="form-group">
                      <label>Color</label>
                        <div class="input-group my-colorpicker2 colorpicker-element">
                          <input type="text" name="color" class="form-control">
                          <div class="input-group-addon"> <i style="background-color: rgb(0, 0, 0);"></i> </div>
                        </div>
                        <!-- /.input group --> 
                      </div>
                      </div>
                      <div class="row">
                      <div class="form-group">
                        <label>Unit</label>
                        <select class="form-control" name="">
                        <option value="unit1">Unit 1</option>
                        <option value="unit2">Unit 2</option>
                        <option value="unit3">Unit 3</option>
                        </select>
                      </div>
                      </div>
                      <div class="row">
                      <div class="form-group">
                      <div class="input_field_wrap">
    				  <label for="text">Size</label>
        			  <input type="number" value="" name="size[]" class="form-control" placeholder="Price" required>
                      </div>
                      <br>
                      <button class="add_fields_button btn btn-success"><i class="fa fa-plus"></i> Add More Size</button>
                      </div>
                    </div>
                </div>
                </div>
                
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                
                <div class="row">
                <div class="page-title">
                        <h5><b>Images</b></h5>
                </div>
                <div class="col-lg-12">
                    <div class="row">
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="imageOne" class="form-control" onchange="readURL(this);"/>
                      <img id="blah" src="{{url('images/demo.png')}}" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="imageTwo" class="form-control" onchange="preview_image(this);"/>
                      <img id="blah2" src="{{url('images/demo.png')}}" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="imageThree" class="form-control" onchange="preview_img(this);"/>
                      <img id="blah3" src="{{url('images/demo.png')}}" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      
                     </div> 
                </div>
                </div>
                
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                
                <div class="col-md-6 pull-right">
                        <button id="send" type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
                </div>
              </div>

          </form>
          </div>
        </div>
      </div>
    </div>


    @endsection
 