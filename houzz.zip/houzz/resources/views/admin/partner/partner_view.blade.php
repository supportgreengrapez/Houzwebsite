@extends('admin.layout.appadmin')
@section('content')

    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Partner Management</h3>
            <h4 style="display:block;">Partner View</h4>
        </div>
      </div>
      <div class="wrap">
      <div class="page-title">
            <h4><b>About Partner</b></h4>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Bussiness Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->business_name)) {{$data[0]->business_name}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Email</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->email)) {{$data[0]->email}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Contact NO</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->phone)) {{$data[0]->phone}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Category</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->category_id))  @php  $cat = DB::table('partner_categories')->where('id',$data[0]->category_id)->get(); if(isset($cat[0]->name)) { echo $cat[0]->name; } @endphp  @endif</p>
            
          </div>
        </div>
      </div>
      
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Country</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->country)) {{$data[0]->country}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Provience/State</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->state)) {{$data[0]->state}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>City</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->city)) {{$data[0]->city}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Zip Code</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>54000</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Location</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if(isset($data[0]->location)) {{$data[0]->location}} @endif</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Product Description</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p>@if(isset($data[0]->description)) {{$data[0]->description}} @endif</p>
          </div>
        </div>
      </div>
      <div class="page-title">
            <h4><b>Logo</b></h4>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>First Image</label><br>
            <img src="{{url('assets/admin/partner_images/logo/')}}@php if(isset($data[0]->logo)){ echo '/'; echo $data[0]->logo;} @endphp " alt="img">
           </div>
        </div>
      </div>

      <div class="page-title">
            <h4><b>Partner Images</b></h4>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>First Image</label><br>
            <img src="{{url('assets/admin/partner_images/first_image/')}}@php if(isset($data[0]->image_one)){ echo '/'; echo $data[0]->image_one;} @endphp " alt="img">
           </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>Second Image</label><br>
            <img src="{{url('assets/admin/partner_images/second_image/')}}@php if(isset($data[0]->image_two)){ echo '/'; echo $data[0]->image_two;} @endphp " alt="img">
           </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12">
          <div class="dbicons">
          <label>Third Image</label><br>
            <img src="{{url('assets/admin/partner_images/third_image/')}}@php if(isset($data[0]->image_three)){ echo '/'; echo $data[0]->image_three;} @endphp " alt="img">
           </div>
        </div>
      </div>

        @if(isset($product) && !empty($product))
      
      <div class="page-title">
            <h4><b>Product Image</b></h4>
      </div>

    
       @foreach($product as $p)

          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="dbicons">

              <?php if($p->imageOne != null) { ?>
              <label>First Image</label><br>
                <img src="{{url('assets/admin/product_images/')}}@php if(isset($p->imageOne)){ echo '/'; echo $p->imageOne;} @endphp " alt="img">
              <?php } ?>
             
               </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="dbicons">
              <?php if(!empty($p->imageTwo)) { ?>
              <label>Second Image</label><br>
                <img src="{{url('assets/admin/product_images/')}}@php if(isset($p->imageTwo)){ echo '/'; echo $p->imageTwo;} @endphp " alt="img">
                <?php } ?>
               </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="dbicons">
              <?php if(!empty($p->imageThree)) { ?>
              <label>Third Image</label><br>
                <img src="{{url('assets/admin/product_images/')}}@php if(isset($p->imageThree)){ echo '/'; echo $p->imageThree;} @endphp " alt="img">
              <?php } ?>
               </div>
            </div>
          </div>
        @endforeach
        @else
           <div class="page-title">
            <h4><b>Not Found Product Image</b></h4>
      </div>

      @endif
      </div>
    </div>


    <!-- /page content --> 
         @endsection