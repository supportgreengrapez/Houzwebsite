@extends('admin.layout.appadmin')
@section('content')


 <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Partner Management</h3>
            <h4 style="display: block;">Add Titanium Partner Icon</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <form  action="{{route('add.slider.image.post')}}" method="POST" enctype="multipart/form-data">
                  @csrf
                <div class="row">
                <div class="page-title">
                        <h5><b>Icon</b></h5>
                </div>
                <div class="col-lg-3">
                      
                <div class="input_field_wrap_img">
                      <div class="form-group">
                      <input type="file" name="file[]" class="form-control" onchange="slider(this);"/>
                      <img id="slider" src="{{url('images/demo.png')}}" alt="Product Image" style="width:252px;" />
                  </div>
                </div>
                <br>
                <button class="add_field_button_img btn btn-success"><i class="fa fa-plus"></i> Add More Item</button>
                </div>
                </div>
                
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                
                <div class="col-md-6 pull-right">
                        <button type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
                </div>
              </form>
              </div>
          </div>
        </div>
      </div>
    </div>


@endsection
 

