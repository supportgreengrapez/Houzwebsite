@extends('admin.layout.appadmin')
@section('content')


    
    <!-- page content -->
  <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Partner Management</h3>
            <h4 style="display: block;">Add Partner</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <div class="row">
              <form action="{{route('partner.detail.update')}}" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="id" value="{{$id}}">
                <div class="col-md-3 col-sm-12 col-xs-12">
                  <div class="page-title">
                    <h5><b>About Partner</b></h5>
                  </div>
                </div>

                
                @csrf
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  <div class="row">
                    <div class="form-group">
                      <label>Bussiness Name</label>
                     
                      <input type="text" class="form-control" name="businessName" value="{{$data[0]->business_name}}" placeholder="Bussiness Name" required>
                    </div>
                    <div class="form-group">
                      <label>Email</label>
                      <input type="email" class="form-control" name="email" value="{{$data[0]->email}}" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                      <label>Contact No</label>
                      <input type="tel" class="form-control" name="phone" value="{{$data[0]->phone}}" placeholder="Comtact No" required>
                    </div>
                    <div class="form-group">
                      <label>Category Name</label>
                      <select class="form-control" name="category_id">
                        @foreach($categoreis as $value)
                       <option <?php if( $data[0]->category_id == $value->id) {echo 'selected';} ?> value="{{$value->id}}">{{$value->name}}</option>
                    
                        @endforeach
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Country</label>
                      <select name="country" class="form-control countries order-alpha" id="countryId">
                        <option  value="">Select Country</option>
                        <option value="pak">pakistan</option>
                        <option value="uae">UAE</option>
                        <option value="uk">UK</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>State/Provience</label>
                      <select name="state" class=" form-control states order-alpha" id="stateId">
                        <option value="">Select State</option>
                        <option value="punjab">Pubjab</option>
                        <option value="sindh">Sindh</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>City</label>
                      <select name="city" class=" form-control cities order-alpha" id="cityId">
                        <option value="">Select City</option>
                         <option value="lahore">lahoe</option>
                        <option value="Islambad">Islambad</option>
                        <option value="karachi">Karachi</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label>Zip Code</label>
                      <input type="text" value="<?php if( $data[0]->zip_code) {echo $data[0]->zip_code; } ?>" class="form-control" name="" placeholder="Zip Code" required>
                    </div>
                    <div class="form-group">
                      <label>Location</label>
                      <input type="text" class="form-control" value="<?php if( $data[0]->location) {echo $data[0]->location; } ?>" name="location" value="" placeholder="Location" required>
                    </div>
                    
                    <div class="row">
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      
                    <label>Logo</label>
                      <input type="file" name="logo" class="form-control" onchange="preview_imgss(this);"/>
                       <?php if(empty($data[0]->logo)) { ?>
                      <img id="blah4" src="{{url('assets/admin/images/demo.png')}}" alt="Product Image" style="width:200px; height:150px;" />
                          <?php }else{ ?>
                      <img id="blah4" src="{{url('assets/admin/partner_images/logo/'.$data[0]->logo)}}" alt="Product Image" style="width:200px; height:150px;" />
                            <?php } ?>
                      </div>
                      
                     </div> 
                    
                    <div class="row">
                    <div class="form-group">
                      
                    <label>Partner Image</label>
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="imageOne" class="form-control" onchange="readURL(this);"/>
                      <?php if(empty($data[0]->image_one)) { ?>
                      <img id="blah" src="{{url('assets/admin/images/demo.png')}}" alt="Product Image" style="width:200px; height:150px;" />
                    <?php }else{ ?>
                      <img id="blah" src="{{url('assets/admin/partner_images/first_image/'.$data[0]->image_one)}}" alt="Partner Image" style="width:200px; height:150px;" />
                    <?php } ?>
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="imagesTwo" class="form-control" onchange="preview_image(this);"/>
                       <?php if(empty($data[0]->image_two)) { ?>
                      <img id="blah2" src="{{url('assets/admin/images/demo.png')}}" alt="Product Image" style="width:200px; height:150px;" />
                         <?php }else{ ?>
                      <img id="blah2" src="{{url('assets/admin/partner_images/second_image/'.$data[0]->image_two)}}" alt="Product Image" style="width:200px; height:150px;" />
                         <?php } ?>
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="imagesThree" class="form-control" onchange="preview_img(this);"/>
                        <?php if(empty($data[0]->image_three)) { ?>
                      <img id="blah3" src="{{url('assets/admin/images/demo.png')}}" alt="Product Image" style="width:200px; height:150px;" />
                        <?php }else{ ?>
                      <img id="blah3" src="{{url('assets/admin/partner_images/third_image/'.$data[0]->image_three)}}" alt="Product Image" style="width:200px; height:150px;" />
                         <?php } ?>
                      </div>


                      
                     </div> 
                    <div class="form-group">
                      <label>Description</label>
                      <textarea class="form-control" rows="9" name="" placeholder="Enter Your Description"></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-sm-12 col-xs-12"> </div>
              </div>
              <div class="col-md-6 pull-right">
                <button id="send" type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
              </div>
            </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
          @endsection