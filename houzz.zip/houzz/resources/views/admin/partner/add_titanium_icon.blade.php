@extends('admin.layout.appadmin')
@section('content')

  <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Partner Management</h3>
            <h4 style="display: block;">Add Titanium Partner Icon</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">

            <form action="@if(isset($data[0]) && !empty($data[0]) ){{route('titanium.icon.update')}}  @else {{url('admin/add-titanium-icon-post')}} @endif" method="POST" enctype="multipart/form-data">
              @csrf

              @if(isset($data[0]) && !empty($data[0]) ) 
                 <input type="hidden" name="id" value="{{$data[0]->id}}" />
              @endif
              <div class="x_content">
                <div class="row">
                <div class="page-title">
                        <h5><b>Icon</b></h5>
                </div>

                <div class="col-lg-12">
                    <div class="row">
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="titanium_icon" class="form-control" onchange="readURL(this);"/>
                      @if(isset($data[0]))
                      <img id="blah" src="{{url('assets/admin/titanium_icons/')}}@php if(isset($data[0]->name)){ echo '/'; echo $data[0]->name;} @endphp " alt="Product Image" style="width:350px; height:300px;" />
                      @else
                      <img id="blah" src="images/demo.png" alt="Product Image" style="width:350px; height:300px;" />
                      @endif
                      </div>
                      
                     </div> 
                </div>
                </div>
                
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                
                <div class="col-md-6 pull-right">
                        <button type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
                </div>
              </div>
            </form> 
          </div>
        </div>
      </div>
    </div>
@endsection