@extends('admin.layout.appadmin')
@section('content')


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Partner Management</h3>
            <h4>Titanium Partner List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{route('add.titanium.icon')}}" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Titanium Partner Icon</a>
          </div>
          </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Icon</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  	@if(isset($data))
                  	@foreach($data as $value)
                    <tr>
                      <td>{{$value->id}}</td>
                      <td><img src="{{url('assets/admin/titanium_icons/')}}@php if(isset($data[0]->name)){ echo '/'; echo $value->name;} @endphp " alt="icon"></td>
                      <td>
                      <a href="{{url('admin/edit-titanium-icon/').'/'.$value->id}}">Edit</a>
                      <a href="{{url('admin/delete-titanium-icon/').'/'.$value->id}}" class="red">Delete</a>
                      </td>
                    </tr>
                    @endforeach
                    @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    



@endsection