  

@extends('admin.layout.appadmin')
@section('content')


   <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Partner Management</h3>
            <h4>Partner Category</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{route('add.category')}}" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Partner Category</a>
          </div>
          </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Category Name</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    @if(isset($data[0]) && !empty($data[0]))

                    @foreach($data as $value)
                    <tr>
                      <td>{{$value->id}}</td>
                      <td>{{$value->name}}</td>
                      <td>
                      <a href="{{url('admin/edit-category').'/'.$value->id}}">Edit</a>
                      <a href="{{url('admin/delete-category').'/'.$value->id}}" class="red">Delete</a>
                      </td>
                    </tr>
                    @endforeach
                    @endif
                    
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>

    @endsection