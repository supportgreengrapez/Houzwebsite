@extends('admin.layout.appadmin')
@section('content')


    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Partner Management</h3>
            <h4>Partner List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          </div>
        </div>
        <div class="clearfix"></div>
        <form method="POST" action="{{route('create.partner')}}">  
          @csrf
        <div class="row">
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label class="col-lg-6 col-sm-12 col-form-label" style="text-align:center;">Select Partner:</label>
            <div class="col-lg-6 col-sm-12 col-xs-12">
               <select class="form-control" name="partner_id">
              <option disabled=""> Select Partner</option>
              @foreach($partner_list as $p)
                <option value="{{$p->id}}"> {{$p->business_name}}</option>
              @endforeach
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Partner Category:</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <select class="form-control" name="category_id">
                 <option disabled=""> Select Category</option>
              @foreach($categoreis as $c)
                <option value="{{$c->id}}"> {{$c->name}}</option>
              @endforeach
              </select>
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Create</button>
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
<!--                 <div class="alert alert-danger">
  <strong></strong> Indicates a dangerous or potentially negative action.
</div> -->
<a href="{{route('add.partner.detail')}}" type="button" class="btn btn-success"><i class="fa fa-plus"></i> Add Partner</a>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
    <!-- footer content -->
          @endsection
