@extends('admin.layout.appadmin')

@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Photo Management</h3>
            <h4 style="display:block;">Edit Idea</h4>
          </div>
        </div>

        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">

              <div class="x_content">
              @if(count($result1)>0)
              <form method="post" action = "{{url('/')}}/admin/home/edit/idea/{{$result1[0]->pk_id}}" class="login-form" enctype="multipart/form-data">
                      {{ csrf_field() }}
                      @if($errors->any())

<div class="alert alert-danger">
  <strong>Danger!</strong> {{$errors->first()}}
</div>
@endif
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="form-group">
                        <label>Category</label>
                        <select class="form-control" name="photo_category" id="photo_category">
                        @if($result>0)
                    @foreach($result as $results)
                          <option value="{{urlencode($results->photo_category)}}" @if($result1[0]->photo_category==$results->photo_category) selected @endif>{{$results->photo_category}}</option>
                            @endforeach
                            @endif
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Sub Category</label>
                        <select class="form-control" name="photo_sub_category" id="photo_sub_category" >
                        <option value="{{$result1[0]->photo_sub_category}}" >{{$result1[0]->photo_sub_category}}</option>

                        </select>
                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000">{{$result1[0]->description}}</textarea>
                      </div>
                </div>
      		  </div>
              <div class="row">
                <div class="page-title">
                        <h5><b>Images</b></h5>
                </div>
                <div class="col-lg-12">
                    <div class="row">
                    <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="file" value="{{url('/')}}/storage/images/{{$result1[0]->thumbnail}}" class="form-control" onchange="readURL(this);"/>
                      <img id="blah" src="{{url('/')}}/storage/images/{{$result1[0]->thumbnail}}" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="images2" value="{{url('/')}}/storage/images/{{$result1[0]->thumbnail2}}" class="form-control" onchange="preview_image(this);"/>
                      <img id="blah2" src="{{url('/')}}/storage/images/{{$result1[0]->thumbnail2}}" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="images3" class="form-control" value="{{url('/')}}/storage/images/{{$result1[0]->thumbnail3}}" onchange="preview_img(this);"/>
                      <img id="blah3" src="{{url('/')}}/storage/images/{{$result1[0]->thumbnail3}}" alt="Product Image" style="width:350px; height:300px;" />
                      </div>

                     </div>
                </div>
                </div>

              <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Done</button>
                </div>
                </form>
                @endif
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

    @endsection
