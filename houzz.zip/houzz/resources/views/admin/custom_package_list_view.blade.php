@extends('admin.layout.appadmin')
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }

  </script>
@section('content')
      <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Package Management</h3>
            <h4>Custome Feature</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{url('/')}}/admin/home/add/custom/package/view" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Feature</a>
          </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Package Name</th>
                      <th>Package Price</th>
                      <th>Is Active?</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  @if(count($result)>0)
                  @foreach($result as $results)
                    <tr>
                      <td>{{$results->package_name}}</td>
                      <td>{{$results->package_price}}</td>
                      <td>
                      <label for="cmn-toggle-{{$results->pk_id}}" class="switch">
                      <input @if($results->status==1) checked @endif  onchange="updateStatus(this.id)"  id="cmn-toggle-{{$results->pk_id}}" type="checkbox">
                      <span class="slider round"></span>
                  </label>
                      </td>
                      <td>
                      <a href="{{url('/')}}/admin/home/custom/package/detail/view/{{$results->pk_id}}">View</a>
                      <a href="{{url('/')}}/admin/home/edit/custom/package/{{$results->pk_id}}">Edit</a>
                      <a href="{{url('/')}}/admin/home/delete/custom/package/{{$results->pk_id}}" class="red">Delete</a>
                      </td>
                    </tr>
                   @endforeach
                   @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
  @endsection
  <script>
    function updateStatus(id)
    {
      CheckBox = id;
      id = id.split("-");
      id = id[2];
      cstatus = document.getElementById(CheckBox).checked;
      status= 0;

    if(cstatus)
      {
        status = 1;
      }
      else
      status=0;

      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
               alert("status updated");
            }
        };
        xmlhttp.open("GET", "{{URL('/')}}/admin/home/custom/package/status/update/"+id+"/"+status, true);
        xmlhttp.send();

    }
    </script>