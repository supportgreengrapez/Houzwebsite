@extends('admin.layout.appadmin')

@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management</h3>
        <h4 style="display: block;">Add Image Slider</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <form method="post" action = "{{url('/')}}/admin/add/slider" class="login-form" enctype="multipart/form-data">
          {{ csrf_field() }}
          @if($errors->any())
          <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
          @endif
          <div class="x_content">
            <div class="row">
              <div class="page-title">
                <h5><b>Images</b></h5>
              </div>
              <div class="col-lg-12">
                <div class="alert alert-info"> <strong>Info!</strong> Please Upload 500*500 pixel image. </div>
                <div class="row">
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Ad One</label>
                    <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                    <img id="blah" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Ad Two</label>
                    <input type="file" name="images2" class="form-control" onchange="preview_image(this);"/>
                    <img id="blah2" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Ad Three</label>
                    <input type="file" name="images3" class="form-control" onchange="preview_img(this);"/>
                    <img id="blah3" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Ad Four</label>
                    <input type="file" name="images4" class="form-control" onchange="preview_imgs(this);"/>
                    <img id="blah4" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Ad Five</label>
                    <input type="file" name="images5" class="form-control" onchange="ad_five(this);"/>
                    <img id="blah5" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Ad Six</label>
                    <input type="file" name="images6" class="form-control" onchange="ad_six(this);"/>
                    <img id="blah6" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <label>Main Image</label>
                    <input type="file" name="images7" class="form-control" onchange="main(this);"/>
                    <img id="blah7" src="{{url('/')}}/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="col-md-6 pull-right">
              <button type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 
@endsection 