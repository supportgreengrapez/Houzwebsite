
@extends('admin.layout.appadmin')
@section('content')



    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Admin Management</h3>
            <h4 style="display:block;">Admin View</h4>
        </div>
      </div>
      <div class="wrap">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p >{{$result[0]->fname}} {{$result[0]->lname}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Email</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p >{{$result[0]->username}}</p>
          </div>
        </div>
      </div>

      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Phone</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p >{{$result[0]->phone}}</p>
          </div>
        </div>
      </div>

      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Address</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p >{{$result[0]->address}}</p>
          </div>
        </div>
      </div>

      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Image</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p >{{$result[0]->thumbnail}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Permisions</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><span class="label label-info">Admin & management</span>
            @if($result[0]->admin_management==1)
                          <span class="label label-warning">Admin</span>
                            @endif
                          @if($result[0]->product_management==1)
                            <span class="label label-success">Product </span>
                            @endif
                            @if($result[0]->category_management==1)
                          <span class="label label-primary">Category</span>
                          @endif

                           @if($result[0]->brand_management==1)
                          <span class="label label-warning">Brand </span>
                            @endif
                          @if($result[0]->order_management==1)
                            <span class="label label-success">Order Management</span>
                            @endif
                            @if($result[0]->reporting==1)
                          <span class="label label-primary">Reporting</span>
                          @endif

                           @if($result[0]->discount==1)
                          <span class="label label-warning">Discount</span>
                            @endif
                          @if($result[0]->promocode==1)
                            <span class="label label-success">Promocode</span>
                            @endif
                            @if($result[0]->vendor_management==1)
                          <span class="label label-primary">Vendor Management</span>
                          @endif</p>

          </div>
        </div>
      </div>
      </div>

    </div>
    <!-- /page content -->


      @endsection
