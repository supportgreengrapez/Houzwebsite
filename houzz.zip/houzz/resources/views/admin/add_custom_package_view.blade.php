@extends('admin.layout.appadmin')
@section('content')
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Package Management</h3>
            <h4 style="display: block;">Add Cutome Feature</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
            <form method="post" action = "{{url('/')}}/admin/home/add/custom/package" class="login-form">
              {{ csrf_field() }}
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group ">
                    <label class="control-label requiredField" for="name"> Package Name <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="package_name" type="text">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group ">
                    <label class="control-label requiredField" for="name1">Package Price <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="package_price" type="number">
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-6 col-xs-12">
                  <div class="form-group ">
                    <label class="control-label "> Custom Feature </label>
                    <div class=" ">
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="online_inventory" type="checkbox">
                          Manangement inventory collections for online sale  </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="offline_inventory" type="checkbox" value="Manangement inventory collections for offline sale">
                          Manangement inventory collections for offline sale </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="promotion" type="checkbox" value="Add Promotions">
                          Add Promotions </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="invoice" type="checkbox" value="Invoice with logo">
                          Invoice with logo </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="payment_report" type="checkbox" value="Payment Reports">
                          Payment Reports </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="client" type="checkbox" value="Add Client">
                          Add Client </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="message_box" type="checkbox" value="Message Box">
                          Message Box </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="chat_box" type="checkbox" value="Chat Box">
                          Chat Box </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="featured_seller" type="checkbox" value="Featured Seller">
                          Featured Seller </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="featured_product" type="checkbox" id="myCheck"  onclick="myFunction()" value="Featured Products">
                          Featured Products </label>
                          
                      </div>
                      <div class="checkbox">
                      <div id="text" style="display:none">
                  <div class="form-group ">
                    <label class="control-label requiredField" for=""> No Of Featured Products <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="no_of_featured_product" type="text">
                    </div>
                  </div>
                          
                          </div>
                          </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="hot_product" type="checkbox" id="myChecked"  onclick="myFunctions()" value="Hot Products">
                          Hot Products </label>
                          
                      </div>
                      <div class="checkbox">
                      <div id="texts" style="display:none">
                  <div class="form-group ">
                    <label class="control-label requiredField" for=""> No Of Hot Products <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="no_of_hot_product" type="text">
                    </div>
                  </div>
                          </div>
                          </div>
                          
                          
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="product" type="checkbox" id="myChecks"  onclick="myFunctionss()" value="Hot Products">
                          Add Products </label>
                          
                      </div>
                      <div class="checkbox">
                      <div id="textss" style="display:none">
                  <div class="form-group ">
                    <label class="control-label requiredField" for=""> No Of Products <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="no_of_product" type="text">
                    </div>
                  </div>
                          </div>
                          </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <div>
                      <button class="btn btn-success" name="submit" type="submit"> Submit </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
@endsection