@extends('admin.layout.appadmin')
@section('content') 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Product Management</h3>
            <h4 style="display:block;">Manage Collection</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          <form method="post" action = "{{url('/')}}/admin/add/collection" class="login-form" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        @if($errors->any())

<div class="alert alert-danger">
  <strong></strong> {{$errors->first()}}
</div>
@endif
              <div class="x_content">
                      <div class="form-group">
                        <label>Choose Collection</label>
                        <select class="form-control" name="category">
                          @if($result>0)
                    @foreach($result as $results)
                           <option value="{{$results->pk_id}}">{{$results->collection_name}}</option>
                           @endforeach
           @endif
                        </select>
                      </div>
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                <div class="form-group">
                        <label>SKU</label>
                        <select  class="js-example-tokenizer form-control" name="sku[]" multiple="multiple" required>
                        
                                                   @if(count($result1)>0)
                    @foreach($result1 as $results)
                           <option value="{{$results->pk_id}}">{{$results->sku}}</option>
                           @endforeach
           @endif
                    </select>
                </div>
      
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                                
                <div class="col-md-6">
                        <button type="submit" class="btn btn-success btn-lg">Create Collection</button>
                        
                </div>
              </div>
              </form>
          </div>
          
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                     <form method="post" action = "{{url('/')}}/admin/add/collection/category" class="login-form" enctype="multipart/form-data" >
                        {{ csrf_field() }}
                    
              <div class="x_content">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="title_left">
            <h4>Add Collection Name</h4>
          </div>
                      <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="collection_name" placeholder="Collection Name" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000"></textarea>
                      </div>
                      <div class="form-group">
                      <label>Cover Photo</label>
                      <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                      <img id="blah" src="images/851x315.png" alt="Product Image" style="width:100%; height:315px;" />
                      </div>
                </div>
      		  </div>
      
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                                
                <div class="col-md-6">
                        <button type="submit" class="btn btn-success btn-lg">Submit</button>
                        
                </div>
              </div>
              </form>
          </div>
          
        </div>
        <div class="clearfix"></div>
        
      </div>
    </div>
    <!-- /page content --> 
@endsection