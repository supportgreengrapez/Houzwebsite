@extends('admin.layout.appadmin')
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Order Management</h3>
          <h4>Coupon List</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
        <div class="title_left"> <a href="{{url('/')}}/admin/home/add/promo" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Create Coupon</a> </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>P_Code</th>
              <th>Discount Type</th>
              <th>Discount For</th>
              <th>Discount Amount</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Min Subtotal</th>
              <th>Max Subtotal</th>
              <th>Is Active?</th>
              <th> Actions</th>
            </tr>
          </thead>
          <tbody>
          
          @if(count($result)>0)
          @foreach($result as $results)
          <tr>
            <td>{{$results->promo_code}}</td>
            <td>{{$results->discount_type}}</td>
            <td>{{$results->discount_for}}</td>
            <td>{{$results->discount_amount}}</td>
            <td>{{$results->start_date}}</td>
            <td>{{$results->end_date}}</td>
            <td>{{$results->min_total}}</td>
            <td>{{$results->max_total}}</td>
            <td>
            <label for="cmn-toggle-{{$results->pk_id}}" class="switch">
                          <input @if($results->status==0) checked @endif  onchange="updateStatus(this.id)"  id="cmn-toggle-{{$results->pk_id}}" type="checkbox">
                          <span class="slider round"></span>
                      </label>
            </td>
            <td><a href="{{url('/')}}/admin/home/delete/promo/{{$results->pk_id}}">Delete</a></td>
          </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 
<script>
            function updateStatus(id)
            {
              CheckBox = id;
              id = id.split("-");
              id = id[2];
              cstatus = document.getElementById(CheckBox).checked;
              status= 1;
            
            if(cstatus)
              {
                status = 0;
              }
              else
              status=1;
              
              var xmlhttp = new XMLHttpRequest();
                xmlhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                       alert("status updated");
                  
                    }
                };
                xmlhttp.open("GET", "{{URL('/')}}/admin/home/view/promo/status/update/"+id+"/"+status, true);
                xmlhttp.send();
            
            }

</script>