@extends('admin.layout.appadmin')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">

          <div class="title_left">
            <h3>Seller Management</h3>
            <h4>Seller Package</h4>
          </div>
          </div>
        </div>
      <div class="row">
      <form method="post" action = "{{url('/')}}/admin/home/search/subs/by/order/id" class="login-form">
                            {{ csrf_field() }}
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="number" name="search" class="form-control" id="inputPassword" placeholder="Seller ID">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
</form>

<form method="post" action = "{{url('/')}}/admin/home/search/by/subs/package" class="login-form">
                            {{ csrf_field() }}
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Type :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <select class="form-control" name="package">
              	<option value="All">All</option>
                <option value="COMMISSION">Commission</option>
                <option value="BASIC">Basic</option>
                <option value="PLANTINUM">Plantinum</option>
              </select>
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>
</form>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Seller Name</th>
                    <th>Packages</th>
                    <th>date</th>

                  </tr>
                </thead>
                <tbody>
                @if(count($result)>0)
                      @foreach($result as $results)

                  <tr>
                    <td>{{$results->pk_id}}</td>
                    <td>{{$results->fname}} {{$results->lname}}</td>
                    <td>{{$results->subscription}}</td>
                    <td>{{$results->created_at}}</td>

                  </tr>
                  @endforeach
         @endif


                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->
  @endsection
