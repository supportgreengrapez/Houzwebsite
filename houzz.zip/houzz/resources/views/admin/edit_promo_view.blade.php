@extends('admin.layout.appadmin')
@section('content')
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Coupon Management</h3>
            <h4 style="display: block;">Edit Coupon</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
            <form method="post" action = "{{url('/')}}/admin/home/edit/promo/{{$result[0]->pk_id}}" class="login-form" enctype="multipart/form-data">
                            {{ csrf_field() }}
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  @if($errors->any())
                  <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
                  @endif 
                    <div class="row">
                      <div class="form-group">
                        <label>Coupon Code</label>
                        <input type="text" class="form-control" value="{{$result[0]->promo_code}}" name="promo" placeholder="Coupon Code" required>
                      </div>
                      <div class="form-group">
                        <label>Discount Type</label>
                        <div class="radio">
                          <label>
                            <input type="radio" @if($result[0]->discount_type=="fixed") checked @endif value="1" name="radio" checked>
                            Fixed</label>
                        </div>
                        <div class="radio">
                          <label>
                            <input type="radio" value="2" name="radio"  @if($result[0]->discount_type=="percentage") checked @endif>
                            Pecentage</label>
                        </div>
                      </div>
                      <div class="form-group">
                        <label>Discount Amount</label>
                        <input type="number" class="form-control" name="discount" value="{{$result[0]->discount_amount}}" placeholder="Discount Amount" required>
                      </div>
                      <div class="form-group">
                        <label>Start Date</label>
                        <input type="date" class="form-control" value="{{$result[0]->start_date}}" name="start_date" placeholder="Start Date" required>
                      </div>
                      <div class="form-group">
                        <label>End Date</label>
                        <input type="date" class="form-control" value="{{$result[0]->end_date}}" name="end_date" placeholder="End Date" required>
                      </div>
                      <div class="form-group">
                        <label>Min Sub Total</label>
                        <input type="number" class="form-control" value="{{$result[0]->min_total}}" name="min" placeholder="Min Sub Total" required>
                      </div>
                      <div class="form-group">
                        <label>Max Sub Total</label>
                        <input type="number" class="form-control" value="{{$result[0]->max_total}}" name="max" placeholder="Max Sub Total" required>
                      </div>
                      <div class="form-group">
                        <label>Apply Discount for</label>
                        <div class="radio">
                          <label>
                            <input type="radio" value="3" @if($result[0]->discount_for=="all customers") checked @endif name="optradio" checked>
                            All Customer</label>
                        </div>
                        <div class="radio">
                          <label>
                            <input type="radio" value="4"  @if($result[0]->discount_for=="exiting customers") checked @endif name="optradio">
                            Exsiting Customer</label>
                        </div>
                        <div class="radio">
                          <label>
                            <input type="radio" @if($result[0]->discount_for=="new customers") checked @endif value="5" name="optradio">
                            New Customer</label>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-3 col-sm-12 col-xs-12">
                    <div class="togglebutn">
                      <div id="wrapper">
                        <p>In Active?</p>
                        <div id="check">
                          <input type="checkbox" id="ch" name="status"  @if($result[0]->status==1) checked @endif >
                          <div id="cadre"></div>
                          <div id="bulle"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <button type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    
   
     @endsection