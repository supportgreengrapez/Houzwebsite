@extends('admin.layout.appadmin')

@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Forum Management</h3>
            <h4 style="display: block;">Add Post</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">


              <div class="x_content">
              <form method="post" action = "{{url('/')}}/admin/home/edit/forum/post/{{$post[0]->pk_id}}" enctype="multipart/form-data" class="login-form">
                            {{ csrf_field() }}
                            @if($errors->any())

<div class="alert alert-danger">
  <strong>Danger!</strong> {{$errors->first()}}
</div>
@endif
              <div class="row">
                <div class="col-lg-5">
                    <div class="row">
                      <div class="form-group">
                        <label>Category Name</label>
                        <select class="form-control" name="category">
                        @if(count($result)>0)
                      @foreach($result as $results)
                        	<option value="{{$results->category}}">{{$results->category}}</option>
                            @endforeach
         @endif
                        </select>
                      </div>

                      <div class="form-group">
                        <label>Topic</label>
                        <select class="form-control" name="topic">
                        @if(count($topic)>0)
                      @foreach($topic as $results)
                        	<option value="{{$results->topic}}">{{$results->topic}}</option>
                            @endforeach
         @endif
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" value="{{$post[0]->title}}" name="title" placeholder="Title" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000">{{$post[0]->description}}</textarea>
                      </div>
                    </div>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
                </div>

                </form>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


    @endsection
