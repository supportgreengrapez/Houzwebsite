@extends('admin.layout.appadmin')

@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Product Management</h3>
            <h4 style="display: block;">Import New Product</h4>
        </div>
      </div>

      <div class="row">
      <form method="post" action = "{{url('/')}}/admin/import/product/view" class="login-form">
                        {{ csrf_field() }}

                        @if($errors->any())

<div class="alert alert-danger">
  <strong>Danger!</strong> {{$errors->first()}}
</div>
@endif
      		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            	<div class="left-side">
                	<h4>Follow Step Below to Upload New Product</h4>
                    <p>Step 1: Select the template type for your products and select additional setting (optional)</p>
                    <div class="form-group">
                        <select class="form-control" name="file_type">
                        <option value="csv">Csv file</option>
                        <option value="pdf">Pdf</option>
                        <option value="world">world</option>
                        </select>
                      </div>
                      <p>Step 2: Download Houzz template and review th instructions</p>
                      <p>Step 3: Chose the complete file of your product and click upload button</p>

                      <div class="form-group">
                        <input type="file" class="form-control" name="" placeholder="File" required>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                        <button type="submit" class="btn btn-successs">Upload</button>

                      </div>

                </div>
            </div>
            </form>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
            	<div class="right-side">
                <div class="row">
                	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    	<div class="left-side">
                        <h4>Formatting</h4>
                        	<p><i class="fa fa-check"></i> File in all required columns</p>
                            <p><i class="fa fa-check"></i> For CSV file  , rserve the first row for the header andmake sure the columns name match</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    	<div class="left-side">
                        <h4>File Size</h4>
                        	<p><i class="fa fa-check"></i> Smaller then 20MB</p>

                        </div>
                    </div>
                    </div>
                    <div class="botm">
                    <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    	<div class="left-side">
                        	<p><i class="fa fa-times"></i> Missing the required columns</p>
                            <p><i class="fa fa-times"></i> Missing the header row in feed</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    	<div class="left-side">
                        	<p><i class="fa fa-times"></i> Larger then 20MB</p>

                        </div>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
      </div>
    </div>
    <!-- /page content -->

    @endsection
