@extends('admin.layout.appadmin')
@section('content')


    <!-- page content -->
    <div class="right_col" role="main">
    <div class="page-title">
          <div class="title_left">
            <h3>Rating and Reviews Management</h3>
            <h4 style="display: block;">Rating & Reviews List</h4>
          </div>
        </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>SKU</th>
                    <th>Product Name</th>
                    <th>Customer Name</th>
                    <th>Rating</th>
                    <th>Comments</th>

                  </tr>
                </thead>
                <tbody>
                @if(count($result)>0)
                      @foreach($result as $results)
                      @php
                      $user = DB::select( DB::raw("SELECT * FROM client_details WHERE pk_id = :value"), array(
   'value' => $results->user_id,
 ));
 $product = DB::select( DB::raw("SELECT * FROM product WHERE pk_id = :value"), array(
   'value' => $results->product_id,
 ));
                      @endphp
                      @if(count($product)>0)
                    <tr>
                      <td>{{$product[0]->sku}}</td>
                      <td>{{$product[0]->name}}</td>
                      <td>{{$user[0]->fname}} {{$user[0]->lname}}</td>
                      <td>    @php
                $count = $results->rating;
                $star = 5 - $count;
                @endphp
                @for($i = 0; $i<$count; $i++)
                 <span class="fa fa-star checked" style="color:yellow;"></span>
                 @endfor
                 @for($i = 0; $i<$star; $i++)
                  <span class="fa fa-star" style="color:lightgrey;"></span>
                  @endfor</td>
                      <td><p style="text-align:left;">{{$results->comment}}</p></td>
                    </tr>
                    @endif
                    @endforeach
         @endif

                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


@endsection
