@extends('admin.layout.appadmin')
@section('content')

    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Admin Dashboard</h3>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Products</h3>
            <img src="{{url('/')}}/images/12.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <span>{{$pa}} active products.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="{{url('/')}}/admin/home/add/product">Add or manage your products <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Payments</h3>
            <img src="{{url('/')}}/images/13.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <span>No recent payments.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="">View your payments <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Orders</h3>
            <img src="{{url('/')}}/images/14.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have {{$week}} Order in the last week. View <a href="{{url('/')}}/admin/home/view/active/orders"><span>Previous Orders here.</span></a></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="{{url('/')}}/admin/home/view/active/orders">Manage your Orders <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="{{url('/')}}/images/2.png" alt="icons">
            <div class="dbboticonstext">
              <h4>{{$o}}<br>
                <span>Processing</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="{{url('/')}}/images/3.png" alt="icons">
            <div class="dbboticonstext">
              <h4>{{$hold}} <br>
                <span>On Hold</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="{{url('/')}}/images/4.png" alt="icons">
            <div class="dbboticonstext">
              <h4>{{$shipped}} <br>
                <span>Shipped</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="{{url('/')}}/images/5.png" alt="icons">
            <div class="dbboticonstext">
              <h4>{{$return}}<br>
                <span>Returned</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="{{url('/')}}/images/6.png" alt="icons">
            <div class="dbboticonstext">
              <h4>{{$cancel}} <br>
                <span>Cancelled</span></h4>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->



      @endsection
