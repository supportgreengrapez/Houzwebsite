@extends('admin.layout.appadmin')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">


            <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Order Management</h3>
            <h4>Invoice Detail</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
            <a href="add-invoice.html" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Create Invoice</a>
          </div>
          </div>
          </div>
        </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table  class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>

                    <th>Product Id</th>

                    <th>Product Name</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Price </th>
                    <th>Size </th>
                    <th>Promotions</th>


                  </tr>
                </thead>
                <tbody>
             @if(count($result1)>0)
             @foreach($result1 as $results)
                  <tr>

                    <td>{{$results->product_id}}</td>
                    <td>{{$results->product_name}}</td>
                    <td>{{$results->description}}</td>
                    <td>{{$results->quantity}}</td>
                    <td>PKR {{number_format($results->price)}}</td>
                    <td>{{$results->size}}</td>
                    <td>{{$results->discount}}</td>

                  </tr>
                  @endforeach
                  @endif
                </tbody>
              </table>
            </div>
        </div>
      </div>
      <div class="row">
      	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
        <div class="title_left">
            <button type="button" class="btn btn-success">Print Invoice</button>
          </div>
        </div>
        @if(count($result)>0)

      	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Order_id</h4>
           </div>
        </div>

        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->order_id}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Bill From</h4>
           </div>
        </div>

        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->bill_from}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Bill To</h4>
           </div>
        </div>

        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->bill_to}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Shipment</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p>{{$result[0]->shipment_address}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Amount</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>PKR {{number_format($result[0]->amount)}}</p>

          </div>
        </div>
      </div>
        </div>
        @endif
      </div>
    </div>
    <!-- /page content -->

   @endsection
