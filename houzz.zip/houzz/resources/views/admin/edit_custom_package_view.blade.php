@extends('admin.layout.appadmin')
@section('content')
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Package Management</h3>
            <h4 style="display: block;">Edit Cutome Feature</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
            @if(count($result)>0)
            <form method="post" action = "{{url('/')}}/admin/home/edit/custom/package/{{$result[0]->pk_id}}" class="login-form">
              {{ csrf_field() }}
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group ">
                    <label class="control-label requiredField" for="name"> Package Name <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="package_name" value="{{$result[0]->package_name}}" type="text">
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group ">
                    <label class="control-label requiredField" for="name1">Package Price <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="package_price" value="{{$result[0]->package_price}}" type="number">
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-6 col-xs-12">
                  <div class="form-group ">
                    <label class="control-label "> Custom Feature </label>
                    <div class=" ">
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="online_inventory" @if($result[0]->online_inventory == 1) checked @endif type="checkbox">
                          Manangement inventory collections for online sale  </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="offline_inventory" type="checkbox" @if($result[0]->offline_inventory == 1) checked @endif>
                          Manangement inventory collections for offline sale </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="promotion" type="checkbox" @if($result[0]->promotion == 1) checked @endif value="Add Promotions">
                          Add Promotions </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="invoice" type="checkbox" @if($result[0]->invoice == 1) checked @endif value="Invoice with logo">
                          Invoice with logo </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="payment_report" type="checkbox" @if($result[0]->payment_report == 1) checked @endif value="Payment Reports">
                          Payment Reports </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="client" type="checkbox" @if($result[0]->client == 1) checked @endif value="Add Client">
                          Add Client </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="message_box" @if($result[0]->message_box == 1) checked @endif type="checkbox" value="Message Box">
                          Message Box </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="chat_box" @if($result[0]->chat_box == 1) checked @endif type="checkbox" value="Chat Box">
                          Chat Box </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="featured_seller" type="checkbox" @if($result[0]->featured_seller == 1) checked @endif value="Featured Seller">
                          Featured Seller </label>
                      </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="featured_product" type="checkbox" id="myCheck" @if(!empty($result[0]->featured_product)) checked @endif  onclick="myFunction()" value="Featured Products">
                          Featured Products </label>
                          
                      </div>
                      <div class="checkbox">
                      <div id="text" style="display:none">
                  <div class="form-group ">
                    <label class="control-label requiredField" for=""> No Of Featured Products <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="no_of_featured_product" value="{{$result[0]->featured_product}}" type="text">
                    </div>
                  </div>
                          
                          </div>
                          </div>
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="hot_product" type="checkbox" id="myChecked"  onclick="myFunctions()"  @if(!empty($result[0]->hot_product)) checked @endif value="Hot Products">
                          Hot Products </label>
                          
                      </div>
                      <div class="checkbox">
                      <div id="texts" style="display:none">
                  <div class="form-group ">
                    <label class="control-label requiredField" for=""> No Of Hot Products <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" value="{{$result[0]->hot_product}}" name="no_of_hot_product" type="text">
                    </div>
                  </div>
                          </div>
                          </div>
                          
                          
                      <div class="checkbox">
                        <label class="checkbox">
                          <input name="product" type="checkbox" id="myChecks"  @if(!empty($result[0]->hot_product)) checked @endif  onclick="myFunctionss()"  value="Hot Products">
                          Add Products </label>
                          
                      </div>
                      <div class="checkbox">
                      <div id="textss" style="display:none">
                  <div class="form-group ">
                    <label class="control-label requiredField" for=""> No Of Products <span class="asteriskField"> * </span> </label>
                    <div class="input-group">
                      <div class="input-group-addon"> <i class="fa fa-table"> </i> </div>
                      <input class="form-control" name="no_of_product" value ="{{$result[0]->no_of_product}}" type="text">
                    </div>
                  </div>
                          </div>
                          </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="form-group">
                    <div>
                      <button class="btn btn-success" name="submit" type="submit"> Submit </button>
                    </div>
                  </div>
                </div>
              </form>
              @endif
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
@endsection