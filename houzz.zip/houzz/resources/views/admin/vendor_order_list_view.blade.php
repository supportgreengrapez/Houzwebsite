@extends('admin.layout.appadmin')
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Order Management</h3>
          <h4>Order Detail</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12"> </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table  class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>SKU</th>
              <th>Product Name</th>
              <th>Total Price</th>
              <th>Commission</th>
              <th>Payable Amount</th>
              <th>Size</th>
              <th>Quantity</th>
              <th>Vendor</th>
              <th>Order Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          
          @if(count($result)>0)
          @foreach($result as $results)
          @php 
          $product = DB::select("select* from product where pk_id ='$results->product_id'");
          $seller = DB::select("select* from client_details where pk_id ='$results->vendor_id' and customer_type='seller'");
          @endphp
          <tr>
            <td>{{$results->sku}}</td>
            <td><a href="{{url('/')}}/admin/home/view/product/{{$product[0]->pk_id}}">{{$results->product_name}}</a></td>
            <td>{{number_format($results->price)}}</td>
            <td>{{number_format($results->commission)}}%</td>
            <td>{{number_format($results->price - (($results->price*$results->commission)/100))}}</td>
            <td>{{$results->size}}</td>
            <td>{{$results->quantity}}</td>
            <td><a href="{{url('/')}}/admin/home/view/vendor/{{$seller[0]->pk_id}}">{{$seller[0]->fname}} {{$seller[0]->lname}}</a></td>
            
            @if($results->v_order_status == 0)
            <td><span class="label label-primary">Processing</span></td>
            @elseif($results->v_order_status == 1)
            <td><span class="label label-primary">On Hold</span></td>
            @elseif($results->v_order_status == 2)
            <td><span class="label label-primary">Shipped Product</span></td>
            @elseif($results->v_order_status == 3)
            <td><span class="label label-primary">Return</span></td>
            @elseif($results->v_order_status == 4)
            <td><span class="label label-primary">Cancel</span></td>
            @endif 
            <td><a href="{{url('/')}}/admin/home/view/active/order/view/specific/order/{{$results->order_id}}">View</a></td>
            </tr>
          @endforeach
          @endif
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

@endsection 