@extends('admin.layout.appadmin')
@section('content') 
    @if(count($result)>0)
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Package Managment</h3>
            <h4 style="display:block;">Cutome Feature</h4>
        </div>
      </div>
      <div class="wrap">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Package Name </h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$result[0]->package_name}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Package Price</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>PKR {{number_format($result[0]->package_price)}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Featured Product</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p>{{$result[0]->featured_product}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>No. of Product</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p>{{$result[0]->no_of_product}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Hot Product</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p>{{$result[0]->hot_product}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Custom Feature</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>@if($result[0]->online_inventory == 1)<span class="label label-info">Online Inventory</span>@endif
            @if($result[0]->offline_inventory == 1)<span class="label label-info">Offline Inventory</span>@endif
           @if($result[0]->promotion == 1)<span class="label label-info">Promotion</span>@endif
            @if($result[0]->invoice == 1)<span class="label label-info">Invoice</span>@endif
            @if($result[0]->payment_report == 1)<span class="label label-info">Payment Report</span>@endif
            @if($result[0]->client == 1)<span class="label label-info">Client</span>@endif
            @if($result[0]->message_box == 1)<span class="label label-info">Message Box</span>@endif
            @if($result[0]->chat_box == 1)<span class="label label-info">Chat Box</span>@endif
            @if($result[0]->featured_seller == 1)<span class="label label-info">Featured seller</span>@endif
    </p>
            
          </div>
        </div>
      </div>
      </div>
    </div>
    <!-- /page content --> 
    @endif
   @endsection