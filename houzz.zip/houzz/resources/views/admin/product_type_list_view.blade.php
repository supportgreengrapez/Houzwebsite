@extends('admin.layout.appadmin')
@section('content')

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Product Management</h3>
            <h4>Product Type</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="{{URL('/')}}/admin/home/add/product/type" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Product Type</a>
          </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Product Type</th>
                      <th>Category</th>
                      <th>Sub Category</th>
                      <th>User Name</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  @if($result>0)
                            @foreach($result as $results)
                    <tr>

                    <td>{{$results->pk_id}}</td>
                              <td>{{$results->product_type}}</td>
                              <td>{{$results->main_category}}</td>
                              <td>{{$results->sub_category}}</td>
                                  <td>{{$results->username}}</td>
                      <td>
                      <a href="{{URL('/')}}/admin/home/edit/product/type/{{$results->pk_id}}">Edit</a>
                      <a href="{{URL('/')}}/admin/home/delete/product/type/{{$results->pk_id}}" class="red">Delete</a>
                      </td>
                    </tr>
                    @endforeach
                            @endif
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

   @endsection
