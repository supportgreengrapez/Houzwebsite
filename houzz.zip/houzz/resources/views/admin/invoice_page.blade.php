<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<meta name="google-site-verification" content="-3fR2s0fAH-tDmr1Fkt1Zn9Zv3qA3tcabWHX8mpCd28" />
<link rel="shortcut icon" href="images/favicon.png"/>
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<title>Houzz</title>

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->

<link href="css/style.css" rel="stylesheet">

<!-- Datatables -->
<link href="css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="css/responsive.bootstrap.min.css" rel="stylesheet">
<link href="css/scroller.bootstrap.min.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="invoicetopbg">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-4 colsm-12 col-xs-12">
        <div class="invoicetopimg"> <img src="images/logo.png" alt="logo"> </div>
      </div>
      <div class="col-lg-4 colsm-12 col-xs-12 text-center">
        <div class="invoicetoptext">
          <h3>Invoice</h3>
        </div>
      </div>
      <div class="col-lg-3 colsm-12 col-xs-12 col-lg-offset-1">
        <div class="invoicetoptext2">
          <p>Houxx Store 150 Street<br>
            Lahore, ON K2P, 1L4<br>
            Pakistan</p>
          <span><a href="" style="color:white;">abc@gmail.com</a></span> </div>
      </div>
    </div>
  </div>
</div>
<div class="container">
  <div class="row mt-10">
    <div class="col-lg-6 col-sm-12 col-xs-12">
      <div class="row mt-10">
        <div class="col-lg-12 col-xs-12">
          <h4>Bill To:</h4>
        </div>
      </div>
      <div class="row mt-10">
        <div class="col-lg-12 col-xs-12">
          <h4>Faizan Rasool</h4>
        </div>
      </div>
      <div class="row mt-10">
        <div class="col-lg-12 col-xs-12">
          <h4 style="margin-bottom:3px;">150 Street Lahore, ON K2P, 1L4<br>
            Pakistan</h4>
          <span>abc@gmail.com</span> </div>
      </div>
    </div>
    <div class="col-lg-5 col-sm-12 col-xs-12 col-lg-offset-1">
      <div class="row mt-10">
        <div class="col-lg-6 col-xs-12">
          <h4>Invoice#</h4>
        </div>
        <div class="col-lg-6 col-xs-12">
          <h4>0074</h4>
        </div>
      </div>
      <div class="row mt-10">
        <div class="col-lg-6 col-xs-12">
          <h4>Invoice Date</h4>
        </div>
        <div class="col-lg-6 col-xs-12">
          <h4>Jan 13, 2015</h4>
        </div>
      </div>
      <div class="row mt-10">
        <div class="col-lg-6 col-xs-12">
          <h4><b>Amount Due</b></h4>
        </div>
        <div class="col-lg-6 col-xs-12">
          <h4 style="color:#6d9b25;"><b>24,000</b></h4>
        </div>
      </div>
    </div>
  </div>
  <div class="row" style="margin-top:30px;">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel" style="border-bottom:2px solid;">
        <div class="x_content">
          <table class="table table-condensed">
            <thead style="color:#6d9b25;">
              <tr>
                <th>Product ID</th>
                <th>Product Name</th>
                <th>Description</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Promotion</th>
                <th>Commission %</th>
                <th>Commission Amount</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>01</td>
                <td>Bed</td>
                <td><p>Actual Product weight: 66 Product Dimensions: 60X51 Product Width: 30 Product Height: 60</p></td>
                <td>01</td>
                <td>26,000</td>
                <td>20%</td>
                <td>20%</td>
                <td>4,800</td>
                <td>19,200</td>
              </tr>
              <tr>
                <td>01</td>
                <td>Bed</td>
                <td><p>Actual Product weight: 66 Product Dimensions: 60X51 Product Width: 30 Product Height: 60</p></td>
                <td>01</td>
                <td>26,000</td>
                <td>20%</td>
                <td>20%</td>
                <td>4,800</td>
                <td>19,200</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
  <div class="row mt-10">
    <div class="col-lg-5 col-sm-12 col-xs-12 col-lg-offset-7">
      <div class="row mt-10">
        <div class="col-lg-6 col-xs-12">
          <h4>SUBTOTAL</h4>
        </div>
        <div class="col-lg-6 col-xs-12">
          <h4>24,000</h4>
        </div>
      </div>
      <div class="invoicetopbg">
        <div class="row mt-10">
          <div class="col-lg-6 col-xs-12">
            <h4>TOTAL</h4>
          </div>
          <div class="col-lg-6 col-xs-12">
            <h4>24,000</h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- jQuery --> 
<script src="js/jquery.min.js"></script> 
<!-- Bootstrap --> 
<script src="js/bootstrap.min.js"></script> 

<!-- Custom Theme Scripts --> 
<script src="js/custom.min.js"></script> 
<!-- Datatables --> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/dataTables.bootstrap.min.js"></script> 
<script src="js/dataTables.responsive.min.js"></script> 
<script src="js/responsive.bootstrap.js"></script> 
<script src="js/dataTables.scroller.min.js"></script>
</body>
</html>