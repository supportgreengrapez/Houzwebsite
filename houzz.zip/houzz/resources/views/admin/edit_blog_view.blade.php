@extends('admin.layout.appadmin')

@section('content')



    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Blog Management</h3>
            <h4 style="display: block;">Edit Blog</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
              @if(count($result)>0)
              <form method="post" action = "{{url('/')}}/admin-blog-edit/{{$result[0]->pk_id}}" enctype="multipart/form-data" class="login-form">
                            {{ csrf_field() }}
                            @if($errors->any())

<div class="alert alert-danger">
  <strong>Danger!</strong> {{$errors->first()}}
</div>
@endif
              <div class="row">
                <div class="col-lg-5">
                    <div class="row">
                      <div class="form-group">
                        <label>Category Name</label>
                        <select class="form-control" name="category">
                        @if(count($category)>0)
                      @foreach($category as $results)
                        	<option value="{{$results->category}}">{{$results->category}}</option>
                            @endforeach
         @endif
                        </select>
                      </div>

                      <div class="form-group">
                        <label>Title</label>
                        <input type="text" class="form-control" value="{{$result[0]->title}}" name="title" placeholder="Title" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      <div class="form-group">
                        <label> Body</label>
                        <textarea class="form-control" rows="9"  name="body" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000">{{$result[0]->body}}</textarea>
                      </div>
                    </div>
                </div>
                </div>
                <div class="row">
                <div class="page-title">
                        <h5><b>Images</b></h5>
                </div>
                <div class="col-lg-4">
                      <div class="form-group">
                      <input type="file" name="file" class="form-control" value="{{url('/')}}/storage/images/{{$result[0]->post}}" onchange="readURL(this);">
                      <img id="blah" src="{{url('/')}}/storage/images/{{$result[0]->post}}" alt="Product Image" style="width:350px; height:300px;">
                      </div>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Done</button>
                </div>
                </div>

                </form>
                @endif
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


    @endsection
