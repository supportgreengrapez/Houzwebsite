@extends('admin.layout.appadmin')

@section('content')
    <!-- page content -->
    <div class="right_col" role="main">
    <div class="page-title">
          <div class="title_left">
            <h3>Form Management</h3>
            <h4>Post View</h4>
          </div>
        </div>
      <div class="clearfix"></div>
      @if(count($result)>0)
                      @foreach($result as $results)
      <div class="wrap">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Id</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->pk_id}}</p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Category Name</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->category}}</p>
            
          </div>
        </div>
      </div>
      
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Topic</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->topic}}</p>
            
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Title</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p>{{$results->title}}</p>
            
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Product Description</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p>{{$results->description}}</p>
          </div>
        </div>
      </div>
      
      </div>
      @endforeach
         @endif
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>User Name</th>
                    <th>Comments</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                      <td>01</td>
                      <td>Kiran</td>
                      <td>Used sheet to make king dovet covet.Very happy with look and feek.</td>
                  </tr>
                   
                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    @endsection