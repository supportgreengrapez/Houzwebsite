@extends('admin.layout.appadmin')

@section('content')
<form method="post" action="{{url('/')}}/admin/home/create/seller" class="login-form" enctype="multipart/form-data">
  {{ csrf_field() }}
  @if($errors->any())
  <div class="alert alert-danger"> <strong>Danger!</strong> {{$errors->first()}} </div>
  @endif 
  <!-- page content -->
  <div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Seller Management</h3>
          <h4 style="display: block;">Add Seller</h4>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content">
            <div class="row">
              <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Basic Info</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>First Name</label>
                    <input type="text" class="form-control" name="fname" placeholder="First Name" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                  <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" class="form-control" name="lname" placeholder="Last Name" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                  <div class="form-group" >
                    <label>Email</label>
                    <input type="email" class="form-control" name="username" placeholder="User Name" maxlength="50" required>
                  
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Password" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  
                 
                  </div>
                  
                  <div class="form-group">
                    <label>Bussiness Name</label>
                    <input type="text" class="form-control" name="business_name" placeholder="Bussiness Name" pattern="[a-zA-Z0-9\s]+" maxlength="100" required>
                  </div>
                  
                  <div class="form-group">
                    <label>Address</label>
                    <input type="text" class="form-control" name="address" placeholder="Address" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                  
                  <div class="form-group">
                    <label>Postal/Zip Code</label>
                    <input type="text" class="form-control" name="zip" placeholder="Bussiness Name" pattern="[a-zA-Z0-9\s]+" maxlength="100" required>
                  </div>
                  <div class="form-group">
                    <label>Country</label>
                    <select name="country" class="form-control countries order-alpha" id="countryId">
    <option value="">Select Country</option>
</select>
                  </div>
                   <div class="form-group">
                    <label>State</label>
                    <select name="state" class="form-control states order-alpha" id="stateId">
    <option value="">Select State</option>
</select>
                  </div>
                  <div class="form-group">
                    <label>City</label>
                    <select name="city" class="form-control cities order-alpha" id="cityId">
    <option value="">Select City</option>
</select>
                  </div>
                  <div class="form-group">
                    <label>Phone</label>
                    <input type="tel" class="form-control" name="phone" placeholder="Phone" pattern="[a-zA-Z0-9\s]+" maxlength="100" required>
                  </div>
                  
                  <div class="form-group">
                    <label>Fax</label>
                    <input type="number" class="form-control" name="fax" placeholder="Fax" pattern="[a-zA-Z0-9\s]+" maxlength="100" required>
                  </div>
                  <div class="form-group">
                    <label>Image</label>
                    <input type="file" class="form-control" name="file" placeholder="Image" required>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Additional Seller Info</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Federal Text id No</label>
                    <input type="text" class="form-control" name="federal_tax" placeholder="Federal Text id No" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Name of Primary Contact</label>
                    <input type="tel" class="form-control" name="primary_contact" placeholder="Name of Primary Contact" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Name of Payee More</label>
                    <input type="text" class="form-control" name="payee" placeholder="Name of Payee More" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Customer Service</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <div class="checkbox">
                        <label class="checkbox">
                        <input name="admin_management" type="checkbox" value="1"/>

                          Same as primary? </label>
                      </div>
                  </div>
                  <div class="form-group">
                    <label>Phone</label>
                     <input type="tel" class="form-control" name="phone1" placeholder="Phone" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  
                  </div>
                  <div class="form-group">
                    <label>Fax</label>
                   <input type="text" class="form-control" name="fax1" placeholder="Fax" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  
                  </div>
                    <div class="form-group">
                    <label>Email</label>
                   <input type="text" class="form-control" name="email1" placeholder="Fax" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  
                  </div>
                  <div class="form-group">
                    <label>Support Hours More</label>
                    <input type="text" class="form-control" name="support_hourz" placeholder="Support Hours More" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Shipping & Handling</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-9 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <label>Ship To</label>
                     <select class="form-control">
              <option></option>
              <option>Days</option>
              <option>Weeks</option>
              <option>Months</option>
              <option>Years</option>
            </select>
</div>
              </div>
              <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                  <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16" for="inputEmail1">Standard Shipping<br>
            Time (days)<span style="color:#669a25;font-size:12px;font-style:italic;"> More</span></label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Min</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="number" class="form-control" placeholder="">
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <div class="row form-group">
              <label  class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Max</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="number" class="form-control" placeholder="">
              </div>
            </div>
          </div>
        </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Order & Returns</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16" for="inputEmail1">Is RMA required?</label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <input type="checkbox" name="checkboxes" id="ckbx3" class="a11y-checkbox">
            <label for="ckbx3" class="a11y-checkbox-label"></label>
          </div>
        </div>
                </div>
                <div class="row">
                  <div class="form-group row mt-20">
          <label class="col-lg-4 col-sm-12 col-xs-12 f-16" for="inputEmail1">Same as primary?</label>
          <div class="col-lg-4 col-sm-12 col-xs-12">
            <input type="checkbox" name="checkboxes" id="ckbx2" class="a11y-checkbox">
            <label for="ckbx2" class="a11y-checkbox-label"></label>
          </div>
        </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Address</label>
                      <input type="text" name ="return_address" placeholder="Address"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Country</label>
                      <input type="text" name ="return_country" placeholder="Country"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>City</label>
                      <input type="text" name ="return_city" placeholder="City"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>State</label>
                      <input type="text" name ="return_state" placeholder="State"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Postal/Zip Code</label>
                      <input type="text" name ="return_zip" placeholder="Postal/Zip Code"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Phone</label>
                      <input type="tel" name ="return_phone" placeholder="Phone"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Fax</label>
                      <input type="text" name ="return_fax" placeholder="Fax"  class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Order Notification Email</label>
                      <input type="text" name ="notification_email" placeholder="Order Notification Email"  class="form-control">
                  </div>
                </div>
            </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Bank Info</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Bank Name</label>
                      <input type="text" name ="bank_name" placeholder="Bank Name" class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Account No</label>
                      <input type="text" name ="account_no" placeholder="Account No" class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Account Type</label>
                      <input type="text" name ="account_type" placeholder="Account Type" class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Routing No.</label>
                      <input type="text" name ="routing_no" placeholder="Routing No." class="form-control">
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Cheque</label>
                    <input type="file" class="form-control" name="cheque" placeholder="Image" required>
                  </div>
                </div>
              </div>
            </div>
            
               
                  
                  
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="col-md-6 pull-right">
              <button name="submit" type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content -->
</form>
@endsection 