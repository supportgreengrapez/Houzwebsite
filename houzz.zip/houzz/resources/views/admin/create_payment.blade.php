@extends('admin.layout.appadmin')
@section('content') 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Reporting Management</h3>
        <h4 style="display: block;">Create Payment</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
        @if($result>0)
            @foreach($result as $results)
          <form method="post" enctype="multipart/form-data" action = "{{url('/')}}/admin/home/create/payment/{{$results->payment_id}}" >
            {{ csrf_field() }}
            @if($errors->any())
            <div class="alert alert-danger"> <strong></strong> {{$errors->first()}} </div>
            @endif
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label>Seller Name</label>
                  <input type="text" class="form-control" name="name" value="{{$results->fname}} {{$results->lname}}" readonly>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" name="username" value="{{$results->username}}" readonly>
                </div>
                <div class="form-group">
                  <label>Total Earning</label>
                  <input type="text" class="form-control" name="remaining" value="{{$results->remaining}}" readonly>
                </div>
                <div class="form-group">
                  <label>Amount Pay</label>
                  <input type="number" class="form-control" name="amount_pay">
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
              </div>
            </div>
          </form>
          @endforeach
          @endif </div>
      </div>
    </div>
  </div>
</div>
@endsection 