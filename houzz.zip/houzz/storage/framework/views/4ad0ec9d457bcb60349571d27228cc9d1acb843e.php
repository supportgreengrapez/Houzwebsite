<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">


            <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Reporting Management</h3>
            <h4>Order Detail</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">

          </div>
          </div>
        </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table  class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>

                  <th>SKU</th>
                    <th>Product Name</th>
                  <th>Total Price</th>
                      <th>Discounted Price</th>
                        <th>Discount</th>
                    <th> Size</th>
                    <th>Quantity</th>




                  </tr>
                </thead>
                <tbody>
             <?php if(count($result1)>0): ?>
             <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>

                  <tr>
                          <td><?php echo e($results->sku); ?></td>

                          <td><?php echo e($results->product_name); ?></td>

                         <td><?php echo e(number_format($results->price)); ?></td>
                         <?php if(empty($results->discount_price)): ?>
                         <td> ---</td>
                         <?php else: ?>
                             <td><?php echo e($results->discount_price); ?></td>
                             <?php endif; ?>
                             <?php if($results->percentage > 0): ?>
                                <td><?php echo e($results->percentage); ?>%</td>
                                <?php else: ?>
                                  <td> ---</td>
                                  <?php endif; ?>
                          <td><?php echo e($results->size); ?></td>
                          <td><?php echo e($results->quantity); ?></td>



                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
        </div>
      </div>
      <div class="row">
      	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
        <div class="title_left">
            <button type="button" class="btn btn-success">Print Invoice</button>
          </div>
        </div>
        <?php if(count($result)>0): ?>

      	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Order_id</h4>
           </div>
        </div>

        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->pk_id); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Customer Name</h4>
           </div>
        </div>

        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->fname); ?> <?php echo e($result[0]->lname); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Amount</h4>
           </div>
        </div>

        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e(number_format($result[0]->amount)); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Shipment</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">

            <p><?php echo e($result[0]->address); ?></p>
          </div>
        </div>
      </div>

        </div>
        <?php endif; ?>
      </div>
    </div>
    <!-- /page content -->

   <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/sale_reporting_detail_view.blade.php ENDPATH**/ ?>