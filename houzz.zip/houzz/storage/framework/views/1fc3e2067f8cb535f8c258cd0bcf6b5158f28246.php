<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Order Management</h3>
            <h4>Seller Subscription Invoice List</h4>
          </div>
          </div>
        </div>
      <div class="row">
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="password" class="form-control" id="inputPassword" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by Type :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="password" class="form-control" placeholder="1234-1234-">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="button" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>Order Id</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity </th>
                    <th>Amount</th>


                  </tr>
                </thead>
                <tbody>
                  <tr>
                  <?php if(count($result)>0): ?>
                  <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($results->order_id); ?></td>
                    <td><?php echo e($results->product_name); ?></td>
                    <td><?php echo e(number_format($results->price)); ?></td>
                    <td><?php echo e($results->quantity); ?></td>
                    <td><?php echo e(number_format($results->price * $results->quantity)); ?></td>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                  </tr>

                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/vendor/subscription_seller_invoice.blade.php ENDPATH**/ ?>