
<?php $__env->startSection('content'); ?>
<div class="gray-bg3 pb-70 pt-20">
  <div class="container">
    <div class="breadcrumb-tow mb-20">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="breadcrumb-title">
              <h1>FAQ</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--Breadcrumb Tow End--> 
    <!--Blog Area Start-->
    <div class="blog-area white-bg pt-1 pb-1">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-10">
            <div class="faqcontent">
              <div class="accordion" id="accordion2">
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseOne" aria-expanded="false"> How can i login as Seller?</h4>
                  </div>
                  <div id="collapseOne" class="accordion-body collapse" aria-expanded="false" style="height: 0px;">
                    <div class="accordion-inner">
                      <p>At top right corner select “login /signup” option. The login window will appear. Do click “I am seller ” & provide your login details along with products to upload with description.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo" aria-expanded="false"> How can i login as Customer/Buyer? </h4>
                  </div>
                  <div id="collapseTwo" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p> At top right corner select “login” option next to switch to services. The login window will appear. Do click “I am Customer/buyer” & provide your login details along with Profile.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseThree" aria-expanded="false"> How can i get help?</h4>
                  </div>
                  <div id="collapseThree" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>Please call +92 309- 49 777 66 for instant response or you can email your query to customer@houz.pk</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFourth" aria-expanded="false"> What is the warranty of products on portal?</h4>
                  </div>
                  <div id="collapseFourth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>Kindly refer to our Warranties page (link to warranty page). Please note that each item sold on houz is under warranty of the manufacturer/seller.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false"> What’s the expected delivery time of product ordered through portal?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>Delivery time varies per product depending on availability and policy of relevant seller.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false"> How can i get to know the details of product?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>The description given below at the every product incline the detail.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false"> Do you offer live chat?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>We offer live chat option in between buyer and houz, as well as buyer with seller.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false">The item I ordered is out of stock. What can i do now?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>Stock availability of all products are the sole responsibility of our Seller. Please contact the relevant vendor directly.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false"> Do you accept online payments?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>This feature is coming on future versions.</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false"> Can i exchange my order instead of returning?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>Please refer to our Return Policy</p>
                    </div>
                  </div>
                </div>
                <div class="accordion-group">
                  <div class="accordion-heading">
                    <h4 class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion2" href="#collapseFifth" aria-expanded="false"> What form of payments do you accept?</h4>
                  </div>
                  <div id="collapseFifth" class="accordion-body collapse" aria-expanded="false">
                    <div class="accordion-inner">
                      <p>We currently offer Cash on Delivery, jazz cash, direct bank transfer, easy paisa and credit card in future. </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/faq.blade.php ENDPATH**/ ?>