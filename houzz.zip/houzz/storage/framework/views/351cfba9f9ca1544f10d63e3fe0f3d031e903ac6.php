
<?php $__env->startSection('content'); ?> 
<!-- page content -->
<div class="right_col" role="main">
  <div class="page-title">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="title_left">
        <h3>Message Management</h3>
        <h4>Message List</h4>
      </div>
    </div>
  </div>
  <div id="exTab1" class="container">
    <ul  class="nav nav-pills" style="border-bottom:2px solid #6d9b25;">
      <li class="active"> <a  href="#1a" data-toggle="tab">New Message</a> </li>
      <li><a href="#2a" data-toggle="tab">Delivered Message</a> </li>
    </ul>
    <div class="tab-content clearfix">
      <div class="tab-pane active" id="1a"> <?php if(count($result)>0): ?>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="messg"><a href="<?php echo e(url('/')); ?>/vendor/home/send/message/<?php echo e($results->pk_id); ?>"> <?php
          $seller = DB::select("select* from client_details where pk_id ='$results->customer_name'");
          ?>
          <div class="row borderbotm">
            <div class="col-lg-3 col-md-3 col-sm-12">
              <div class="dbicon">
                <h3><span><?php echo e($results->date); ?></span><br>
                  <?php if(count($seller)>0): ?> <?php echo e($seller[0]->fname); ?> <?php echo e($seller[0]->lname); ?> <?php endif; ?></h3>
              </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
              <div class="dbparahs">
                <p><?php echo e($results->message); ?></p>
                <h6><?php echo e($results->reply); ?></h6>
              </div>
            </div>
          </div>
          </a></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?> </div>
      <div class="tab-pane" id="2a">
      <?php if(count($result1)>0): ?>
        <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="messg"><a href="<?php echo e(url('/')); ?>/vendor/home/send/message/<?php echo e($results->pk_id); ?>"> <?php
          $seller = DB::select("select* from client_details where pk_id ='$results->customer_name'");
          ?>
          <div class="row borderbotm">
            <div class="col-lg-3 col-md-3 col-sm-12">
              <div class="dbicon">
                <h3><span><?php echo e($results->date); ?></span><br>
                  <?php if(count($seller)>0): ?> <?php echo e($seller[0]->fname); ?> <?php echo e($seller[0]->lname); ?> <?php endif; ?></h3>
              </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
              <div class="dbparahs">
                <p><?php echo e($results->message); ?></p>
                <h6><?php echo e($results->reply); ?></h6>
              </div>
            </div>
          </div>
          </a></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>  </div>
    </div>
  </div>
</div>
<!-- /page content --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/message_list_view.blade.php ENDPATH**/ ?>