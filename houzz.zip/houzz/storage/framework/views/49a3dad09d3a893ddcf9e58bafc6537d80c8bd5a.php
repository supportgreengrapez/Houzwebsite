
<?php $__env->startSection('content'); ?> 
  <!--Breadcrumb Tow Start-->
  <div class="gray-bg3">
    <div class="container">
      <div class="white-bg p-3">
        <div class="">
          <div class="page-title">
            <div class="row">
              <div class="col-10">
                <div class="salogan">
                  <h2 class="text-center font-weight-bold">Payment List</h2>
                </div>
              </div>
              <div class="col-md-2 col-sm-12 col-xs-12">
                <div class="title_left"> <a href="<?php echo e(url('/')); ?>/client/add/payment/view" type="button" class="add-btns pull-right">Create Payment</a> </div>
              </div>
            </div>
          </div>
        </div>
        <form method="post" action = "<?php echo e(url('/')); ?>/client/search/payment/by/id"   enctype="multipart/form-data" >
              <?php echo e(csrf_field()); ?>

              <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
        <div class="row">
          <div class="col-lg-6 mt-20">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label">Search by Payment Id :</label>
              <div class="col-lg-5 col-sm-12 col-xs-12">
                <input type="number" name="search" class="form-control" placeholder="Enter Invoice#">
              </div>
              <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
                <button type="submit" class="add-btns">Search</button>
              </div>
            </div>
          </div>
        </div>
        </form>
        <form method="post" action = "<?php echo e(url('/')); ?>/client/search/payment/by/status"   enctype="multipart/form-data" >
              <?php echo e(csrf_field()); ?>

        <div class="row">
          <div class="col-lg-4 mt-20">
            <div class="row form-group">
              <label class="col-lg-6 col-sm-12 col-form-label">Filter by Status :</label>
              <div class="col-lg-6 col-sm-12 col-xs-12">
                <select class="form-control" name="status" >
                <option >Select Status</option>
                  <option value="0">Submitted</option>
                  <option value="1">Approved</option>
                  <option value="2">Rejected</option>
                  <option value="3">Pending</option>
                </select>
              </div>
            </div>
          </div>
          <div class="col-lg-4 mt-20">
            <div class="row form-group">
              <label class="col-lg-5 col-sm-12 col-form-label">Date range :</label>
            
            </div>
          </div>
          <div class="col-lg-2 mt-20">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label">From</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="date" name="start_date" class="form-control">
              </div>
            </div>
          </div>
          <div class="col-lg-2 mt-20">
            <div class="row form-group">
              <label class="col-lg-4 col-sm-12 col-form-label">To</label>
              <div class="col-lg-8 col-sm-12 col-xs-12">
                <input type="date" name="end_date" class="form-control">
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12 ccol-sm-6 col-xs-6">
            <button type="submit" class="add-btns pull-right mb-20">Filter Results</button>
          </div>
        </div>

        </form>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <table id="myTable" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
              
                  <th>Invoice No</th>
                  <th>Payment Receipt</th>
                  <th>Payee</th>
                  <th>Payer</th>
                  <th>Date </th>
                  <th>Amount</th>
                  <th>Status </th>
                </tr>
              </thead>
              <tbody>
              <?php if(count($result)>0): ?>
              <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
             
                  <td><?php echo e($results->invoice_no); ?></td>
                  <td><img src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="img"></td>
                  <td><?php echo e($results->payee); ?></td>
                  <td><?php echo e($results->payer); ?></td>
                  <td><?php echo e($results->date); ?></td>
                  <td><?php echo e(number_format($results->amount)); ?></td>
                  <?php if($results->status == 0): ?>
                  <td><label class="label label-info">Submitted</label></td>
                  <?php elseif($results->status == 1): ?>
                  <td><label class="label label-info">Approved</label></td>
                  <?php elseif($results->status == 2): ?>
                  <td><label class="label label-info">Rejected</label></td>
                  <?php else: ?>
                  <td><label class="label label-info">Pending</label></td>
                  <?php endif; ?>

                </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/payment_list_view.blade.php ENDPATH**/ ?>