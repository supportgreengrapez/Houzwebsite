 
<?php $__env->startSection('content'); ?> 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Seller Management</h3>
          <h4>Commission Seller</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>Seller ID</th>
              <th> Name</th>
              <th>Email</th>
              <th>Package</th>
              <th>No. of Products</th>
              <th>No. of orders</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          
          <?php if($result>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $user_id = $results->vendor_id;
          $user = DB::select("select* from client_details where pk_id ='$user_id'");
          $product = DB::select("select* from product where vendor_id ='$user_id'");
          $order = DB::select("select DISTINCT(order_id) from detail_table where vendor_id ='$user_id'");
          
          ?>
          <tr>
            <td><?php echo e($results->vendor_id); ?></td>
            <td><?php echo e($user[0]->fname); ?> <?php echo e($user[0]->lname); ?></td>
            <td><?php echo e($user[0]->username); ?></td>
            <td>Commission</td>
            <td><?php echo e(count($product)); ?></td>
            <td><?php echo e(count($order)); ?></td>
            <td><a href="<?php echo e(url('/')); ?>/admin/home/view/vendor/<?php echo e($results->vendor_id); ?>" class="green">View</a> | <a href="<?php echo e(url('/')); ?>/admin/home/view/vendor/orders/<?php echo e($results->vendor_id); ?>">Order View</a></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/commission_vendor_list_view.blade.php ENDPATH**/ ?>