<?php $__env->startSection('content'); ?>

<?php if($result>0): ?>
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Client Management</h3>
            <h4 style="display:block;">Client View</h4>
        </div>
      </div>
      <div class="wrap">
     
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->name); ?></p>
          </div>
        </div>
      </div>
     
       <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Email</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->email); ?></p>
          </div>
        </div>
      </div>
      
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Address</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->address); ?></p>
          </div>
        </div>
      </div>

        <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Phone</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->phone); ?></p>
          </div>
        </div>
      </div>
      
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Country</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->country); ?></p>
          </div>
        </div>
      </div>
      
        <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>State</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->state); ?></p>
          </div>
        </div>
      </div>
      
        <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>City</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->city); ?></p>
          </div>
        </div>
      </div>
      
        <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Zip Code</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->zip); ?></p>
          </div>
        </div>
      </div>
      </div> 
  
    </div>

        <?php endif; ?>

     <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/vendor/offline_client_detail_view.blade.php ENDPATH**/ ?>