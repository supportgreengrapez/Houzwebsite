<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Forum Management</h3>
            <h4 style="display: block;">Edit Forum Category</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
              <?php if($result>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/forum/category/<?php echo e($results->pk_id); ?>" class="login-form">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong>Danger!</strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
              <div class="row">
                <div class="col-lg-5">
                    <div class="row">
                      <div class="form-group col-lg-12 col-sm-12 col-md-12">
                        <label>Main Category</label>
                        <input type="text" class="form-control" value="<?php echo e($results->category); ?>" name="forumCategory" placeholder="Main Category" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>

                    </div>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
                </div>

                </form>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


          <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/edit_forum_category.blade.php ENDPATH**/ ?>