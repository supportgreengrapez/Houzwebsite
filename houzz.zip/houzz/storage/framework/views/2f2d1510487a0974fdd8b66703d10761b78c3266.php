<?php $__env->startSection('content'); ?> 
<!-- Nice Select CSS-->

<div class="gray-bg3">
  <div class="shop-area mb-20">
    <div class="container-fluid">
      <div class="white-bg p-3"> 

        <!--Breadcrumb One Start-->
        <div class="breadcrumb-content breadcrumb-content-tow mt-20 mb-20">
          <ul>
            <li><a href="<?php echo e(url('/')); ?>/">Home</a></li>
            <li><a href="<?php echo e(url('/')); ?>/product/<?php echo e($main); ?>"><?php echo e($main); ?></a></li>
            <li class="active"><?php echo e($sub); ?></li>
            
                      <input type="hidden" name="sub" class="m" value="<?php echo e($sub); ?>">
          </ul>
        </div>
        <!--Breadcrumb One End-->
        <div class="home-product-layout-area mt-20">
          <h3><?php echo e($main); ?></h3>
          <div class="row"> <?php if(count($main_category)>0): ?>
            <?php $__currentLoopData = $main_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3">
              <div class="img-box"> <img src="<?php echo e(URL('/')); ?>/pic/31.png" alt=""> </div>
              <div class="thumb-content">
                <h4><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></h4>
                
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="shop-area">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="white-bg p-3">
            <div class="shop-layout">
              <div class="shop-topbar-wrapper mt-20">
                <div class="row">
                  <!--<div class="col-lg-2 mt-10"> <a href="#open-modals" title="Quick view" data-toggle="modal" class="btn filterbutton"><i class="fa fa-sliders mr-10"></i>All Filters </a> </div>-->
                  <div class="col-lg-2 mt-10">
                    <select class="form-control" name="style" id="style">
                        <option value="" disable="true" selected="true" >---Select Style---</option>
                    <?php if($style>0): ?>
                    <?php $__currentLoopData = $style; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(urlencode($results->pk_id)); ?>"><?php echo e($results->style); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </select>
                  </div>
                  <div class="col-lg-2 mt-10">
                    <select class="form-control" name="brand" id="brand">
                        <option value="" disable="true" selected="true" >---Select Brand---</option>
                        <?php if($brand>0): ?>
                        <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(urlencode($results->SKU)); ?>"><?php echo e($results->brand_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                  </div>
                  <div class="col-lg-2 mt-10">
                      
                    <select class="form-control"  name="price" id="price">
                        <option value="" disable="true" selected="true" >---Select Price---</option>
                      <option value="1">Low to High</option>
                      <option value="2">High to Low</option>
                    </select>
                  </div>
                  <div class="col-lg-2 mt-10">
                    <select class="form-control" name="material" id="material">
                        <option value="" disable="true" selected="true" >---Select Material---</option>
                        <?php if($material>0): ?>
                        <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(urlencode($results->pk_id)); ?>"><?php echo e($results->material); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                  </div>
                  
                <div class="col-lg-2 text-right mt-10">
                  <div class="grid-list-option">
                    <ul class="nav">
                      <li> <a  class="active"  data-toggle="tab" href="#grid"><i class="fa fa-th-large"></i></a> </li>
                      <li> <a data-toggle="tab" href="#list"><i class="fa fa-th-list"></i></a> </li>
                    </ul>
                  </div>
                </div>
                </div>
              </div>
              <!--Shop Product Start-->
              <div class="shop-product">
                <div id="myTabContent-2" class="tab-content">
                  <div id="grid" class="tab-pane fade show active">
                    <div class="product-grid-view">
                          
                      <div class="row">
                          
                          <div id="subCategory">
                              
                              
                          
                           <?php if(count($result)>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <div class="col-md-3" style="float:left;"> 
                          <!--Single Product Start-->
                          <div class="single-product mb-25">
                                       
                            <div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="" style=" position: relative;"> </a>
                              <div class="product-action">
                                <ul>
                                  <li><a href="#open-modal<?php echo e($results->pk_id); ?>" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                </ul>
                              </div>
                            </div>
                            <div class="product-content">
                              <h2><a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"><?php echo e($results->name); ?></a></h2>
                              <p>PKR <?php echo e(number_format($results->price)); ?></p>
                              <div class="product-price">
                                <div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/<?php echo e($results->pk_id); ?>" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                              </div>
                            </div>
                          </div>
                          <!--Single Product End--> 
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </div>
                         <?php if(count($result)>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Modal Area Strat -->
                          <div class="modal fade" id="open-modal<?php echo e($results->pk_id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                </div>
                                <div class="modal-body">
                                  <div class="row"> 
                                    <!--Modal Img-->
                                    <div class="col-md-5"> 
                                      <!--Modal Tab Content Start-->
                                      <div class="tab-content product-details-large" id="myTabContent">
                                        <div class="tab-pane fade show active" id="single-slide1" role="tabpanel" aria-labelledby="single-slide-tab-1"> 
                                          <!--Single Product Image Start-->
                                          <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt=""> </div>
                                          <!--Single Product Image End--> 
                                        </div>
                                        <div class="tab-pane fade" id="single-slide2" role="tabpanel" aria-labelledby="single-slide-tab-2"> 
                                          <!--Single Product Image Start-->
                                          <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail2); ?>" alt=""> </div>
                                          <!--Single Product Image End--> 
                                        </div>
                                        <div class="tab-pane fade" id="single-slide3" role="tabpanel" aria-labelledby="single-slide-tab-3"> 
                                          <!--Single Product Image Start-->
                                          <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail3); ?>" alt=""> </div>
                                          <!--Single Product Image End--> 
                                        </div>
                                      </div>
                                      <!--Modal Content End--> 
                                      <!--Modal Tab Menu Start-->
                                      <div class="single-product-menu">
                                        <div class="nav single-slide-menu owl-carousel" role="tablist">
                                          <div class="single-tab-menu img-full"> <a class="active" data-toggle="tab" id="single-slide-tab-1" href="#single-slide1"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt=""></a> </div>
                                          <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-2" href="#single-slide2"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail2); ?>" alt=""></a> </div>
                                          <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-3" href="#single-slide3"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail3); ?>" alt=""></a> </div>
                                        </div>
                                      </div>
                                      <!--Modal Tab Menu End--> 
                                    </div>
                                    <!--Modal Img--> 
                                    <!--Modal Content-->
                                    <div class="col-md-7">
                                      <div class="modal-product-info">
                                        <h1><?php echo e($results->name); ?></h1>
                                        <div class="modal-product-price"><span class="new-price">PKR <?php echo e(number_format($results->price)); ?></span> </div>
                                        <div class="mb-10">
                                          <lable>Color</lable>
                                          <div class="color-choose"> <?php if(count($result)>0): ?> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($result[0]->pk_id); ?>/<?php echo e($result[0]->sku); ?>">
                                            <input id="black" type="button" name="color">
                                            <label><span style="background-color:<?php echo e($result[0]->color); ?> "></span></label>
                                            </a>
                                            <?php endif; ?> </div>
                                        </div>
                                        <div>
                                          <div class="form-group">
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Urgent Delivery">
                                                <span class="label-text">Urgent Delivery PKR<?php echo e($results->urgent_charges); ?> <?php echo e($result[0]->urgent_time); ?> Days</span> </label>
                                            </div>
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Express Delivery">
                                                <span class="label-text">Express Delivery PKR<?php echo e($results->express_charges); ?> <?php echo e($result[0]->express_time); ?> Days</span> </label>
                                            </div>
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Normal Delivery" checked>
                                                <span class="label-text">Normal Delivery PKR<?php echo e($results->normal_charges); ?> <?php echo e($result[0]->normal_time); ?> Days</span> </label>
                                            </div>
                                            <div>
                                              <label>
                                                <input type="radio" name="tab" value="Free Delivery">
                                                <span class="label-text">Free Delivery <?php echo e($results->free_delivery); ?></span> </label>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="add-to-cart quantity">
                                          <div class="add-to-link">
                                            <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"  class="add-btn text-center">add to cart</a>
                                          </div>
                                        </div>
                                        <div class="faq-accordion">
                                          <div id="accordion">
                                            <div class="card">
                                              <div class="card-header" id="headingThree">
                                                <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"> Product Description </a> </h5>
                                              </div>
                                              <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                                <div class="card-body"> <?php echo e($results->description); ?></div>
                                              </div>
                                            </div>
                                            <div class="card">
                                              <div class="card-header" id="headingTwo">
                                                <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> Product Specifications </a> </h5>
                                              </div>
                                              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                                <div class="card-body"> <?php echo e($results->material); ?> <?php echo e($results->style); ?></div>
                                              </div>
                                            </div>
                                            <div class="card">
                                              <div class="card-header" id="headingFour">
                                                <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour"> Shipping & Returns </a> </h5>
                                              </div>
                                              <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                                                <div class="card-body"> <?php echo e($results->return_policy); ?> </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Modal Content--> 
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        <!-- Modal Area End --> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?> 
                        
                        
                        </div>
                    </div>
                  </div>
                  <div id="list" class="tab-pane fade">
                    <div class="product-list-view"> <?php if(count($result)>0): ?>
                      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="product-list-item mb-40">
                        <div class="row"> 
                          <!--Single List Product Start-->
                          <div class="col-md-2">
                            <div class="single-product">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt=""> </a> </div>
                            </div>
                          </div>
                          <div class="col-md-8">
                            <div class="product-content shop-list">
                              <h1><a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"><?php echo e($results->name); ?></a></h1>
                              <div class="product-description">
                                <p class="text-justify"><?php echo e($results->description); ?></p>
                              </div>
                              <div class="product-price">
                                <div class="price-box">
                                  <h4 class="regular-price">PKR <?php echo e(number_format($results->price)); ?></h4>
                                </div>
                              </div>
                              <div class="product-list-action">
                                <div class="add-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>">Add To Cart</a> </div>
                              </div>
                            </div>
                          </div>
                          <!--Single List Product End--> 
                        </div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?> </div>
                  </div>
                </div>
              </div>
              <!--Shop Product End--> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Area Strat -->
<div class="modal fade" id="open-modals" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document" style="max-width:63%;">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
      </div>
      <div class="modal-body" style="padding:34px 0px 34px 0px;">
        <div class="row"> 
          
          <!--Modal Content-->
          
          <div class="col-md-4"> 
            <!--Modal Tab Content Start-->
            <div class="tab-content product-details-large">
              <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'Customer Rating')" id="defaultOpen">Customer Rating <i class="fa fa-chevron-right pull-right"></i></button>
                <button class="tablinks" onclick="openCity(event, 'Style')">Style <i class="fa fa-chevron-right pull-right"></i></button>
                <button class="tablinks" onclick="openCity(event, 'Price')">Price <i class="fa fa-chevron-right pull-right"></i></button>
                <button class="tablinks" onclick="openCity(event, 'Sale')">Sale <i class="fa fa-chevron-right pull-right"></i></button>
                <button class="tablinks" onclick="openCity(event, 'Brand')">Brand <i class="fa fa-chevron-right pull-right"></i></button>
                <button class="tablinks" onclick="openCity(event, 'Color')">Color <i class="fa fa-chevron-right pull-right"></i></button>
                <button class="tablinks" onclick="openCity(event, 'Material')">Material <i class="fa fa-chevron-right pull-right"></i></button>
              </div>
            </div>
            <!--Modal Content End--> 
          </div>
          <div class="col-md-8">
            <div class="modal-product-info">
              <div id="Customer Rating" class="tabcontent active">
                <h3>Fillter By Customer Rating</h3>
                <div class="row">
                  <div class="col-6"> 
                    <!-- Group of default radios - option 1 -->
                    
                    <div class="custom-control custom-radio mt-20">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample21" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample21"><span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star"></span> & up</label>
                    </div>
                    <div class="custom-control custom-radio mt-20">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample22" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample22"><span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> & up</label>
                    </div>
                  </div>
                  <div class="col-6"> 
                    
                    <!-- Group of default radios - option 2 -->
                    <div class="custom-control custom-radio mt-20">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample23" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample23"><span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star checked"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> & up</label>
                    </div>
                    
                    <!-- Group of default radios - option 3 -->
                    <div class="custom-control custom-radio mt-20">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample24" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample24"><span class="fa fa-star checked"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> & up</label>
                    </div>
                  </div>
                </div>
              </div>
              <div id="Style" class="tabcontent">
                <h3>Fillter By Style</h3>
                <div class="row">
                  <div class="col-lg-6 col-sm-12"> 
                    <!-- Material checked --> 
                    <!-- Default checked -->
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked91">
                      <label class="custom-control-label" for="defaultChecked91">Contemporary</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked92">
                      <label class="custom-control-label" for="defaultChecked92">Modern </label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked93">
                      <label class="custom-control-label" for="defaultChecked93">Asian</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked94">
                      <label class="custom-control-label" for="defaultChecked94">Craftman</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked95">
                      <label class="custom-control-label" for="defaultChecked95">Industial</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked96">
                      <label class="custom-control-label" for="defaultChecked96">Midcentury</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked97">
                      <label class="custom-control-label" for="defaultChecked97">Scandinavian</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked98">
                      <label class="custom-control-label" for="defaultChecked98">Transitional</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked99">
                      <label class="custom-control-label" for="defaultChecked99">Victorian</label>
                    </div>
                  </div>
                  <div class="col-lg-6 col-sm-12"> 
                    <!-- Material checked --> 
                    <!-- Default checked -->
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked101">
                      <label class="custom-control-label" for="defaultChecked101">Eclectic</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked102">
                      <label class="custom-control-label" for="defaultChecked102">Traditional</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked103">
                      <label class="custom-control-label" for="defaultChecked103">Beach Style</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked104">
                      <label class="custom-control-label" for="defaultChecked104">Farmhouse</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked105">
                      <label class="custom-control-label" for="defaultChecked105">Mediterranean</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked106">
                      <label class="custom-control-label" for="defaultChecked106">Rustic</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked107">
                      <label class="custom-control-label" for="defaultChecked107">Southwestern</label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked108">
                      <label class="custom-control-label" for="defaultChecked108">Tropical</label>
                    </div>
                  </div>
                </div>
              </div>
              <div id="Price" class="tabcontent">
                <h3>Fillter By Price</h3>
                <div class="row">
                  <div class="col-6"> 
                    <!-- Group of default radios - option 1 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample1" name="groupOfDefaultRadios">
                      <label class="custom-control-label" for="defaultGroupExample1">All sale</label>
                    </div>
                    
                    <!-- Group of default radios - option 2 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample2" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample2">25% off or more</label>
                    </div>
                    
                    <!-- Group of default radios - option 3 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample3" name="groupOfDefaultRadios">
                      <label class="custom-control-label" for="defaultGroupExample3">75% off or more</label>
                    </div>
                  </div>
                  <div class="col-6"> 
                    
                    <!-- Group of default radios - option 2 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample4" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample4">10% off or more</label>
                    </div>
                    
                    <!-- Group of default radios - option 3 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample5" name="groupOfDefaultRadios">
                      <label class="custom-control-label" for="defaultGroupExample5">50% off or more</label>
                    </div>
                  </div>
                </div>
                <div class="row mt-20">
                  <div class="col-lg-12">
                    <div class="bt">
                      <h5>Enter Amount</h5>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-3 col-sm-12 mt-10">
                    <form class="form-inline">
                      <div class="form-group divset">
                        <label for="focusedInput">$</label>
                        <input class="form-control" type="text">
                      </div>
                    </form>
                  </div>
                  <div class="col-1 text-center mt-10">
                    <p>To</p>
                  </div>
                  <div class="col-lg-3 mt-10">
                    <form class="form-inline">
                      <div class="form-group divset">
                        <label for="focusedInput">$</label>
                        <input class="form-control" type="text">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div id="Sale" class="tabcontent">
                <h3>Fillter By Sale</h3>
                <div class="row">
                  <div class="col-6"> 
                    <!-- Group of default radios - option 1 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample11" name="groupOfDefaultRadios">
                      <label class="custom-control-label" for="defaultGroupExample11">All sale</label>
                    </div>
                    
                    <!-- Group of default radios - option 2 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample12" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample12">25% off or more</label>
                    </div>
                    
                    <!-- Group of default radios - option 3 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample13" name="groupOfDefaultRadios">
                      <label class="custom-control-label" for="defaultGroupExample13">75% off or more</label>
                    </div>
                  </div>
                  <div class="col-6"> 
                    
                    <!-- Group of default radios - option 2 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample14" name="groupOfDefaultRadios" checked>
                      <label class="custom-control-label" for="defaultGroupExample14">10% off or more</label>
                    </div>
                    
                    <!-- Group of default radios - option 3 -->
                    <div class="custom-control custom-radio mt-10">
                      <input type="radio" class="custom-control-input" id="defaultGroupExample15" name="groupOfDefaultRadios">
                      <label class="custom-control-label" for="defaultGroupExample15">50% off or more</label>
                    </div>
                  </div>
                </div>
              </div>
              <div id="Brand" class="tabcontent">
                <h3>Fillter By Brand</h3>
                <div class="row">
                  <div class="col-6"> 
                    <!-- Material checked --> 
                    <!-- Default checked -->
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked41">
                      <label class="custom-control-label" for="defaultChecked41">Dianoche Design <span class="brandcheckfont">(75,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked42">
                      <label class="custom-control-label" for="defaultChecked42">Society6 <span class="brandcheckfont">(55,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked43">
                      <label class="custom-control-label" for="defaultChecked43">Design Art <span class="brandcheckfont">(15,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked45">
                      <label class="custom-control-label" for="defaultChecked45">Surya <span class="brandcheckfont">(25,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked46">
                      <label class="custom-control-label" for="defaultChecked46">The Pillow Collection Inc.<span class="brandcheckfont">(5,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked47">
                      <label class="custom-control-label" for="defaultChecked47">The HomeCentric <span class="brandcheckfont">(12,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked2">
                      <label class="custom-control-label" for="defaultChecked2">CB Station <span class="brandcheckfont">(13,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked48">
                      <label class="custom-control-label" for="defaultChecked48">E By Design <span class="brandcheckfont">(9,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked49">
                      <label class="custom-control-label" for="defaultChecked49">Deny Designs <span class="brandcheckfont">(5,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked50">
                      <label class="custom-control-label" for="defaultChecked50">DDCG <span class="brandcheckfont">(15,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked51">
                      <label class="custom-control-label" for="defaultChecked51">Close To Custom Linens <span class="brandcheckfont">(18,956)</span></label>
                    </div>
                  </div>
                  <div class="col-6"> </div>
                </div>
              </div>
              <div id="Color" class="tabcontent">
                <h3>Fillter By Color</h3>
                <h3>Long list of colors</h3>
                colorpicker-longlist:
                <select name="colorpicker-longlist">
                  <option value="#ac725e">#ac725e</option>
                  <option value="#d06b64">#d06b64</option>
                  <option value="#f83a22">#f83a22</option>
                  <option value="#fa573c">#fa573c</option>
                  <option value="#ff7537">#ff7537</option>
                  <option value="#ffad46">#ffad46</option>
                  <option value="#42d692">#42d692</option>
                  <option value="#16a765">#16a765</option>
                  <option value="#7bd148">#7bd148</option>
                  <option value="#b3dc6c">#b3dc6c</option>
                  <option value="#fbe983">#fbe983</option>
                  <option value="#fad165">#fad165</option>
                  <option value="#92e1c0">#92e1c0</option>
                  <option value="#9fe1e7">#9fe1e7</option>
                  <option value="#9fc6e7">#9fc6e7</option>
                  <option value="#4986e7">#4986e7</option>
                  <option value="#9a9cff">#9a9cff</option>
                  <option value="#b99aff">#b99aff</option>
                  <option value="#c2c2c2">#c2c2c2</option>
                  <option value="#cabdbf">#cabdbf</option>
                  <option value="#cca6ac">#cca6ac</option>
                  <option value="#f691b2">#f691b2</option>
                  <option value="#cd74e6">#cd74e6</option>
                  <option value="#a47ae2">#a47ae2</option>
                </select>
              </div>
              <div id="Material" class="tabcontent">
                <h3>Fillter By Material</h3>
                <div class="row">
                  <div class="col-6"> 
                    <!-- Material checked --> 
                    <!-- Default checked -->
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked61">
                      <label class="custom-control-label" for="defaultChecked61">Dianoche Design <span class="brandcheckfont">(75,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked62">
                      <label class="custom-control-label" for="defaultChecked62">Society6 <span class="brandcheckfont">(55,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked63">
                      <label class="custom-control-label" for="defaultChecked63">Design Art <span class="brandcheckfont">(15,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked65">
                      <label class="custom-control-label" for="defaultChecked65">Surya <span class="brandcheckfont">(25,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked66">
                      <label class="custom-control-label" for="defaultChecked66">The Pillow Collection Inc.<span class="brandcheckfont">(5,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked67">
                      <label class="custom-control-label" for="defaultChecked67">The HomeCentric <span class="brandcheckfont">(12,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked68">
                      <label class="custom-control-label" for="defaultChecked68">CB Station <span class="brandcheckfont">(13,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked69">
                      <label class="custom-control-label" for="defaultChecked69">E By Design <span class="brandcheckfont">(9,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked70">
                      <label class="custom-control-label" for="defaultChecked70">Deny Designs <span class="brandcheckfont">(5,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked71">
                      <label class="custom-control-label" for="defaultChecked71">DDCG <span class="brandcheckfont">(15,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked72">
                      <label class="custom-control-label" for="defaultChecked72">Close To Custom Linens <span class="brandcheckfont">(18,956)</span></label>
                    </div>
                  </div>
                  <div class="col-6"> 
                    <!-- Material checked --> 
                    <!-- Default checked -->
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked73">
                      <label class="custom-control-label" for="defaultChecked73">Dianoche Design <span class="brandcheckfont">(75,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked74">
                      <label class="custom-control-label" for="defaultChecked74">Society6 <span class="brandcheckfont">(55,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked75">
                      <label class="custom-control-label" for="defaultChecked75">Design Art <span class="brandcheckfont">(15,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked76">
                      <label class="custom-control-label" for="defaultChecked76">Surya <span class="brandcheckfont">(25,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked77">
                      <label class="custom-control-label" for="defaultChecked77">The Pillow Collection Inc.<span class="brandcheckfont">(5,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked78">
                      <label class="custom-control-label" for="defaultChecked78">The HomeCentric <span class="brandcheckfont">(12,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked79">
                      <label class="custom-control-label" for="defaultChecked79">CB Station <span class="brandcheckfont">(13,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked80">
                      <label class="custom-control-label" for="defaultChecked80">E By Design <span class="brandcheckfont">(9,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked81">
                      <label class="custom-control-label" for="defaultChecked81">Deny Designs <span class="brandcheckfont">(5,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked82">
                      <label class="custom-control-label" for="defaultChecked82">DDCG <span class="brandcheckfont">(15,956)</span></label>
                    </div>
                    <div class="custom-control custom-checkbox mt-10">
                      <input type="checkbox" class="custom-control-input" id="defaultChecked83">
                      <label class="custom-control-label" for="defaultChecked83">Close To Custom Linens <span class="brandcheckfont">(18,956)</span></label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-12 col-sm-12 text-right">
            <div class="add-to-link modalbtnstyle">
              <button class="product-btn" type="submit" data-text="add to cart">Done</button>
            </div>
          </div>
          <!--Modal Content--> 
        </div>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/product_list.blade.php ENDPATH**/ ?>