<!doctype html>
<html class="no-js" lang="en">

<!-- Mirrored from d29u17ylf1ylz9.cloudfront.net/plantmore-v3/index-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Oct 2018 12:38:11 GMT -->
<head>
<meta charset="utf-8">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Houzz</title>
<meta name="description" content="">
<meta name="robots" content="noindex, follow" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow"/>
<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('/')); ?>/pic/favicon.png">
<!--All Css Here-->

<!-- Bootstrap CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/bootstrap.min.css">
<!-- Linearicon CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/linearicons.min.css">
<!-- Font Awesome CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/font-awesome.min.css">

<!-- Animate CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/animate.css">
<!-- Owl Carousel CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/owl.carousel.min.css">
<!-- Slick CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/slick.css">
<!-- Meanmenu CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/meanmenu.min.css">
<!-- Easyzoom CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/easyzoom.css">
<!-- Venobox CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/venobox.css">
<!-- Jquery Ui CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/jquery-ui.css">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/responsive.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css" rel="stylesheet" />
<!-- Modernizr Js -->
<script src="<?php echo e(url('/')); ?>/js1/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body>
<!--[if lt IE 8]>
	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
<div class="wrapper">
  <!--Header Area Start-->
  <header>
    <div class="header-container">
      <!--Header Top Area Start-->
      <div class="header-top-area black-bg">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-8">
              <!--Header Top Left Start-->
              <div class="header-top-left">
                <div class="header-top-language-currency">
                  <div class="switcher">
                    <p>Free Deliver <strong style="color:#689a29;">Applies on more then 50$ and return is always free</strong> </p>
                  </div>
                </div>
              </div>
              <!--Header Top Left End-->
            </div>
            <div class="col-lg-4 col-md-4">
              <!--Header Top Right Start-->
              <div class="header-top-right">
                <ul class="menu-top-menu text-md-right">
                  <li><a href=""><i class="fa fa-facebook"></i></a></li>
                  <li><a href=""><i class="fa fa-twitter"></i></a></li>
                  <li><a href=""><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <!--Header Top Right End-->
            </div>
          </div>
        </div>
      </div>
      <!--Header Top Area End-->
      <!--Header Middle Area Start-->
      <div class="header-middle-area">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-lg-3 col-md-4">
              <!--Header Logo Start-->
              <div class="header-logo"> <a href="index.html"><img src="<?php echo e(url('/')); ?>/pic/logo.png" alt=""></a> </div>
              <!--Header Logo End-->
            </div>
            <div class="col-xl-4 col-lg-3 col-md-10">
              <!--Header Search Area-->
              <div class="header-search-area">
              <form  role="form" action="<?php echo e(url('/')); ?>/search" method="post" id="payment-form">
          <?php echo e(csrf_field()); ?>

                  <div class="form-input">
                    <input name="search" id="search" placeholder="Search ...."  onblur="if(this.value==''){this.value='Search...'}" onfocus="if(this.value=='Search...'){this.value=''}" type="text">
                    <button type="submit" class="header-search-btn"><i class="fa fa-search"></i></button>
                  </div>
                </form>
              </div>
              <!--Header Search Area-->
            </div>
            <div class="col-xl-4 col-lg-3 col-md-4">
              <div class="header-top-right">
                <ul class="nav justify-content-center">
                  <li class="nav-item"> <a class="nav-link" href="#">Forums</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#">Maps</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/blog">Blog</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#">Propert ID Search</a> </li>
                </ul>
              </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-4">
              <div class="mini-cart"> <a href="#"> <span class="cart-icon"> <span class="cart-quantity"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : '0'); ?></span> </span> <span class="cart-title">Your cart <br>
                <strong>PKR <?php echo e(number_format($totalPrice)); ?></strong></span> </a>
                <!--Cart Dropdown Start-->
                <?php if(Session::has('cart')): ?>
                <div class="cart-dropdown">
                  <ul>



<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="single-cart-item">
                      <div class="cart-img"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($product['item']->thumbnail); ?>" alt=""> </div>
                      <div class="cart-content">
                        <h5 class="product-name"><?php echo e($product['item']->name); ?></h5>
                        <span class="cart-price"><?php echo e($product['qty']); ?> × PKR <?php echo e(number_format($product['item']->price)); ?>

        <?php if($product['save']>0): ?> saving -<?php echo e($product['save']); ?><?php endif; ?></span> </div>
                      <div class="cart-remove"> <a title="Remove" href="<?php echo e(URL('/')); ?>/remove/item/cart/<?php echo e($product['item']->pk_id); ?>/<?php echo e($product['size']); ?>/<?php echo e($product['qty']); ?>"><i class="fa fa-times"></i></a> </div>
                    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>
                  <p class="cart-subtotal"><strong>Subtotal:</strong> <span class="float-right">PKR <?php echo e(number_format($totalPrice)); ?></span></p>
                  <p class="cart-btn"> <a href="<?php echo e(url('/')); ?>/cart">View cart</a> <a href="<?php echo e(url('/')); ?>/cart/checkout">Checkout</a> </p>
                </div>
                <?php endif; ?>
                <!--Cart Dropdown End-->
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Header Middle Area End-->
      <!--Header Bottom Area Start-->
      <div class="header-bottom-area header-sticky">
        <div class="header-boxshadow">
          <div class="header-inner">
            <div class="container">
              <div class="row">
                <div class="col-12">
                  <!--Logo Sticky Start-->
                  <div class="logo-sticky"> <a href="<?php echo e(url('/')); ?>/"><img src="<?php echo e(url('/')); ?>/pic/logo2.png" alt=""></a> </div>
                  <!--Logo Sticky End-->
                  <!--Main Menu Area Start-->
                  <div class="header-menu text-center">
                    <nav>
                      <ul class="main-menu">
                        <li><a href="<?php echo e(url('/')); ?>/">home</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/shop">Shop</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/sale/view">Sale</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/seller/list/view">Seller</a></li>
                        <li><a href="#">Find Professional</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/properties">Properties</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/collection">Collections</a></li>
                        <li><a href="bedroomproducts.html">Galleries</a></li>
                        <?php if(Session::has('username')): ?>
     <!--                   <li><a href="<?php echo e(url('/')); ?>/login"><?php echo e(session::get('name')); ?></a></li>-->
     <!--                   <li><a href="<?php echo e(URL('/')); ?>/logout">logout</a></li>-->

     <!--<li><a href="<?php echo e(URL('/')); ?>/order/tracking/view">Order Tracking</a></li>-->
<li>
<div class="header-option">
    <div class="mini-cart-search">

<div class="currency">
                                           <div class="currency-box">
                                               <a href="#"><?php echo e(session::get('name')); ?></a>
                                               <div class="currency-dropdown">
                                                   <ul class="menu-top-menu">
                                                       <li><a href="<?php echo e(URL('/')); ?>/order/tracking/view">Order Tracking</a></li>
                                                       <li><a href="<?php echo e(URL('/')); ?>/client/payment/list/view/<?php echo e(session::get('pk_id')); ?>">Payment List</a></li>
                                                       <li><a href="<?php echo e(URL('/')); ?>/realtor/dashboard">Switch to My Account</a></li>
                                                       <li><a href="<?php echo e(URL('/')); ?>/client/send/message">Compose Message</a></li>
                                                       <li><a href="<?php echo e(URL('/')); ?>/client/chat/<?php echo e(session::get('pk_id')); ?>">Chat</a></li>
                                                       <li><a href="<?php echo e(URL('/')); ?>/logout">Logout</a></li>
                                                   </ul>
                                               </div>
                                           </div>
                                       </div>
                                </div>
                                       </div>
                                       </li>

                        <?php else: ?>
                        <li><a href="<?php echo e(url('/')); ?>/login">Login</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/signup">Signup</a></li>
                        <?php endif; ?>
                      </ul>
                    </nav>
                  </div>
                  <!--Main Menu Area End-->
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                  <!--Mobile Menu Area Start-->
                  <div class="mobile-menu d-lg-none"></div>
                  <!--Mobile Menu Area End-->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Header Bottom Area End-->
    </div>
  </header>
  <!--Header Area End-->
  <?php echo $__env->yieldContent('content'); ?>
   <!--Footer Area Start-->
   <footer>
    <div class="footer-container">
      <!--Footer Top Area Start-->
      <div class="footer-top-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6">
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="Faq.html">Faqs</a></li>
                  <li><a href="termscondition.html">Terms & Condition</a></li>
                  <li><a href="privcy.html">Privacy Policy</a></li>
                  <li><a href="privcy.html">Houzz Policy</a></li>
                  <li><a href="#">Be a Realtor</a></li>
                  <li><a href="#">Advertise with us</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End-->
            </div>
            <div class="col-lg-3 col-md-6">
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="about.html">About Us</a></li>
                  <li><a href="contact.html">Contact Us</a></li>
                  <li><a href="contact.html">Payment Information</a></li>
                  <li><a href="blog.html">Blog</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/login">Seller Login</a></li>
                  <li><a href="">Be a Professional</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End-->
            </div>
            <div class="col-lg-6 col-md-6">
              <!--Single Footer Widget Start-->
              <div class="text-center"> <a href="" target="_blank" class="btn-social btn-facebook"><i class="fa fa-facebook"></i></a> <a href="" target="_blank" class="btn-social btn-instagram"><i class="fa fa-instagram"></i></a> <a href="" target="_blank" class="btn-social btn-twitter"><i class="fa fa-twitter"></i></a> </div>
              <div class="footer-title mt-40">
                <h3>Contact Us</h3>
              </div>
              <div class="single-footer-widget mb-40">
                <div class="news-letter-form mb-10">
                  <form class="popup-subscribe-form validate" target="_blank" novalidate>
                    <div id="mc_embed_signup_scroll">
                      <div id="mc-form" class="mc-form subscribe-form " style=" border-top: 1px solid white;border-bottom: 1px solid white;
    padding: 1%;">
                        <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email here">
                        <button type="button" class="btn btn-serach">Login</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!--Single Footer Widget End-->
            </div>
          </div>
        </div>
      </div>
      <!--Footer Top Area End-->
      <!--Footer Bottom Area Start-->
      <div class="footer-bottom-area pt-50 pb-50">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <!--Footer Copyright Start-->
              <div class="footer-copyright">
                <p>Copyright © <a href="#">Houzz.pk</a> All Rights Reserved</p>
              </div>
              <div class="footer-copyright">
                <p>Powered By <a href="https://greengrapez.com/"><img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="Green Grapez" style="width:75px; height:50px;"></a></p>
              </div>
              <!--Footer Copyright End-->
            </div>
          </div>
        </div>
      </div>
      <!--Footer Bottom Area End-->
    </div>
  </footer>
  <!--Footer Area End-->
</div>
<!--All Js Here-->

<!--Jquery 1.12.4-->
<script src="<?php echo e(url('/')); ?>/js1/vendor/jquery-1.12.4.min.js"></script>
<!--Popper-->
<script src="<?php echo e(url('/')); ?>/js1/popper.min.js"></script>
<!--Bootstrap-->
<script src="<?php echo e(url('/')); ?>/js1/bootstrap.min.js"></script>
<!--Imagesloaded-->
<script src="<?php echo e(url('/')); ?>/js1/imagesloaded.pkgd.min.js"></script>
<!--Isotope-->
<script src="<?php echo e(url('/')); ?>/js1/isotope.pkgd.min.js"></script>
<!--Waypoints-->
<script src="<?php echo e(url('/')); ?>/js1/waypoints.min.js"></script>
<!--Counterup-->
<script src="<?php echo e(url('/')); ?>/js1/jquery.counterup.min.js"></script>
<!--Carousel-->
<script src="<?php echo e(url('/')); ?>/js1/owl.carousel.min.js"></script>
<!--Slick-->
<script src="<?php echo e(url('/')); ?>/js1/slick.min.js"></script>
<!--Meanmenu-->
<script src="<?php echo e(url('/')); ?>/js1/jquery.meanmenu.min.js"></script>
<!--Easyzoom-->
<script src="<?php echo e(url('/')); ?>/js1/easyzoom.min.js"></script>
<!--ScrollUp-->
<script src="<?php echo e(url('/')); ?>/js1/jquery.scrollUp.min.js"></script>
<!--Wow-->
<script src="<?php echo e(url('/')); ?>/js1/wow.min.js"></script>
<!--Venobox-->
<script src="<?php echo e(url('/')); ?>/js1/venobox.min.js"></script>
<!--Jquery Ui-->
<script src="<?php echo e(url('/')); ?>/js1/jquery-ui.js"></script>
<!--Countdown-->
<script src="<?php echo e(url('/')); ?>/js1/jquery.countdown.min.js"></script>
<!--Plugins-->
<script src="<?php echo e(url('/')); ?>/js1/plugins.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script> 
<!--Main Js-->
<script src="<?php echo e(url('/')); ?>/js1/main.js"></script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5d720cebeb1a6b0be60b473b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
 var countChecked = function () {
    var n = $("input:checked").length;
    if (n >= 1) {
        $("#selected-toolbar").css({
            "display": "block"
        });
    } else {
        $("#selected-toolbar").css({
            "display": "none"
        });
    }
};
countChecked();

$("input[type=checkbox]").on("click", countChecked);

$(document).ready(function() {
   $('.js-example-basic-multiple').select2();
});

function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>

</body>

<!-- Mirrored from d29u17ylf1ylz9.cloudfront.net/plantmore-v3/index-5.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 02 Oct 2018 12:38:20 GMT -->
</html>
<?php /**PATH F:\xamp\htdocs\houzz\resources\views/client/layout/appclient.blade.php ENDPATH**/ ?>