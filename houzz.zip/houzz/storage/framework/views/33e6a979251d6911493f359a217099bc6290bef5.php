<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<title>Houzz</title>

<!-- Bootstrap -->

<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/chat.css" type="text/css" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/normalize.css">

<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/demo.css">

<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/component.css">

		<script>(function(e,t,n){var r=e.querySelectorAll("html")[0];r.className=r.className.replace(/(^|\s)no-js(\s|$)/,"$1js$2")})(document,window,0);</script>

</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title"> <a href="<?php echo e(URL('/')); ?>/admin/home" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images/favicon.png" alt="logo"></i> <span>Houzz</span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
          <ul class="nav side-menu">
              <li><a href="<?php echo e(URL('/')); ?>/admin/home"><i class="fa fa-tachometer"></i> Home </a> </li>

              <li><a href="<?php echo e(url('/')); ?>/admin/home/view/admin"><i class="fa fa-user"></i> Admin & permissions </a> </li>


              <li><a><i class="fa fa-table"></i> Product Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/product">All Products</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/add/product">Add Products</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/product/type">Product Type</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/main/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/sub/category">Sub Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/brand">Brand</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/material">Material</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/style">Style</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/collection/list/view">Manage Collection</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/import/product/view">Import New Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/slider/list/view">Top Page Image Slider</a></a></li>
                </ul>
              </li>

              <li><a><i class="fa fa-table"></i> Seller Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/vendor">All Seller</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/create/seller">Add Seller</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/pending/products">Seller Products</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/seller/rating">Seller Rating & Reviews</a></li>
                  <li><a href="seller_collection_list.html">Seller Collection</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package/invoice">Package Invoice</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package/payment">Package Payment</a></li>
                  <!--<li><a href="seller_commision_invoice_list.html">Commision Seller Invoice</a></li>-->
                  <!--<li><a href="seller_commision_payments_list.html">Commision Seller Payments</a></li>-->
                </ul>
              </li>
              
              <li><a><i class="fa fa-table"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/active/orders">All Orders</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/payment/list/view">Payments</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/invoice/list/view">Invoice</a></li>
                </ul>
              </li>


              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/return/orders"><i class="fa fa-table"></i> Return Management </a> </li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/discount"><i class="fa fa-table"></i> Promotion Management</a></li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/promo"><i class="fa fa-table"></i> Coupons Management</a></li>
              <li><a><i class="fa fa-table"></i> Package Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package">Seller Packages</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package/invoice">Package Invoice</a></li>
                  
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/custom/package">Custom Package</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Reporting Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/commission/vendor">Seller Information</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/reporting/by/products">By Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/reporting/by/sale">By Sales</a></li>
                </ul>
              </li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/rating"><i class="fa fa-table"></i> Rating & Reviews</a></li>
              <li><a><i class="fa fa-table"></i> Photo Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/photo/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/photo/sub/category">Sub Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/idea/list">Idea</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Forum Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/forum/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/forum/topic">Topics</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/forum/post">Post</a></li>
                </ul>
              </li>
               <li><a><i class="fa fa-table"></i> Blog Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/blog/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin-blog">Blog</a></li>
                </ul>
              </li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/message"><i class="fa fa-tachometer"></i> Message </a> </li>
               <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/chat"><i class="fa fa-tachometer"></i> Live Chat </a> </li>
            </ul>
          </div>
        </div>
        <!-- /sidebar menu -->
      </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="<?php echo e(url('/')); ?>/images/vendorprofile.png" alt=""><?php echo e(Session::get('name')); ?> <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/admin/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
            <li role="presentation" class="dropdown">
<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
<i class="fa fa-bell"></i>
<?php

$noti = DB::select("select* from notification ORDER BY pk_id DESC");

?>
<span class="badge bg-green"><?php echo e(count($noti)); ?></span>
</a>
<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
<?php if(count($noti)>0): ?>
<?php $__currentLoopData = $noti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($results->type == 'new vendor created'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
New Seller is Waiting for Approval
</span>
</a>
</li>
<?php endif; ?>


<?php if($results->type == 'new product created'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
Seller is Waiting for Product Approval
</span>
</a>
</li>
<?php endif; ?>

<?php if($results->type == 'COMMISSION'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
<?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?> is Subscribed to COMMISSION Based Package
</span>
</a>
</li>
<?php endif; ?>

<?php if($results->type == 'BASIC'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
<?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?> is Subscribed to BASIC Package
</span>
</a>
</li>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<li>
<div class="text-center">
<a>
<strong>See All Alerts</strong>
<i class="fa fa-angle-right"></i>
</a>
</div>
</li>
</ul>
</li>
          </ul>
        </nav>
      </div>
    </div>

    
    
    <div class="right_col" role="main">
      <div class="row"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
                  <input type="text" hidden id="admin_id" value="<?php echo e(session('pk_id')); ?>">
      <div class="x_panel">
        <div class="x_content">
          <div id="frame">
            <div id="sidepanel">
              <div id="profile">
                <div class="wrap"> <img id="profile-img" src="http://emilcarlsson.se/assets/mikeross.png" alt="" />
                  <p>Fahad Maqsood</p>
                </div>
              </div>
              <div id="search">
                <label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
                <input type="text" placeholder="Search contacts..." />
              </div>
              <div id="contacts">
                 <ul id="userlist">
                          <?php
              $count = 0;
              ?>
                   <?php if(count($user)>0): ?>
         <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($count==0): ?>
         <li onclick="getMessage(this.id)" id="<?php echo e($users->pk_id); ?>" class="contact active">
     
             <?php else: ?>
         <li onclick="getMessage(this.id)" id="<?php echo e($users->pk_id); ?>" class="contact">
             <?php endif; ?>
             <?php
             $count++;
             ?>
                    <div class="wrap"><img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                      <div class="meta">
                        <p class="name"><?php echo e($users->fname); ?> <?php echo e($users->lname); ?></p>
                        <p class="preview"><?php echo e($users->lastmessage); ?></p>
                      </div>
                    </div>
                  </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php endif; ?>
                  
                </ul>
              </div>
            </div>
            <div class="content">
              <div class="contact-profile"> <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                <p>Kiran Riaz</p>
              </div>
              <div  id="msg" class="messages">
             
              </div>
              <div class="message-input">
                <div class="wrap">
                  <input type="text" placeholder="Write your message..." />
                  <div class="box">
					<input type="file" name="file-5[]" id="file-5" class="inputfile inputfile-4" data-multiple-caption="{count} files selected" multiple style="display:none;" />
					<label for="file-5"><figure><svg xmlns="http://www.w3.org/2000/svg" width="20" height="17" viewBox="0 0 20 17"><i class="fa fa-paperclip" aria-hidden="true"></i></svg></figure> <span>Choose a file&hellip;</span></label>
				
			<button class="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
				</div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
            </div>
    </div>


 <!-- footer content -->
 <footer>
      <div class=""> Copyright © 2017-2018 Houzz.com. All rights reserved. </div>
      <div class="pull-right"> Powered By <a href="https://greengrapez.com">Green Grapez <img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="green grapez" style="width:5%;"></a> </div>

      <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
  </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
<!-- DateJS -->
<script src="<?php echo e(url('/')); ?>/js/build/date.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/js/icheck.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(url('/')); ?>/js/custom.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js1/custom-file-input.js"></script>  
<script src="https://js.pusher.com/5.0/pusher.min.js"></script> 
            
            

<script >

var pusher = new Pusher('c271052b8d017b6a07c8', {
              cluster: 'ap2',
              authEndpoint: './auth-pusher'
            
            });
            
            
                    var userId = document.getElementById('admin_id').value;
            var selectedUser=$('#userlist li.active').attr('id');
            var socketId = null;
            pusher.connection.bind('connected', function() {
              socketId = pusher.connection.socket_id;
              console.log(socketId);
            });
            
            
                      var channel = pusher.subscribe('private-admin-channel');
            console.log(channel);
            channel.bind('my-event', function(data) {
                  console.log('working');
                  if(data.from == $('#userlist li.active').attr('id'))
              {
                  var ul = document.getElementById("receive");

              $('<li class="replies"><p>' + data.message + '</p></li>').appendTo($('.messages ul'));
              $(".messages").animate({ scrollTop: document.getElementById("msg").scrollHeight }, "fast");
              }
              
            });
            
            
/*  getting very first message of user*/

            

url = "../vendor/get-messages/"+$('#userlist li.active').attr('id');
        
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                 var data = this.responseText;
  document.getElementById("msg").innerHTML = data;
  $(".messages").animate({ scrollTop: document.getElementById("msg").scrollHeight }, "fast");
  //$(".messages").animate({ scrollTop: $(document).height() }, "fast");
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
  
  // End of getting first message of user
  
   function getMessage($id)
            {
               
                var a = $('#userlist li.active').hasClass('active');
                
                if(a)
                {
                    $('#userlist li.active').removeClass('active');
                }
              
                var a = document.getElementById($id).classList.add("active");
                

                var username = $('#userlist li.active #name').html();
                
                 var name = $('#userlist li.active #profileImage').html();
               
                // document.getElementsByClassName("asd")[0].innerHTML = name;
             //   document.getElementById('inchatname').innerHTML = username;

          
                selectedUser = $id;
                console.log(selectedUser);
        url = "../vendor/get-messages/"+$id;
      
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                 var data = this.responseText;
document.getElementById("msg").innerHTML = data;
$(".messages").animate({ scrollTop: document.getElementById("msg").scrollHeight }, "fast");
                 
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
      
            }
            
            
//$(".messages").animate({ scrollTop: $(document).height() }, "fast");

function newMessage() {
	message = $(".message-input input").val();
	if($.trim(message) == '') {
		return false;
	}
	
	var data = new FormData();
data.append('message', message);
data.append('selected_user',selectedUser);

var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
message = message;

var today = new Date();
var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();



  // xmlhttp.open("POST", "/../send-customer-message", true);
    
  //     xmlhttp.send(data,CSRF_TOKEN);
  console.log(selectedUser);
$.ajax({
      /* the route pointing to the post function */
      url: "<?php echo e(url('/')); ?>/admin/to/vendor/send-admin-message",
      type: 'POST',
      /* send the csrf-token and the input to the controller */
      data: {_token: CSRF_TOKEN, message:message, selected_user:selectedUser,

    },
      /* remind that 'data' is the response of the AjaxController */
      success: function (data) { 
        window.location.href = data;
      }
      
  }); 

	$('<li class="sent"><p>' + message + '</p> <span>' + time  + '</span></li>').appendTo($('.messages ul'));
	$('.message-input input').val(null);
	$('.contact.active .preview').html('<span>You: </span>' + message);
	$(".messages").animate({ scrollTop: $(document).height() }, "fast");
	
  window.stop();
  
  
};

$('.submit').click(function() {
 event.preventDefault();
newMessage();
window.stop();
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
    event.preventDefault();
newMessage();
window.stop();
  }
});
</script>
  </body>
</html>
<?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/chat_system.blade.php ENDPATH**/ ?>