<?php $__env->startSection('content'); ?>
<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Product Management</h3>
          <h4>Approved Product</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
        <div class="title_left"> <a href="<?php echo e(URL('/')); ?>/vendor/home/add/product" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Product</a> </div>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
          <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog"> 
              
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Status Change</h4>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                    <label>Update Status</label>
                    <select id="status" name="status" class="form-control">
                      <option>Select status</option>
                      <option value="0">Premium</option>
                      <option value="1">Hot</option>
                      <option value="2">Featured</option>
                    </select>
                  </div>
                  <button id="hot" type="button" class="btn btn-submmit">Submit</button>
                </div>
              </div>
            </div>
          </div>
          <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>SKU</th>
                <th>Name</th>
                <th>Price</th>
                <th>Commission</th>
                <th>Category</th>
                <th>Sub Category</th>
                <th>Status </th>
                <th>Is Active?</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
            
            <?php if(count($result)>0): ?>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($results->sku); ?></td>
              <td><?php echo e($results->name); ?></td>
              <td><?php echo e(number_format($results->price)); ?></td>
              <td><?php echo e($results->commission); ?>%</td>
              <td><?php echo e($results->category); ?></td>
              <td><?php echo e($results->sub_category); ?></td>
              <?php if($results->hot_product == 0): ?>
              <td><span id="<?php echo e($results->pk_id); ?>" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Premium</span></td>
              <?php elseif($results->hot_product == 1): ?>
              <td><span id="<?php echo e($results->pk_id); ?>"  onclick="getId(this.id)"  data-toggle="modal" data-target="#myModal"  class="label label-primary">Hot</span></td>
              <?php elseif($results->hot_product == 2): ?>
              <td><span id="<?php echo e($results->pk_id); ?>"  onclick="getId(this.id)"  data-toggle="modal" data-target="#myModal"  class="label label-primary">Featured</span></td>
              <?php endif; ?>
              <td><label for="cmn-toggle-<?php echo e($results->pk_id); ?>" class="switch">
                  <input <?php if($results->
                  status==1): ?> checked <?php endif; ?>  onchange="updateStatus(this.id)"  id="cmn-toggle-<?php echo e($results->pk_id); ?>" type="checkbox"> <span class="slider round"></span> </label></td>
              <td><a href="<?php echo e(url('/')); ?>/vendor/home/view/product/<?php echo e($results->pk_id); ?>">View</a> <a href="<?php echo e(url('/')); ?>/vendor/home/edit/product/<?php echo e($results->pk_id); ?>" class="green">Edit</a> <a href="<?php echo e(url('/')); ?>/vendor/home/delete/product/<?php echo e($results->pk_id); ?>" class="red">Delete</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
              </tbody>
            
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?> 
<script>
    function updateStatus(id)
    {
      CheckBox = id;
      id = id.split("-");
      id = id[2];
      cstatus = document.getElementById(CheckBox).checked;
      status= 0;

    if(cstatus)
      {
        status = 1;
      }
      else
      status=0;

      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
               alert("status updated");
            }
        };
        xmlhttp.open("GET", "<?php echo e(URL('/')); ?>/vendor/home/view/product/status/update/"+id+"/"+status, true);
        xmlhttp.send();

    }
    </script> 
<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/approved_product_list_view.blade.php ENDPATH**/ ?>