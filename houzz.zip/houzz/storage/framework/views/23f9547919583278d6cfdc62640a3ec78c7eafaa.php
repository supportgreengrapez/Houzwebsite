
<?php $__env->startSection('content'); ?> 
<!--Shop Area Start-->
<style>
  /* Make the image fully responsive */
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
  </style>
<div class="greyyy">
  <div class="container">
    <div class="shop-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="shop-layout">
              <div class="row">
                <div class="col-md-12">
                  <div class="bg-white p-2 mb-20">
                    <div class=" mt-20">
                      <h2 class="text-center">Partners</h2>
                    </div>
                  </div>
                  <div class="bg-white p-2 mb-20">
                    <div class="row">
                      <div class="col-lg-8 col-md-8 col-sm-12"> 
                        <!--Carousel Wrapper-->
                        <div id="carousel-thumb" class="carousel slide carousel-fade carousel-thumbnails" data-ride="carousel"> 
                          <!--Slides-->
                          <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active"> <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(88).jpg"
        alt="First slide"> </div>
                            <div class="carousel-item"> <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(121).jpg"
        alt="Second slide"> </div>
                            <div class="carousel-item"> <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(31).jpg"
        alt="Third slide"> </div>
                          </div>
                          <!--/.Slides--> 
                          <!--Controls--> 
                          <a class="carousel-control-prev" href="#carousel-thumb" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carousel-thumb" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> 
                          <!--/.Controls-->
                          <ol class="carousel-indicators">
                            <li data-target="#carousel-thumb" data-slide-to="0" class="active"> <img src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(88).jpg" width="100"> </li>
                            <li data-target="#carousel-thumb" data-slide-to="1"> <img src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(121).jpg" width="100"> </li>
                            <li data-target="#carousel-thumb" data-slide-to="2"> <img src="https://mdbootstrap.com/img/Photos/Others/Carousel-thumbs/img%20(31).jpg" width="100"> </li>
                          </ol>
                        </div>
                        <!--/.Carousel Wrapper-->
                        <div class="salogan mt-20">
                          <h2 class="font-weight-bold">Description</h2>
                          <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                        </div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="profile text-center">
                          <h2 class="font-weight-bold">Name</h2>
                          <img src="<?php echo e(URL('/')); ?>/images/3.jpg" alt="icon">
                          <p>CC-380, Phase 4, DHA, Lahore</p>
                          <div class="row mt-10 mb-10">
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"> <a href="#" class="profile_btn">Live Chat</a> </div>
                            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"> <a class="profile_btn" href="#number" data-toggle="modal">View Number</a> </div>
                          </div>
                          <div class="modal fade" id="number">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
                                </div>
                                <div class="modal-body">
                                  <h2 class="font-weight-bold text-center">090078601</h2>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <div class="white-bg p-3">
                          <div class="shop-layout"> 
                            <!--Shop Product Start-->
                            <div class="shop-product">
                              <div id="myTabContent-2" class="tab-content">
                                <div id="grid" class="tab-pane fade show active">
                                  <div class="product-grid-view">
                                    <div class="row">
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/3.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/1.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/5.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                                <li><a href="#" title="Whishlist"><i class="fa fa-heart-o"></i></a></li>
                                                <li><a href="#" title="Compare"><i class="fa fa-refresh"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/6.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/7.jpg" alt=""> </a> <span class="onsale">Sale!</span>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/3.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/1.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/4.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/10.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/10.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/6.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/9.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/8.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/7.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                      <div class="col-md-2"> 
                                        <!--Single Product Start-->
                                        <div class="single-product mb-25">
                                          <div class="product-img img-full"> <a href="single-product.html"> <img src="<?php echo e(URL('/')); ?>/images/2.jpg" alt=""> </a>
                                            <div class="product-action">
                                              <ul>
                                                <li><a href="#open-modal" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                              </ul>
                                            </div>
                                          </div>
                                          <div class="product-content">
                                            <h2><a href="single-product.html">Eleifend quam</a></h2>
                                            <p>$115.00</p>
                                            <div class="product-price">
                                              <div class="wishlist-compare-btn"> <a href="http://general.greengrapez.com/houzz/public/products/details/4/100" class="add-btn">add to cart</a> <a href="#" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                            </div>
                                          </div>
                                        </div>
                                        <!--Single Product End--> 
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                <!--Pagination Start-->
                                <div class="product-pagination">
                                  <ul>
                                    <li class="active"><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
                                  </ul>
                                </div>
                                <!--Pagination End--> 
                              </div>
                            </div>
                            <!--Shop Product End--> 
                            
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2406.154276715389!2d74.39167743377375!3d31.474247046625837!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39190674c96aaaab%3A0x6a7a2e6a45102169!2sGreen%20Grapez%20Office!5e0!3m2!1sen!2s!4v1595488959448!5m2!1sen!2s" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--Shop Product End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Shop Area End--> 
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/partner_detail.blade.php ENDPATH**/ ?>