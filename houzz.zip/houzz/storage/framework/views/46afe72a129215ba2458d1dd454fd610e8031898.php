<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
    <div class="page-title">
          <div class="title_left">
            <h3>Rating and Reviews Management</h3>
            <h4 style="display: block;">Rating & Reviews List</h4>
          </div>
        </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>SKU</th>
                    <th>Product Name</th>
                    <th>Customer Name</th>
                    <th>Rating</th>
                    <th>Comments</th>

                  </tr>
                </thead>
                <tbody>
                <?php if(count($result)>0): ?>
                      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      $user = DB::select( DB::raw("SELECT * FROM client_details WHERE pk_id = :value"), array(
   'value' => $results->user_id,
 ));
 $product = DB::select( DB::raw("SELECT * FROM product WHERE pk_id = :value"), array(
   'value' => $results->product_id,
 ));
                      ?>
                    <tr>
                      <td><?php echo e($product[0]->sku); ?></td>
                      <td><?php echo e($product[0]->name); ?></td>
                      <td><?php echo e($user[0]->fname); ?> <?php echo e($user[0]->lname); ?></td>
                      <td>    <?php
                $count = $results->rating;
                $star = 5 - $count;
                ?>
                <?php for($i = 0; $i<$count; $i++): ?>
                 <span class="fa fa-star checked" style="color:yellow;"></span>
                 <?php endfor; ?>
                 <?php for($i = 0; $i<$star; $i++): ?>
                  <span class="fa fa-star" style="color:lightgrey;"></span>
                  <?php endfor; ?></td>
                      <td><p style="text-align:left;"><?php echo e($results->comment); ?></p></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>

                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/admin/rating_list_view.blade.php ENDPATH**/ ?>