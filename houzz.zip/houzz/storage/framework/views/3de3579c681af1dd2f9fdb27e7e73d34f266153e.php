<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Form Management</h3>
            <h4>Topic List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="<?php echo e(URL('/')); ?>/admin/home/add/forum/topic/view" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Topic</a>
          </div>
          </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Topic</th>
                      <th>Category Name</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php if(count($result)>0): ?>
                      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($results->pk_id); ?></td>
                      <td><?php echo e($results->topic); ?></td>
                      <td><?php echo e($results->category); ?></td>
                      <td>
                      <a href="<?php echo e(URL('/')); ?>/admin/home/edit/forum/topic/view/<?php echo e($results->pk_id); ?>" class="green">Edit</a>
                      <a href="<?php echo e(URL('/')); ?>/admin/home/delete/forum/topic/<?php echo e($results->pk_id); ?>" class="red">Delete</a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\houzz\resources\views/admin/topics_list.blade.php ENDPATH**/ ?>