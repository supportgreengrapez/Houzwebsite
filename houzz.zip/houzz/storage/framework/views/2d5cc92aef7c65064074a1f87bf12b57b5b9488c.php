
<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
           <h3>Customer Management</h3>
            <h4> Offline Client</h4>
          </div>
        </div>
        <div class="title_left">
           <a href="<?php echo e(url('/')); ?>/vendor/home/add/offline/client/view" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Client</a>
          </div>
          </div>
       
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>Customer ID</th>
                         <th>Name</th>
                      <th>Email</th>
                          <th>Phone</th>
                          <th>City</th>
                          <th> Actions</th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php if(count($result)>0): ?>
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($results->pk_id); ?></td>
                                <td><?php echo e($results->name); ?></td>
                             <td><?php echo e($results->email); ?></td>
                             <td><?php echo e($results->phone); ?></td>
                             <td><?php echo e($results->city); ?></td>
            
                           <td><a href="<?php echo e(url('/')); ?>/vendor/home/offline/client/detail/view/<?php echo e($results->pk_id); ?>">View</a><a href="<?php echo e(url('/')); ?>/vendor/home/edit/offline/client/view/<?php echo e($results->pk_id); ?>">Edit</a><a href="<?php echo e(url('/')); ?>/vendor/home/delete/offline/client/<?php echo e($results->pk_id); ?>">Delete</a></td>
                              </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->



     <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/offline_client_list_view.blade.php ENDPATH**/ ?>