<?php $__env->startSection('content'); ?> 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management</h3>
        <h4 style="display: block;">Add Sub Category</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
          <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/sub/category" class="login-form" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            
            <?php if($errors->any()): ?>
            <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
            <?php endif; ?>
            <div class="row">
              <div class="col-lg-5">
                <div class="row">
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label>Main Category Name</label>
                    <select class="form-control" name="mainCategory" id="maincat">
                      <option value="">Select Main Category</option>
                      
                <?php if($result>0): ?>
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                      <option value="<?php echo e($results->main_category); ?>"><?php echo e($results->main_category); ?></option>
                      
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php endif; ?>
                   
                    </select>
                  </div>
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label>Category Sub Type</label>
                    <input type="text" class="form-control" name="subCategory"  placeholder="Category Sub Type" required>
                  </div>
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label> Category Image</label>
                    <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                    <img id="blah" src="<?php echo e(url('/')); ?>/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> 
                  </div>
                  <div class="form-group col-lg-12 col-sm-12 col-md-12">
                    <label>Commission</label>
                    <input type="number" class="form-control" name="commission" id="commission"  placeholder="Commission" >
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/add_sub_category_view.blade.php ENDPATH**/ ?>