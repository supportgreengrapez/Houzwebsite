<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<title>Houzz</title>

<!-- Bootstrap -->

<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
<!-- Datatables -->
<link href="<?php echo e(url('/')); ?>/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/responsive.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/scroller.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/bootstrap-colorpicker.min.css" rel="stylesheet"/>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title"> <a href="<?php echo e(URL('/')); ?>/admin/home" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images/favicon.png" alt="logo"></i> <span>Houzz</span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
          <ul class="nav side-menu">
              <li><a href="<?php echo e(URL('/')); ?>/admin/home"><i class="fa fa-tachometer"></i> Home </a> </li>

              <li><a href="<?php echo e(url('/')); ?>/admin/home/view/admin"><i class="fa fa-user"></i> Admin & permissions </a> </li>


              <li><a><i class="fa fa-table"></i> Product Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/product">All Products</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/add/product">Add Products</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/product/type">Product Type</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/main/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/sub/category">Sub Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/brand">Brand</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/material">Material</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/style">Style</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/collection/list/view">Manage Collection</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/import/product/view">Import New Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/slider/list/view">Top Page Image Slider</a></a></li>
                </ul>
              </li>

              <li><a><i class="fa fa-table"></i> Seller Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/vendor">All Seller</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/create/seller">Add Seller</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/pending/products">Seller Products</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/seller/rating">Seller Rating & Reviews</a></li>
                  <li><a href="seller_collection_list.html">Seller Collection</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package/invoice">Package Invoice</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package/payment">Package Payment</a></li>
                  <!--<li><a href="seller_commision_invoice_list.html">Commision Seller Invoice</a></li>-->
                  <!--<li><a href="seller_commision_payments_list.html">Commision Seller Payments</a></li>-->
                </ul>
              </li>
              
              <li><a><i class="fa fa-table"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/active/orders">All Orders</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/payment/list/view">Payments</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/invoice/list/view">Invoice</a></li>
                </ul>
              </li>


              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/return/orders"><i class="fa fa-table"></i> Return Management </a> </li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/discount"><i class="fa fa-table"></i> Promotion Management</a></li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/promo"><i class="fa fa-table"></i> Coupons Management</a></li>
              <li><a><i class="fa fa-table"></i> Package Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                    
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package">Seller Packages</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/package/invoice">Package Invoice</a></li>
                  
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/custom/package">Custom Package</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Reporting Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/commission/vendor">Seller Information</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/reporting/by/products">By Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/reporting/by/sale">By Sales</a></li>
                </ul>
              </li>
              <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/rating"><i class="fa fa-table"></i> Rating & Reviews</a></li>
              <li><a><i class="fa fa-table"></i> Photo Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/photo/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/photo/sub/category">Sub Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/idea/list">Idea</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Forum Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/forum/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/forum/topic">Topics</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/forum/post">Post</a></li>
                </ul>
              </li>
               <li><a><i class="fa fa-table"></i> Blog Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(URL('/')); ?>/admin/home/view/blog/category">Categories</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/admin-blog">Blog</a></li>
                </ul>
              </li>

            </ul>
          </div>
        </div>
        <!-- /sidebar menu -->
      </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="<?php echo e(url('/')); ?>/images/vendorprofile.png" alt=""><?php echo e(Session::get('name')); ?> <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/admin/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
            <li role="presentation" class="dropdown">
<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
<i class="fa fa-bell"></i>
<?php

$noti = DB::select("select* from notification ORDER BY pk_id DESC");

?>
<span class="badge bg-green"><?php echo e(count($noti)); ?></span>
</a>
<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
<?php if(count($noti)>0): ?>
<?php $__currentLoopData = $noti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($results->type == 'new vendor created'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
New Seller is Waiting for Approval
</span>
</a>
</li>
<?php endif; ?>


<?php if($results->type == 'new product created'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
Seller is Waiting for Product Approval
</span>
</a>
</li>
<?php endif; ?>

<?php if($results->type == 'COMMISSION'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
<?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?> is Subscribed to COMMISSION Based Package
</span>
</a>
</li>
<?php endif; ?>

<?php if($results->type == 'BASIC'): ?>
<?php

$name = DB::select("select* from client_details where pk_id = '$results->vendor_id'");

?>
<li>
<a>
<span>
<span><?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?></span>
<span class="time"><?php echo e(Carbon\Carbon::parse($results->created_at,'America/New_York')->diffForHumans()); ?></span>
</span>
<span class="message">
<?php echo e($name[0]->fname); ?> <?php echo e($name[0]->lname); ?> is Subscribed to BASIC Package
</span>
</a>
</li>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<li>
<div class="text-center">
<a>
<strong>See All Alerts</strong>
<i class="fa fa-angle-right"></i>
</a>
</div>
</li>
</ul>
</li>
          </ul>
        </nav>
      </div>
    </div>

      <?php echo $__env->yieldContent('content'); ?>


 <!-- footer content -->
 <footer>
      <div class=""> Copyright © 2017-2018 Houzz.com. All rights reserved. </div>
      <div class="pull-right"> Powered By <a href="https://greengrapez.com">Green Grapez <img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="green grapez" style="width:5%;"></a> </div>

      <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
  </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
<!-- DateJS -->
<script src="<?php echo e(url('/')); ?>/js/build/date.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/js/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo e(url('/')); ?>/js/moment.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/daterangepicker.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(url('/')); ?>/js/custom.min.js"></script>
<!-- Datatables -->
<script src="<?php echo e(url('/')); ?>/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/responsive.bootstrap.js"></script>
<script src="<?php echo e(url('/')); ?>/js/dataTables.scroller.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/bootstrap-colorpicker.min.js" type="text/javascript"></script>
<script>
$(".my-colorpicker2").colorpicker();
</script>

    <!-- page script -->
    <script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/order/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>



     <script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/vendor/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
    
          $("#hot").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/product/hot/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

    $("#payment").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/payment/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>


 <script type="text/javascript">
    $("#photo_category").on('change',function(e){

      console.log(e);

      var cat_id = e.target.value;

      $.get('<?php echo e(URL('/')); ?>/ajax-photocat?cat_id='+ cat_id,function(data){
        console.log(data);
        $('#photo_sub_category').empty();
        $('#photo_sub_category').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

        $.each(data,function(create,subcatObj){

          $('#photo_sub_category').append('<option value ="'+subcatObj.SKU+'">'+subcatObj.photo_sub_category+'</option>');
      });



      });


  });
  </script>
  <script type="text/javascript">
    $("#mainCategory").on('change',function(e){

      console.log(e);

      var cat_id = e.target.value;

      $.get('<?php echo e(URL('/')); ?>/ajax-subcat?cat_id='+ cat_id,function(data){
        console.log(data);
        $('#SubCategory').empty();
        $('#SubCategory').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

        $.each(data,function(create,subcatObj){

          $('#SubCategory').append('<option value ="'+subcatObj.SKU+'">'+subcatObj.sub_category+'</option>');
      });



      });


  });

    $("#SubCategory").on('change',function(e){

      console.log(e);

      var type_id = e.target.value;

      $.get('<?php echo e(URL('/')); ?>/ajax-product-type?type_id='+ type_id,function(data){
        console.log(data);
      $('#ProductType').empty();
        $('#ProductType').append('<option value="" disable="true" selected="true" >---Add Product Type---</option>');
        $.each(data,function(create,typeObj){

          $('#ProductType').append('<option value ="'+typeObj.product_type+'">'+typeObj.product_type+'</option>');
      });



      });


  });
</script>

<script>
    $("#b1").click(function(){
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var status = $('#status').val();
      $.ajax({
        /* the route pointing to the post function */
        url: "<?php echo e(URL('/')); ?>/admin/home/vendor/order/update/status",
        type: 'POST',
        /* send the csrf-token and the input to the controller */
        data: {_token: CSRF_TOKEN, status:status,
        id: OrgID,
      },
        /* remind that 'data' is the response of the AjaxController */
        success: function (data) {
          window.location.href = data;
        }
    });

  });
</script>

<script>
    $("#b1").click(function(){
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var status = $('#status').val();
      $.ajax({
        /* the route pointing to the post function */
        url: "<?php echo e(URL('/')); ?>/admin/home/product/update/status",
        type: 'POST',
        /* send the csrf-token and the input to the controller */
        data: {_token: CSRF_TOKEN, status:status,
        id: OrgID,
      },
        /* remind that 'data' is the response of the AjaxController */
        success: function (data) {
          window.location.href = data;
        }
    });

  });

   $("#button_1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        console.log(status);
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/vendor/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

        $("#update_payment").click(function(){
      var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
      var status = $('#status').val();
      $.ajax({
        /* the route pointing to the post function */
        url: "<?php echo e(URL('/')); ?>/admin/home/update/payment/status",
        type: 'POST',
        /* send the csrf-token and the input to the controller */
        data: {_token: CSRF_TOKEN, status:status,
        id: OrgID,
      },
        /* remind that 'data' is the response of the AjaxController */
        success: function (data) {
          window.location.href = data;
        }
    });

  });

  $("#invoice_package").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/invoice/package/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

        $("#update_invoice").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/admin/home/payment/invoice/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
</script>








   <script type="text/javascript">
      $("#MainCategory").on('change',function(e){

        console.log(e);

        var cat_id =  e.target.value;

        $.get('<?php echo e(URL('/')); ?>/ajax-subcat?cat_id='+ cat_id,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<option value ="'+subcatObj.sub_category+'">'+subcatObj.sub_category+'</option>');
        });



        });


    });

  </script>
  <script>
      $(document).ready(function() {
	
	$(".js-example-tokenizer").select2({
    tags: true,
    tokenSeparators: [',', ' ']
})
});
  </script>
  <script>
function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("text");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>

<script>
function myFunctions() {
  var checkBox = document.getElementById("myChecked");
  var text = document.getElementById("texts");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>
<script>
function myFunctionss() {
  var checkBox = document.getElementById("myChecks");
  var text = document.getElementById("textss");
  if (checkBox.checked == true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>
<script>
$(document).ready(function(){
   var maxField = 10; //Input fields increment limitation
   var addButton = $('.add_button2'); //Add button selector
   var wrapper = $('.field_wrapper'); //Input field wrapper
   var fieldHTML = '<div class="opendiv"><div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2"><div class="boxborder"><div class="form-group nomargin contform2"><label>Product ID</label><input type="text" class="form-control" name="product_id[]"></div><div class="form-group nomargin contform2"><label>Product Name</label><input type="text" class="form-control" name="product_name[]"></div><div class="form-group contform2"><label>Product Description</label><textarea class="form-control" rows="5" name="product_description[]"></textarea></div><div class="row"><div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><div class="form-group nomargin contform2"><label>Quantity</label><input type="number" class="form-contro" name="quantity[]"></div></div></div><div class="row"><div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"><div class="form-group nomargin contform2"><label>Price</label><input type="number" class="form-control" name="price[]"></div></div></div><div class="form-group nomargin contform2"><label>Size</label><input type="text" class="form-control" name="size[]"></div><div class="form-group nomargin contform2"><label>Promotion</label><input type="text" class="form-control" name="promotion"></div></div></div><a href="javascript:void(0);" class="remove_button minusbtn col-lg-1 col-sm-12"><span class="glyphicon glyphicon-minus marginsets"></span></a></div>'; //New input field html
   var x = 1; //Initial field counter is 1
   //Once add button is clicked
   $(addButton).click(function(){
       //Check maximum number of input fields
       if(x < maxField){
           x++; //Increment field counter
           $(wrapper).append(fieldHTML); //Add field html
       }
   });
   //Once remove button is clicked
   $(wrapper).on('click', '.remove_button', function(e){
       e.preventDefault();
       $(this).parent('div').remove(); //Remove field html
       x--; //Decrement field counter
   });
});
</script>
  </body>
</html>
<?php /**PATH F:\xamp\htdocs\houzz\resources\views/admin/layout/appadmin.blade.php ENDPATH**/ ?>