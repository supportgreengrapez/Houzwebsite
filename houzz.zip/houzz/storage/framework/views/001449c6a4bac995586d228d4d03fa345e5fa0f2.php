<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }



  </script>
<?php $__env->startSection('content'); ?>




    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Product Management</h3>
            <h4>Product</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">

          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
              <div id="myModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Status Change</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Update Status</label>
                                    <select id="status" name="status" class="form-control">
                                        <option>Select status</option>
                                        <option value="1">Pending</option>
                                        <option value="2">Approved</option>
                                        <option value="3">Unapproved</option>

                                    </select>
                             </div>
                             <button id="b1" type="button" class="btn btn-submmit">Submit</button>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </div>

                        </div>
                      </div>
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>SKU</th>
                          <th>Product Name</th>
                          <th>Price</th>
                          <th>Categoty</th>
                          <th>Status</th>
                          <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>


                  <?php if(count($result)>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                          <td><?php echo e($results->sku); ?></td>

                          <td><?php echo e($results->name); ?></td>

                          <td><div class="sparkbar" data-color="#00a65a" data-height="20"><?php echo e($results->price); ?></div></td>
                          <td><?php echo e($results->category); ?></td>

                          <td><span id="<?php echo e($results->pk_id); ?>" onclick="getId(this.id)" class="label label-primary" data-toggle="modal" data-target="#myModal">Pending</span></td>

                          <td><a href="<?php echo e(url('/')); ?>/admin/home/view/pending/products/view/detail/product/<?php echo e($results->pk_id); ?>">View</a></td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

     <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/admin/pending_product_list_view.blade.php ENDPATH**/ ?>