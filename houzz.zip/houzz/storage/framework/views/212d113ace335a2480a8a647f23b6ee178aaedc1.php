<?php $__env->startSection('content'); ?> 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Order Management</h3>
          <h4>Order Detail</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12"> </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_content">
        <table  class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
          <thead>
            <tr>
              <th>SKU</th>
              <th>Product Name</th>
              <th>Total Price</th>
              <th>Commission</th>
              <th>Payable Amount</th>
              <th>Size</th>
              <th>Quantity</th>
              <th>Vendor</th>
              <th>Order Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          
          <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php 
          $product = DB::select("select* from product where pk_id ='$results->product_id'");
          $seller = DB::select("select* from client_details where pk_id ='$results->vendor_id' and customer_type='seller'");
          ?>
          <tr>
            <td><?php echo e($results->sku); ?></td>
            <td><a href="<?php echo e(url('/')); ?>/admin/home/view/product/<?php echo e($product[0]->pk_id); ?>"><?php echo e($results->product_name); ?></a></td>
            <td><?php echo e(number_format($results->price)); ?></td>
            <td><?php echo e(number_format($results->commission)); ?>%</td>
            <td><?php echo e(number_format($results->price - (($results->price*$results->commission)/100))); ?></td>
            <td><?php echo e($results->size); ?></td>
            <td><?php echo e($results->quantity); ?></td>
            <td><a href="<?php echo e(url('/')); ?>/admin/home/view/vendor/<?php echo e($seller[0]->pk_id); ?>"><?php echo e($seller[0]->fname); ?> <?php echo e($seller[0]->lname); ?></a></td>
            
            <?php if($results->v_order_status == 0): ?>
            <td><span class="label label-primary">Processing</span></td>
            <?php elseif($results->v_order_status == 1): ?>
            <td><span class="label label-primary">On Hold</span></td>
            <?php elseif($results->v_order_status == 2): ?>
            <td><span class="label label-primary">Shipped Product</span></td>
            <?php elseif($results->v_order_status == 3): ?>
            <td><span class="label label-primary">Return</span></td>
            <?php elseif($results->v_order_status == 4): ?>
            <td><span class="label label-primary">Cancel</span></td>
            <?php endif; ?> 
            <td><a href="<?php echo e(url('/')); ?>/admin/home/view/active/order/view/specific/order/<?php echo e($results->order_id); ?>">View</a></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </tbody>
          
        </table>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/vendor_order_list_view.blade.php ENDPATH**/ ?>