<?php $__env->startSection('content'); ?> 

<!-- page content -->
<div class="right_col" role="main">
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <div class="textcen">
        <h4>Create Payments</h4>
      </div>
    </div>
  </div>
  <form method="post" action = "<?php echo e(url('/')); ?>/vendor/home/add/payment/invoice" class="login-form">
    <?php echo e(csrf_field()); ?>

    
    <?php if($errors->any()): ?>
    <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
    <?php endif; ?>
    <div class="row">
      <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
        <div class="form-group nomargin contform2">
          <label for="email">Invoice#</label>
          <input type="number" class="form-control blueborder" value="<?php echo e($result[0]->pk_id); ?>" id="" placeholder="invoice No" name="invoice_no" >
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group mt-20">
          <label for="email">Payment Receipt</label>
          <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
          <img id="blah" src="<?php echo e(url('/')); ?>/images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
        <div class="form-group nomargin contform2">
          <label for="email">Payee</label>
          <input type="text" class="form-control blueborder" value="Admin" id="" placeholder="" name="payee" disabled>
        </div>
        <div class="form-group nomargin contform2">
          <label for="email">Payer</label>
          <input type="text" class="form-control blueborder" id="" value="<?php echo e(session()->get('fname')); ?> <?php echo e(session()->get('lname')); ?>" placeholder="" name="email" disabled>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
        <div class="form-group">
          <label>Date</label>
          <input type="text" id="mydate" class="form-control" name="date" placeholder="date">
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
        <div class="form-group nomargin contform2">
          <label for="email">Amount</label>
          <input type="number" value="" class="form-control blueborder" placeholder="Amount" name="amount" >
        </div>
      </div>
    </div>
    <br>
    <div class="row">
      <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12 mt-20">
        <button type="submit" class="btn btnupdate">Create</button>
        <div class="banktext"> </div>
      </div>
    </div>
  </form>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/add_payment_invoice_view.blade.php ENDPATH**/ ?>