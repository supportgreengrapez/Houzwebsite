
<?php $__env->startSection('content'); ?> 

<!-- page content -->
<div class="right_col" role="main">
  
    <div class="page-title">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left">
          <h3>Payment Management</h3>
          <h4>View Payment Duartion</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
        <div class="title_left"> <a href="<?php echo e(URL('/')); ?>/vendor/payment/add/duration" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Payment Duration</a> </div>
      </div>
    </div>
  <div class="wrap">
    <div class="row borderbotms">
      <div class="col-lg-3 col-md-3 col-sm-12">
        <div class="dbicons">
          <h4>Payment Duration</h4>
        </div>
      </div>
      <div class="col-lg-8 col-md-8 col-sm-12">
        <div class="dbparahsss">
          <p><?php echo e($result[0]->payment_duration); ?> Days</p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- /page content --> 

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/payment_duration.blade.php ENDPATH**/ ?>