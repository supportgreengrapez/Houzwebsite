
<?php $__env->startSection('content'); ?> 
<!--Shop Area Start-->
<style>
  /* Make the image fully responsive */
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
  </style>
<div class="greyyy">
  <div class="container">
    <div class="shop-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="shop-layout">
              <div class="row">
                <div class="col-md-12">
                  <div class="bg-white p-2 mb-20">
                    <div class=" mt-20">
                      <h2 class="text-center">Partners</h2>
                    </div>
                  </div>
                  <div class="bg-white p-2 mb-20">
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="boxcheck1">
                          <div class="form-group">
                            <label for="text">City</label>
                            <select class="form-control" >
                              <option>Lahore</option>
                              <option>Karachi</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="boxcheck1">
                          <div class="form-group">
                            <label for="text">Category</label>
                            <select class="form-control" >
                              <option>Category 1</option>
                              <option>Category 2</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="boxcheck1">
                          <div class="form-group">
                            <label for="text">Location</label>
                            <select class="form-control" >
                              <option>Lahore</option>
                              <option>Karachi</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="form-group">
                          <button type="submit"  class="btn button btn-md">Search</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                      <div class="carousel-item active"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/pic/slider2.jpg" alt="First slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/pic/slider1.jpg" alt="Second slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/pic/slider3.jpg" alt="Third slide"> </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
                </div>
              </div>
              <div class="grey p-2">
                <h3 class="text-center">Featured Partners</h3>
              </div>
              <div class="bg-white p-2 mb-20"> 
                <!--Brand Area Start-->
                
                <div class="brand-area mt-20">
                  <div class="container">
                    <div class="row">
                      <div class="col-12">
                        <div class="brand-active"> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/Homegoods.jpg" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/mobile_logo.png" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/nookkar-com-delhi-online-shopping-websites-yq4ja.jpg" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/Zameen.com_-_Logo.png" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/hg_final-signature_hor_tag2-final.png" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/Homegoods.jpg" alt=""></a> </div>
                          <!--Single Brand End--> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!--Brand Area End--> 
              </div>
              <div class="bg-white p-2">
                <div class="shop-product">
                  <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item"> <a class="nav-link active" data-toggle="pill" href="#home">Partners</a> </li>
                    <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#menu1">Products</a> </li>
                  </ul>
                  
                  <!-- Tab panes -->
                  <div class="tab-content">
                    <div id="home" class="container tab-pane active ">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="border_top mb-10 mt-10"></div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-img img-full">
                            <h4 class="text-center">Kitchen Dinning</h4>
                            <img src="<?php echo e(URL('/')); ?>/pic/31.png" alt="img"> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="border_top mb-10 mt-10"></div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-img img-full">
                            <h4 class="text-center">Kitchen Dinning</h4>
                            <img src="<?php echo e(URL('/')); ?>/pic/31.png" alt="img"> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                      </div>
                    </div>
                    <div id="menu1" class="container tab-pane fade">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="border_top mb-10 mt-10"></div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-img img-full">
                            <h4 class="text-center">Kitchen Dinning</h4>
                            <img src="<?php echo e(URL('/')); ?>/pic/31.png" alt="img"> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="border_top mb-10 mt-10"></div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-img img-full">
                            <h4 class="text-center">Kitchen Dinning</h4>
                            <img src="<?php echo e(URL('/')); ?>/pic/31.png" alt="img"> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                          <div class="product-content"> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> <a href="#">
                            <p class="grey text-justify">Category</p>
                            </a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!--Shop Product End--> 
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End--> 
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/partner.blade.php ENDPATH**/ ?>