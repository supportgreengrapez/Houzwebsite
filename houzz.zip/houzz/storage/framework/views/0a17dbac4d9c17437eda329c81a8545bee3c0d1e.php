
<?php $__env->startSection('content'); ?> 

<!-- /NAVIGATION --> 

<!-- BREADCRUMB -->

<div id="breadcrumb">
<div class="section"> 
  <!-- container -->
  <div class="container"> 
    <!-- row -->
    <div class="content-wrapper"> 
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h3> Order Tracking </h3>
      </section>
      <tbody class="nDividerBlockOuter">
        <tr>
          <td class="nDividerBlockInner" style="padding: 18px;"><table class="nDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top-width: 5px;border-top-style: solid;border-top-color: #689a29;">
              <tbody>
                <tr>
                  <td><span></span></td>
                </tr>
              </tbody>
            </table></td>
        </tr>
      </tbody>
      
      <!-- Main content --> 
      <!-- /.content -->
      
      <div class="wrappers">
        <div id="login-form" class="form">
          <h3 class="text-center content-header pt-20 pb-20">Order Detail</h3>
          <div class="x_panel" style="border:0px">
            <div class="member-left-side"> <?php if(count($ordertracking)>0): ?>
              <div class="member-email clearfix"> <b>Tracking ID</b> <span><?php echo e($ordertracking[0]->tracking_id); ?></span> </div>
              <div class="member-email clearfix"> <b>Customer Name</b> <span><?php echo e($ordertracking[0]->fname); ?> <?php echo e($ordertracking[0]->lname); ?></span> </div>
              <div class="member-email clearfix"> <b>Total Price</b> <span>PKR <?php echo e(number_format($ordertracking[0]->amount)); ?></span> </div>
              <div class="member-email clearfix"> <b>Payment Method</b> <span>Cash On Delivery </span> </div>
              <?php if($ordertracking[0]->status == 0): ?>
              <div class="member-email clearfix"> <b>Status</b> <span>Processing</span> </div>
              <?php elseif($ordertracking[0]->status == 1): ?>
              <div class="member-email clearfix"> <b>Status</b> <span>On Hold</span> </div>
              <?php elseif($ordertracking[0]->status == 3): ?>
              <div class="member-email clearfix"> <b>Status</b> <span>Return</span> </div>
              <?php elseif($ordertracking[0]->status == 2): ?>
              <div class="member-email clearfix"> <b>Status</b> <span>Shipped Product</span> </div>
              <?php else: ?>
              <div class="member-email clearfix"> <b>Status</b> <span>cancel</span> </div>
              <?php endif; ?>
              <?php endif; ?>
              <?php if(count($ad)>0): ?>
              <div class="member-email clearfix"> <b>Phone No</b> <span><?php echo e($ad[0]->phone); ?></span> </div>
              <div class="member-email clearfix"> <b>Shipment Address </b> <span><?php echo e($ad[0]->address); ?></span> </div>
              <?php endif; ?> </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /row --> 
  </div>
</div>
<div class="section"> 
  <!-- container -->
  <div class="container"> 
    <!-- row -->
    <div class="content-wrapper"> 
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h3> </h3>
      </section>
      <tbody class="nDividerBlockOuter">
        <tr>
          <td class="nDividerBlockInner" style="padding: 18px;"><table class="nDividerContent" border="0" cellpadding="0" cellspacing="0" width="100%" style="border-top-width: 5px;border-top-style: solid;border-top-color: #689a29;">
              <tbody>
                <tr>
                  <td><span></span></td>
                </tr>
              </tbody>
            </table></td>
        </tr>
      </tbody>
      
      <!-- Main content --> 
      <!-- /.content --> 
    </div>
    <!-- /row --> 
  </div>
</div>
<div class="section"> 
  <!-- container -->
  <div class="container"> 
    <!-- row -->
    <div class="content-wrapper"> 
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h3> View Order </h3>
      </section>
      <div class="row">
        <div class="col-sm-12 col-md-12">
          <table class="table">
            <thead>
              <tr>
                <th>Images</th>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Size</th>
                <th class="text-center">Unit Price</th>
                <th class="text-center">Total</th>
                <th>Shipment Charges</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
            
            <?php if(count($orderdetail)>0): ?>
            <?php $__currentLoopData = $orderdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> <?php 
              $thumbnail = DB::select("select* from product where  pk_id ='$results->product_id'");
              ?>
              <td style="width:10%;"><image src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($thumbnail[0]->thumbnail); ?>" alt="img" style="width:150px;height:150px;"></td>
              <td><?php echo e($results->product_name); ?></td>
              <td><?php echo e($results->quantity); ?></td>
              <td><?php echo e($results->size); ?></td>
              <td><strong>PKR <?php echo e(number_format($results->price)); ?></strong></td>
              <td><strong>PKR <?php echo e(number_format($results->quantity * $results->price)); ?> </strong></td>
              <td><strong>PKR <?php echo e(number_format($results->delivery_charges)); ?></strong></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
              </tbody>
            
          </table>
        </div>
      </div>
      
      <!-- Main content --> 
      <!-- /.content --> 
    </div>
    
    <!-- /row --> 
    
  </div>
  <!-- /container --> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/view_order_tracking.blade.php ENDPATH**/ ?>