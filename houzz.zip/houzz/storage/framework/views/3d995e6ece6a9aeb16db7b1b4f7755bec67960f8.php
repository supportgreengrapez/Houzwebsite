<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
           <h3>Product Management</h3>
            <h4>Product</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
           <a href="<?php echo e(URL('/')); ?>/admin/home/add/product" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Product</a>
          </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                      <th>SKU</th>
                      <th>Name</th>
                      <th>Price</th>
                      <th>Category</th>
                      <th>Sub Category</th>
                      <th>Is Active?</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>

                  <?php if(count($result)>0): ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($results->sku); ?></td>
                      <td><?php echo e($results->name); ?></td>
                      <td><?php echo e(number_format($results->price)); ?></td>
                      <td><?php echo e($results->category); ?></td>
                      <td><?php echo e($results->sub_category); ?></td>
                      <td>
                      <label for="cmn-toggle-<?php echo e($results->pk_id); ?>" class="switch">
                          <input <?php if($results->status==1): ?> checked <?php endif; ?>  onchange="updateStatus(this.id)"  id="cmn-toggle-<?php echo e($results->pk_id); ?>" type="checkbox">
                          <span class="slider round"></span>
                      </label>
                      </td>
                      <td>
                      <a href="<?php echo e(url('/')); ?>/admin/home/view/product/<?php echo e($results->pk_id); ?>">View</a>
                      <a href="<?php echo e(url('/')); ?>/admin/home/edit/product/<?php echo e($results->pk_id); ?>" class="green">Edit</a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\houzz\resources\views/admin/product_list_view.blade.php ENDPATH**/ ?>