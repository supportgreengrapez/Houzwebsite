<?php $__env->startSection('content'); ?>
<!--Shop Area Start-->
<div class="greyyy">
    <div class="container">
      <div class="shop-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3">
              <!--Product Category Widget Start-->
              <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
                <div class="shop-sidebar">
                  <h4>By categories</h4>
                  <div class="categori-checkbox">
                    <ul>
                      <h4 class="green">All Products</h4>
                      <?php if(count($main_category)>0): ?>
			<?php $__currentLoopData = $main_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>"><?php echo e($results->main_category); ?></a></i>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


                    </ul>
                  </div>
                  <hr class="green">
                  <h4>Shop Daily Sales</h4>
                  <div class="categori-checkbox">
                    <ul>
                      <li>Bar stool & counter stools 50</li>
                      <li>Off or more</li>
                      <li>Area rugs 70% or more</li>
                      <li>40% off</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-9">
              <div class="shop-layout">
                
                <div class="bg-white p-2">
                  <div class="shop-product">
                    <div id="myTabContent-2" class="tab-content">
                      <div id="grid" class="tab-pane fade show active">
                        <div class="product-grid-view">
                          <div class="row">
                          <?php if(count($result)>0): ?>
                          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                              <!--Single Product Start-->
                              <div class="collect">
                              <h4 class="green"><?php echo e($results->collection_name); ?></h4>
                              <img src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="img">
                              <p> <?php echo e($results->description); ?> <a href="<?php echo e(url('/')); ?>/collection/detail/view/<?php echo e($results->pk_id); ?>" class="green">More...</a></p>
                              </div>
                              <!--Single Product End-->
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--Shop Product End-->
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End-->
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/collection_list.blade.php ENDPATH**/ ?>