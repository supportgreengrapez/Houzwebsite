<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Product Management</h3>
            <h4 style="display: block;">Add Brand</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
              <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/brand" class="login-form" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>


              <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong>Danger!</strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
              <div class="row">
                <div class="col-lg-5">
                    <div class="row">
                      <div class="form-group col-lg-12 col-sm-12 col-md-12">
                        <label>Brand</label>
                        <input type="text" class="form-control" name ="brandname"  placeholder="Brand" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>

                    </div>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
                </div>

                </form>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->



    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/add_brand_view.blade.php ENDPATH**/ ?>