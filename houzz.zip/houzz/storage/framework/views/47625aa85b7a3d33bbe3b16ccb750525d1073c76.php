<?php $__env->startSection('content'); ?>
<form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/product/<?php echo e($result[0]->pk_id); ?>" class="login-form" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php if($errors->any()): ?>
  <div class="alert alert-danger"> <strong>Danger!</strong> <?php echo e($errors->first()); ?> </div>
  <?php endif; ?> 
  <!-- page content -->
  <div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Product Management</h3>
          <h4 style="display: block;">Add Product</h4>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content">
            <div class="row">
              <div class="col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>About this Item</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo e($result[0]->name); ?>" placeholder="Product Name" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                  <div class="form-group">
                    <label>Product Description</label>
                    <textarea class="form-control" rows="9" name="description"  placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000"><?php echo e($result[0]->description); ?></textarea>
                  </div>
                  <div class="form-group" >
                    <label>Category Name</label>
                    <select class="form-control" name="mainCategory" id="mainCategory" >
                      
                    <?php if($result1>0): ?>
                    <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          
                      <option value="<?php echo e(urlencode($results->main_category)); ?>" <?php if($result[0]->category==$results->main_category): ?> selected <?php endif; ?>><?php echo e($results->main_category); ?></option>
                      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Category Type</label>
                    <select class="form-control" name="SubCategory" id="SubCategory" >
                      <option value="<?php echo e($result[0]->sub_category); ?>" ><?php echo e($result[0]->sub_category); ?></option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Product Type</label>
                    <select class="form-control" name="ProductType" id="ProductType">
                      <option value="<?php echo e($result[0]->product_type); ?>" ><?php echo e($result[0]->product_type); ?></option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Brand Name</label>
                    <select class="form-control" name="BrandName">
                      
                        <?php if($result4>0): ?>
                                 <?php $__currentLoopData = $result4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                         
                      <option value="<?php echo e($results->brand_name); ?>" <?php if($result[0]->brand_name == $results->brand_name): ?> selected <?php endif; ?>><?php echo e($results->brand_name); ?></option>
                      
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                        
                    </select>
                  </div>
                  <div class="form-group"> <?php
                    $array = [];
                    $str = $result[0]->tags;
                    $tok = strtok($str, ",");
                    
                    
                    $skillset =$tok;
                    $array = array_wrap($skillset);
                    
                    while ($tok !== false) {
                    $tok = strtok(",");
                    
                    if(is_string($tok))
                    $skillset= $tok;
                    //  $array = array_prepend($array, $skillset);
                    array_push($array, $skillset);
                    
                    }
                    array_pop($array);
                    ?>
                    <label>Product Tags</label>
                    <select  class="js-example-tokenizer form-control" name="tags[]" multiple="multiple" required>
                      
                           <?php if(count($array)>0): ?>
							<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>               
                      
                      <option value="<?php echo e($arrays); ?>" selected><?php echo e($arrays); ?></option>
                      
                      						               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
                        
                    
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-lg-3 col-sm-12 col-xs-12">
                <div class="togglebutn">
                  <div id="wrapper">
                    <p>In Active?</p>
                    <div id="check">
                      <input type="checkbox" id="ch" name="status" <?php if($result[0]->
                      status==1): ?> checked <?php endif; ?> >
                      <div id="cadre"></div>
                      <div id="bulle"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Pricing</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>SKU</label>
                    <input type="text" class="form-control" name="sku" value="<?php echo e($result[0]->sku); ?>" placeholder="Sku" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Quantity in Hand</label>
                    <input type="text" class="form-control" value="<?php echo e($result[0]->quantity_on_hand); ?>" name="quantity_on_hand" placeholder="Quantity in Hand" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Price</label>
                    <input type="number" class="form-control" name="price" value="<?php echo e($result[0]->price); ?>"  placeholder="Pricing" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Detail</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Material</label>
                    <select class="form-control" name="">
                      <option value="">Material 1</option>
                      <option value="">Material 2</option>
                      <option value="">Material 3</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Style</label>
                    <select class="form-control" name="">
                      <option value="">Style 1</option>
                      <option value="">Style 2</option>
                      <option value="">Style 3</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Color</label>
                    <div class="input-group my-colorpicker2 colorpicker-element">
                      <input type="text" name = "_color" value ="<?php echo e($result[0]->color); ?>" class="form-control">
                      <div class="input-group-addon"> <i style="background-color: rgb(0, 0, 0);"></i> </div>
                    </div>
                    <!-- /.input group --> 
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <label>Unit</label>
                    <select class="form-control" name="unit">
                      <option   <?php if($result[0]->unit=="Feet"): ?> selected <?php endif; ?>  value="Feet">Feet</option>
                      <option  <?php if($result[0]->unit=="Meter"): ?> selected <?php endif; ?>  value="Meter">Meter</option>
                      <option  <?php if($result[0]->unit=="Yard"): ?> selected <?php endif; ?>  value="Yard">Yard</option>
                      <option  <?php if($result[0]->unit=="inchs"): ?> selected <?php endif; ?>  value="inchs">Inches</option>
                      <option   <?php if($result[0]->unit=="Centimeter"): ?> selected <?php endif; ?> value="Centimeter">Centimeter</option>
                      <option  <?php if($result[0]->unit=="Kilogram"): ?> selected <?php endif; ?>  value="Kilogram">Kilogram</option>
                      <option  <?php if($result[0]->unit=="Gram"): ?> selected <?php endif; ?>  value="Gram">Gram</option>
                      <option  <?php if($result[0]->unit=="Litre"): ?> selected <?php endif; ?>  value="Litre">Litre</option>
                      <option  <?php if($result[0]->unit=="Mililitre"): ?> selected <?php endif; ?>  value="Mililitre">Mililitre</option>
                      <option  <?php if($result[0]->unit=="Watt"): ?> selected <?php endif; ?>  value="Watt">Watt</option>
                      <option  <?php if($result[0]->unit=="Volt-ampere"): ?> selected <?php endif; ?>  value="Volt-ampere">Volt-ampere</option>
                      <option  <?php if($result[0]->unit=="Horse-power"): ?> selected <?php endif; ?>  value="Horse-power">Horse-power</option>
                      <option <?php if($result[0]->unit=="Cubic centimeter"): ?> selected <?php endif; ?>   value="Cubic centimeter">Cubic centimeter</option>
                      <option  <?php if($result[0]->unit=="Radian"): ?> selected <?php endif; ?>  value="Radian">Radian</option>
                      <option  <?php if($result[0]->unit=="Degree"): ?> selected <?php endif; ?>  value="Degree">Degree</option>
                      <option  <?php if($result[0]->unit=="Bit"): ?> selected <?php endif; ?>  value="Bit">Bit</option>
                      <option  <?php if($result[0]->unit=="Byte"): ?> selected <?php endif; ?>  value="Byte">Byte</option>
                      <option  <?php if($result[0]->unit=="Kilobyte"): ?> selected <?php endif; ?>  value="Kilobyte">Kilobyte</option>
                      <option  <?php if($result[0]->unit=="Megabyte"): ?> selected <?php endif; ?>  value="Megabyte">Megabyte</option>
                      <option  <?php if($result[0]->unit=="GigaByte"): ?> selected <?php endif; ?>  value="GigaByte">GigaByte</option>
                      <option  <?php if($result[0]->unit=="Terabyte"): ?> selected <?php endif; ?>  value="Terabyte">Terabyte</option>
                      <option  <?php if($result[0]->unit=="Pixel"): ?> selected <?php endif; ?>  value="Pixel">Pixel</option>
                      <option  <?php if($result[0]->unit=="Density per pixel"): ?> selected <?php endif; ?> value="Density per pixel">Density per pixel</option>
                      <option  <?php if($result[0]->unit=="Pieces"): ?> selected <?php endif; ?>  value="Pieces">Pieces</option>
                      <option  <?php if($result[0]->unit=="Packs"): ?> selected <?php endif; ?>  value="Packs">Packs</option>
                      <option  <?php if($result[0]->unit=="Pairs"): ?> selected <?php endif; ?>  value="Pairs">Pairs</option>
                      <option  <?php if($result[0]->unit=="Dozen"): ?> selected <?php endif; ?>  value="Dozen">Dozen</option>
                      <option  <?php if($result[0]->unit=="Vol"): ?> selected <?php endif; ?>  value="Vol">Vol</option>
                      <option  <?php if($result[0]->unit=="Percent"): ?> selected <?php endif; ?>  value="Percent">Percent</option>
                    </select>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group">
                    <div class="input_field_wrap">
                      <label for="text">Size</label>
                      <?php if(count($result)>0): ?>
                      <?php
                      $str = $result[0]->size;
                      $tok = strtok($str, ",");
                      
                      
                      $skillset =$tok;
                      $array = array_wrap($skillset);
                      
                      while ($tok !== false) {
                      $tok = strtok(",");
                      
                      if(is_string($tok))
                      $skillset= $tok;
                      //  $array = array_prepend($array, $skillset);
                      array_push($array, $skillset);
                      
                      }
                      array_pop($array);
                      
                      ?>
                      <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <input type="text"  name="size[]" value="<?php echo e($results); ?>" class="form-control" placeholder="Size" required>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </div>
                    <br>
                    <?php endif; ?>
                    <button class="add_fields_button btn btn-success"><i class="fa fa-plus"></i> Add More Size</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Urgent Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Charges</label>
                    <input type="number" value="<?php echo e($result[0]->urgent_charges); ?>" name ="urgent_charges" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" value="<?php echo e($result[0]->urgent_time); ?>" name ="urgent_time" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Express Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Charges</label>
                    <input type="number" value="<?php echo e($result[0]->express_charges); ?>" name ="express_charges" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" value="<?php echo e($result[0]->express_time); ?>" name ="express_time" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Normal Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Charges</label>
                    <input type="number" value="<?php echo e($result[0]->normal_charges); ?>" name ="normal_charges" class="form-control">
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" value="<?php echo e($result[0]->normal_time); ?>" name ="normal_time" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Free Delivery</b></h5>
                </div>
              </div>
              <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <label>Time</label>
                    <input type="text" value="<?php echo e($result[0]->free_delivery); ?>" name ="free_delivery" class="form-control">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                <div class="page-title">
                  <h5><b>Add Return/Refund Policy</b></h5>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="row">
                  <div class="form-group">
                    <textarea class="form-control" name="return_policy" rows="9"><?php echo e($result[0]->return_policy); ?></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="row">
              <div class="page-title">
                <h5><b>Images</b></h5>
              </div>
              <div class="col-lg-12">
                <div class="row">
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="file" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" class="form-control" onchange="readURL(this);"/>
                    <img id="blah" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images2" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail2); ?>" class="form-control" onchange="preview_image(this);"/>
                    <img id="blah2" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail2); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images3" class="form-control" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail3); ?>" onchange="preview_img(this);"/>
                    <img id="blah3" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail3); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                    
                    
                    <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images4" class="form-control" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail4); ?>" onchange="preview_imgs(this);"/>
                    <img id="blah4" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail4); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                    <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images5" class="form-control" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail5); ?>" onchange="preview_img5(this);"/>
                    <img id="blah5" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail5); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                    <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images6" class="form-control" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail6); ?>" onchange="preview_img6(this);"/>
                    <img id="blah6" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail6); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                    <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images7" class="form-control" value="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail7); ?>" onchange="preview_img7(this);"/>
                    <img id="blah7" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail7); ?>" alt="Product Image" style="width:350px; height:300px;" /> </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="col-md-6 pull-right">
              <button id="send" type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content -->
</form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/edit_product.blade.php ENDPATH**/ ?>