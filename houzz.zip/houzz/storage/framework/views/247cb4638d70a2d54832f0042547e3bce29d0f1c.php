<?php $__env->startSection('content'); ?>
<form method="post" action = "<?php echo e(url('/')); ?>/admin/add/invoice" class="login-form" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Customer Management</h3>
            <h4>Create Invoice</h4>
          </div>
          </div>
        </div>
      <div class="wrap">
 
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

          <div class="form-group nomargin contform2">
            <label>Order ID</label>
            <input type="number" class="form-control" name="order_id">
          </div>
          <div class="form-group nomargin contform2">
            <label>Bill From</label>
            <input type="text" class="form-control" name="bill_from">
          </div>
          <div class="form-group nomargin contform2">
            <label>Bill To</label>
            <input type="text" class="form-control" name="bill_to">
          </div>
           <div class="form-group nomargin contform2">
            <label>Shipment</label>
            <input type="text" class="form-control" name="shipment">
          </div>
          <div class="form-group nomargin contform2">
            <label>Date</label>
            <div class="datepicker" name="date">
              <div class="row">
                <div id="title" class="label">1st May 2015</div>
              </div>
              <div class="block action" onclick="addDay(1)">+</div>
              <div class="block action" onclick="addMonth(1)">+</div>
              <div class="block action" onclick="addYear(1)">+</div>
              <div ></div>
              <div class="block middle" id="day">1</div>
              <div class="block middle" id="month">May</div>
              <div class="block middle" id="year">15</div>
              <div ></div>
              <div class="block action" onclick="addDay(-1)">-</div>
              <div class="block action" onclick="addMonth(-1)">-</div>
              <div class="block action" onclick="addYear(-1)">-</div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="textcen"> </div>
        </div>
      </div>
      </div>
      <div class="dividers"></div>
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="textsets">
            <h4><b>Products</b></h4>
          </div>
        </div>
        <div class="field_wrapper">
          <div class="opendiv">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
              <div class="boxborder">
                <div class="form-group nomargin contform2">
                  <label for="email">Product Id</label>
                  <input type="text" class="form-control" name="product_id[]">
                </div>
                <div class="form-group nomargin contform2">
                  <label for="email">Product Name</label>
                  <input type="text" class="form-control" name="product_name[]">
                </div>
                <div class="form-group contform2">
                  <label for="comment">Product Description</label>
                  <textarea class="form-control" rows="5"  name="product_description[]"></textarea>
                </div>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="form-group nomargin contform2">
                      <label for="email">Quantity</label>
                      <input type="number" class="form-control blueborder" id="" placeholder="Quantity" name="quantity[]">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="form-group nomargin contform2">
                      <label for="email">Price</label>
                      <input type="number" class="form-control blueborder" id="" placeholder="Price" name="price[]">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="form-group nomargin contform2">
                      <label for="email">Size</label>
                      <input type="text" class="form-control blueborder" id="" placeholder="Size" name="size[]">
                    </div>
                  </div>
                </div>
                <div class="form-group nomargin contform2">
                  <label for="email">Promotions</label>
                  <input type="text" class="form-control blueborder" id="" placeholder="Promotions" name="promotion[]">
                </div>

              </div>
            </div>
            <br>
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="plusbutton">
                <a href="javascript:void(0);" class="add_button2 plusbtn" title="Add field"><span class="glyphicon glyphicon-plus"></span></a>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="row">
                  <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12 col-lg-offset-2">
                    <div class="form-group nomargin contform2">
                      <label for="email">Amount</label>
                      <input type="number" class="form-control" name="amount">
                    </div>
                  </div>
                </div>
                 <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-lg-offset-4">
      <div class="widheight">
            <button type="submit" class="submitbtn btn">Submit</button>
          </div>
      </div>

      </div>

    </div>
    <!-- /page content -->

    </form>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/add_invoice_view.blade.php ENDPATH**/ ?>