<?php $__env->startSection('content'); ?> 
<!--Shop Area Start-->
<div class="gray-bg3">
  <div class="shop-area mb-20">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-sm-12 col-xs-12 mt-20">
          <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
                <div class="shop-sidebar">
                  <h4>By categories</h4>
                  <div class="categori-checkbox">
                    <ul>
                      <h4 class="green">All Products</h4>
            
            <li><a href="<?php echo e(url('/')); ?>/home">Homes</a> </li>
            <li><a href="<?php echo e(url('/')); ?>/commercial">Commercial</a> </li>
            <li><a href="<?php echo e(url('/')); ?>/plot">Plots</a></li>
             <li><a href="<?php echo e(url('/')); ?>/flat">Apartments</a> </li>
           <li> <a href="<?php echo e(url('/')); ?>/land">Agriculture Land</a></li>
            <li> <a href="<?php echo e(url('/')); ?>/rent">Rent</a> </li>
           <li> <a href="<?php echo e(url('/')); ?>/sale">Sale</a></li> 
            <li><a href="<?php echo e(url('/')); ?>/office">Offices</a> </li>
            <li><a href="<?php echo e(url('/')); ?>/hot">Wanted</a></li>
            <li><a href="<?php echo e(url('/')); ?>/agents">Agents</a> </li>

                    </ul>
                  </div>
                </div>
              </div>
        </div>
        <div class="col-lg-9 col-sm-12 col-xs-12 mt-20 white-bg">
          <div class="row">
            <div class="col-lg-12 col-sm-12 col-xs-12 mt-20">
              <h3>House for sale in all cities of Pakistan</h3>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-3 col-sm-3 col-xs-12 mt-20">
              <ul style="list-style:none;">
                <?php if(count($sale)>0): ?>
                <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('/')); ?>/property/home/<?php echo e($results->city); ?>"><?php echo e($results->city); ?> <span>(<?php echo e($results->count); ?>)</span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </ul>
            </div>
        
          </div>
          <div class="row">
            <div class="col-lg-12 col-sm-12 col-xs-12 mt-20">
              <h3>House for rent in all cities of Pakistan</h3>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-3 col-sm-3 col-xs-12 mt-20">
              <ul style="list-style:none;">
              <?php if(count($rent)>0): ?>
                <?php $__currentLoopData = $rent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('/')); ?>/property/home/<?php echo e($results->city); ?>"><?php echo e($results->city); ?> <span>(<?php echo e($results->count); ?>)</span></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </ul>
            </div>
      
         
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--Shop Area End--> 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/home_list_view.blade.php ENDPATH**/ ?>