
<?php $__env->startSection('content'); ?> 
<!--Login Register Area Strat-->
<div class="container">
  <div class="page-title">
    <div class="row">
      <div class="col-md-10 col-sm-12 col-xs-12">
        <div class="title_left m-2">
          <h3>Message Management</h3>
          <h4>Message List</h4>
        </div>
      </div>
      <div class="col-md-2 col-sm-12 col-xs-12">
        <div class="title_left m-2"> <a href="<?php echo e(url('/')); ?>/client/compose/message" type="button" class="add-btn pull-right"><i class="fa fa-plus"></i> Compose New Message</a> </div>
      </div>
    </div>
  </div>
  
  <!-- Nav pills -->
  <ul class="nav nav-pills" role="tablist">
    <li class="nav-item"> <a class="nav-link active" data-toggle="pill" href="#home">New Message</a> </li>
    <li class="nav-item"> <a class="nav-link" data-toggle="pill" href="#menu1">Delivered Message </a> </li>
  </ul>
  
  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
      <?php if(count($result)>0): ?>
      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $seller = DB::select("select* from client_details where pk_id ='$results->seller_name'");
      ?>
      <div class="messg mb-20 p-2"><a href="#">
        <div class="row borderbotm">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="dbicon">
              <h3><span><?php echo e($results->date); ?></span><br>
                <?php if($results->seller_name == 'admin'): ?>
                HOUZZ  <?php else: ?> <?php if(count($seller)>0): ?> <?php echo e($seller[0]->fname); ?> <?php echo e($seller[0]->lname); ?> <?php endif; ?> <?php endif; ?></h3>
            </div>
          </div>
          <div class="col-lg-8 col-md-8 col-sm-12">
            <div class="dbparahs">
              <p><?php echo e($results->message); ?></p>
              <h6><?php echo e($results->reply); ?> <i class="fa fa-angle-double-right"></i></h6>
            </div>
          </div>
        </div>
        </a></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?> </div>
    <div id="menu1" class="container tab-pane fade"><br>
    <?php if(count($result1)>0): ?>
      <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $seller = DB::select("select* from client_details where pk_id ='$results->seller_name'");
      ?>
      <div class="messg mb-20 p-2"><a href="#">
        <div class="row borderbotm">
          <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="dbicon">
              <h3><span><?php echo e($results->date); ?></span><br>
                <?php if($results->seller_name == 'admin'): ?>
                HOUZZ  <?php else: ?> <?php if(count($seller)>0): ?> <?php echo e($seller[0]->fname); ?> <?php echo e($seller[0]->lname); ?> <?php endif; ?> <?php endif; ?></h3>
            </div>
          </div>
          <div class="col-lg-8 col-md-8 col-sm-12">
            <div class="dbparahs">
              <p><?php echo e($results->message); ?></p>
              <h6><?php echo e($results->reply); ?> <i class="fa fa-angle-double-right"></i></h6>
            </div>
          </div>
        </div>
        </a></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      <div class="clearfix"></div>
      </div>
     
  </div>
</div>
<!--Login Register Area End-->
<div class="clearfix"></div>

<!--All Js Here--> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/message_send_view.blade.php ENDPATH**/ ?>