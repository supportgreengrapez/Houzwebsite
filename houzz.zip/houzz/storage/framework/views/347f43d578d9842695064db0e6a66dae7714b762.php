<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<meta name="google-site-verification" content="-3fR2s0fAH-tDmr1Fkt1Zn9Zv3qA3tcabWHX8mpCd28" />
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<title>Houzz</title>

<!-- Bootstrap -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
<!-- Datatables -->
<link href="<?php echo e(url('/')); ?>/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/responsive.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/scroller.bootstrap.min.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title"> <a href="<?php echo e(url('/')); ?>/" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images/favicon.png" alt="logo"></i> <span>Houzz</span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
            <ul class="nav side-menu">
              <li><a href="<?php echo e(url('/')); ?>/"><i class="fa fa-tachometer"></i> Home </a> </li>
              <li><a><i class="fa fa-table"></i> Product Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/product/list">Products</a></li>
                  <li><a href="#">Product Type</a></li>
                  <li><a href="#">Categories</a></li>
                  <li><a href="#">Sub Categories</a></li>
                  <li><a href="#">Products</a></li>
                  <li><a href="#">Brand</a></li>
                  <li><a href="#">Material</a></li>
                  <li><a href="#">Style</a></li>
                  <li><a href="#">Manage Collection</a></li>
                  <li><a href="#">Import New Product</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-file"></i> Reporting <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="#">View Users</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-envelope"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="#">View Users</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-exchange"></i> Returns </a> </li>
              <li><a><i class="fa fa-square"></i> Promotions <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="#">View Users</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-money"></i> Payments <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="#">View Users</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-star-half"></i> Rating & Review </a> </li>
              <li><a><i class="fa fa-cog"></i> Settings </a> </li>
              <li><a><i class="fa fa-th"></i> Resources </a> </li>
            </ul>
          </div>
        </div>
        <!-- /sidebar menu --> 
      </div>
    </div>
    
    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="<?php echo e(url('/')); ?>/images/vendorprofile.png" alt="">Green Grapez <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation --> 
    <?php echo $__env->yieldContent('content'); ?>
    
    <!-- footer content -->
    <footer>
      <div class=""> Copyright © 2017-2018 Houzz.com. All rights reserved. </div>
      <div class="pull-right"> Powered By <a href="https://greengrapez.com">Green Grapez <img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="green grapez" style="width:5%;"></a> </div>
      
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content --> 
  </div>
</div>

<!-- jQuery --> 
<script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script> 
<!-- Bootstrap --> 
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script> 
<!-- DateJS --> 
<script src="<?php echo e(url('/')); ?>/js/build/date.js"></script> 
<!-- bootstrap-progressbar --> 
<script src="<?php echo e(url('/')); ?>/js/bootstrap-progressbar.min.js"></script> 
<!-- iCheck --> 
<script src="<?php echo e(url('/')); ?>/js/icheck.min.js"></script> 
<!-- bootstrap-daterangepicker --> 
<script src="<?php echo e(url('/')); ?>/js/moment.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js/daterangepicker.js"></script> 
<!-- Custom Theme Scripts --> 
<script src="<?php echo e(url('/')); ?>/js/custom.min.js"></script> 
<!-- Datatables --> 
<script src="<?php echo e(url('/')); ?>/js/jquery.dataTables.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js/dataTables.bootstrap.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js/dataTables.responsive.min.js"></script> 
<script src="<?php echo e(url('/')); ?>/js/responsive.bootstrap.js"></script> 
<script src="<?php echo e(url('/')); ?>/js/dataTables.scroller.min.js"></script>
</body>
</html>
<?php /**PATH F:\xamp\htdocs\houzz\resources\views/layout/adminlayout.blade.php ENDPATH**/ ?>