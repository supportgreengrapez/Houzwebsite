<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
      <div class="page-title">
          <div class="title_left">
            <h3>Settings</h3>
            <h4 style="display: block;">View Bank</h4>
          </div>
        </div>
      </div>
      
      
      <div class="wrap">
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Bank Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->bank_name); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Account Type</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
            <p><?php echo e($result[0]->account_type); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Account Number</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p><?php echo e($result[0]->account_no); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotms">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicons">
            <h4>Routing Number</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahsss">
          
            <p><?php echo e($result[0]->routing_no); ?></p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 col-md-3 col-sm-12 col-xs-12">
          <div class="banktext">
           <a href="<?php echo e(url('/')); ?>/vendor/home/edit/bank/account/<?php echo e($result[0]->id); ?>" type="button" class="btn btn-success btn-lg">Edit</a>
          </div>
        </div>
      </div>
      
      </div>
      
    </div>
    <!-- /page content -->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/bank_account_view.blade.php ENDPATH**/ ?>