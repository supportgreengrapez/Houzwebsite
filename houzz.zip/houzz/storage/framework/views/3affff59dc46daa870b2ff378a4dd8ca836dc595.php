<?php $__env->startSection('content'); ?> 
  <!--Header Area End--> 
  <!--Breadcrumb Tow Start-->
  <div class="gray-bg3">
    <div class="container">
      <div class="white-bg p-3"> 
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="row">
            <div class="col-12">
              <div class="salogan">
                <h2 class="text-center font-weight-bold">Create Payment</h2>
              </div>
            </div>
          </div>
          <form method="post" action = "<?php echo e(url('/')); ?>/client/add/payment" class="login-form"  enctype="multipart/form-data" >
              <?php echo e(csrf_field()); ?>

          <div class="row">
            <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
            <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?> <div class="form-group nomargin contform2">
                <label>Invoice#</label>
                <input type="text" class="form-control" name="invoice_no">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <div class="form-group mt-20">
                <label for="email">Payment Receipt</label>
                <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                <img id="blah" src="img/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
              <div class="form-group nomargin contform2">
                <label>Payee</label>
                <input type="text" class="form-control" name="payee">
              </div>
              <div class="form-group nomargin contform2">
                <label>Payer</label>
                <input type="text" class="form-control" name="payer">
              </div>
            </div>
          </div>
    
          <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
              <div class="form-group">
                <label>Date</label>
                <input type="date" name="date" class="form-control" placeholder="date">
              </div>
            </div>
          
          
          </div>
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <div class="form-group nomargin contform2">
                <label>Amount</label>
                <input type="number" class="form-control" name="amount">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
              <div class="widheight">
                <button type="submit" class="submitbtn btn">Submit</button>
              </div>
            </div>
          </div>
          </form>
        </div>
        <!-- /page content --> 
      </div>
    </div>
  </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/client/add_payment_view.blade.php ENDPATH**/ ?>