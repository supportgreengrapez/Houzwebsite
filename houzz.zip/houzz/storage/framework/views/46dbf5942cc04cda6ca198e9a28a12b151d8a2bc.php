<?php $__env->startSection('content'); ?><!-- Content Wrapper. Contains page content -->



    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Product Management</h3>
            <h4 style="display: block;">Add Product Type</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
              <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/product/type" class="login-form">
                        <?php echo e(csrf_field()); ?>

                        <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong>Danger!</strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
              <div class="row">
                <div class="col-lg-5">
                    <div class="row">
                      <div class="form-group col-lg-12 col-sm-12 col-md-12">
                        <label>Add Product Type</label>
                        <input type="text" class="form-control" name="productType" placeholder="Add Product Type" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>

                      <div class="form-group col-lg-12 col-sm-12 col-md-12">
                        <label>Category Name</label>
                        <select class="form-control" name="mainCategory"  id="MainCategory" >
                     <option value="" disable="true" selected="true" >---select Category---</option>
                    <?php if($result>0): ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e(urlencode($results->main_category)); ?>"><?php echo e($results->main_category); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
                       </select>
                      </div>

                      <div class="form-group col-lg-12 col-sm-12 col-md-12">
                        <label>Category Sub Type</label>
                        <select class="form-control" name="subCategory"  id="subCategory">
                      <option value="" disable="true" selected="true" >---select sub Category---</option>
                       </select>
                      </div>

                    </div>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
                </div>

                </form>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->



      <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/admin/add_product_type_view.blade.php ENDPATH**/ ?>