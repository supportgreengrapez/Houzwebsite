<?php $__env->startSection('content'); ?>



    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
           <h3>Reporting Management</h3>
            <h4>By Sale</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="page-title">
           <h2>Total Revenue : PKR <?php echo e(number_format($total)); ?> </h2>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>O_ID</th>
                          <th>Customer Name</th>
                          <th>Price</th>
                          <th>Date</th>
                          <th>Status</th>
                          <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>

                    <?php if($result>0): ?>
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($results->pk_id); ?></td>
                          <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                     <?php if($results->promo_amount == ""): ?>
                          <td><div class="sparkbar" data-color="#f56954" data-height="20">PKR <?php echo e(number_format($results->amount)); ?></div></td>
                          <?php else: ?>
                                <td><div class="sparkbar" data-color="#f56954" data-height="20">PKR <?php echo e(number_format($results->promo_amount)); ?></div></td>
                          <?php endif; ?>

                           <td><?php echo e($results->placed_at); ?></td>
                           <td><label class="label label-info">Shipped Product</label> </td>
                          <td><a href="<?php echo e(url('/')); ?>/admin/home/view/detail/reporting/by/sale/<?php echo e($results->pk_id); ?>">View</a></td>
                        </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->



     <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/reporting_by_sale_list_view.blade.php ENDPATH**/ ?>