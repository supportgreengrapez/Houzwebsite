<!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Fashion Factory</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="<?php echo e(URL('/')); ?>/pic/fevicon.png"/>
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/bootstrap.css" type="text/css"/>
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/bootstrap.min.css" type="text/css"/>
<link type="text/css" rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/nouislider.min.css" />
<link href="<?php echo e(URL('/')); ?>/css1/slick.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL('/')); ?>/css1/slick-theme.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL('/')); ?>/css1/main.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL('/')); ?>/css1/util.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL('/')); ?>/css1/slick.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL('/')); ?>/css1/slippry.css" rel="stylesheet" type="text/css"/>
<link href="<?php echo e(URL('/')); ?>/css1/style.css" rel="stylesheet" type="text/css"/>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800" rel="stylesheet" type="text/css">
<link href="<?php echo e(URL('/')); ?>/css1/megamenu.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
<!-- //End menu -->
<!---slider---->



<!----//End-pricerage-seletion---->

</head>
<body>
    
    
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>

<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script>
  window.fbAsyncInit = function() {
    FB.init({
        appId      : '532414280614092',
      xfbml            : true,
      version          : 'v3.2'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="2165724393682276">
</div>
    
<!---start-container----> 
<!---start-header---->
<div class="header">
  <div class="top-header">
    <div class="container">
         <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <a class="mobilesOnly"></a>
     
     
   <a class="mobilesOnly"  href="tel:+923244244934" style="color:white; float:left; padding: 0px 0 0 0; margin-top: 7px;"><i class="fa fa-phone"></i> +923244244934</a>
   
   </div>
   <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
    <div class="top-header-center">Free Shipping All Over Pakistan | Cash on Delivery</div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
     <?php if(Session::has('username')): ?>   
            <li><a href="order/tracking/view" style="margin-left:10px;color:white;float:right;margin-top:10px;">Order History</a></li> 
            <?php else: ?>
        <li><a class="color8" href="guest/order/tracking/view" style="margin-left:10px;color:white;float:right;margin-top:10px;"> Order Tracking</a>  </li>
        <?php endif; ?>
        </div>
        </div>
        
    </div>
  </div>
  <!----start-mid-head---->
  <div class="container">
  <div class="row">
  <div class="col-lg-2">
  <div class="mid-grid-left"> <a href="<?php echo e(url('/')); ?>/">
      	<img src="<?php echo e(url('/')); ?>/pic/logo.png" alt="logo">
      </a> </div>
  </div>
  
  <!----//End-mid-head----> 
  <!----start-bottom-header---->

 


  <div class="col-lg-10">
  <div class="header-bottom">
      <!-- start header menu -->
      <div class="col-lg-6">
      <div class="mid-grid-right">
        <form  role="form" action="<?php echo e(url('/')); ?>/search" method="post" id="payment-form">
          <?php echo e(csrf_field()); ?>

          <div class="input-group add-on">
            <input class="form-control" placeholder="Search" name="search" id="srch-term" type="text" style="margin:0px;">
            <div class="input-group-btn">
              <button class="btn btn-default" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </form>
      </div>
      </div>
	
  <div class="col-lg-6">
       <div class="top-header-left" id="cartscroll">
        <ul>
 
                   <li><a class="cart" href="<?php echo e(URL('/')); ?>/cart"><span></span><div class="badge">  <?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : '0'); ?> </div></a></li>
                   <!---start-cart-bag---->
                   
                 </ul>
               </div>
               <div class="top-header-right">
               
                 <ul>
                     <?php if(Session::has('username')): ?>                  
    <li class="dropdown dropdown-btn">
        <a class="dropdown-toggle" data-toggle="dropdown">
            <div id="uniqueId"><?php echo e(session::get('name')); ?><span class="caret"/></span></div>
        </a >
        <ul class="dropdown-menu">
            <li><a href="<?php echo e(URL('/')); ?>/logout">logout</a></li>
        </ul>
    </li>
    <li class="dropdown dropdown-btn">
        <a class="dropdown-toggle" data-toggle="dropdown">
            <div id="uniqueId2">wishlist<span class="caret"/></span></div>
        </a >
        <ul class="dropdown-menu">
                 <li><a href="<?php echo e(URL('/')); ?>/search/wishlist"> Search wishlist</a></li>
     <li><a href="<?php echo e(URL('/')); ?>/view/wishlist">  view my wishlist</a></li>
        </ul>
    </li>
                  
                     <?php else: ?>
                     <li><a href="<?php echo e(URL('/')); ?>/login" style="margin-left:10px;">Log in</a></li>  
                     <li><a href="<?php echo e(URL('/')); ?>/signup" style="margin-left:10px;">Join</a></li>
   		     <li><a href="<?php echo e(URL('/')); ?>/search/wishlist" style="margin-left:10px;">wishlist</a></li>
                     <?php endif; ?>
                    
    
        </ul>
      </div>
      <div class="clear"> </div>
  </div>	
      <div class="clear"> </div>
      <ul class="megamenu skyblue">
        <li class="grid"><a class="color2" href="<?php echo e(URL('/')); ?>/">Home</a> </li>
    
        <li><a class="color8" href="<?php echo e(URL('/')); ?>/product/garments">Garments</a>
          <div class="megapanel">
            <div class="row">
              <div class="col2">
                <div class="h_nav">
                  <h4> <a href="<?php echo e(URL('/')); ?>/product/garments/garments category">Garments Category</a></h4>
                 
                  <ul>
                    <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/tshirts">T-Shirts</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/hoodies">Hoodies</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/trouser">Trouser</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/abaya">Abaya</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/scarfs">Scarfs</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/printed lawn">Printed Lawn</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/embroidery fabrics">Embroidery Fabrics</a></li>
                    </ul>
                </div>
              </div>

              <div class="col1">
                <div class="h_nav">
                  <h4><a href="<?php echo e(URL('/')); ?>/product/garments/kids category">Kids Category</a></h4>
                  <ul>
                    <li><a href="<?php echo e(URL('/')); ?>/product/garments/kids category/children">Children</a></li>
                
                  </ul>
                </div>
                <div class="h_nav">
                
                  <h4 class="top"><a href="<?php echo e(URL('/')); ?>/product/garments/leather category">Leather Category</a></h4>
                  <ul>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/leather category/leather garments">Leather Garments</a></li>
             
                  </ul>
                </div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
              </div>
            </div>
          </div>
        </li>
        <li class="grid"><a class="color2" href="<?php echo e(URL('/')); ?>/product/shoes">Shoes</a>
        <div class="megapanel">
            <div class="row">
              <div class="col1">
                <div class="h_nav">
                  <h4> <a href="<?php echo e(URL('/')); ?>/product/garments/garments category">Shoes Category</a></h4>
                 
                  <ul>
                    <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/tshirts">Kitten heel</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/hoodies">Kolhapuri Chappal.</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/trouser">Jelly shoes</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/abaya">Dress shoes</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/scarfs">Earth shoes</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/printed lawn">Elevator shoes</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/garments category/embroidery fabrics">Ruby slippers </a></li>
                    </ul>
                </div>
              </div>

              <div class="col1">
                <div class="h_nav">
                  <h4><a href="<?php echo e(URL('/')); ?>/product/garments/kids category">Kids Category</a></h4>
                  <ul>
                    <li><a href="<?php echo e(URL('/')); ?>/product/garments/kids category/children">Children</a></li>
                
                  </ul>
                </div>
                <div class="h_nav">
                
                  <h4 class="top"><a href="<?php echo e(URL('/')); ?>/product/garments/leather category">Leather Category</a></h4>
                  <ul>
                      <li><a href="<?php echo e(URL('/')); ?>/product/garments/leather category/leather garments">Leather Garments</a></li>
             
                  </ul>
                </div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
              </div>
            </div>
          </div>
        </li>
           
        <li><a class="color8" href="<?php echo e(URL('/')); ?>/product/accessories">Accessories</a>
          <div class="megapanel">
            <div class="row">
              <div class="col1">
                <div class="h_nav">
                  <h4> <a href="<?php echo e(URL('/')); ?>/product/accessories/accessories">Accessories</a></h4>
                 
                  <ul>
                      <li><a href="<?php echo e(URL('/')); ?>/product/accessories/accessories/car accessories">Car Accessories</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/accessories/accessories/general accessories">General Accessories</a></li>
                      <li><a href="<?php echo e(URL('/')); ?>/product/accessories/accessories/bags and wallets">Bags and Wallet</a></li>
   </ul>
                </div>
              </div>

              <div class="col1">
             
         
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
              </div>
            </div>
          </div>
        </li>

        <li><a class="color8" href="<?php echo e(URL('/')); ?>/product/home textile">Home Textile</a>
          <div class="megapanel">
            <div class="row">
              <div class="col1">
                <div class="h_nav">
                  <h4> <a href="<?php echo e(URL('/')); ?>/product/home textile/bed sheets">Bed Sheets</a></h4>
                 
                  <ul>
                      <li><a href="<?php echo e(URL('/')); ?>/product/home textile/bed sheets/fitted bedsheets">Fitted bedsheets</a></li>
                    <li><a href="<?php echo e(URL('/')); ?>/product/home textile/bed sheets/knitted bedsheets">Knitted bedsheets</a></li>
   </ul>
                </div>
              </div>

              <div class="col1">
             
         
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
                <div class="col1"></div>
              </div>
            </div>
          </div>
        </li>
      <!--<?php if(Session::has('username')): ?>   -->
      <!--      <li><a href="order/tracking/view" style="margin-left:10px;">Order History</a></li> -->
      <!--      <?php else: ?>-->
      <!--  <li><a class="color8" href="guest/order/tracking/view"> Order Tracking</a>  </li>-->
      <!--  <?php endif; ?>-->
          
      
      </ul>

      
  </div>
  </div>
  </div>
  </div>
</div>

  
                


                            
 <?php echo $__env->yieldContent('content'); ?>


 <div class="footer1">
    <div class="container-fluid ">
      <div class="row"><!-- row -->
        
        <div class="col-lg-3 col-md-3"><!-- widgets column left -->
          <ul class="list-unstyled clear-margins">
            <!-- widgets -->
            
            <li class="widget-container widget_nav_menu"><!-- widgets list -->
              
              <h1 class="title-widget">NewsLetter</h1>
              <ul>
                <li><div class="input-group"> <span class="input-group-addon"><svg class="svg-inline--fa fa-envelope fa-w-16" aria-hidden="true" data-prefix="fa" data-icon="envelope" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"></path></svg><!-- <i class="fa fa-envelope fa" aria-hidden="true"></i> --></span>
              <input type="text" class="form-control" name="email" id="email" placeholder="Enter your Email">
            </div></li>
              </ul>
            </li>
          </ul>
        </div>
        <!-- widgets column left end -->
        
        <div class="col-lg-3 col-md-3"><!-- widgets column left -->
          
          <ul class="list-unstyled clear-margins">
            <!-- widgets -->
            
            <li class="widget-container widget_nav_menu"><!-- widgets list -->
              
              <h1 class="title-widget">MY ACCOUNT</h1>
              <ul>
                <li><a  href="<?php echo e(url('/')); ?>/signup">Create Account</a></li>
                <li><a  href="<?php echo e(url('/')); ?>/accounts">Accounts</a></li>
              </ul>
            </li>
          </ul>
        </div>

        <div class="col-lg-3 col-md-3"><!-- widgets column left -->
          
          <ul class="list-unstyled clear-margins">
            <!-- widgets -->
            
            <li class="widget-container widget_nav_menu"><!-- widgets list -->
              
              <h1 class="title-widget">MAKE MONEY WITH US</h1>
              <ul>
                <li><a  href="<?php echo e(url('/')); ?>/vendor/signup">Become a Vendor</a></li>
                <li><a  href="<?php echo e(url('/')); ?>/vendor/login">Vendor Login</a></li>
                  
              </ul>
            </li>
          </ul>
        </div>
        <!-- widgets column left end -->
        
        <div class="col-lg-3 col-md-3"><!-- widgets column left -->
          
          <ul class="list-unstyled clear-margins">
            <!-- widgets -->
            
            <li class="widget-container widget_nav_menu"><!-- widgets list -->
              
              <h1 class="title-widget">CUSTOMER SERVICS</h1>
              <ul>
         
                <li><a  href="<?php echo e(url('/')); ?>/aboutus">About Us</a></li>
                <li><a href="<?php echo e(url('/')); ?>/faq"> FAQ</a></li>
                
                <li><a href="<?php echo e(url('/')); ?>/returns/and/refunds"> Returns & Refunds</a></li>
                <li><a href="<?php echo e(url('/')); ?>/terms/and/conditions">Terms and Conditions</a></li>
                <li><a href="<?php echo e(url('/')); ?>/search/wishlist"> Wish List</a></li>
              <li><a href="<?php echo e(url('/')); ?>/payment/policy"> Payment Policy</a></li>
              <li><a href="<?php echo e(url('/')); ?>/privacy/policy"> Privacy Policy</a></li>
                <li><a href="<?php echo e(url('/')); ?>/contact/us"> Contact Us</a></li>
                <li><a href="<?php echo e(url('/')); ?>/warranty/and/repairs"> Warranty & Repair</a></li>
             </ul>
            </li>
          </ul>
        </div>
        <!-- widgets column left end -->
        
        <div class="col-lg-3 col-md-3"><!-- widgets column center -->
          
          <ul class="list-unstyled clear-margins">
            <!-- widgets -->
            
            <li class="widget-container widget_recent_news"><!-- widgets list -->
              <div class="footerp">
                <p><b>Email id : </b> <a href="https://mail.google.com/mail/u/0/">support@fashionfactory.com</a></p>
                <p><b>Phone Numbers : </b><a class="mobilesOnly"  href="tel:+923244244934"> +92 324 4244934</p>
              </div>
              <div class="social-icons">
                <ul class="nomargin">
                  <a target="_blank" href="https://www.facebook.com/FashionFactoryWorld1/"><i class="fab fa-facebook-square fa-3x social-fb" id="social"></i></a> <a target="_blank" href="#"><i class="fab fa-twitter-square fa-3x social-tw" id="social1"></i></a><a target="_blank" href="https://www.instagram.com/fashionfactory_world"><i class="fab fa-instagram instagram"></i></a> 
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12">
          <div class="design">Copyright © 2019 Fashion Factory. All rights reserved. <br>
           <p>Powered By : <a href="https://greengrapez.com/" target="_blank"><img src="<?php echo e(url('/')); ?>/pic/GG.png" alt="logo" style="max-width:70px;"></a></p></div>
        </div>
      </div>
    </div>
  </div>
  <!---//End-container---->


  	<!-- Container Selection -->
	<div id="dropDownSelect1"></div>
	<div id="dropDownSelect2"></div>
<!-- Product Detail -->

<!--End of Tawk.to Script-->
<script src="<?php echo e(URL('/')); ?>/js1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js1/slick.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js1/nouislider.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js1/jquery.zoom.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js1/main.js"></script>
<script src="<?php echo e(URL('/')); ?>/js1/fontawesome-all.min.js"></script>
<script src="<?php echo e(URL('/')); ?>/js/magiczoomplus.js"></script>
<script src="<?php echo e(URL('/')); ?>/js/animsition.js"></script>
<script src="<?php echo e(URL('/')); ?>/js/select2.min.js"></script>
<script src="<?php echo e(URL('/')); ?>/js/slick.min.js"></script>
<script src="<?php echo e(URL('/')); ?>/js/slick-custom.js"></script>
<script src="<?php echo e(URL('/')); ?>/js/sweetalert.min.js"></script>
<script src="<?php echo e(URL('/')); ?>/js1/jquery-ui.js" type="text/javascript"></script>
<script src="<?php echo e(URL('/')); ?>/js1/scripts-f0e4e0c2.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(URL('/')); ?>/js1/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>

<script src="<?php echo e(URL('/')); ?>/js1/menu_jquery.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script> 
<script>
    $(document).ready( function () {
    $('#myTable').dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": true,
          "bSort": false,
          "bInfo": false,
          "bAutoWidth": false
        });
} );
    </script>
<script>
			  jQuery('#jquery-demo').slippry({
			  // general elements & containerper
			  slipprycontainerper: '<div class="sy-box jquery-demo" />', // containerper to container everything, including pager
			  // options
			  adaptiveHeight: false, // height of the sliders adapts to current slide
			  useCSS: false, // true, false -> fallback to js if no browser support
			  autoHover: false,
			  transition: 'fade'
			});
		</script>

<script type="text/javascript">//<![CDATA[ 
			$(window).load(function(){
			 $( "#slider-range" ).slider({
			            range: true,
			            min: 0,
			            max: 500,
			            values: [ 100, 400 ],
			            slide: function( event, ui ) {  $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
			            }
			 });
			$( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) + " - $" + $( "#slider-range" ).slider( "values", 1 ) );
			
			});//]]>  
		</script>
		<script type="text/javascript">
		$('.block2-btn-addcart').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to cart !", "success");
			});
		});

		$('.block2-btn-addwishlist').each(function(){
			var nameProduct = $(this).parent().parent().parent().find('.block2-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to wishlist !", "success");
			});
		});

		$('.btn-addcart-product-detail').each(function(){
			var nameProduct = $('.product-detail-name').html();
			$(this).on('click', function(){
				swal(nameProduct, "is added to wishlist !", "success");
			});
		});
		
		function myFunction() {
    var checkBox = document.getElementById("myCheck");
    var text = document.getElementById("text");
	var textbox = document.getElementById("textbox");
    if (checkBox.checked == true){
        text.style.display = "block";
		textbox.style.display = "none";
    } else {
       text.style.display = "none";
	   textbox.style.display = "block";
    }
}
	</script>
  <!--Start of Tawk.to Script-->

  <script type="text/javascript">
      $(document).ready(function () {
          $(".sub > a").click(function() {
              var ul = $(this).next(),
                      clone = ul.clone().css({"height":"auto"}).appendTo(".mini-menu"),
                      height = ul.css("height") === "0px" ? ul[0].scrollHeight + "px" : "0px";
              clone.remove();
              ul.animate({"height":height});
              return false;
          });
             $('.mini-menu > ul > li > a').click(function(){
             $('.sub a').removeClass('active');
             $(this).addClass('active');
          }),
             $('.sub ul li a').click(function(){
             $('.sub ul li a').removeClass('active');
             $(this).addClass('active');
          });
      });
  
  
    function filterSystem(minPrice, maxPrice) {
        $(".items div.item").hide().filter(function () {
            var price = parseInt($(this).data("price"), 10);
            return price >= minPrice && price <= maxPrice;
        }).show();
    }
  </script>
  </body>
  </html>
  
  
  <?php /**PATH C:\xampp\htdocs\houzz\resources\views/client/layout/app.blade.php ENDPATH**/ ?>