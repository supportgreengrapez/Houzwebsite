<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
            <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Admin Management</h3>
            <h4>Admin</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
            <a href="<?php echo e(url('/')); ?>/admin/home/create/admin" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Add Admin</a>
          </div>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>

                      <th>Admin Name</th>
                      <th>Permisions</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php if($result>0): ?>
                          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></td>
                      <?php if($results->admin_management==1): ?>
                      <td><span class="label label-info">Admin & management</span>
                      <?php endif; ?>
                      <?php if($results->product_management==1): ?>
                      <span class="label label-info">Product Manegement</span>
                      <?php endif; ?>

                      <!-- <?php if($results->product_management==1): ?>
                      <span class="label label-info">Blog</span>
                      <?php endif; ?>

                      <?php if($results->product_management==1): ?>
                      <span class="label label-info">Seller</span>
                      <?php endif; ?>
                      <?php if($results->product_management==1): ?>
                      <span class="label label-info">Customer</span>
                      <?php endif; ?> -->

                      <?php if($results->category_management==1): ?>
                          <span class="label label-primary">Category Management</span>
                          <?php endif; ?>

                           <?php if($results->brand_management==1): ?>
                          <span class="label label-warning">Brand anagemen</span>
                            <?php endif; ?>
                          <?php if($results->order_management==1): ?>
                            <span class="label label-success">Order Management</span>
                            <?php endif; ?>
                            <?php if($results->reporting==1): ?>
                          <span class="label label-primary">Reporting</span>
                          <?php endif; ?>


                          <?php if($results->discount==1): ?>
                          <span class="label label-warning">Discount</span>
                            <?php endif; ?>
                          <?php if($results->promocode==1): ?>
                            <span class="label label-success">Promocode</span>
                            <?php endif; ?>
                            <?php if($results->vendor_management==1): ?>
                          <span class="label label-primary">Vendor Management</span>
                          <?php endif; ?>


                      </td>

                      <td>

                      <form method="post" enctype="multipart/form-data" action = "<?php echo e(URL('/')); ?>/admin/home/delete/admin/<?php echo e($results->pk_id); ?>" >

<?php echo e(csrf_field()); ?>

<a href="<?php echo e(URL('/')); ?>/admin/home/view/admin/<?php echo e($results->pk_id); ?>">View</a>
                      <a href="<?php echo e(url('/')); ?>/admin/home/view/admin/edit/admin/<?php echo e($result[0]->pk_id); ?>">Edit</a>
                      <button type="submit" class=" btn btn-link red">Delete</button>
                      </form>
                      </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?>
                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


      <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/view_admin_list.blade.php ENDPATH**/ ?>