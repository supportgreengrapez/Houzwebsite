<?php $__env->startSection('content'); ?>



    <!-- page content -->
    <div class="right_col" role="main">
      <div class="page-title">
        <div class="title_left">
          <h3>Admin Management</h3>
            <h4 style="display:block;">Admin View</h4>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h4>Name</h4>
           </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahss">
            <p ><?php echo e($result[0]->fname); ?> <?php echo e($result[0]->lname); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h4>Email</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahss">

            <p ><?php echo e($result[0]->username); ?></p>
          </div>
        </div>
      </div>

      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h4>Phone</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahss">

            <p ><?php echo e($result[0]->phone); ?></p>
          </div>
        </div>
      </div>

      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h4>Address</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahss">

            <p ><?php echo e($result[0]->address); ?></p>
          </div>
        </div>
      </div>

      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h4>Image</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahss">

            <p ><?php echo e($result[0]->thumbnail); ?></p>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h4>Permisions</h4>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahss">
            <p><span class="label label-info">Admin & management</span>
            <?php if($result[0]->admin_management==1): ?>
                          <span class="label label-warning">Admin</span>
                            <?php endif; ?>
                          <?php if($result[0]->product_management==1): ?>
                            <span class="label label-success">Product </span>
                            <?php endif; ?>
                            <?php if($result[0]->category_management==1): ?>
                          <span class="label label-primary">Category</span>
                          <?php endif; ?>

                           <?php if($result[0]->brand_management==1): ?>
                          <span class="label label-warning">Brand </span>
                            <?php endif; ?>
                          <?php if($result[0]->order_management==1): ?>
                            <span class="label label-success">Order Management</span>
                            <?php endif; ?>
                            <?php if($result[0]->reporting==1): ?>
                          <span class="label label-primary">Reporting</span>
                          <?php endif; ?>

                           <?php if($result[0]->discount==1): ?>
                          <span class="label label-warning">Discount</span>
                            <?php endif; ?>
                          <?php if($result[0]->promocode==1): ?>
                            <span class="label label-success">Promocode</span>
                            <?php endif; ?>
                            <?php if($result[0]->vendor_management==1): ?>
                          <span class="label label-primary">Vendor Management</span>
                          <?php endif; ?></p>

          </div>
        </div>
      </div>

    </div>
    <!-- /page content -->


      <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/admin/view_admin_profile.blade.php ENDPATH**/ ?>