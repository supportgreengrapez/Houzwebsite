<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="page-title">
          <div class="title_left">
            <h3>Seller</h3>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Products</h3>
            <img src="<?php echo e(url('/')); ?>/images/12.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <span><?php echo e($p); ?> active products.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="<?php echo e(url('/')); ?>/vendor/home/add/product">Add or manage your products <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Payments</h3>
            <img src="<?php echo e(url('/')); ?>/images/13.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <span>No recent payments.</span></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="">View your payments <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row borderbotm">
        <div class="col-lg-3 col-md-3 col-sm-12">
          <div class="dbicon">
            <h3>Orders</h3>
            <img src="<?php echo e(url('/')); ?>/images/14.jpg" alt="icon"> </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-12">
          <div class="dbparahs">
            <p>You have <?php echo e($week); ?> Order in the last week. View <a href="<?php echo e(url('/')); ?>/vendor/home/view/active/orders"><span>Previous Orders here.</span></a></p>
            <p style="margin-top: 25px;">You can create products and multiple variants easily usingthe self service tool OR you can bulk import products.</p>
            <h6><a href="<?php echo e(url('/')); ?>/vendor/home/view/active/orders">Manage your Orders <i class="fa fa-angle-double-right"></i></a></h6>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="<?php echo e(url('/')); ?>/images/2.png" alt="icons">
            <div class="dbboticonstext">
              <h4>hjfj<br>
                <span>Processing</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="<?php echo e(url('/')); ?>/images/3.png" alt="icons">
            <div class="dbboticonstext">
              <h4> <?php echo e($hold); ?><br>
                <span>On Hold</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="<?php echo e(url('/')); ?>/images/4.png" alt="icons">
            <div class="dbboticonstext">
              <h4><?php echo e($shipped); ?> <br>
                <span>Shipped</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="<?php echo e(url('/')); ?>/images/5.png" alt="icons">
            <div class="dbboticonstext">
              <h4><?php echo e($return); ?><br>
                <span>Returned</span></h4>
            </div>
          </div>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
          <div class="dbboticons"> <img src="<?php echo e(url('/')); ?>/images/6.png" alt="icons">
            <div class="dbboticonstext">
              <h4><?php echo e($cancel); ?> <br>
                <span>Cancelled</span></h4>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


      <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\houzz\resources\views/vendor/home.blade.php ENDPATH**/ ?>