<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main"><div class="page-title">
          <div class="title_left">
            <h3>Package Management</h3>
            <h4 style="display: block;"><?php echo e(Session::has('package_name') ? Session::get('package_name') : 'NONE'); ?></h4>
          </div>
        </div>
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="textcen2" style="margin:0px !important;">
  
          <h1><?php echo e(Session::has('package_name') ? 'Your Request has been Submitted. Please Check Your Email' : 'Please Select Your Package Plan'); ?></h1>  

          </div>
        </div>
      </div>
      <div class="row" style="margin-bottom: 40px;">
      <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
      
          <div class="pricinglist">
            <div class="pricelisthead">
              <h2 style="font-size:18px !important;">BASIC</h2>
            </div>
            <div class="menu">
              <ul class="nav navbar-nav widthtab">
              <li><span class="menu1">Add Products</span></li>
              <li><span class="menu1">Hot Products</span></li>
                <li><span class="menu1">Manage inventory collections for online sale</span></li>
                <li><span class="menu1">Manage inventory collections for shop/store offline sale</span></li>
                <li><span class="menu1">Add Promotions</span></li>
                <li><span class="menu1">Add Group Products</span></li>
                <li><span class="menu1">Paymeny reports</span></li>
                <li><span class="menu1">Invoice with logo</span></li>
                <li><span class="menu1">Message box</span></li>
                <li><span class="menu1">Add Clients</span></li>
                <li><span class="menu1">Featured Product</span></li>
                <li><span class="menu1">Chat box</span></li>
                <li><span class="menu1">Featured seller</span></li>
                <li><span class="menu1">Duration</span></li>
              </ul>
            </div>

            <div class="pricelisthead">
              <h2 style="font-size:18px !important;">Free</h2>
            </div>

         
            <form action="<?php echo e(url('/')); ?>/vendor/home/subscribe/COMMISSION/BASIC/0" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

         
            <button type="submit"  class="btn btn-success btn-lg"><?php if(Session::get('package_name') == 'BASIC'): ?> SUBSCRIBED <?php else: ?> Get Started <?php endif; ?>
        
            </button>
</form>


          </div>
      
        </div>
         <?php if(count($result1)>0): ?>
        <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
       
          <div class="pricinglist">
            <div class="pricelisthead">
              <h2 style="font-size:18px !important;"><?php echo e($results->package_name); ?></h2>
            </div>
            <div class="menu">
              <ul class="nav navbar-nav widthtab">
                <li><span class="menu1"><?php if(!empty($results->no_of_product)): ?>Add Products <?php echo e($results->no_of_product); ?>  <?php else: ?> ---<?php endif; ?></span></li>
                <li><span class="menu1"><?php if(!empty($results->hot_product)): ?>Hot Products <?php echo e($results->hot_product); ?>  <?php else: ?> ---<?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->online_inventory == 1): ?> Manage inventory collections for online sale <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->offline_inventory == 1): ?> Manage inventory collections for shop/store offline sale <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->promotion == 1): ?>Add Promotions  <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"> Add Group Products</span></li>
                <li><span class="menu1"><?php if($results->payment_report == 1): ?>Paymeny reports  <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->invoice == 1): ?>Invoice with logo  <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->message_box == 1): ?> Message box  <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->client == 1): ?> Add Clients  <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->featured_product == 1): ?>Featured Product <?php echo e($results->featured_product); ?> <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->chat_box == 1): ?>Chat box  <?php else: ?> --- <?php endif; ?></span></li>
                <li><span class="menu1"><?php if($results->featured_seller == 1): ?>Featured seller  <?php else: ?> --- <?php endif; ?></span></li>
              <li><span class="menu1">Duration 1 Month</span></li>
              </ul>
            </div>

            <div class="pricelisthead">
              <h2 style="font-size:18px !important;"><?php echo e($results->package_price); ?></h2>
            </div>

         
            <form action="<?php echo e(url('/')); ?>/vendor/home/subscribe/SUBSCRIPTION/<?php echo e($results->package_name); ?>/<?php echo e($results->package_price); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

         
            <button type="submit"  class="btn btn-success btn-lg"><?php if(Session::get('package_name') == $results->package_name): ?> SUBSCRIBED <?php else: ?> Get Started <?php endif; ?></button>
</form>


          </div>
          
        </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      </div>
    </div>
    <!-- /page content -->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/vendor/package_view.blade.php ENDPATH**/ ?>