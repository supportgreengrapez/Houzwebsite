<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">


            <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Order Management</h3>
            <h4>Invoice List</h4>
          </div>
          </div>
          <div class="col-md-2 col-sm-12 col-xs-12">
          <div class="title_left">
            <a href="<?php echo e(url('/')); ?>/admin/add/invoice/view" type="button" class="btn btn-success pull-right"><i class="fa fa-plus"></i> Create Invoice</a>
          </div>
          </div>
          </div>
        </div>
        <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/search/invoice/by/order/id" class="login-form">
                            <?php echo e(csrf_field()); ?>

      <div class="row">
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by order Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="number" name="search" class="form-control" id="inputPassword" placeholder="Order ID">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
        </div>
      </div>
      </form>
      <div class="row">
        <div class="col-lg-4 mt-20">
          <div class="row form-group">
            <label for="inputPassword" class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">Filter by order type :</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <select class="form-control">
                <option>All</option>
                <option>Days</option>
                <option>Weeks</option>
                <option>Months</option>
                <option>Years</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mt-20">
          <div class="row form-group">
            <label class="col-lg-5 col-sm-12 col-form-label" style="text-align:center;">Date range :</label>
            <div class="col-lg-7 col-sm-12 col-xs-12">
              <select class="form-control">
                <option>All</option>
                <option>Days</option>
                <option>Weeks</option>
                <option>Months</option>
                <option>Years</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-lg-2 mt-20">
          <div class="row form-group">
            <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">From</label>
            <div class="col-lg-8 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
        <div class="col-lg-2 mt-20">
          <div class="row form-group">
            <label class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">To</label>
            <div class="col-lg-8 col-sm-12 col-xs-12">
              <input type="date" class="form-control" id="" placeholder="">
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-2 ccol-sm-6 col-xs-6 mt-20">
          <button type="button" class="btn btnsubmit" style="width: 80% !important;">Filter Results</button>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>Invoice No</th>
                    <th>Order Id</th>
                    <th>Bill From</th>
                    <th>Bill To</th>
                    <th>Date </th>
                    <th>Shipment</th>
                    <th>Amount</th>
                    <th>Status </th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
            <?php if(count($result)>0): ?>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($results->pk_id); ?></td>
                    <td><?php echo e($results->order_id); ?></td>
                    <td><?php echo e($results->bill_from); ?></td>
                    <td><?php echo e($results->bill_to); ?></td>
                    <td><?php echo e($results->date); ?></td>
                    <td><?php echo e($results->shipment_address); ?></td>
                    <td>PKR <?php echo e(number_format($results->amount)); ?></td>
                    <td><label class="label label-success">Pending</label></td>
                    <td><a href="<?php echo e(url('/')); ?>/admin/edit/invoice/view/<?php echo e($results->pk_id); ?>" class="green">Edit</a>
                    	<a href="<?php echo e(url('/')); ?>/admin/invoice/detail/view/<?php echo e($results->pk_id); ?>/<?php echo e($results->order_id); ?>">View</a>
                        <a href="<?php echo e(url('/')); ?>/admin/delete/invoice/<?php echo e($results->pk_id); ?>/<?php echo e($results->order_id); ?>" class="red">Delete</a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/invoice_list_view.blade.php ENDPATH**/ ?>