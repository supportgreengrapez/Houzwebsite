<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<title>Houzz</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="<?php echo e(url('/')); ?>/css/style2.css" rel="stylesheet">
</head>

<body class="nav-md">
<div id="invoice">
  <div class="invoice overflow-auto">
    <div style="min-width: 600px">
      <header>
        <div class="row">
          <div class="col"> <a href="<?php echo e(URL('/')); ?>/admin/home"> <img src="<?php echo e(url('/')); ?>/images/logo.png" data-holder-rendered="true" /> </a> </div>
          <div class="col company-details">
            <h2 class="name"> Houzz.pk </h2>
            <div>455 Foggy Heights, AZ 85004, US</div>
            <div>(123) 456-789</div>
            <div>support@houzz.com</div>
          </div>
        </div>
      </header>
      <main>
        <div class="row contacts"> <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col invoice-to">
            <div class="text-gray-light">INVOICE TO:</div>
            <h2 class="to"><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></h2>
            <div class="address"><?php echo e($results->address); ?></div>
            <div class="email"><?php echo e($results->username); ?></div>
          </div>
          <div class="col invoice-details">
            <h1 class="invoice-id">INVOICE # :<?php echo e($results->pk_id); ?></h1>
            <div class="date">Date of Invoice: <?php echo e($results->created_at); ?></div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?> </div>
        <table border="0" cellspacing="0" cellpadding="0">
          <thead>
            <tr>
              <th class="text-left">Package Name</th>
              <th class="text-right">Bussiness Name</th>
              <th class="text-right">Account Type</th>
              <th class="text-right">Subscription</th>
            </tr>
          </thead>
          <tbody>
          
          <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="no"><?php echo e($results->package_name); ?></td>
            <td class="unit"><?php echo e($results->business_name); ?></td>
            <td class="qty"><?php echo e($results->account_t); ?></td>
            <td class="total"><?php echo e($results->subscription); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </tbody>
          
          <tfoot>
          
          <?php if(count($result)>0): ?>
          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="2"></td>
            <td colspan="2">Total</td>
            <td>PKR <?php echo e(number_format($results->amount)); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </tfoot>
          
        </table>
      </main>
    </div>
    <div></div>
  </div>
</div>
</body>
</html><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/invoice-page.blade.php ENDPATH**/ ?>