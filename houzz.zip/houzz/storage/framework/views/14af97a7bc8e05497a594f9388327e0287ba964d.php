<?php $__env->startSection('content'); ?>


  <!--Shop Area Start-->
  <div class="gray-bg3 pb-70">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-3 col-md-3 col-md-12 col-xs-12">
          <div class="signintophead mt-20">
            <h4>Realtor</h4>
          </div>
        </div>
      </div>

      <form method="post" action = "<?php echo e(url('/')); ?>/realtor/signin">
               <?php echo e(csrf_field()); ?>


               <?php if($errors->any()): ?>
<br>
<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
      <div class="row justify-content-center">
        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div class="bgmentorsign2">
            <div class="row">
              <div class="col-lg-3 col-md-3 col-sm-3 col-xs-5">
                <div class="form-group text-left signinlabelssets">
                  <label for="phone">Phone</label>
                  <input type="tel" class="form-control" id="" placeholder="Phone" name="phone">
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <div class="form-group text-left signinlabelssets">
                  <label for="gender">City</label>
                  <select class="form-control" style="height:42px;border:1px solid #ced4da;"  name="city">

                    <option value="Ahmadpur East">Ahmadpur East</option>
                    <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                    <option value="Alipur">Alipur</option>
                    <option value="Arifwala">Arifwala</option>
                    <option value="Attock City">Attock City</option>
                    <option value="Baddomalhi">Baddomalhi</option>
                    <option value="Bahawalnagar">Bahawalnagar</option>
                    <option value="Bahawalpur">Bahawalpur</option>
                    <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                    <option value="Basirpur">Basirpur</option>
                    <option value="Basti Dosa">Basti Dosa</option>
                    <option value="Begowala">Begowala</option>
                    <option value="Bhai Pheru">Bhai Pheru</option>
                    <option value="Bhakkar">Bhakkar</option>
                    <option value="Bhalwal">Bhalwal</option>
                    <option value="Bhawana">Bhawana</option>
                    <option value="Bhera">Bhera</option>
                    <option value="Bhopalwala">Bhopalwala</option>
                    <option value="Burewala">Burewala</option>
                    <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                    <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                    <option value="Chakwal">Chakwal</option>
                    <option value="Chawinda">Chawinda</option>
                    <option value="Chichawatni">Chichawatni</option>
                    <option value="Chiniot">Chiniot</option>
                    <option value="Chishtian Mandi">Chishtian Mandi</option>
                    <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                    <option value="Chuhar Kana">Chuhar Kana</option>
                    <option value="Chunian">Chunian</option>
                    <option value="Daira Din Panah">Daira Din Panah</option>
                    <option value="Dajal">Dajal</option>
                    <option value="Dandot RS">Dandot RS</option>
                    <option value="Darya Khan">Darya Khan</option>
                    <option value="Daska">Daska</option>
                    <option value="Daud Khel">Daud Khel</option>
                    <option value="Daultala">Daultala</option>
                    <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                    <option value="Dhanot">Dhanot</option>
                    <option value="Dhaunkal">Dhaunkal</option>
                    <option value="Dijkot">Dijkot</option>
                    <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                    <option value="Dinga">Dinga</option>
                    <option value="Dipalpur">Dipalpur</option>
                    <option value="Dullewala">Dullewala</option>
                    <option value="Dunga Bunga">Dunga Bunga</option>
                    <option value="Dunyapur">Dunyapur</option>
                    <option value="Eminabad">Eminabad</option>
                    <option value="Faisalabad">Faisalabad</option>
                    <option value="Faqirwali">Faqirwali</option>
                    <option value="Faruka">Faruka</option>
                    <option value="Fazilpur">Fazilpur</option>
                    <option value="Fort Abbas">Fort Abbas</option>
                    <option value="Garh Maharaja">Garh Maharaja</option>
                    <option value="Gojra">Gojra</option>
                    <option value="Gujar Khan">Gujar Khan</option>
                    <option value="Gujranwala">Gujranwala</option>
                    <option value="Gujrat">Gujrat</option>
                    <option value="Hadali">Hadali</option>
                    <option value="Hafizabad">Hafizabad</option>
                    <option value="Harnoli">Harnoli</option>
                    <option value="Haru Zbad">Haru Zbad</option>
                    <option value="Hasan Abdal">Hasan Abdal</option>
                    <option value="Hasilpur">Hasilpur</option>
                    <option value="Haveli">Haveli</option>
                    <option value="Hazro City">Hazro City</option>
                    <option value="Hujra">Hujra</option>
                    <option value="Jahanian Shah">Jahanian Shah</option>
                    <option value="Jalalpur">Jalalpur</option>
                    <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                    <option value="Jampur">Jampur</option>
                    <option value="Jand">Jand</option>
                    <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                    <option value="Jaranwala">Jaranwala</option>
                    <option value="Jatoi Shimali">Jatoi Shimali</option>
                    <option value="Jauharabad">Jauharabad</option>
                    <option value="Jhang City">Jhang City</option>
                    <option value="Jhang Sadr">Jhang Sadr</option>
                    <option value="Jhawarian">Jhawarian</option>
                    <option value="Jhelum">Jhelum</option>
                    <option value="Jhumra">Jhumra</option>
                    <option value="Kabirwala">Kabirwala</option>
                    <option value="Kahna">Kahna</option>
                    <option value="Kahuta">Kahuta</option>
                    <option value="Kalabagh">Kalabagh</option>
                    <option value="Kalaswala">Kalaswala</option>
                    <option value="Kaleke Mandi">Kaleke Mandi</option>
                    <option value="Kallar Kahar">Kallar Kahar</option>
                    <option value="Kalur Kot">Kalur Kot</option>
                    <option value="Kamalia">Kamalia</option>
                    <option value="Kamar Mushani">Kamar Mushani</option>
                    <option value="Kamir">Kamir</option>
                    <option value="Kamoke">Kamoke</option>
                    <option value="Kamra">Kamra</option>
                    <option value="Kanganpur">Kanganpur</option>
                    <option value="Karor">Karor</option>
                    <option value="Kasur">Kasur</option>
                    <option value="Keshupur">Keshupur</option>
                    <option value="Khairpur">Khairpur</option>
                    <option value="Khanewal">Khanewal</option>
                    <option value="Khangah Dogran">Khangah Dogran</option>
                    <option value="Khangarh">Khangarh</option>
                    <option value="Khanpur">Khanpur</option>
                    <option value="Kharian">Kharian</option>
                    <option value="Khewra">Khewra</option>
                    <option value="Khurrianwala">Khurrianwala</option>
                    <option value="Khushab">Khushab</option>
                    <option value="Kohror Pakka">Kohror Pakka</option>
                    <option value="Kot Addu">Kot Addu</option>
                    <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                    <option value="Kot Mumin">Kot Mumin</option>
                    <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                    <option value="Kot Samaba">Kot Samaba</option>
                    <option value="Kot Sultan">Kot Sultan</option>
                    <option value="Kotli Loharan">Kotli Loharan</option>
                    <option value="Kundian">Kundian</option>
                    <option value="Kunjah">Kunjah</option>
                    <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                    <option value="Lahore">Lahore</option>
                    <option value="Lala Musa">Lala Musa</option>
                    <option value="Lalian">Lalian</option>
                    <option value="Layyah">Layyah</option>
                    <option value="Liliani">Liliani</option>
                    <option value="Lodhran">Lodhran</option>
                    <option value="Mailsi">Mailsi</option>
                    <option value="Malakwal">Malakwal</option>
                    <option value="Malakwal City">Malakwal City</option>
                    <option value="Mamu Kanjan">Mamu Kanjan</option>
                    <option value="Mananwala">Mananwala</option>
                    <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                    <option value="Mangla">Mangla</option>
                    <option value="Mankera">Mankera</option>
                    <option value="Mehmand Chak">Mehmand Chak</option>
                    <option value="Mian Channun">Mian Channun</option>
                    <option value="Mianwali">Mianwali</option>
                    <option value="Minchinabad">Minchinabad</option>
                    <option value="Mitha Tiwana">Mitha Tiwana</option>
                    <option value="Moza Shahwala">Moza Shahwala</option>
                    <option value="Multan">Multan</option>
                    <option value="Muridke">Muridke</option>
                    <option value="Murree">Murree</option>
                    <option value="Mustafabad">Mustafabad</option>
                    <option value="Muzaffargarh">Muzaffargarh</option>
                    <option value="Nankana Sahib">Nankana Sahib</option>
                    <option value="Narang">Narang</option>
                    <option value="Narowal">Narowal</option>
                    <option value="Naushahra Virkan">Naushahra Virkan</option>
                    <option value="Nazir Town">Nazir Town</option>
                    <option value="Okara">Okara</option>
                    <option value="Pakpattan">Pakpattan</option>
                    <option value="Pasrur">Pasrur</option>
                    <option value="Pattoki">Pattoki</option>
                    <option value="Phalia">Phalia</option>
                    <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                    <option value="Pindi Bhattian">Pindi Bhattian</option>
                    <option value="Pindi Gheb">Pindi Gheb</option>
                    <option value="Pir Mahal">Pir Mahal</option>
                    <option value="Qadirpur Ran">Qadirpur Ran</option>
                    <option value="Rabwah">Rabwah</option>
                    <option value="Raiwind">Raiwind</option>
                    <option value="Raja Jang">Raja Jang</option>
                    <option value="Rajanpur">Rajanpur</option>
                    <option value="Rasulnagar">Rasulnagar</option>
                    <option value="Rawalpindi">Rawalpindi</option>
                    <option value="Renala Khurd">Renala Khurd</option>
                    <option value="Rojhan">Rojhan</option>
                    <option value="Sadiqabad">Sadiqabad</option>
                    <option value="Sahiwal">Sahiwal</option>
                    <option value="Sambrial">Sambrial</option>
                    <option value="Sangla Hill">Sangla Hill</option>
                    <option value="Sanjwal">Sanjwal</option>
                    <option value="Sarai Alamgir">Sarai Alamgir</option>
                    <option value="Sarai Sidhu">Sarai Sidhu</option>
                    <option value="Sargodha">Sargodha</option>
                    <option value="Shahkot">Shahkot</option>
                    <option value="Shahpur">Shahpur</option>
                    <option value="Shahr Sultan">Shahr Sultan</option>
                    <option value="Shakargarh">Shakargarh</option>
                    <option value="Sharqpur">Sharqpur</option>
                    <option value="Sheikhupura">Sheikhupura</option>
                    <option value="Shujaabad">Shujaabad</option>
                    <option value="Sialkot">Sialkot</option>
                    <option value="Sillanwali">Sillanwali</option>
                    <option value="Sodhra">Sodhra</option>
                    <option value="Sukheke Mandi">Sukheke Mandi</option>
                    <option value="Surkhpur">Surkhpur</option>
                    <option value="Talagang">Talagang</option>
                    <option value="Talamba">Talamba</option>
                    <option value="Tandlianwala">Tandlianwala</option>
                    <option value="Taunsa">Taunsa</option>
                    <option value="Toba Tek Singh">Toba Tek Singh</option>
                    <option value="Vihari">Vihari</option>
                    <option value="Warburton">Warburton</option>
                    <option value="Wazirabad">Wazirabad</option>
                    <option value="Yazman">Yazman</option>
                    <option value="Zafarwal">Zafarwal</option>
                    <option value="Zahir Pir">Zahir Pir</option>
                    <option value="Adilpur">Adilpur</option>
                    <option value="Badin">Badin</option>
                    <option value="Bagarji">Bagarji</option>
                    <option value="Bandhi">Bandhi</option>
                    <option value="Berani">Berani</option>
                    <option value="Bhan">Bhan</option>
                    <option value="Bhiria">Bhiria</option>
                    <option value="Bhit Shah">Bhit Shah</option>
                    <option value="Bozdar">Bozdar</option>
                    <option value="Bulri">Bulri</option>
                    <option value="Chak">Chak</option>
                    <option value="Chambar">Chambar</option>
                    <option value="Chhor">Chhor</option>
                    <option value="Chuhar Jamali">Chuhar Jamali</option>
                    <option value="Dadu">Dadu</option>
                    <option value="Daro Mehar">Daro Mehar</option>
                    <option value="Darya Khan Marri">Darya Khan Marri</option>
                    <option value="Daulatpur">Daulatpur</option>
                    <option value="Daur">Daur</option>
                    <option value="Dhoro Naro">Dhoro Naro</option>
                    <option value="Digri">Digri</option>
                    <option value="Diplo">Diplo</option>
                    <option value="Dokri">Dokri</option>
                    <option value="Gambat">Gambat</option>
                    <option value="Garhi Yasin">Garhi Yasin</option>
                    <option value="Gharo">Gharo</option>
                    <option value="Ghauspur">Ghauspur</option>
                    <option value="Ghotki">Ghotki</option>
                    <option value="Goth Garelo">Goth Garelo</option>
                    <option value="Hala">Hala</option>
                    <option value="Hingorja">Hingorja</option>
                    <option value="Hyderabad">Hyderabad</option>
                    <option value="Islamkot">Islamkot</option>
                    <option value="Jacobabad">Jacobabad</option>
                    <option value="Jam Sahib">Jam Sahib</option>
                    <option value="Jamshoro">Jamshoro</option>
                    <option value="Jati">Jati</option>
                    <option value="Jhol">Jhol</option>
                    <option value="Johi">Johi</option>
                    <option value="Kadhan">Kadhan</option>
                    <option value="Kambar">Kambar</option>
                    <option value="Kandhkot">Kandhkot</option>
                    <option value="Kandiari">Kandiari</option>
                    <option value="Kandiaro">Kandiaro</option>
                    <option value="Karachi">Karachi</option>
                    <option value="Karaundi">Karaundi</option>
                    <option value="Kario">Kario</option>
                    <option value="Kashmor">Kashmor</option>
                    <option value="Keti Bandar">Keti Bandar</option>
                    <option value="Khadro">Khadro</option>
                    <option value="Khairpur">Khairpur</option>
                    <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                    <option value="Khanpur">Khanpur</option>
                    <option value="Kot Diji">Kot Diji</option>
                    <option value="Kotri">Kotri</option>
                    <option value="Kunri">Kunri</option>
                    <option value="Lakhi">Lakhi</option>
                    <option value="Larkana">Larkana</option>
                    <option value="Madeji">Madeji</option>
                    <option value="Malir Cantonment">Malir Cantonment</option>
                    <option value="Matiari">Matiari</option>
                    <option value="Matli">Matli</option>
                    <option value="Mehar">Mehar</option>
                    <option value="Miro Khan">Miro Khan</option>
                    <option value="Mirpur Batoro">Mirpur Batoro</option>
                    <option value="Mirpur Khas">Mirpur Khas</option>
                    <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                    <option value="Mirpur Sakro">Mirpur Sakro</option>
                    <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                    <option value="Mithi">Mithi</option>
                    <option value="Moro">Moro</option>
                    <option value="Nabisar">Nabisar</option>
                    <option value="Nasirabad">Nasirabad</option>
                    <option value="Naudero">Naudero</option>
                    <option value="Naukot">Naukot</option>
                    <option value="Naushahro Firoz">Naushahro Firoz</option>
                    <option value="Nawabshah">Nawabshah</option>
                    <option value="New Badah">New Badah</option>
                    <option value="Pad Idan">Pad Idan</option>
                    <option value="Pano Aqil">Pano Aqil</option>
                    <option value="Phulji">Phulji</option>
                    <option value="Pir Jo Goth">Pir Jo Goth</option>
                    <option value="Pithoro">Pithoro</option>
                    <option value="Radhan">Radhan</option>
                    <option value="Rajo Khanani">Rajo Khanani</option>
                    <option value="Ranipur">Ranipur</option>
                    <option value="Ratodero">Ratodero</option>
                    <option value="Rohri">Rohri</option>
                    <option value="Rustam">Rustam</option>
                    <option value="Sakrand">Sakrand</option>
                    <option value="Samaro">Samaro</option>
                    <option value="Sanghar">Sanghar</option>
                    <option value="Sann">Sann</option>
                    <option value="Sehwan">Sehwan</option>
                    <option value="Setharja Old">Setharja Old</option>
                    <option value="Shahdad Kot">Shahdad Kot</option>
                    <option value="Shahdadpur">Shahdadpur</option>
                    <option value="Shahpur Chakar">Shahpur Chakar</option>
                    <option value="Shikarpur">Shikarpur</option>
                    <option value="Sinjhoro">Sinjhoro</option>
                    <option value="Sita Road">Sita Road</option>
                    <option value="Sobhodero">Sobhodero</option>
                    <option value="Sukkur">Sukkur</option>
                    <option value="Talhar">Talhar</option>
                    <option value="Tando Adam">Tando Adam</option>
                    <option value="Tando Allahyar">Tando Allahyar</option>
                    <option value="Tando Bago">Tando Bago</option>
                    <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                    <option value="Tando Jam">Tando Jam</option>
                    <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                    <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                    <option value="Tangwani">Tangwani</option>
                    <option value="Tharu Shah">Tharu Shah</option>
                    <option value="Thatta">Thatta</option>
                    <option value="Thul">Thul</option>
                    <option value="Ubauro">Ubauro</option>
                    <option value="Umarkot">Umarkot</option>
                    <option value="Warah">Warah</option>
                    <option value="Abbottabad">Abbottabad</option>
                    <option value="Akora">Akora</option>
                    <option value="Alpurai">Alpurai</option>
                    <option value="Aman Garh">Aman Garh</option>
                    <option value="Amirabad">Amirabad</option>
                    <option value="Ashanagro Koto">Ashanagro Koto</option>
                    <option value="Baffa">Baffa</option>
                    <option value="Bannu">Bannu</option>
                    <option value="Bat Khela">Bat Khela</option>
                    <option value="Battagram">Battagram</option>
                    <option value="Charsadda">Charsadda</option>
                    <option value="Cherat Cantonement">Cherat Cantonement</option>
                    <option value="Chitral">Chitral</option>
                    <option value="Daggar">Daggar</option>
                    <option value="Dasu">Dasu</option>
                    <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                    <option value="Doaba">Doaba</option>
                    <option value="Hangu">Hangu</option>
                    <option value="Haripur">Haripur</option>
                    <option value="Havelian">Havelian</option>
                    <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                    <option value="Karak">Karak</option>
                    <option value="Khalabat">Khalabat</option>
                    <option value="Kohat">Kohat</option>
                    <option value="Kulachi">Kulachi</option>
                    <option value="Lachi">Lachi</option>
                    <option value="Lakki Marwat">Lakki Marwat</option>
                    <option value="Malakand">Malakand</option>
                    <option value="Mansehra">Mansehra</option>
                    <option value="Mardan">Mardan</option>
                    <option value="Mingora">Mingora</option>
                    <option value="Noorabad">Noorabad</option>
                    <option value="Nowshera">Nowshera</option>
                    <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                    <option value="Pabbi">Pabbi</option>
                    <option value="Paharpur">Paharpur</option>
                    <option value="Peshawar">Peshawar</option>
                    <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                    <option value="Saidu Sharif">Saidu Sharif</option>
                    <option value="Sarai Naurang">Sarai Naurang</option>
                    <option value="Shabqadar">Shabqadar</option>
                    <option value="Shingli Bala">Shingli Bala</option>
                    <option value="Shorko">Shorko</option>
                    <option value="Swabi">Swabi</option>
                    <option value="Tal">Tal</option>
                    <option value="Tangi">Tangi</option>
                    <option value="Tank">Tank</option>
                    <option value="Timargara">Timargara</option>
                    <option value="Topi">Topi</option>
                    <option value="Upper Dir">Upper Dir</option>
                    <option value="Utmanzai">Utmanzai</option>
                    <option value="Zaida">Zaida</option>
                    <option value="Islamabad">Islamabad</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                <div class="custom-control custom-checkbox">
                  <input type="checkbox" class="checkbox custom-control-input" name="agent" id="defaultChecked102">
                  <label class="custom-control-label" for="defaultChecked102">Are You An Agent?</label>
                </div>
              </div>
            </div>
            <div id="selected-toolbar">
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="form-group text-left signinlabelssets">
                        <label for="gender">Select City you Deal In</label>
                        <select class="form-control" style="height:42px;border:1px solid #ced4da;" name="deal_city">

                          <option value="Ahmadpur East">Ahmadpur East</option>
                          <option value="Ahmadpur Sial">Ahmadpur Sial</option>
                          <option value="Alipur">Alipur</option>
                          <option value="Arifwala">Arifwala</option>
                          <option value="Attock City">Attock City</option>
                          <option value="Baddomalhi">Baddomalhi</option>
                          <option value="Bahawalnagar">Bahawalnagar</option>
                          <option value="Bahawalpur">Bahawalpur</option>
                          <option value="Bakhri Ahmad Khan">Bakhri Ahmad Khan</option>
                          <option value="Basirpur">Basirpur</option>
                          <option value="Basti Dosa">Basti Dosa</option>
                          <option value="Begowala">Begowala</option>
                          <option value="Bhai Pheru">Bhai Pheru</option>
                          <option value="Bhakkar">Bhakkar</option>
                          <option value="Bhalwal">Bhalwal</option>
                          <option value="Bhawana">Bhawana</option>
                          <option value="Bhera">Bhera</option>
                          <option value="Bhopalwala">Bhopalwala</option>
                          <option value="Burewala">Burewala</option>
                          <option value="Chak Azam Saffo">Chak Azam Saffo</option>
                          <option value="Chak Two Hundred Forty-Nine TDA">Chak Two Hundred Forty-Nine TDA</option>
                          <option value="Chakwal">Chakwal</option>
                          <option value="Chawinda">Chawinda</option>
                          <option value="Chichawatni">Chichawatni</option>
                          <option value="Chiniot">Chiniot</option>
                          <option value="Chishtian Mandi">Chishtian Mandi</option>
                          <option value="Choa Saidan Shah">Choa Saidan Shah</option>
                          <option value="Chuhar Kana">Chuhar Kana</option>
                          <option value="Chunian">Chunian</option>
                          <option value="Daira Din Panah">Daira Din Panah</option>
                          <option value="Dajal">Dajal</option>
                          <option value="Dandot RS">Dandot RS</option>
                          <option value="Darya Khan">Darya Khan</option>
                          <option value="Daska">Daska</option>
                          <option value="Daud Khel">Daud Khel</option>
                          <option value="Daultala">Daultala</option>
                          <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                          <option value="Dhanot">Dhanot</option>
                          <option value="Dhaunkal">Dhaunkal</option>
                          <option value="Dijkot">Dijkot</option>
                          <option value="Dinan Bashnoian Wala">Dinan Bashnoian Wala</option>
                          <option value="Dinga">Dinga</option>
                          <option value="Dipalpur">Dipalpur</option>
                          <option value="Dullewala">Dullewala</option>
                          <option value="Dunga Bunga">Dunga Bunga</option>
                          <option value="Dunyapur">Dunyapur</option>
                          <option value="Eminabad">Eminabad</option>
                          <option value="Faisalabad">Faisalabad</option>
                          <option value="Faqirwali">Faqirwali</option>
                          <option value="Faruka">Faruka</option>
                          <option value="Fazilpur">Fazilpur</option>
                          <option value="Fort Abbas">Fort Abbas</option>
                          <option value="Garh Maharaja">Garh Maharaja</option>
                          <option value="Gojra">Gojra</option>
                          <option value="Gujar Khan">Gujar Khan</option>
                          <option value="Gujranwala">Gujranwala</option>
                          <option value="Gujrat">Gujrat</option>
                          <option value="Hadali">Hadali</option>
                          <option value="Hafizabad">Hafizabad</option>
                          <option value="Harnoli">Harnoli</option>
                          <option value="Haru Zbad">Haru Zbad</option>
                          <option value="Hasan Abdal">Hasan Abdal</option>
                          <option value="Hasilpur">Hasilpur</option>
                          <option value="Haveli">Haveli</option>
                          <option value="Hazro City">Hazro City</option>
                          <option value="Hujra">Hujra</option>
                          <option value="Jahanian Shah">Jahanian Shah</option>
                          <option value="Jalalpur">Jalalpur</option>
                          <option value="Jalalpur Pirwala">Jalalpur Pirwala</option>
                          <option value="Jampur">Jampur</option>
                          <option value="Jand">Jand</option>
                          <option value="Jandiala Sher Khan">Jandiala Sher Khan</option>
                          <option value="Jaranwala">Jaranwala</option>
                          <option value="Jatoi Shimali">Jatoi Shimali</option>
                          <option value="Jauharabad">Jauharabad</option>
                          <option value="Jhang City">Jhang City</option>
                          <option value="Jhang Sadr">Jhang Sadr</option>
                          <option value="Jhawarian">Jhawarian</option>
                          <option value="Jhelum">Jhelum</option>
                          <option value="Jhumra">Jhumra</option>
                          <option value="Kabirwala">Kabirwala</option>
                          <option value="Kahna">Kahna</option>
                          <option value="Kahuta">Kahuta</option>
                          <option value="Kalabagh">Kalabagh</option>
                          <option value="Kalaswala">Kalaswala</option>
                          <option value="Kaleke Mandi">Kaleke Mandi</option>
                          <option value="Kallar Kahar">Kallar Kahar</option>
                          <option value="Kalur Kot">Kalur Kot</option>
                          <option value="Kamalia">Kamalia</option>
                          <option value="Kamar Mushani">Kamar Mushani</option>
                          <option value="Kamir">Kamir</option>
                          <option value="Kamoke">Kamoke</option>
                          <option value="Kamra">Kamra</option>
                          <option value="Kanganpur">Kanganpur</option>
                          <option value="Karor">Karor</option>
                          <option value="Kasur">Kasur</option>
                          <option value="Keshupur">Keshupur</option>
                          <option value="Khairpur">Khairpur</option>
                          <option value="Khanewal">Khanewal</option>
                          <option value="Khangah Dogran">Khangah Dogran</option>
                          <option value="Khangarh">Khangarh</option>
                          <option value="Khanpur">Khanpur</option>
                          <option value="Kharian">Kharian</option>
                          <option value="Khewra">Khewra</option>
                          <option value="Khurrianwala">Khurrianwala</option>
                          <option value="Khushab">Khushab</option>
                          <option value="Kohror Pakka">Kohror Pakka</option>
                          <option value="Kot Addu">Kot Addu</option>
                          <option value="Kot Ghulam Muhammad">Kot Ghulam Muhammad</option>
                          <option value="Kot Mumin">Kot Mumin</option>
                          <option value="Kot Radha Kishan">Kot Radha Kishan</option>
                          <option value="Kot Samaba">Kot Samaba</option>
                          <option value="Kot Sultan">Kot Sultan</option>
                          <option value="Kotli Loharan">Kotli Loharan</option>
                          <option value="Kundian">Kundian</option>
                          <option value="Kunjah">Kunjah</option>
                          <option value="Ladhewala Waraich">Ladhewala Waraich</option>
                          <option value="Lahore">Lahore</option>
                          <option value="Lala Musa">Lala Musa</option>
                          <option value="Lalian">Lalian</option>
                          <option value="Layyah">Layyah</option>
                          <option value="Liliani">Liliani</option>
                          <option value="Lodhran">Lodhran</option>
                          <option value="Mailsi">Mailsi</option>
                          <option value="Malakwal">Malakwal</option>
                          <option value="Malakwal City">Malakwal City</option>
                          <option value="Mamu Kanjan">Mamu Kanjan</option>
                          <option value="Mananwala">Mananwala</option>
                          <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                          <option value="Mangla">Mangla</option>
                          <option value="Mankera">Mankera</option>
                          <option value="Mehmand Chak">Mehmand Chak</option>
                          <option value="Mian Channun">Mian Channun</option>
                          <option value="Mianwali">Mianwali</option>
                          <option value="Minchinabad">Minchinabad</option>
                          <option value="Mitha Tiwana">Mitha Tiwana</option>
                          <option value="Moza Shahwala">Moza Shahwala</option>
                          <option value="Multan">Multan</option>
                          <option value="Muridke">Muridke</option>
                          <option value="Murree">Murree</option>
                          <option value="Mustafabad">Mustafabad</option>
                          <option value="Muzaffargarh">Muzaffargarh</option>
                          <option value="Nankana Sahib">Nankana Sahib</option>
                          <option value="Narang">Narang</option>
                          <option value="Narowal">Narowal</option>
                          <option value="Naushahra Virkan">Naushahra Virkan</option>
                          <option value="Nazir Town">Nazir Town</option>
                          <option value="Okara">Okara</option>
                          <option value="Pakpattan">Pakpattan</option>
                          <option value="Pasrur">Pasrur</option>
                          <option value="Pattoki">Pattoki</option>
                          <option value="Phalia">Phalia</option>
                          <option value="Pind Dadan Khan">Pind Dadan Khan</option>
                          <option value="Pindi Bhattian">Pindi Bhattian</option>
                          <option value="Pindi Gheb">Pindi Gheb</option>
                          <option value="Pir Mahal">Pir Mahal</option>
                          <option value="Qadirpur Ran">Qadirpur Ran</option>
                          <option value="Rabwah">Rabwah</option>
                          <option value="Raiwind">Raiwind</option>
                          <option value="Raja Jang">Raja Jang</option>
                          <option value="Rajanpur">Rajanpur</option>
                          <option value="Rasulnagar">Rasulnagar</option>
                          <option value="Rawalpindi">Rawalpindi</option>
                          <option value="Renala Khurd">Renala Khurd</option>
                          <option value="Rojhan">Rojhan</option>
                          <option value="Sadiqabad">Sadiqabad</option>
                          <option value="Sahiwal">Sahiwal</option>
                          <option value="Sambrial">Sambrial</option>
                          <option value="Sangla Hill">Sangla Hill</option>
                          <option value="Sanjwal">Sanjwal</option>
                          <option value="Sarai Alamgir">Sarai Alamgir</option>
                          <option value="Sarai Sidhu">Sarai Sidhu</option>
                          <option value="Sargodha">Sargodha</option>
                          <option value="Shahkot">Shahkot</option>
                          <option value="Shahpur">Shahpur</option>
                          <option value="Shahr Sultan">Shahr Sultan</option>
                          <option value="Shakargarh">Shakargarh</option>
                          <option value="Sharqpur">Sharqpur</option>
                          <option value="Sheikhupura">Sheikhupura</option>
                          <option value="Shujaabad">Shujaabad</option>
                          <option value="Sialkot">Sialkot</option>
                          <option value="Sillanwali">Sillanwali</option>
                          <option value="Sodhra">Sodhra</option>
                          <option value="Sukheke Mandi">Sukheke Mandi</option>
                          <option value="Surkhpur">Surkhpur</option>
                          <option value="Talagang">Talagang</option>
                          <option value="Talamba">Talamba</option>
                          <option value="Tandlianwala">Tandlianwala</option>
                          <option value="Taunsa">Taunsa</option>
                          <option value="Toba Tek Singh">Toba Tek Singh</option>
                          <option value="Vihari">Vihari</option>
                          <option value="Warburton">Warburton</option>
                          <option value="Wazirabad">Wazirabad</option>
                          <option value="Yazman">Yazman</option>
                          <option value="Zafarwal">Zafarwal</option>
                          <option value="Zahir Pir">Zahir Pir</option>
                          <option value="Adilpur">Adilpur</option>
                          <option value="Badin">Badin</option>
                          <option value="Bagarji">Bagarji</option>
                          <option value="Bandhi">Bandhi</option>
                          <option value="Berani">Berani</option>
                          <option value="Bhan">Bhan</option>
                          <option value="Bhiria">Bhiria</option>
                          <option value="Bhit Shah">Bhit Shah</option>
                          <option value="Bozdar">Bozdar</option>
                          <option value="Bulri">Bulri</option>
                          <option value="Chak">Chak</option>
                          <option value="Chambar">Chambar</option>
                          <option value="Chhor">Chhor</option>
                          <option value="Chuhar Jamali">Chuhar Jamali</option>
                          <option value="Dadu">Dadu</option>
                          <option value="Daro Mehar">Daro Mehar</option>
                          <option value="Darya Khan Marri">Darya Khan Marri</option>
                          <option value="Daulatpur">Daulatpur</option>
                          <option value="Daur">Daur</option>
                          <option value="Dhoro Naro">Dhoro Naro</option>
                          <option value="Digri">Digri</option>
                          <option value="Diplo">Diplo</option>
                          <option value="Dokri">Dokri</option>
                          <option value="Gambat">Gambat</option>
                          <option value="Garhi Yasin">Garhi Yasin</option>
                          <option value="Gharo">Gharo</option>
                          <option value="Ghauspur">Ghauspur</option>
                          <option value="Ghotki">Ghotki</option>
                          <option value="Goth Garelo">Goth Garelo</option>
                          <option value="Hala">Hala</option>
                          <option value="Hingorja">Hingorja</option>
                          <option value="Hyderabad">Hyderabad</option>
                          <option value="Islamkot">Islamkot</option>
                          <option value="Jacobabad">Jacobabad</option>
                          <option value="Jam Sahib">Jam Sahib</option>
                          <option value="Jamshoro">Jamshoro</option>
                          <option value="Jati">Jati</option>
                          <option value="Jhol">Jhol</option>
                          <option value="Johi">Johi</option>
                          <option value="Kadhan">Kadhan</option>
                          <option value="Kambar">Kambar</option>
                          <option value="Kandhkot">Kandhkot</option>
                          <option value="Kandiari">Kandiari</option>
                          <option value="Kandiaro">Kandiaro</option>
                          <option value="Karachi">Karachi</option>
                          <option value="Karaundi">Karaundi</option>
                          <option value="Kario">Kario</option>
                          <option value="Kashmor">Kashmor</option>
                          <option value="Keti Bandar">Keti Bandar</option>
                          <option value="Khadro">Khadro</option>
                          <option value="Khairpur">Khairpur</option>
                          <option value="Khairpur Nathan Shah">Khairpur Nathan Shah</option>
                          <option value="Khanpur">Khanpur</option>
                          <option value="Kot Diji">Kot Diji</option>
                          <option value="Kotri">Kotri</option>
                          <option value="Kunri">Kunri</option>
                          <option value="Lakhi">Lakhi</option>
                          <option value="Larkana">Larkana</option>
                          <option value="Madeji">Madeji</option>
                          <option value="Malir Cantonment">Malir Cantonment</option>
                          <option value="Matiari">Matiari</option>
                          <option value="Matli">Matli</option>
                          <option value="Mehar">Mehar</option>
                          <option value="Miro Khan">Miro Khan</option>
                          <option value="Mirpur Batoro">Mirpur Batoro</option>
                          <option value="Mirpur Khas">Mirpur Khas</option>
                          <option value="Mirpur Mathelo">Mirpur Mathelo</option>
                          <option value="Mirpur Sakro">Mirpur Sakro</option>
                          <option value="Mirwah Gorchani">Mirwah Gorchani</option>
                          <option value="Mithi">Mithi</option>
                          <option value="Moro">Moro</option>
                          <option value="Nabisar">Nabisar</option>
                          <option value="Nasirabad">Nasirabad</option>
                          <option value="Naudero">Naudero</option>
                          <option value="Naukot">Naukot</option>
                          <option value="Naushahro Firoz">Naushahro Firoz</option>
                          <option value="Nawabshah">Nawabshah</option>
                          <option value="New Badah">New Badah</option>
                          <option value="Pad Idan">Pad Idan</option>
                          <option value="Pano Aqil">Pano Aqil</option>
                          <option value="Phulji">Phulji</option>
                          <option value="Pir Jo Goth">Pir Jo Goth</option>
                          <option value="Pithoro">Pithoro</option>
                          <option value="Radhan">Radhan</option>
                          <option value="Rajo Khanani">Rajo Khanani</option>
                          <option value="Ranipur">Ranipur</option>
                          <option value="Ratodero">Ratodero</option>
                          <option value="Rohri">Rohri</option>
                          <option value="Rustam">Rustam</option>
                          <option value="Sakrand">Sakrand</option>
                          <option value="Samaro">Samaro</option>
                          <option value="Sanghar">Sanghar</option>
                          <option value="Sann">Sann</option>
                          <option value="Sehwan">Sehwan</option>
                          <option value="Setharja Old">Setharja Old</option>
                          <option value="Shahdad Kot">Shahdad Kot</option>
                          <option value="Shahdadpur">Shahdadpur</option>
                          <option value="Shahpur Chakar">Shahpur Chakar</option>
                          <option value="Shikarpur">Shikarpur</option>
                          <option value="Sinjhoro">Sinjhoro</option>
                          <option value="Sita Road">Sita Road</option>
                          <option value="Sobhodero">Sobhodero</option>
                          <option value="Sukkur">Sukkur</option>
                          <option value="Talhar">Talhar</option>
                          <option value="Tando Adam">Tando Adam</option>
                          <option value="Tando Allahyar">Tando Allahyar</option>
                          <option value="Tando Bago">Tando Bago</option>
                          <option value="Tando Ghulam Ali">Tando Ghulam Ali</option>
                          <option value="Tando Jam">Tando Jam</option>
                          <option value="Tando Mittha Khan">Tando Mittha Khan</option>
                          <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                          <option value="Tangwani">Tangwani</option>
                          <option value="Tharu Shah">Tharu Shah</option>
                          <option value="Thatta">Thatta</option>
                          <option value="Thul">Thul</option>
                          <option value="Ubauro">Ubauro</option>
                          <option value="Umarkot">Umarkot</option>
                          <option value="Warah">Warah</option>
                          <option value="Abbottabad">Abbottabad</option>
                          <option value="Akora">Akora</option>
                          <option value="Alpurai">Alpurai</option>
                          <option value="Aman Garh">Aman Garh</option>
                          <option value="Amirabad">Amirabad</option>
                          <option value="Ashanagro Koto">Ashanagro Koto</option>
                          <option value="Baffa">Baffa</option>
                          <option value="Bannu">Bannu</option>
                          <option value="Bat Khela">Bat Khela</option>
                          <option value="Battagram">Battagram</option>
                          <option value="Charsadda">Charsadda</option>
                          <option value="Cherat Cantonement">Cherat Cantonement</option>
                          <option value="Chitral">Chitral</option>
                          <option value="Daggar">Daggar</option>
                          <option value="Dasu">Dasu</option>
                          <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                          <option value="Doaba">Doaba</option>
                          <option value="Hangu">Hangu</option>
                          <option value="Haripur">Haripur</option>
                          <option value="Havelian">Havelian</option>
                          <option value="Kakad Wari Dir Upper">Kakad Wari Dir Upper</option>
                          <option value="Karak">Karak</option>
                          <option value="Khalabat">Khalabat</option>
                          <option value="Kohat">Kohat</option>
                          <option value="Kulachi">Kulachi</option>
                          <option value="Lachi">Lachi</option>
                          <option value="Lakki Marwat">Lakki Marwat</option>
                          <option value="Malakand">Malakand</option>
                          <option value="Mansehra">Mansehra</option>
                          <option value="Mardan">Mardan</option>
                          <option value="Mingora">Mingora</option>
                          <option value="Noorabad">Noorabad</option>
                          <option value="Nowshera">Nowshera</option>
                          <option value="Nowshera Cantonment">Nowshera Cantonment</option>
                          <option value="Pabbi">Pabbi</option>
                          <option value="Paharpur">Paharpur</option>
                          <option value="Peshawar">Peshawar</option>
                          <option value="Risalpur Cantonment">Risalpur Cantonment</option>
                          <option value="Saidu Sharif">Saidu Sharif</option>
                          <option value="Sarai Naurang">Sarai Naurang</option>
                          <option value="Shabqadar">Shabqadar</option>
                          <option value="Shingli Bala">Shingli Bala</option>
                          <option value="Shorko">Shorko</option>
                          <option value="Swabi">Swabi</option>
                          <option value="Tal">Tal</option>
                          <option value="Tangi">Tangi</option>
                          <option value="Tank">Tank</option>
                          <option value="Timargara">Timargara</option>
                          <option value="Topi">Topi</option>
                          <option value="Upper Dir">Upper Dir</option>
                          <option value="Utmanzai">Utmanzai</option>
                          <option value="Zaida">Zaida</option>
                          <option value="Islamabad">Islamabad</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                      <div class="form-group text-left signinlabelssets">
                        <label for="address 2">Agency Name</label>
                        <input type="text" class="form-control blueborder" id="" placeholder="Agency Name" name="agency_name">
                </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="form-group text-left signinlabelssets">
                        <label for="address 2">Descriotion</label>
                        <textarea rows="4" cols="50" style="border:1px solid #ced4da;background-color:white;" name="description">

</textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-5">
                      <div class="form-group text-left signinlabelssets">
                        <label for="phone">Agency Phone</label>
                        <input type="tel" class="form-control" id="" placeholder="Agency Phone" name="agency_phone">
                </div>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-7">
                      <div class="form-group text-left signinlabelssets" style="margin-top:32px;">
                        <input type="phone" class="form-control blueborder" id="" placeholder="" name="email">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-5">
                      <div class="form-group text-left signinlabelssets">
                        <label for="fax">FAX</label>
                        <input type="text" class="form-control" id="" placeholder="FAX" name="fax">
                 </div>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-7">
                      <div class="form-group text-left signinlabelssets" style="margin-top:32px;">
                        <input type="text" class="form-control blueborder" id="" placeholder="" name="email">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="form-group text-left signinlabelssets">
                        <label for="address 1">Address</label>
                        <input type="text" class="form-control blueborder" id="" placeholder="Address" name="address">
                 </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="form-group text-left signinlabelssets">
                        <label for="company email">Company Email</label>
                          <input type="email" class="form-control blueborder" id="" placeholder="Company Email" name="company_email">
                     </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                      <div class="form-group text-left signinlabelssets">
                        <label for="phone">Upload Logo</label>
                        <input type="file" name="file" class="form-control" onchange="readURL(this);">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="submitbutton">
                <button type="submit" class="btn submitbtn  btn-responsive"  aria-expanded="false">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</form>
  </div>
</div>
<!--Shop Area End-->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/client/realtor_signin.blade.php ENDPATH**/ ?>