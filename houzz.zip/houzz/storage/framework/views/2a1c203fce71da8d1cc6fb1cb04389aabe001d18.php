              
<?php $__env->startSection('content'); ?>
<div id="login" class="mb-50 mt-70">
  <div class="container">
    <div id="login-row" class="row justify-content-center align-items-center">
      <div id="login-column" class="col-md-8">
        <div id="login-box" class="col-md-12 shadow-lg p-3 mb-5 bg-white rounded">
          <div class="panel panel-default pnel">
            <div class="panel-heading panelhead">
              <h3 class="panel-title "> <strong>1 :</strong> YOUR EMAIL<span><?php echo e(Session::get('username')); ?></span> </h3>
            </div>
            <div class="panel-heading">
              <h3 class="panel-title"> <strong>2 :</strong> YOUR ADDRESS </h3>
            </div>
            <div class="row">
            <?php if(count($result1)>0): ?>
                                    <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-6 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_content">
                    <div class="member-left-side">
                      <div class="member-email clearfix"> <b>Name</b> <span><?php echo e($results->fname); ?> <?php echo e($results->lname); ?></span> </div>
                      <div class="member-email clearfix"> <b>Phone No</b> <span><?php echo e($results->phone); ?></span> </div>
                      <div class="member-email clearfix"> <b>Address</b> <span><?php echo e($results->address); ?></span> </div>
                      <div class="member-email clearfix">  <a href="<?php echo e(url('/')); ?>/cart/checkout/edit/address/<?php echo e($results->pk_id); ?>"  <span>Edit</span></a> </div>
                      <div class="member-email clearfix">
                        <div class="col-lg-12"> <a href="<?php echo e(url('/')); ?>/cart/checkout/address/view/order/<?php echo e($results->pk_id); ?>" class="button btn-block">Use This Address</a> </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
              <div class="col-lg-12">
                <div class="x_content"> <a href="<?php echo e(url('/')); ?>/cart/checkout/add/new/address"  class="button pull-right">Add New Address</a> </div>
              </div>
            </div>
            <div class="panel-heading panelhead">
              <h3 class="panel-title"> <strong>3 :</strong> ORDER SUMMERY </h3>
            </div>
            <div class="panel-heading panelhead">
              <h3 class="panel-title"> <strong>4 :</strong> PAYMENT </h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
              <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/client_address_view.blade.php ENDPATH**/ ?>