
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz"><link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<title>Houzz</title>

<!-- Bootstrap -->

<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css2/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css2/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css2/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css2/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css2/custom.min.css" rel="stylesheet">
<!-- Datatables -->
<link href="<?php echo e(url('/')); ?>/css2/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css2/responsive.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css2/scroller.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css2/bootstrap-colorpicker.min.css" rel="stylesheet"/>
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title"> <a href="index.html" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images2/favicon.png" alt="logo"></i> <span>Houzz</span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
            <ul class="nav side-menu">
              <li><a href="index.html"> Home </a> </li>
              <li><a href="#"> Permission Management </a> </li>
              <li><a href="<?php echo e(url('/')); ?>/realtor/home/view/property"> Property Management </a> </li>
              <li><a href="#"> User Listing </a> </li>
              <li><a href="#"> User Projects </a> </li>
              <li><a href="#"> Reporting </a> </li>
              <li><a href="#"> Massage </a> </li>
              <li><a href="#"> User Management </a> </li>
<li><a> Invoices <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">

                  <li><a href="view-approved-invoice.html">Approved</a></li>
                  <li><a href="view-pending-invoice.html">Pending</a></li>
                  <li><a href="view-rejected-invoice.html">Rejected</a></li>
                  <li><a href="view-submitted-invoice.html">Submitted</a></li>
                </ul>
              </li>
              <li><a> Payments <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">

                  <li><a href="view-approved-invoice.html">Approved</a></li>
                  <li><a href="view-pending-invoice.html">Pending</a></li>
                  <li><a href="view-rejected-invoice.html">Rejected</a></li>
                  <li><a href="view-submitted-invoice.html">Submitted</a></li>
                </ul>
              </li>
             <li><a href="#"> Orders </a> </li>
             <li><a> Package Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">

                  <li><a href="#">Package Invoice</a></li>
                  <li><a href="#">Package Payment</a></li>

                </ul>
              </li>
            </ul>
          </div>
        </div>
        <!-- /sidebar menu -->
      </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="<?php echo e(url('/')); ?>/images2/vendorprofile.png" alt="">Ibrahim Anwar <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="<?php echo e(url('/')); ?>/realtor/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
            <li class="message-nav dropdown"> <a href="#" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> <i class="fa fa-bell-o"> <span class="badge" style="margin-top: -25px;">2</span> </i>
              <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu1">
                <li class="notification-title">
                  <h4 style="text-align:center;">Notification</h4>
                </li>
                <ul class="notification-list">
                  <li class="notification-item"> <a class="notification-anchor" href="#">
                    <p class="notification-user"> <strong>Anh Nguyen</strong> | <span class="timestamp">15 mins ago</span> </p>

                    </a> </li>
                  <li class="notification-item"> <a class="notification-anchor" href="#">
                    <p class="notification-user"> <strong>Anh Nguyen</strong> | <span class="timestamp">15 mins ago</span> </p>

                    </a> </li>
                </ul>
                <li class="notification-footer">
                  <a href="#" style="text-align:center;">View All</a>
                </li>
              </ul>
              </a> </li>
              <li class=""><button type="button" class="btn btnnav">Go to website</button>

            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation -->

      <?php echo $__env->yieldContent('content'); ?>


 <!-- footer content -->
 <footer>
      <div class=""> Copyright © 2017-2018 Houzz.com. All rights reserved. </div>
      <div class="pull-right"> Powered By <a href="https://greengrapez.com">Green Grapez <img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="green grapez" style="width:5%;"></a> </div>

      <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
  </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/js2/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(url('/')); ?>/js2/bootstrap.min.js"></script>
<!-- DateJS -->
<script src="<?php echo e(url('/')); ?>/js2/build/date.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(url('/')); ?>/js2/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/js2/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo e(url('/')); ?>/js2/moment.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js2/daterangepicker.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(url('/')); ?>/js2/custom.min.js"></script>
<!-- Datatables -->
<script src="<?php echo e(url('/')); ?>/js2/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js2/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js2/dataTables.responsive.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js2/responsive.bootstrap.js"></script>
<script src="<?php echo e(url('/')); ?>/js2/dataTables.scroller.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js2/bootstrap-colorpicker.min.js" type="text/javascript"></script>



<script>
      $("#type").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/realtor/home/property/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });

    $("#project").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
     
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/realtor/home/project/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>

<script>
window.onload = function(){

    //Check File API support
    if(window.File && window.FileList && window.FileReader)
    {
        var filesInput = document.getElementById("files");

        filesInput.addEventListener("change", function(event){

            var files = event.target.files; //FileList object
            var output = document.getElementById("result");

            for(var i = 0; i< files.length; i++)
            {
                var file = files[i];

                //Only pics
                if(!file.type.match('image'))
                  continue;

                var picReader = new FileReader();

                picReader.addEventListener("load",function(event){

                    var picFile = event.target;

                    var div = document.createElement("div");

                    div.innerHTML = "<button class='remove-btn'>x</button><a href='" + picFile.result + "' data-fancybox='images'><img class='thumbnail' src='" + picFile.result + "'" +
                            "title='" + picFile.name + "'/></a>";

                    output.insertBefore(div,null);
                    setPop();
                });

                 //Read the image
                picReader.readAsDataURL(file);
            }

        });
    }
    else
    {
        console.log("Your browser does not support File API");
    }
}

function setPop() {
  $('[data-fancybox="images"]').fancybox({
    thumbs : {
      autoStart : true,
      axis      : 'x'
    }
  });
}

$(document).on('click', '.remove-btn', function(e) {
  $(this).parent().remove();
});

$(document).ready(function() {
  $('#media').carousel({
    pause: true,
    interval: false,
  });
});
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\houzz\resources\views/adminRealtor/layout/appAdminRealtor.blade.php ENDPATH**/ ?>