<?php $__env->startSection('content'); ?>
<style>
.slide {
    top: 0;
    opacity: 1;
    width: 100%;
    height: auto;
    display: block;
    position: inherit;
    transform: inherit;
    transition: all .7s ease-in-out;
}
</style>
<div class="greyyy">
  <div class="container">
    <div class="shop-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-3"> 
            <!--Product Category Widget Start-->
            <div class="bg-white p-2" style="box-shadow: 0px 1px 3px 0px rgba(0,0,0,0.2);">
              <div class="shop-sidebar">
                <h4>By categories</h4>
                <div class="categori-checkbox">
                  <ul>
                    <?php if(count($main_category)>0): ?>
                    <?php $__currentLoopData = $main_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><img src="<?php echo e(URL('/')); ?>/images/dott.png" alt=""><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>"><?php echo e($results->main_category); ?></a></i> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                  </ul>
                </div>
              </div>
            </div>
            <div class="sidebar-layout mb-35">
              <div class="sidebar-banner single-banner">
                <div class="banner-img"> <a href="#"><img src="http://localhost/houzz/public/pic/adding_2.jpg" alt="image"></a> </div>
              </div>
              <div class="sidebar-banner single-banner">
                <div class="banner-img"> <a href="#"><img src="http://localhost/houzz/public/pic/adding_1.jpg" alt="image"></a> </div>
              </div>
            </div>
          </div>
          <?php if($errors->any()): ?>
          <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
          <?php endif; ?>
          <div class="col-lg-9">
            <div class="shop-layout">
              <div class="row">
                <div class="col-md-12"> 
                  <!--Single Banner Area Start-->
                  <div id="carouselExampleControls" class="carousel slide" data-ride="carousel"> <?php if(count($slider)>0): ?>
                    <div class="carousel-inner">
                      <div class="carousel-item active"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/images/slider1.jpg" alt="First slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/images/slider2.jpg" alt="Second slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/images/slider3.jpg" alt="Third slide"> </div>
                      <div class="carousel-item"> <img class="d-block w-100" src="<?php echo e(URL('/')); ?>/images/slider4.jpg" alt="Fourth slide"> </div>
                    </div>
                    <?php endif; ?> <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
                  <!--Single Banner Area End--> 
                </div>
              </div>
              <div class="bg-white p-2">
                <div class="shop-product">
                  <div id="myTabContent-2" class="tab-content">
                    <div id="grid" class="tab-pane fade show active">
                      <div class="product-grid-view">
                        <div class="row">
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Kitchen and Dining"> <img src="<?php echo e(URL('/')); ?>/pic/31.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Kitchen and Dining">Kitchen and Dining</a></h2>
                                <?php if(count($kitchen)>0): ?>
                                <?php $__currentLoopData = $kitchen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Kitchen and Dining">
                                <p class="grey">See All</p>
                                </a> </div>
                              <!--Single Product End--> 
                            </div>
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Bath"> <img src="<?php echo e(URL('/')); ?>/pic/36.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Bath">Bath</a></h2>
                                <?php if(count($bath)>0): ?>
                                <?php $__currentLoopData = $bath; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Bath">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Bedroom"> <img src="<?php echo e(URL('/')); ?>/pic/34.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Bedroom">Bedroom</a></h2>
                                <?php if(count($bed)>0): ?>
                                <?php $__currentLoopData = $bed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Bedroom">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Living"> <img src="<?php echo e(URL('/')); ?>/pic/35.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Living">Living</a></h2>
                                <?php if(count($living)>0): ?>
                                <?php $__currentLoopData = $living; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Living">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Lighting"> <img src="<?php echo e(URL('/')); ?>/pic/36.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Lighting">Lighting</a></h2>
                                <?php if(count($lighting)>0): ?>
                                <?php $__currentLoopData = $lighting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Lighting">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Furniture"> <img src="<?php echo e(URL('/')); ?>/pic/37.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Furniture">Furniture</a></h2>
                                <?php if(count($furniture)>0): ?>
                                <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Furniture">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Home Decor"> <img src="<?php echo e(URL('/')); ?>/pic/38.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Home Decor">Home Decor</a></h2>
                                <?php if(count($decore)>0): ?>
                                <?php $__currentLoopData = $decore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Home Decor">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                          <div class="col-md-3"> 
                            <!--Single Product Start-->
                            <div class="single-product mb-25 greyyy">
                              <div class="product-img img-full"> <a href="<?php echo e(URL('/')); ?>/product/Outdoor"> <img src="<?php echo e(URL('/')); ?>/pic/39.png" alt="" class="p-2"> </a> </div>
                              <div class="product-content">
                                <h2><a href="<?php echo e(URL('/')); ?>/product/Outdoor">OutDoor Product</a></h2>
                                <?php if(count($outdoor)>0): ?>
                                <?php $__currentLoopData = $outdoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kitchens): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/product/<?php echo e($kitchens->main_category); ?>/<?php echo e($kitchens->sub_category); ?>">
                                <p class="grey"><?php echo e($kitchens->sub_category); ?></p>
                                </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> <a href="<?php echo e(URL('/')); ?>/product/Outdoor">
                                <p class="grey">See All</p>
                                </a> </div>
                            </div>
                            <!--Single Product End--> 
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--Shop Product End-->
                  <div class="container-fluid">
                    <div class="row">
                      <div class="col-12">
                        <div class="section-title text-center mb-20 mt-30"> <span>
                          <h3>New Arrival</h3>
                          </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="home-product-layout-area mt-20">
                    <div class="container-fluid">
                      <div class="row">
                        <div class="col-md-12">
                          <div id="myCarousel2" class="carousel slide" data-ride="carousel" data-interval="0">
                            <div class="carousel-inner">
                              <div class="item carousel-item active">
                                <div class="row"> <?php if(count($result)>0): ?>
                                  <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php
                                  $vendor_id = $results->vendor_id;
                                  $admin = "";
                                  $date = NOW();
                                  if(empty($vendor_id))
                                  {
                                  $admin = "admin";
                                  }
                                  else{
                                  $vendor_id  = DB::select("select * from client_details where username = '$vendor_id' and customer_type = 'seller' ");
                                  if(count($vendor_id)>0)
                                  {
                                  $vendor_id = $vendor_id[0]->pk_id;
                                  }
                                  
                                  $vendor_id = DB::select("select * from payment_invoice where vendor_id = '$vendor_id' ORDER BY pk_id DESC");
                                  }
                                  ?>
                                  
                                  <?php if($admin == 'admin'): ?>
                                  <div class="col-md-4"> 
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="" style=" position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><?php echo e($results->name); ?></h2>
                                        <p>PKR <?php echo e(number_format($results->price)); ?></p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/<?php echo e($results->pk_id); ?>" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    <!--Single Product End--> 
                                  </div>
                                  <?php else: ?>
                                  
                                  <?php if(!empty($vendor_id) && $vendor_id[0]->expiry_date > $date): ?>
                                  <div class="col-md-4"> 
                                    <!--Single Product Start-->
                                    <div class="single-product mb-25">
                                      <div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="" style="    position: relative;"> </a>
                                        <div class="product-action">
                                          <ul>
                                            <li><a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
                                          </ul>
                                        </div>
                                      </div>
                                      <div class="product-content">
                                        <h2><?php echo e($results->name); ?></h2>
                                        <p>PKR <?php echo e(number_format($results->price)); ?></p>
                                        <div class="product-price">
                                          <div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/<?php echo e($results->pk_id); ?>" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
                                        </div>
                                      </div>
                                    </div>
                                    <!--Single Product End--> 
                                  </div>
                                  <?php endif; ?>
                                  <?php endif; ?>
                                  
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?> </div>
                              </div>
                            </div>
                            <!-- Carousel controls --> 
                            <a class="carousel-control left carousel-control-prev" href="#myCarousel2" data-slide="prev"> <i class="fa fa-angle-left"></i> </a> <a class="carousel-control right carousel-control-next" href="#myCarousel2" data-slide="next"> <i class="fa fa-angle-right"></i> </a> </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!--Brand Area Start-->
                <div class="brand-area mt-20">
                  <div class="container">
                    <div class="row">
                      <div class="col-12">
                        <div class="brand-active"> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/Homegoods.jpg" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/mobile_logo.png" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/nookkar-com-delhi-online-shopping-websites-yq4ja.jpg" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/Zameen.com_-_Logo.png" alt=""></a> </div>
                          <!--Single Brand End--> 
                          <!--Single Brand Start-->
                          <div class="single-brand img-full"> <a href="#"><img src="<?php echo e(URL('/')); ?>/pic/hg_final-signature_hor_tag2-final.png" alt=""></a> </div>
                          <!--Single Brand End--> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!--Brand Area End--> 
              </div>
            </div>
          </div>
        </div>
        <!--Shop Area End--> 
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/client/shop_view.blade.php ENDPATH**/ ?>