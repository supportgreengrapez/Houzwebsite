<?php $__env->startSection('content'); ?>


    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
           <h3>Reporting Management</h3>
            <h4>By Product</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="page-title">
           <h2>Total Revenue : <?php echo e($total); ?> </h2>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>SKU</th>
                      <th>ORDER ID</th>
                      <th>Quantity</th>
                  <th>Total Price</th>
                           <th>Discounted Price</th>
                      <th>Size</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php if(count($result)>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php
                        $a = $results->order_id;
                             $result1 = DB::select("select * from order_table where pk_id = '$a' and status = '4'");
                        ?>
                         <?php if(count($result1)>0): ?>

                        <tr>
                          <td><?php echo e($results->sku); ?></td>
                          <td><?php echo e($results->order_id); ?></td>
                          <td><?php echo e($results->quantity); ?></td>
                          <td>PKR <?php echo e(number_format($results->price)); ?></td>
                          <?php if($results->discount_price == ""): ?>
                           <td>---</td>
                          <?php else: ?>
                               <td>PKR <?php echo e($results->discount_price); ?></td>
                               <?php endif; ?>
                          <td><?php echo e($results->size); ?></td>

                        </tr>
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/admin/product_reporting_detail_view.blade.php ENDPATH**/ ?>