
<?php $__env->startSection('content'); ?> 
<!--Shop Area Start-->

<div class="container-fluid">
  <div class="row">
    <div class="col-lg-12 col-sm-12 col-xs-12 mt-20">
      <ol class="breadcrumb breadcrumb-right-arrow" style="border-bottom: 2px solid;">
        <li class="breadcrumb-item"><a href="#">Houzz</a></li>
        <li class="breadcrumb-item"><a href="#">Lahore Houses</a></li>
        <li class="breadcrumb-item"><a href="#">DHA Defence</a></li>
        <li class="breadcrumb-item"><a href="#">DHA Phase 6</a></li>
        <li class="breadcrumb-item active">House 123455</li>
      </ol>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12 col-sm-12 col-xs-12">
      <div class="productnameontop">
        <h4><?php echo e($result[0]->property_title); ?></h4>
        <p>D<?php echo e($result[0]->location); ?>, <?php echo e($result[0]->city); ?></p>
      </div>
    </div>
  </div>
</div>
<div class="gray-bg3">
<div class="shop-area mb-20">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
  <ul class="slides">
    <input type="radio" name="radio-btn" id="img-1" checked />
    <li class="slide-container">
      <div class="slide"> <img src="h{URL('/')}}/storage/images/<?php echo e($result[0]->thumbnail); ?>" /> </div>
      <div class="nav">
        <label for="img-6" class="prev">&#x2039;</label>
        <label for="img-2" class="next">&#x203a;</label>
      </div>
    </li>
    <input type="radio" name="radio-btn" id="img-2" />
    <li class="slide-container">
      <div class="slide"> <img src="h{URL('/')}}/storage/images/<?php echo e($result[0]->thumbnail); ?>" /> </div>
      <div class="nav">
        <label for="img-1" class="prev">&#x2039;</label>
        <label for="img-3" class="next">&#x203a;</label>
      </div>
    </li>
    <input type="radio" name="radio-btn" id="img-3" />
    <li class="slide-container">
      <div class="slide"> <img src="{URL('/')}}/storage/images/<?php echo e($result[0]->thumbnail); ?>" /> </div>
      <div class="nav">
        <label for="img-2" class="prev">&#x2039;</label>
        <label for="img-4" class="next">&#x203a;</label>
      </div>
    </li>
    <input type="radio" name="radio-btn" id="img-4" />
    <li class="slide-container">
      <div class="slide"> <img src="{URL('/')}}/storage/images/<?php echo e($result[0]->thumbnail); ?>" /> </div>
      <div class="nav">
        <label for="img-3" class="prev">&#x2039;</label>
        <label for="img-5" class="next">&#x203a;</label>
      </div>
    </li>
    <input type="radio" name="radio-btn" id="img-5" />
    <li class="slide-container">
      <div class="slide"> <img src="{URL('/')}}/storage/images/<?php echo e($result[0]->thumbnail); ?>" /> </div>
      <div class="nav">
        <label for="img-4" class="prev">&#x2039;</label>
        <label for="img-6" class="next">&#x203a;</label>
      </div>
    </li>
    <input type="radio" name="radio-btn" id="img-6" />
    <li class="slide-container">
      <div class="slide"> <img src="{URL('/')}}/storage/images/<?php echo e($result[0]->thumbnail); ?>" /> </div>
      <div class="nav">
        <label for="img-5" class="prev">&#x2039;</label>
        <label for="img-1" class="next">&#x203a;</label>
      </div>
    </li>
    <li class="nav-dots">
      <label for="img-1" class="nav-dot" id="img-dot-1"></label>
      <label for="img-2" class="nav-dot" id="img-dot-2"></label>
      <label for="img-3" class="nav-dot" id="img-dot-3"></label>
      <label for="img-4" class="nav-dot" id="img-dot-4"></label>
      <label for="img-5" class="nav-dot" id="img-dot-5"></label>
      <label for="img-6" class="nav-dot" id="img-dot-6"></label>
    </li>
  </ul>
  <div class="white-bg">
    <div class="row justify-content-center pb-30">
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 mt-20 text-center">
        <div class="productdetailicon"> <span><i class="fa fa-bed"></i>&nbsp;&nbsp;6 Beds</span> </div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 mt-20 text-center">
        <div class="productdetailicon"> <span><i class="fa fa-bath"></i>&nbsp;&nbsp;6 Baths</span> </div>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12 mt-20 text-center">
        <div class="productdetailicon"> <span><i class="fa fa-square"></i>&nbsp;&nbsp;1 Kanal</span> </div>
      </div>
      <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 mt-20 text-lg-right">
        <p style="color:#689a29;">PKR <span style="font-size:21px;color:black;"><?php echo e($result[0]->price); ?></span></p>
      </div>
    </div>
  </div>
  <div class="white-bg">
    <div class="row mt-20">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <h4 style="padding: 15px 0px 0px 15px;">Details</h4>
      </div>
    </div>
    <div class="row mt-20">
      <div class="col-lg-12 col-sm-12 col-xs-12" style="padding: 0px 30px;">
        <table class="table table-bordered">
          <tbody>
            <tr>
              <td>Details</td>
              <td>House</td>
              <td>Area</td>
              <td>1 Kanal</td>
            </tr>
            <tr>
              <td>Price</td>
              <td>PKR 4.1 Crore</td>
              <td>Purpose</td>
              <td>For Sale</td>
            </tr>
            <tr>
              <td>Location</td>
              <td>DHA, Lahore</td>
              <td>Bedrooms</td>
              <td>5</td>
            </tr>
            <tr>
              <td>Baths</td>
              <td>6</td>
              <td>Added</td>
              <td>1 Day ago</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="white-bg">
    <div class="container-fluid">
      <div class="row mt-20">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <h4 style="padding: 15px 0px 0px 15px;">Amenities</h4>
        </div>
      </div>
      <div class="row mt-20">
        <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12">
          <div class="textbanner">
            <h4>Main Features</h4>
          </div>
        </div>
      </div>
      <div class="row mt-20">
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-calendar"></i>&nbsp;&nbsp;Built in year: 2018</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-product-hunt"></i>&nbsp;&nbsp;Parking space: 4</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-window-restore"></i>&nbsp;&nbsp;Double Glazed Window</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-star"></i>&nbsp;&nbsp;Central Air Conditioning</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-h-square"></i>&nbsp;&nbsp;Central Heating</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-th"></i>&nbsp;&nbsp;Flooring</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-bolt"></i>&nbsp;&nbsp;Electricity Backup</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-trash"></i>&nbsp;&nbsp;Waste Disposal</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-road"></i>&nbsp;&nbsp;Floor:2</span> </div>
        </div>
        <div class="col-lg-4 col-sm-12 col-xs-12 col-md-4">
          <div class="iconsets"> <span><i class="fa fa-ellipsis-h"></i>&nbsp;&nbsp;Other Main Features</span> </div>
        </div>
      </div>
      <div class="row justify-content-center mt-20" style="border-top:2px solid #ececec;">
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mt-20 text-center">
          <div class="productdetailicon"> <span><i class="fa fa-bed"></i>&nbsp;&nbsp;6 Beds</span> </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mt-20 text-center">
          <div class="productdetailicon"> <span><i class="fa fa-bath"></i>&nbsp;&nbsp;6 Baths</span> </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 mt-20 text-center">
          <div class="productdetailicon"> <span><i class="fa fa-square"></i>&nbsp;&nbsp;1 Kanal</span> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="white-bg">
    <div class="container-fluid">
      <div class="row mt-20 mb-100">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="bsbottom mt-20">
            <h4>Description</h4>
            <p><?php echo e($result[0]->description); ?></p>
          
          
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

<body id="particles-js">
</body>
<div class="animated bounceInDown" style="background:white;"><span class="error animated tada" id="msg"></span>
  <form name="form1" class="box" onsubmit="return checkStuff()">
    <h4>Contact Agent for more Information.</h4>
    <input type="text" name="name" placeholder="Name*" autocomplete="off">
    <input type="text" name="email" placeholder="Email*" autocomplete="off">
    <i class="typcn typcn-eye" id="eye"></i>
    <input type="text" name="cell" placeholder="Phone*" id="" autocomplete="off">
    <textarea rows="4" cols="50" name="comment" form="usrform" style="width: 82%;
    border-radius: 5px;background-color:#ececec;">
Message*</textarea>
  </form>
  <div class="row mt-10">
    <div class="col-lg-3 col-sm-12" style="text-align: center;"><span style="font-size: 15px;">I am a :</span></div>
    <div class="col-lg-3 col-sm-12">
      <label class="radios">Buyer
        <input type="radio" checked="checked" name="radio">
        <span class="checkmark"></span></label>
    </div>
    <div class="col-lg-3 col-sm-12">
      <label class="radios">Agent
        <input type="radio" checked="checked" name="radio">
        <span class="checkmark"></span></label>
    </div>
    <div class="col-lg-3 col-sm-12">
      <label class="radios">Others
        <input type="radio" checked="checked" name="radio">
        <span class="checkmark"></span></label>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-lg-4 col-sm-12">
      <button type="button" class="btn btncalmail">Call</button>
    </div>
    <div class="col-lg-4 col-sm-12">
      <button type="button" class="btn btncalmail">Email</button>
    </div>
  </div>
  <div class="row justify-content-center mt-10">
    <div class="col-lg-10 col-sm-12 text-center">
      <p style="font-size:12px;">By submitting this form, I agree to<a href="">Terms of Use</a></p>
    </div>
  </div>
</div>
<div class="white-bg">
  <div class="row mt-20">
    <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12">
      <div class="textbanner">
        <h4>Agent Information</h4>
      </div>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-lg-4 col-sm-12 col-xs-12">
      <div class="agentpic"><img src="img/00.png" alt="agentoic"></div>
    </div>
    <div class="col-lg-7 col-sm-12 col-xs-12">
      <div class="agentpic mt-10" style="padding: 25px 0px !important;">
        <p>Sikandar Noshahi</p>
        <p>Chief Executive Officer</p>
        <span id="dotss"></span><span id="moree">
        <p>Sikandar Noshahi</p>
        <p>Chief Executive Officer</p>
        </span>
        <linkbutton onclick="myFunction()" id="myBtnn" style="color:#689a29;float:right;">Read more v</linkbutton>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!--Shop Area End-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/property_detail_view.blade.php ENDPATH**/ ?>