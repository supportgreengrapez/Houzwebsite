
<script>
  var OrgID=-1;
    function getId(id)
    {


      OrgID = id;
      return true;
    }
    function getreal()
    {
      alert(OrgID);


    }

  </script>
<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
    <div class="">
        <div class="page-title">


            <div class="col-md-10 col-sm-12 col-xs-12">
          <div class="title_left">
            <h3>Invoice Management</h3>
            <h4>Package Invoice</h4>
          </div>
          </div>
      <div class="row">
        <div class="col-lg-6 mt-20">
          <div class="row form-group">
                 <form method="post" action = "<?php echo e(url('/')); ?>/vendor/home/search/by/package/id" class="login-form">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->any()): ?>


<div class="alert alert-danger">
<strong>Danger!</strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>

            <label for="inputPassword" class="col-lg-4 col-sm-12 col-form-label" style="text-align:center;">Search by order Id :</label>
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <input type="text" name="search" class="form-control" id="inputPassword" placeholder="Order No">
            </div>
            <div class="col-lg-3 col-md-2 col-sm-6 col-xs-6">
              <button type="submit" class="btn btnsubmit" style="padding: 6px 12px;width: 65%;">Search</button>
            </div>
          </div>
          </form>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_content">
            <div id="myModal" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                          <!-- Modal content-->
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">Status Change</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Update Status</label>
                                    <select id="status" name="status" class="form-control">
                                        <option>Select status</option>
                                        <option value="0">Submitted</option>
                                        <option value="1">Approved</option>
                                        <option value="2">Pending</option>
                                        <option value="3">Rejected</option>
                                    </select>
                             </div>
                             <button id="b1" type="button" class="btn btn-submmit">Submit</button>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                          </div>

                        </div>
                      </div>

              <table id="datatable-responsive" class="table table-condensed dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                  <th>Invoice#</th>
                    <th>Package Name</th>


                    <th>Subscription</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>

                <?php if(count($result)>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($results->pk_id); ?></td>
                          <td><?php echo e($results->package_name); ?></td>
                          <td><?php echo e($results->subscription); ?></td>
                             <td><?php echo e($results->amount); ?></td>
                             <?php if($results->status == 'waiting'): ?>
                             <td><span   class="label label-primary" >Submitted</span></td>
                             <?php endif; ?>
                             <?php if($results->status == 'approved'): ?>
                             <td><span   class="label label-primary" >Approved</span></td>
                             <?php endif; ?>
                             <?php if($results->status == 'pending'): ?>
                             <td><span   class="label label-primary" >Pending</span></td>
                             <?php endif; ?>
                             <?php if($results->status == 'rejected'): ?>
                             <td><span   class="label label-primary" >Rejected</span></td>
                             <?php endif; ?>
                             <td><?php echo e($results->created_at); ?></td>



                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>


                </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
    <!-- /page content -->



     <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/vendor/rejected_package_invoice_list_view.blade.php ENDPATH**/ ?>