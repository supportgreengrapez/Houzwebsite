
<?php $__env->startSection('content'); ?>
<div class="gray-bg">
  <div class="container">
    <div class="bg-white">
      <div class="background">
        <div class="borders">
          <h1 class="text-center  green">Seller</h1>
        </div>
        <div class="box1img">
          <h1><a href="<?php echo e(url('/')); ?>/signup" class="btn join">Join</a></h1>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="salogan mt-20">
            <p class="text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
            <h2 class="text-center mt-20"><a href="" class="btn product-btn">Join us as Realtor</a></h2>
            <h4 class="text-center mt-20" style="text-decoration:underline;">Why Join Realtor</h4>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-6">
          <div class="cont"> <img src="<?php echo e(url('/')); ?>/pic/22.png" alt="logo">
            <h3>List Project</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          </div>
        </div>
        <div class="col-6">
          <div class="cont"> <img src="<?php echo e(url('/')); ?>/pic/66.png" alt="logo">
            <h3>Online Agency</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          </div>
        </div>
        <div class="col-6">
          <div class="cont"> <img src="<?php echo e(url('/')); ?>/pic/41.png" alt="logo">
            <h3>Brand Exposure</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          </div>
        </div>
        <div class="col-6">
          <div class="cont"> <img src="<?php echo e(url('/')); ?>/pic/33.png" alt="logo">
            <h3>Active Community</h3>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
          </div>
        </div>
      </div>
      <hr>
      <div class="row">
        <div class="col-12">
          <div class="salogan mt-20 mb-20">
            <h3 class="text-center" style="text-decoration:underline;">How to register as realtor and make profile</h3>
          </div>
        </div>
      </div>
      <div class="">
        <div class="container"> 
          <!--first section-->
          <div class="row align-items-center how-it-works d-flex">
            <div class="col-2 text-center bottom d-inline-flex justify-content-center align-items-center">
              <div class="circle font-weight-bold">1</div>
            </div>
            <div class="col-6">
              <h5>Fully Responsive</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor gravida aliquam. Morbi orci urna, iaculis in ligula et, posuere interdum lectus.</p>
            </div>
          </div>
          <!--path between 1-2-->
          <div class="row timeline">
            <div class="col-2">
              <div class="corner top-right"></div>
            </div>
            <div class="col-8">
              <hr/>
            </div>
            <div class="col-2">
              <div class="corner left-bottom"></div>
            </div>
          </div>
          <!--second section-->
          <div class="row align-items-center justify-content-end how-it-works d-flex">
            <div class="col-6 text-right">
              <h5>Using Bootstrap</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor gravida aliquam. Morbi orci urna, iaculis in ligula et, posuere interdum lectus.</p>
            </div>
            <div class="col-2 text-center full d-inline-flex justify-content-center align-items-center">
              <div class="circle font-weight-bold">2</div>
            </div>
          </div>
          <!--path between 2-3-->
          <div class="row timeline">
            <div class="col-2">
              <div class="corner right-bottom"></div>
            </div>
            <div class="col-8">
              <hr/>
            </div>
            <div class="col-2">
              <div class="corner top-left"></div>
            </div>
          </div>
          <!--third section-->
          <div class="row align-items-center how-it-works d-flex">
            <div class="col-2 text-center top d-inline-flex justify-content-center align-items-center">
              <div class="circle font-weight-bold">3</div>
            </div>
            <div class="col-6">
              <h5>Now with Pug and Sass</h5>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed porttitor gravida aliquam. Morbi orci urna, iaculis in ligula et, posuere interdum lectus.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class="salogan mt-20 mb-20">
            <h2 class="text-center" style="text-decoration:underline;">How to register as realtor and make profile</h2>
          </div>
        </div>
        <div class="col-12">
          <div class="cont">
            <iframe width="560" height="315" src="https://www.youtube.com/embed/gArDKxA3AeE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
          <div class="salogan">
            <h2 class="text-center mt-20"><a href="" class="btn product-btn">Registor as Realtor on Houzz</a></h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-12">
          <div class=" gray-bg m-5">
            <div class="cont">
              <h4>Need More Help....?</h4>
              <a href="">call Us : 090078601</a> <a href="">Email : greengrapez.com</a> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/sell_on.blade.php ENDPATH**/ ?>