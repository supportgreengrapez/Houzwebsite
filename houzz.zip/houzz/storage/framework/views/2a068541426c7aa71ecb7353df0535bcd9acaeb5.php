<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz"><link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<title>Houzz</title>

<!-- Bootstrap -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/style.css" rel="stylesheet">

<!-- Datatables -->
<link href="<?php echo e(url('/')); ?>/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/responsive.bootstrap.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/scroller.bootstrap.min.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title"> <a href="" class="site_title"><i><img src="<?php echo e(url('/')); ?>/images/vendorprofile.png" alt="logo"></i> <span>Houzz</span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
            <ul class="nav side-menu">
            <?php if(Session::get('subscription') == 1): ?>
              <li><a href="index.html"><i class="fa fa-tachometer"></i> Home </a> </li>
            
              <?php if(!empty(Session::get('package')[0]->no_of_product)): ?>
              <li><a><i class="fa fa-table"></i> Product Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/add/product">Add Product</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/product">View Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/vendor/collection/list/view">Manage Collections</a></li>
                  <li><a href="#">Import New Products</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/cancel/product">Cancel Products</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/pending/product">Pending Products</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/approved/product">Approved Products</a></li>
                </ul>
              </li>
              <?php endif; ?>
              <li><a><i class="fa fa-file"></i> Reporting <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/reporting/by/products">By Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/reporting/by/sale">By Sales</a></li>

                </ul>
              </li>
          
              <li><a><i class="fa fa-table"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/active/orders">Manage Orders</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/commission/invoice">Commission Invoice</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/subscription/invoice">Subscription Invoice</a></li>
                </ul>
              </li>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/return/orders"><i class="fa fa-exchange"></i> Returns </a> </li>
              <?php if(Session::get('package')[0]->promotion == 1): ?>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/discount"><i class="fa fa-square"></i> Promotions </a> </li>
<?php endif; ?>

              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/rating"><i class="fa fa-star"></i> Rating & Review </a> </li>
              <?php if(Session::get('package')[0]->client == 1): ?>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/offline/client"><i class="fa fa-user"></i> Client Management </a> </li>
<?php endif; ?>

              <li><a><i class="fa fa-cog"></i>Settings <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/bank/account">Bank Account</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/edit/seller/info">Seller Info</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/edit/notification">Notifications</a></li>
                </ul>
              </li>
              <li><a href="resources.html"><i class="fa fa-th"></i> Resources </a> </li>
<?php endif; ?>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/package"> <i class="fa fa-cubes"></i>  Packages </a> </li>
              <li><a><i class="fa fa-money"></i> Payments <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/payment/invoice">View Payments</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/submit/payment/invoice">Submitted</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/approved/payment/invoice">Approved</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/pending/payment/invoice">Pending</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/rejected/payment/invoice">Rejected</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Invoices <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/submit/package/invoice">Submitted</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/approved/package/invoice">Approved</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/pending/package/invoice">Pending</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/rejected/package/invoice">Rejected</a></li>
                </ul>
              </li>
              
              <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/message"><i class="fa fa-tachometer"></i> Message </a> </li>
              <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/chat"><i class="fa fa-tachometer"></i> Chat System </a> </li>
            
            </ul>
          </div>
        </div>
        <!-- /sidebar menu -->
      </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="<?php echo e(url('/')); ?>/images/vendorprofile.png" alt=""><?php echo e(Session::get('fname')); ?> <?php echo e(Session::get('lname')); ?> <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="<?php echo e(URL('/')); ?>/vendor/home/edit/seller/info"> Profile</a></li>
                <li><a href="<?php echo e(URL('/')); ?>/vendor/logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
    </div>

    <?php echo $__env->yieldContent('content'); ?>

    <!-- footer content -->
 <footer>
      <div class=""> Copyright © 2017-2018 Houzz.com. All rights reserved. </div>
      <div class="pull-right"> Powered By <a href="https://greengrapez.com">Green Grapez <img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="green grapez" style="width:5%;"></a> </div>

      <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
  </div>
</div>

<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
<!-- DateJS -->
<script src="<?php echo e(url('/')); ?>/js/build/date.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/js/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo e(url('/')); ?>/js/moment.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/daterangepicker.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(url('/')); ?>/js/custom.min.js"></script>
<!-- Datatables -->
<script src="<?php echo e(url('/')); ?>/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/dataTables.responsive.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/responsive.bootstrap.js"></script>
<script src="<?php echo e(url('/')); ?>/js/dataTables.scroller.min.js"></script>

<script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/vendor/home/order/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>

<script>
      $("#b1").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/vendor/home/payment/invoice/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
    
          $("#hot").click(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var status = $('#status').val();
        $.ajax({
          /* the route pointing to the post function */
          url: "<?php echo e(URL('/')); ?>/vendor/home/product/hot/update/status",
          type: 'POST',
          /* send the csrf-token and the input to the controller */
          data: {_token: CSRF_TOKEN, status:status,
          id: OrgID,
        },
          /* remind that 'data' is the response of the AjaxController */
          success: function (data) {
            window.location.href = data;
          }
      });

    });
  </script>

    <script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
        $("#example2").dataTable({
          "bPaginate": true,
          "bLengthChange": false,
          "bFilter": false,
          "bSort": true,
          "bInfo": true,
          "bAutoWidth": false
        });
      });

      $(".my-colorpicker2").colorpicker();
    </script>


  <script type="text/javascript">
      $("#MainCategory").on('change',function(e){

        console.log(e);

        var cat_id = e.target.value;

        $.get('<?php echo e(URL('/')); ?>/vendor/ajax-subcat?cat_id='+ cat_id,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');
          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<option value ="'+subcatObj.sub_category+'">'+subcatObj.sub_category+'</option>');
        });



        });


    });

  </script>



  <script type="text/javascript">
    $("#mainCategory").on('change',function(e){

      console.log(e);

      var cat_id = e.target.value;

      $.get('<?php echo e(URL('/')); ?>/vendor/ajax-subcat?cat_id='+ cat_id,function(data){
        console.log(data);
        $('#subCategory').empty();
        $('#subCategory').append('<option value="" disable="true" selected="true" >---Select Sub Category---</option>');

        $.each(data,function(create,subcatObj){

          $('#subCategory').append('<option value ="'+subcatObj.SKU+'">'+subcatObj.sub_category+'</option>');
      });



      });


  });

    $("#subCategory").on('change',function(e){

      console.log(e);

      var type_id = e.target.value;

      $.get('<?php echo e(URL('/')); ?>/vendor/ajax-product-type?type_id='+ type_id,function(data){
        console.log(data);
      $('#ProductType').empty();
        $('#ProductType').append('<option value="" disable="true" selected="true" >---Add Product Type---</option>');
        $.each(data,function(create,typeObj){

          $('#ProductType').append('<option value ="'+typeObj.product_type+'">'+typeObj.product_type+'</option>');
      });



      });


  });
</script>
 <script>
      $(document).ready(function() {
	
	$(".js-example-tokenizer").select2({
    tags: true,
    tokenSeparators: [',', ' ']
})
});
  </script>
</body>
</html>
<?php /**PATH F:\xamp\htdocs\houzz\resources\views/vendor/layout/appvendor.blade.php ENDPATH**/ ?>