
<?php $__env->startSection('content'); ?> 

<!-- page content -->
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Reporting Management</h3>
        <h4 style="display: block;">Create Payment</h4>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_content">
        <?php if($result>0): ?>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <form method="post" enctype="multipart/form-data" action = "<?php echo e(url('/')); ?>/admin/home/create/payment/<?php echo e($results->payment_id); ?>" >
            <?php echo e(csrf_field()); ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger"> <strong></strong> <?php echo e($errors->first()); ?> </div>
            <?php endif; ?>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label>Seller Name</label>
                  <input type="text" class="form-control" name="name" value="<?php echo e($results->fname); ?> <?php echo e($results->lname); ?>" readonly>
                </div>
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" class="form-control" name="username" value="<?php echo e($results->username); ?>" readonly>
                </div>
                <div class="form-group">
                  <label>Total Earning</label>
                  <input type="text" class="form-control" name="remaining" value="<?php echo e($results->remaining); ?>" readonly>
                </div>
                <div class="form-group">
                  <label>Amount Pay</label>
                  <input type="number" class="form-control" name="amount_pay">
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
              </div>
            </div>
          </form>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?> </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/create_payment.blade.php ENDPATH**/ ?>