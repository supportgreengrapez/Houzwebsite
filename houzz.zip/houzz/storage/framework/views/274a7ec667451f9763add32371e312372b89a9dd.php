<?php $__env->startSection('content'); ?>

<!--Breadcrumb Tow Start-->

<div class="container white-bg wrapp">
  <div class="row">
    <div class="col-lg-12 col-sm-12 col-xs-12">
      <div class="topheadordertracking">
        <h3>Order Tracking</h3>
      </div>
    </div>
  </div>
</div>
<div class="gray-bg3">
  <div class="container pt-40 pb-40">
    <div class="white-bg wrapp pt-30 pb-30">
      <form method="post" action = "<?php echo e(url('/')); ?>/order/tracking" class="login100-form validate-form ">
        <?php echo e(csrf_field()); ?>

        <?php if($errors->any()): ?>
        <div class="alert alert-danger"> <strong>Danger!</strong> <?php echo e($errors->first()); ?> </div>
        <?php endif; ?>
        <div class="row justify-content-center mt-30">
          <div class="col-lg-7 col-sm-12 col-xs-12">
            <div class="form-group">
              <label for="usr">Order Tracking Id:</label>
              <input type="search" name ="orderid" class="form-control" id="usr" style="height:40px;border:1px solid;">
            </div>
            <button type="submit" class="btn btnnav">Search</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<?php if(count($orderdetail)>0): ?>
                    <?php $__currentLoopData = $orderdetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                               <?php
                $order_id =   $results->pk_id;

        $orderdetailed = DB::select("select* from detail_table where order_id = '$order_id' ");

                       ?>
<div id="login" class="mb-30 mt-70">
  <div class="container">
    <div id="login-row" class="row align-items-center">
      <div id="login-column" class="col-md-12">
      	
        <div id="login-box" class="col-md-6 shadow-lg p-3 mb-5 bg-white rounded">
        <div class="wishlist-area mb-20 mt-10">
		    <div class="container">
            
		        <div class="row">
            <div class="col-lg-6 col-sm-12 col-xs-12">
      <div class="ordertrackingheadings"> <a href="<?php echo e(url('/')); ?>/order/tracking/detail/<?php echo e($results->pk_id); ?>">View Orders <span> <?php echo e($results->pk_id); ?> </span></a> </div>
    </div>
    <div class="col-md-6 ml-auto">
		                            <div class="cart-page-total">
		                                <ul>
		                                    <li>Total <span>PKR  <?php echo e(number_format($results->amount)); ?></span></li>
		                                </ul>
		                            </div>
		                        </div>
		            <div class="col-12">
		                    <div class="table-content table-responsive">
		                        <table class="table">
		                            <thead>
		                                <tr>
		                                    <th class="plantmore-product-thumbnail">images</th>
		                                    <th class="cart-product-name">Product</th>
		                                    <th class="plantmore-product-price">Size</th>
                                             <th class="cart-product-name">QTY</th>
		                                    <th class="plantmore-product-price">Price</th>
		                                       <th class="plantmore-product-price">Total Price</th>
		                                </tr>
		                            </thead>
		                            <tbody>
		                                   <?php if(count($orderdetailed)>0): ?>
                    <?php $__currentLoopData = $orderdetailed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php

$id =  $results->product_id;
$thumbnail = DB::select("select* from product where  pk_id ='$id'");

?>
		                                <tr>
		                                    <td class="plantmore-product-thumbnail"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($thumbnail[0]->thumbnail); ?>" alt="odimg" style="width:100px;height:100px;"></td>
		                                    <td class="plantmore-product-name"><a href="#"><?php echo e($results->product_name); ?></a></td>
		                                    <td class="plantmore-product-price"><span class="amount"><?php echo e($results->size); ?></span></td>
                                            <td class="plantmore-product-name"><?php echo e($results->quantity); ?></td>
		                                    <td class="plantmore-product-price"><span class="amount">PKR <?php echo e(number_format($results->price)); ?></span></td>
		                                       <td class="plantmore-product-price"><span class="amount">PKR <?php echo e(number_format($results->price * $results->quantity)); ?></span></td>
		                                </tr>
		                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
		                            </tbody>
		                        </table>
		                    </div>
		            </div>
		        </div>
                <div class="row">
		                        
		                    </div>
		    </div>
		</div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/client/order_id.blade.php ENDPATH**/ ?>