<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz">
<link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<title>Houzz</title>
    <!-- Bootstrap -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
          <form method="post" action = "<?php echo e(url('/')); ?>/vendor/login" class="login-form">
      <?php echo e(csrf_field()); ?>

      <?php if($errors->any()): ?>
<div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>

    <?php endif; ?>
              <h1>Login Form</h1>
              <div>
                <input type="email" name ="username" class="form-control" placeholder="Username" required/>
              </div>
              <div>
                <input type="password" name ="password" class="form-control" placeholder="Password" required />
              </div>
              <div>
                <button type="submit" class="btn btn-success submit" >Log in</button>
                <a class="reset_pass" href="<?php echo e(URL('/')); ?>/vendor/password/reset">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <div>
                  <h1><i><img src="<?php echo e(url('/')); ?>/images/logo.png" alt="logo" style="max-width:250px;"></i></h1>
                  <p>Copyright © 2017-2018 Houzz.com. All rights reserved.</p>
                  <p>Powered By <a href="https://greengrapez.com">Green Grapez <img src="<?php echo e(url('/')); ?>/images/greengrapez.png" alt="green grapez" style="width:20%;"></a></p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
  </body>
</html>
<?php /**PATH F:\xamp\htdocs\houzz\resources\views/vendor/vendor_login_view.blade.php ENDPATH**/ ?>