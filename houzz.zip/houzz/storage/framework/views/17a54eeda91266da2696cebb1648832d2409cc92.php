<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Form Management</h3>
            <h4 style="display: block;">Add Topic</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
          
              <div class="x_content">
              <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/edit/forum/topic/<?php echo e($result[0]->pk_id); ?>" enctype="multipart/form-data" class="login-form">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong>Danger!</strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
              <div class="row">
                <div class="col-lg-5">
                    <div class="row">
                      <div class="form-group">
                        <label>Category Name</label>
                        <select class="form-control" name="category">
                        <?php if(count($result)>0): ?>
                      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<option value="<?php echo e($results->category); ?>"><?php echo e($results->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
                        </select>
                      </div>
                      <div class="form-group">
                        <label>Topic</label>
                        <input type="text" class="form-control" name="topic" placeholder="Title" value="<?php echo e($result[0]->topic); ?>" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                    </div>
                </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Submit</button>
                </div>
                </div>
                
                </form>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content --> 
      
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xamp\htdocs\houzz\resources\views/admin/edit_topic.blade.php ENDPATH**/ ?>