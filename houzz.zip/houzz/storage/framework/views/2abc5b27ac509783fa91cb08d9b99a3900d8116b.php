<?php $__env->startSection('content'); ?>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="//geodata.solutions/includes/countrystatecity.js"></script>
<body>
<?php if(count($result)>0): ?>
    <div class="container">
    <div class="row">
        <div class="col-lg-8 col-md-12 col-sm-12 col-lg-offset-2">

            <div class="panel panel-default">

                <div class="panel-heading">
                    <h3 class="panel-title">
                       1: YOUR EMAIL &nbsp;&nbsp;&nbsp;&nbsp;                </h3>
                </div>


                <div class="panel-heading">
                    <h3 class="panel-title">
                       2: YOUR ADDRESS          </h3>
                </div>

                    <div class="row">
                      <div class="col-md-12">
                        <div id="mainContentWrapper">
                          <div class="col-md-12">
                             <div class="shopping_cart">
                            <form  role="form" action="<?php echo e(url('/')); ?>/cart/checkout/edit/address/<?php echo e($result[0]->pk_id); ?>" method="post" id="payment-form">
                              <?php echo e(csrf_field()); ?>


                                <div class="panel">
                                  <div class="">
                                    <div class="panel-body">
                                      <table class="table" style="font-weight: bold;">

                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_first_name">First name:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_first_name" name="fname" value= "<?php echo e($result[0]->fname); ?>"
                                                                             type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_last_name">Last name:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_last_name" name="lname" value= "<?php echo e($result[0]->lname); ?>"
                                                                              type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_address_line_1">Address:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_address_line_1" value="<?php echo e($result[0]->address); ?>"
                                                                             name="address"  type="text"/></td>
                                        </tr>


                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_phone">Phone:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_phone" value="<?php echo e($result[0]->phone); ?>" name="phone" type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;"><label for="id_phone">Zip Code:</label></td>
                                          <td style="border-top: 0px;"><input class="form-control" id="id_phone" name="zip" value="<?php echo e($result[0]->zip); ?>" type="text"/></td>
                                        </tr>
                                        <tr>
                                          <td style="width: 175px; border-top: 0px;">

                    <label for="id_phone">Country*</label></td>

               <td style="border-top: 0px;"> <select name="country" class="countries form-control" id="countryId">
                    <option value="">Select Country</option>
                </select></td>
                </tr>
                <tr>
                    <td style="width: 175px; border-top: 0px;"><label for="text">State*</label></td>
                    <td style="border-top: 0px;"><select name="state" class="states form-control" id="stateId">

                     <option value="">Select State</option>
                </select></td>
                </tr>
                <tr>

                <td style="width: 175px; border-top: 0px;"><label for="text">City*</label></td>
                <td style="border-top: 0px;"><select name="city"  class="cities form-control" id="cityId">
                          <option value="">Select City</option>
                </select></td>
                </tr>
             </div>

                                          </td>
                                        </tr>


                                      </table>
                                          <button name="submit" type="submit" class="btn login-button">Save Address</button>
                                    </div>
                                  </div>
                                </div>


                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                <div class="panel-heading panelhead">
                    <h3 class="panel-title">
                        3:ORDER SUMMERY                    </h3>
                </div>
                <div class="panel-heading panelhead">
                    <h3 class="panel-title">
                       4: PAYMENT                    </h3>
                </div>

            </div>

            <br/>
        </div>
    </div>
  </div>
  <?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.appclient', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/client/edit_address_view.blade.php ENDPATH**/ ?>