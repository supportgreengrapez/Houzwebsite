<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <div class="textcen">
            <h4>Create Client</h4>
          </div>
        </div>
      </div>
      <form method="post" action = "<?php echo e(url('/')); ?>/vendor/home/add/offline/client" class="login-form">
                        <?php echo e(csrf_field()); ?>


                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
  <strong></strong> <?php echo e($errors->first()); ?>

</div>
    <?php endif; ?>

   <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">Name</label>
            <input type="text" class="form-control blueborder"  id="" placeholder="Name" name="name" >
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">Email</label>
            <input type="email" class="form-control blueborder" id="" placeholder="Email" name="email" >
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">Phone</label>
            <input type="number" class="form-control blueborder" id="" placeholder="Phone" name="phone" >
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">Country</label>
            <input type="text" class="form-control blueborder" id="" placeholder="Country" name="country" >
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">State</label>
            <input type="text" class="form-control blueborder" id="" placeholder="State" name="state" >
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">City</label>
            <input type="text" class="form-control blueborder" id="" placeholder="City" name="city" >
          </div>
        </div>
      </div>
      
      <div class="row">
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          <div class="form-group nomargin contform2">
            <label for="email">Zip</label>
            <input type="text" class="form-control blueborder" id="" placeholder="Zip" name="zip" >
          </div>
        </div>
      </div>

      <br>
      <div class="row">
        <div class="col-lg-2 col-md-3 col-sm-12 col-xs-12 mt-20">
          <button type="submit" class="btn btnupdate">Create</button>
          <div class="banktext"> </div>
        </div>
      </div>
</form>
    </div>
    <!-- /page content -->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/vendor/add_offline_client_view.blade.php ENDPATH**/ ?>