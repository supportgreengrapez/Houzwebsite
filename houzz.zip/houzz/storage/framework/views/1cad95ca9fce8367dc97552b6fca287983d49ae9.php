<?php $__env->startSection('content'); ?>



    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
           <h3>Reporting Management</h3>
            <h4>By Product</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="page-title">
           <h2>Total Revenue : <?php echo e($total); ?> </h2>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_content">
                <table id="datatable-responsive" class="table table-condense dt-responsive" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                    <th>SKU</th>
                      <th>ORDER ID</th>
                      <th>Quantity</th>
                  <th>Total Price</th>
                      <th>Discounted Price</th>
                        <th>Discount</th>
                      <th>Size</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php if(count($result)>0): ?>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($results->sku); ?></td>
                          <td><?php echo e($results->order_id); ?></td>
                          <td><?php echo e($results->quantity); ?></td>
                              <td><?php echo e($results->price); ?></td>
                             <td><?php echo e($results->discount_price); ?></td>
                             <?php if($results->percentage > 0): ?>
                                <td><?php echo e($results->percentage); ?>%</td>
                                <?php else: ?>
                                  <td> </td>
                                  <?php endif; ?>
                          <td><?php echo e($results->size); ?></td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                  </tbody>
                </table>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->


  <?php $__env->stopSection(); ?>

<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/vendor/product_reporting_detail_view.blade.php ENDPATH**/ ?>