<?php $__env->startSection('content'); ?> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Product Management</h3>
            <h4 style="display:block;">Manage Collection</h4>
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
          
          <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
              <?php if(count($result)>0): ?>
                     <form method="post" action = "<?php echo e(url('/')); ?>/vendor/edit/collection/category/<?php echo e($result[0]->pk_id); ?>" class="login-form" enctype="multipart/form-data" >
                        <?php echo e(csrf_field()); ?>

                    
              <div class="x_content">
                   
      
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                
              <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="title_left">
            <h4>Add Collection Name</h4>
          </div>
                      <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="collection_name" value="<?php echo e($result[0]->collection_name); ?>" placeholder="Collection Name" pattern="[a-zA-Z0-9\s]+" maxlength="50" required>
                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000"><?php echo e($result[0]->description); ?></textarea>
                      </div>
                      <div class="form-group">
                      <label>Cover Photo</label>
                      <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                      <img id="blah" src="<?php echo e(url('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" alt="Product Image" style="width:100%; height:315px;" />
                      </div>
                </div>
      		  </div>
      
                <div class="col-md-12">
                <div class="divider"></div>
                </div>
                                
                <div class="col-md-6">
                        <button type="submit" class="btn btn-success btn-lg">Submit</button>
                        
                </div>
              </div>
              </form>
              <?php endif; ?>
          </div>
          
        </div>
        <div class="clearfix"></div>
        
      </div>
    </div>
    <!-- /page content --> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.layout.appvendor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/vendor/edit_collection_view.blade.php ENDPATH**/ ?>