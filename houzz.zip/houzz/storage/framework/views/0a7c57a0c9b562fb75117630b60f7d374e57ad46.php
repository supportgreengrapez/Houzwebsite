<?php $__env->startSection('content'); ?>

    <!-- page content -->
    <div class="right_col" role="main">
      <div class="">
        <div class="page-title">
          <div class="title_left">
            <h3>Photo Management</h3>
            <h4 style="display:block;">Add Idea</h4>
          </div>
        </div>

        <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">

              <div class="x_content">
              <form method="post" action = "<?php echo e(url('/')); ?>/admin/home/add/idea" class="login-form" enctype="multipart/form-data">
                      <?php echo e(csrf_field()); ?>

                      <?php if($errors->any()): ?>

<div class="alert alert-danger">
  <strong>Danger!</strong> <?php echo e($errors->first()); ?>

</div>
<?php endif; ?>
              <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                      <div class="form-group">
                        <label>Category</label>
                        <select class="form-control" name="photo_category" id="photo_category">

                        <option value="" disable="true" selected="true" >---Select Category---</option>
                        <?php if($result>0): ?>
                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(urlencode($results->photo_category)); ?>"><?php echo e($results->photo_category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                        </select>
                      </div>
                      <div class="form-group">
                        <label>Sub Category</label>
                        <select class="form-control" name="photo_sub_category" id="photo_sub_category">
                        <option value="" disable="true" selected="true" >---Select Sub Category---</option>

                        </select>
                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="9" name="description" placeholder="Enter Your Message" pattern="[a-zA-Z0-9\s]+" maxlength="1000"></textarea>
                      </div>
                </div>
      		  </div>
              <div class="row">
                <div class="page-title">
                        <h5><b>Images</b></h5>
                </div>
                <div class="col-lg-12">
                    <div class="row">
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                      <img id="blah" src="<?php echo e(url('/')); ?>/images/demo.png" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="images2" class="form-control" onchange="preview_image(this);"/>
                      <img id="blah2" src="<?php echo e(url('/')); ?>/images/demo.png" alt="Product Image" style="width:350px; height:300px;" />
                      </div>
                      <div class="form-group col-lg-4 col-sm-12 col-md-4">
                      <input type="file" name="images3" class="form-control" onchange="preview_img(this);"/>
                      <img id="blah3" src="<?php echo e(url('/')); ?>/images/demo.png" alt="Product Image" style="width:350px; height:300px;" />
                      </div>

                     </div>
                </div>
                </div>

              <div class="col-md-6">
                        <button id="send" type="submit" class="btn btn-success btn-lg">Create</button>
                </div>
                </form>
              </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /page content -->

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\houzz\resources\views/admin/add_idea.blade.php ENDPATH**/ ?>