<!doctype html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Houzz</title>
<meta name="description" content="">
<meta name="robots" content="noindex, follow" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow"/>
<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('/')); ?>/pic/favicon.png">
<!--All Css Here-->

<!-- Bootstrap CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/bootstrap.min.css">
<!-- Linearicon CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/linearicons.min.css">
<!-- Font Awesome CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/font-awesome.min.css">

<!-- Animate CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/animate.css">
<!-- Owl Carousel CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/owl.carousel.min.css">
<!-- Slick CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/slick.css">
<!-- Meanmenu CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/meanmenu.min.css">
<!-- Easyzoom CSS-->
<!-- Venobox CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/venobox.css">
<!-- Jquery Ui CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/jquery-ui.css">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/responsive.css">
<!-- Modernizr Js -->
<script src="<?php echo e(url('/')); ?>/js1/vendor/modernizr-2.8.3.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css" rel="stylesheet" />
</head>
<body>
<div class="wrapper"> 
  <!--Header Area Start-->
  <header>
    <div class="header-container"> 
      <!--Header Top Area Start-->
      <div class="header-top-area black-bg">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-8"> 
              <!--Header Top Left Start-->
              <div class="header-top-left">
                <div class="header-top-language-currency">
                  <div class="switcher">
                    <p>Free Deliver <strong style="color:#689a29;">Applies on more then 50$ and return is always free</strong> </p>
                  </div>
                </div>
              </div>
              <!--Header Top Left End--> 
            </div>
            <div class="col-lg-4 col-md-4"> 
              <!--Header Top Right Start-->
              <div class="header-top-right">
                <ul class="menu-top-menu text-md-right">
                  <li><a href=""><i class="fa fa-facebook"></i></a></li>
                  <li><a href=""><i class="fa fa-twitter"></i></a></li>
                  <li><a href=""><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <!--Header Top Right End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Header Top Area End--> 
      <!--Header Middle Area Start-->
      <div class="header-middle-area">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-lg-3 col-md-4"> 
              <!--Header Logo Start-->
              <div class="header-logo"> <a href="<?php echo e(url('/')); ?>/"><img src="<?php echo e(url('/')); ?>/pic/logo.png" alt=""></a> </div>
              <!--Header Logo End--> 
            </div>
            <div class="col-xl-3 col-lg-3 col-md-10"> 
              <!--Header Search Area-->
              <div class="header-search-area">
                <form  role="form" action="<?php echo e(url('/')); ?>/search" method="post" id="payment-form">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-input">
                    <input name="search" id="search" placeholder="Search ...." type="text" required>
                    <button type="submit" class="header-search-btn"><i class="fa fa-search"></i></button>
                  </div>
                </form>
              </div>
              <!--Header Search Area--> 
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4">
              <div class="header-top-right">
                <ul class="nav justify-content-center">
                  <li class="nav-item"> <a class="nav-link" href="#">Forums</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#">Maps</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/blog">Blog</a> </li>
                </ul>
              </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-4">
              <div class="mini-cart"> <a href="#"> <span class="cart-icon"> <span class="cart-quantity"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : '0'); ?></span> </span> <span class="cart-title">Your cart <br>
                <strong>PKR <?php echo e(number_format($totalPrice)); ?></strong></span> </a> 
                <!--Cart Dropdown Start--> 
                <?php if(Session::has('cart')): ?>
                <div class="cart-dropdown">
                  <ul>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="single-cart-item">
                      <div class="cart-img"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($product['item']->thumbnail); ?>" alt=""> </div>
                      <div class="cart-content">
                        <h5 class="product-name"><?php echo e($product['item']->name); ?></h5>
                        <span class="cart-price"><?php echo e($product['qty']); ?> × PKR <?php echo e(number_format($product['item']->price)); ?>

                        <?php if($product['save']>0): ?> saving -<?php echo e($product['save']); ?><?php endif; ?></span> </div>
                      <div class="cart-remove"> <a title="Remove" href="<?php echo e(URL('/')); ?>/remove/item/cart/<?php echo e($product['item']->pk_id); ?>/<?php echo e($product['size']); ?>/<?php echo e($product['qty']); ?>/<?php echo e($product['delivery_charges']); ?>"><i class="fa fa-times"></i></a> </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <p class="cart-subtotal"><strong>Subtotal:</strong> <span class="float-right">PKR <?php echo e(number_format($totalPrice)); ?></span></p>
                  <p class="cart-btn"> <a href="<?php echo e(url('/')); ?>/cart">View cart</a> <a href="<?php echo e(url('/')); ?>/cart/checkout">Checkout</a> </p>
                </div>
                <?php endif; ?> 
                <!--Cart Dropdown End--> 
              </div>
            </div>
            
            <div class="col-xl-2 col-lg-3 col-md-4">
                
                <?php if(Session::has('username')): ?> 
                        
                                <div class="currency-box"> <a href="#"><img src="<?php echo e(url('/')); ?>/pic/icon.png" alt="icon"> <?php echo e(session::get('name')); ?> </a>
                                  <div class="currency-dropdown">
                                    <ul class="menu-top-menu">
                                      <li><a href="<?php echo e(URL('/')); ?>/order/tracking/view">Order Tracking</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/client/payment/list/view/<?php echo e(session::get('pk_id')); ?>">Payment List</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/realtor/dashboard">Switch to My Account</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/client/send/message">Compose Message</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/client/chat/<?php echo e(session::get('pk_id')); ?>">Chat</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/logout">Logout</a></li>
                                    </ul>
                                  </div>
                                </div>
                        <?php else: ?>
                        <div class="header-top-right">
                <ul class="nav justify-content-center">
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/login">Login</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/signup">Signin</a> </li>
                </ul>
              </div>
                        <?php endif; ?>
              
            </div>
          </div>
        </div>
      </div>
      <!--Header Middle Area End--> 
      <!--Header Bottom Area Start-->
      <div class="header-bottom-area header-sticky">
        <div class="header-boxshadow">
          <div class="header-inner">
            <div class="container">
              <div class="row">
                <div class="col-12"> 
                  <!--Logo Sticky Start-->
                  <div class="logo-sticky"> <a href="<?php echo e(url('/')); ?>/"><img src="<?php echo e(url('/')); ?>/pic/logo2.png" alt=""></a> </div>
                  <!--Logo Sticky End--> 
                  <!--Main Menu Area Start-->
                  <div class="header-menu text-center">
                    <nav>
                      <ul class="main-menu">
                        <li><a href="<?php echo e(url('/')); ?>/">home</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/shop">Shop</a>
                            <!--Mega Menu Start-->
                            <ul class="mega-menu">
                                <?php
                                $Furniture = DB::select("select* from sub_category where main_category = 'Furniture' LIMIT 5");
                                $Kitchen= DB::select("select* from sub_category where main_category = 'Kitchen and Dining' LIMIT 5");
                                $Bath= DB::select("select* from sub_category where main_category = 'Bath' LIMIT 5");
                                $Lighting= DB::select("select* from sub_category where main_category = 'Lighting' LIMIT 5");
                                $Outdoor= DB::select("select* from sub_category where main_category = 'Outdoor' LIMIT 5");
                                $Bedroom= DB::select("select* from sub_category where main_category = 'Bedroom' LIMIT 5");
                                $Living= DB::select("select* from sub_category where main_category = 'Living' LIMIT 5");
                                $Home= DB::select("select* from sub_category where main_category = 'Home Decor' LIMIT 5");
                                ?>
                                
                                <?php if(count($Furniture)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Furniture[0]->main_category); ?>" class="item-link"><?php echo e($Furniture[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Furniture[0]->main_category); ?>" style="color:green">See All</a></li>
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                
                                
                                <?php if(count($Bath)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bath[0]->main_category); ?>" class="item-link"><?php echo e($Bath[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Bath; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bath[0]->main_category); ?>" style="color:green">See All</a></li>
                                    
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Lighting)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Lighting[0]->main_category); ?>" class="item-link"><?php echo e($Lighting[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Lighting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Lighting[0]->main_category); ?>" style="color:green">See All</a></li>
                                  
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Outdoor)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Outdoor[0]->main_category); ?>" class="item-link"><?php echo e($Outdoor[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Outdoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Outdoor[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Bedroom)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bedroom[0]->main_category); ?>" class="item-link"><?php echo e($Bedroom[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Bedroom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bedroom[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Living)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Living[0]->main_category); ?>" class="item-link"><?php echo e($Living[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Living; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Living[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Kitchen)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Kitchen[0]->main_category); ?>" class="item-link"><?php echo e($Kitchen[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Kitchen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Kitchen[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Home)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Home[0]->main_category); ?>" class="item-link"><?php echo e($Home[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/shop" style="color:green">See All</a></li>
                                    </ul>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <!--Mega Menu End-->
                        </li>
                        <li><a href="<?php echo e(url('/')); ?>/sale/view">Sale</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/seller/list/view">Seller</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/properties">Properties</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/collection">Collections</a></li>
                        
                      </ul>
                    </nav>
                  </div>
                  <!--Main Menu Area End--> 
                </div>
              </div>
              <div class="row">
                <div class="col-12"> 
                  <!--Mobile Menu Area Start-->
                  <div class="mobile-menu d-lg-none"></div>
                  <!--Mobile Menu Area End--> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Header Bottom Area End--> 
    </div>
  </header>
  <!--Header Area End--> 
  <?php echo $__env->yieldContent('content'); ?> 
  <!--Footer Area Start-->
  <footer>
    <div class="footer-container"> 
      <!--Footer Top Area Start-->
      <div class="footer-top-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="<?php echo e(url('/')); ?>/faq">Faqs</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/terms/and/conditions">Terms & Condition</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/warranty/and/repairs">Warrenty and Repairs</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/returns/and/refunds">Return and Refund</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/privacy/policy">Privacy Policy</a></li>
                  <li><a href="#">Be a Realtor</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/sell_on_houzz">Sell on Houzz</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/advertise_with_us">Advertise with us</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End--> 
            </div>
            <div class="col-lg-3 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="<?php echo e(url('/')); ?>/aboutus">About Us</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/contact/us">Contact Us</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/">Payment Information</a></li>
                  <li><a href="#">Blog</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/login">Seller Login</a></li>
                  <li><a href="">Be a Professional</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End--> 
            </div>
            <div class="col-lg-6 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="text-center"> <a href="" target="_blank" class="btn-social btn-facebook"><i class="fa fa-facebook"></i></a> <a href="" target="_blank" class="btn-social btn-instagram"><i class="fa fa-instagram"></i></a> <a href="" target="_blank" class="btn-social btn-twitter"><i class="fa fa-twitter"></i></a> </div>
              <div class="footer-title mt-40">
                <h3>Contact Us</h3>
              </div>
              <div class="single-footer-widget mb-40">
                <div class="news-letter-form mb-10">
                  <form class="popup-subscribe-form validate" target="_blank" novalidate>
                    <div id="mc_embed_signup_scroll">
                      <div id="mc-form" class="mc-form subscribe-form " style=" border-top: 1px solid white;border-bottom: 1px solid white;
    padding: 1%;">
                        <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email here">
                        <button type="button" class="btn btn-serach">Login</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!--Single Footer Widget End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Footer Top Area End--> 
      <!--Footer Bottom Area Start-->
      <div class="footer-bottom-area pt-50 pb-50">
        <div class="container">
          <div class="row">
            <div class="col-md-12"> 
              <!--Footer Copyright Start-->
              <div class="footer-copyright">
                <p>Copyright © <a href="http://general.greengrapez.com/houzz/public/">Houzz.pk</a> All Rights Reserved</p>
              </div>
              <div class="footer-copyright">
                <p>Powered By <a href="https://greengrapez.com/"><img src="<?php echo e(url('/')); ?>/pic/greengrapez.png" alt="Green Grapez"></a></p>
              </div>
              <!--Footer Copyright End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Footer Bottom Area End--> 
    </div>
  </footer>
  <!--Footer Area End--> 
</div>
<!--All Js Here--> 

<!--Jquery 1.12.4--> 
<script src="<?php echo e(url('/')); ?>/js1/vendor/jquery-1.12.4.min.js"></script> 
<!--Popper--> 
<script src="<?php echo e(url('/')); ?>/js1/popper.min.js"></script> 
<!--Bootstrap--> 
<script src="<?php echo e(url('/')); ?>/js1/bootstrap.min.js"></script> 
<!--Imagesloaded--> 
<script src="<?php echo e(url('/')); ?>/js1/imagesloaded.pkgd.min.js"></script> 
<!--Isotope--> 
<script src="<?php echo e(url('/')); ?>/js1/isotope.pkgd.min.js"></script> 
<!--Waypoints--> 
<script src="<?php echo e(url('/')); ?>/js1/waypoints.min.js"></script> 
<!--Counterup--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.counterup.min.js"></script> 
<!--Carousel--> 
<script src="<?php echo e(url('/')); ?>/js1/owl.carousel.min.js"></script> 
<!--Slick--> 
<script src="<?php echo e(url('/')); ?>/js1/slick.min.js"></script> 
<!--Meanmenu--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.meanmenu.min.js"></script> 
<!--Easyzoom--> 
<!--ScrollUp--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.scrollUp.min.js"></script> 
<!--Wow--> 
<script src="<?php echo e(url('/')); ?>/js1/wow.min.js"></script> 
<!--Venobox--> 
<script src="<?php echo e(url('/')); ?>/js1/venobox.min.js"></script> 
<!--Jquery Ui--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery-ui.js"></script> 
<!--Countdown--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.countdown.min.js"></script> 
<!--Plugins--> 
<script src="<?php echo e(url('/')); ?>/js1/plugins.js"></script> 
<!--Main Js--> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script> 
 <script src="http://js-vans.jet.com.br/jquery.colorbox-min.js"> </script>
<script src="<?php echo e(url('/')); ?>/js1/main.js"></script> 
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//geodata.solutions/includes/countrystatecity.js"></script>

<script>
$('#myForm').on('submit', function(e){
  $('#formmodel').modal('show');
  e.preventDefault();
});
</script>
<script type="text/javascript">
      $("#style").on('change',function(e){

        console.log(e);

        var cat_id =  e.target.value;


        $.get('<?php echo e(URL('/')); ?>/style?cat_id='+ cat_id,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('');

          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<div class="col-md-3" style="float:left;"><div class="single-product mb-25"><div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'"> <img src="<?php echo e(URL('/')); ?>/storage/images/'+subcatObj.thumbnail+'" alt="" style=" position: relative;"> </a><div class="product-action"><ul><li><a href="#open-modal'+subcatObj.pk_id+'" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li></ul></div></div><div class="product-content"><h2>'+subcatObj.name+'</h2><p>PKR '+subcatObj.price+'</p><div class="product-price"><div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/'+subcatObj.pk_id+'" class="wishlist-btn mt-10">Add to Wishlist</a> </div></div></div></div></div>');
        });



        });


    });

  </script>
  
<script type="text/javascript">
      $("#brand").on('change',function(e){

        console.log(e);


        var cat_id =  e.target.value;


        $.get('<?php echo e(URL('/')); ?>/brand?cat_id='+ cat_id,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('');

          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<div class="col-md-3" style="float:left;"><div class="single-product mb-25"><div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'"> <img src="<?php echo e(URL('/')); ?>/storage/images/'+subcatObj.thumbnail+'" alt="" style=" position: relative;"> </a><div class="product-action"><ul><li><a href="#open-modal'+subcatObj.pk_id+'" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li></ul></div></div><div class="product-content"><h2>'+subcatObj.name+'</h2><p>PKR '+subcatObj.price+'</p><div class="product-price"><div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/'+subcatObj.pk_id+'" class="wishlist-btn mt-10">Add to Wishlist</a> </div></div></div></div></div>');
        });



        });


    });

  </script>
  
  
<script type="text/javascript">
      $("#material").on('change',function(e){

        console.log(e);


        var cat_id =  e.target.value;

// alert(cat_id);

        $.get('<?php echo e(URL('/')); ?>/material?cat_id='+ cat_id,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('');

          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<div class="col-md-3" style="float:left;"><div class="single-product mb-25"><div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'"> <img src="<?php echo e(URL('/')); ?>/storage/images/'+subcatObj.thumbnail+'" alt="" style=" position: relative;"> </a><div class="product-action"><ul><li><a href="#open-modal'+subcatObj.pk_id+'" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li></ul></div></div><div class="product-content"><h2>'+subcatObj.name+'</h2><p>PKR '+subcatObj.price+'</p><div class="product-price"><div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/'+subcatObj.pk_id+'" class="wishlist-btn mt-10">Add to Wishlist</a> </div></div></div></div></div>');
        });



        });


    });

  </script>
  
  
<script type="text/javascript">
      $("#price").on('change',function(e){

        console.log(e);


        var cat_id =  e.target.value;
        var sub = $('.m').val();


        $.get('<?php echo e(URL('/')); ?>/price?cat_id='+ cat_id+'&sub='+sub,function(data){
          console.log(data);
          $('#subCategory').empty();
          $('#subCategory').append('');

          $.each(data,function(create,subcatObj){

            $('#subCategory').append('<div class="col-md-3" style="float:left;"><div class="single-product mb-25"><div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'"> <img src="<?php echo e(URL('/')); ?>/storage/images/'+subcatObj.thumbnail+'" alt="" style=" position: relative;"> </a><div class="product-action"><ul><li><a href="#open-modal'+subcatObj.pk_id+'" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li></ul></div></div><div class="product-content"><h2>'+subcatObj.name+'</h2><p>PKR '+subcatObj.price+'</p><div class="product-price"><div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/'+subcatObj.pk_id+'/'+subcatObj.sku+'" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/'+subcatObj.pk_id+'" class="wishlist-btn mt-10">Add to Wishlist</a> </div></div></div></div></div>');
        });



        });


    });

  </script>

<script>

var button = $(".click"),
		message = $(".message"),
		open = false;

button.on("click touchstart", function(e) {
	e.preventDefault();
	
	// if opened is true, then we will want to close
	// the overlay as it will mean its already visible.
	if (open){
		open = false;
		message.removeClass("is-open");
	} 
	// if false, then we want to open the overlay
	// so we set open equal to true. 
	else{
		open = true;
		message.addClass("is-open");
		console.log(open);
	}
	
});

function show1(){
      document.getElementById('div1').style.display ='none';
       $("#div1 input[type=text]").val('');
       $("#div1 input[type=tel]").val('');
    }
    function show2(){
      document.getElementById('div1').style.display = 'block';
    }
 var countChecked = function () {
    var n = $("input:checked").length;
    if (n >= 1) {
        $("#selected-toolbar").css({
            "display": "block"
        });
    } else {
        $("#selected-toolbar").css({
            "display": "none"
        });
    }
};
countChecked();

$("input[type=checkbox]").on("click", countChecked);

$(document).ready(function() {
   $('.js-example-basic-multiple').select2();
});

function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
<script>
$("[data-toggle='tab']").click(function () {
  var tabs = $(this).attr('data-tabs');
  var tab = $(this).attr("data-tab");
  $(tabs).find(".gtab").removeClass("active");
  $(tabs).find(tab).addClass("active");
});
</script>

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e5bdb3ea89cda5a1888bfd2/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

</body>
</html>
<?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/layout/appclient.blade.php ENDPATH**/ ?>