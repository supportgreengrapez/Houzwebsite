<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Houzz">
<meta name="keywords" content="HTML,CSS,XML,JavaScript">
<meta name="author" content="Houzz"><link rel="shortcut icon" href="<?php echo e(url('/')); ?>/images/favicon.png"/>
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<title>Houzz</title>

<!-- Bootstrap -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(url('/')); ?>/css/font-awesome.min.css" rel="stylesheet">
<!-- bootstrap-progressbar -->
<link href="<?php echo e(url('/')); ?>/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(url('/')); ?>/css/green.css" rel="stylesheet">
<!-- Custom Theme Style -->
<link href="<?php echo e(url('/')); ?>/css/custom.min.css" rel="stylesheet">
<link href="<?php echo e(url('/')); ?>/css/style.css" rel="stylesheet">
<script src='//production-assets.codepen.io/assets/editor/live/console_runner-079c09a0e3b9ff743e39ee2d5637b9216b3545af0de366d4b9aad9dc87e26bfd.js'></script><script src='//production-assets.codepen.io/assets/editor/live/events_runner-73716630c22bbc8cff4bd0f07b135f00a0bdc5d14629260c3ec49e5606f98fdd.js'></script><script src='//production-assets.codepen.io/assets/editor/live/css_live_reload_init-2c0dc5167d60a5af3ee189d570b1835129687ea2a61bee3513dee3a50c115a77.js'></script>
<link rel="canonical" href="https://codepen.io/emilcarlsson/pen/ZOQZaV?limit=all&page=74&q=contact+" />
<script src="https://use.typekit.net/hoy3lrg.js"></script>
<script>try{Typekit.load({ async: true });}catch(e){}</script>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.2/css/font-awesome.min.css'>
<link href="<?php echo e(url('/')); ?>/css/chat.css" type="text/css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;"> <a href="index.html" class="site_title"><span><img src="images/vendorprofile.png" class="img-circle" alt="logo"></span></a> </div>
        <div class="clearfix"></div>
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
          <div class="menu_section">
            <ul class="nav side-menu">
            <?php if(Session::get('subscription') == 1): ?>
              <li><a href="index.html"><i class="fa fa-tachometer"></i> Home </a> </li>
            
              <?php if(!empty(Session::get('package')[0]->no_of_product)): ?>
              <li><a><i class="fa fa-table"></i> Product Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/add/product">Add Product</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/product">View Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/vendor/collection/list/view">Manage Collections</a></li>
                  <li><a href="#">Import New Products</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/cancel/product">Cancel Products</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/pending/product">Pending Products</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/approved/product">Approved Products</a></li>
                </ul>
              </li>
              <?php endif; ?>
              <li><a><i class="fa fa-file"></i> Reporting <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/reporting/by/products">By Product</a></li>
                  <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/reporting/by/sale">By Sales</a></li>

                </ul>
              </li>
          
              <li><a><i class="fa fa-table"></i> Order Management <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/active/orders">Manage Orders</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/commission/invoice">Commission Invoice</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/subscription/invoice">Subscription Invoice</a></li>
                </ul>
              </li>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/return/orders"><i class="fa fa-exchange"></i> Returns </a> </li>
              <?php if(Session::get('package')[0]->promotion == 1): ?>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/discount"><i class="fa fa-square"></i> Promotions </a> </li>
<?php endif; ?>

              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/rating"><i class="fa fa-star"></i> Rating & Review </a> </li>
              <?php if(Session::get('package')[0]->client == 1): ?>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/offline/client"><i class="fa fa-user"></i> Client Management </a> </li>
<?php endif; ?>

              <li><a><i class="fa fa-cog"></i>Settings <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/bank/account">Bank Account</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/edit/seller/info">Seller Info</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/edit/notification">Notifications</a></li>
                </ul>
              </li>
              <li><a href="resources.html"><i class="fa fa-th"></i> Resources </a> </li>
<?php endif; ?>
              <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/package"> <i class="fa fa-cubes"></i>  Packages </a> </li>
              <li><a><i class="fa fa-money"></i> Payments <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/payment/invoice">View Payments</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/submit/payment/invoice">Submitted</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/approved/payment/invoice">Approved</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/pending/payment/invoice">Pending</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/rejected/payment/invoice">Rejected</a></li>
                </ul>
              </li>
              <li><a><i class="fa fa-table"></i> Invoices <span class="fa fa-chevron-down"></span></a>
                <ul class="nav child_menu">
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/submit/package/invoice">Submitted</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/approved/package/invoice">Approved</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/pending/package/invoice">Pending</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/home/view/rejected/package/invoice">Rejected</a></li>
                </ul>
              </li>
              
              <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/message"><i class="fa fa-tachometer"></i> Message </a> </li>
              <li><a href="<?php echo e(URL('/')); ?>/vendor/home/view/chat"><i class="fa fa-tachometer"></i> Chat System </a> </li>
            
            </ul>
          </div>
        </div>
        <!-- /sidebar menu -->
      </div>
    </div>
    
    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav>
          <div class="nav toggle"> <a id="menu_toggle"><i class="fa fa-bars"></i></a> </div>
          <ul class="nav navbar-nav navbar-right">
            <li class=""> <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="images/vendorprofile.png" alt="">Vendor <span class=" fa fa-angle-down"></span> </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">
                <li><a href="javascript:;"> Profile</a></li>
                <li><a href="login.html"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation --> 
    
    <!-- page content -->
    <div class="right_col" role="main">
      <div class="row"> 
            <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_content">
          <div id="frame">
            <div id="sidepanel">
              <div id="profile">
                <div class="wrap"> <img id="profile-img" src="http://emilcarlsson.se/assets/mikeross.png" alt="" />
                  <p>Fahad Maqsood</p>
                </div>
              </div>
              <div id="search">
                <label for=""><i class="fa fa-search" aria-hidden="true"></i></label>
                <input type="text" placeholder="Search contacts..." />
              </div>
              <div id="contacts">
                <ul>
                  <li class="contact">
                    <div class="wrap"><img src="http://emilcarlsson.se/assets/louislitt.png" alt="" />
                      <div class="meta">
                        <p class="name">Faizan Rasool</p>
                        <p class="preview">You just got LITT up, Mike.</p>
                      </div>
                    </div>
                  </li>
                  <li class="contact active">
                    <div class="wrap"><img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                      <div class="meta">
                        <p class="name">Kiran Riaz</p>
                        <p class="preview">Wrong. You take the gun, or you pull out a bigger one. Or, you call their bluff. Or, you do any one of a hundred and forty six other things.</p>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="content">
              <div class="contact-profile"> <img src="http://emilcarlsson.se/assets/harveyspecter.png" alt="" />
                <p>Kiran Riaz</p>
              </div>
              <div class="messages">
                <ul>
                  <li class="sent">
                    <p>How the hell am I supposed to get a jury to believe you when I am not even sure that I do?!</p>
                  </li>
                  <li class="replies">
                    <p>When you"re backed against the wall, break the god damn thing down.</p>
                  </li>
                </ul>
              </div>
              <div class="message-input">
                <div class="wrap">
                  <input type="text" placeholder="Write your message..." />
                  <i class="fa fa-paperclip attachment" aria-hidden="true"></i>
                  <button class="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
            </div>
    </div>
    <!-- /page content --> 
    
    <!-- footer content -->
    <footer>
      <div class="pull-right"> Copyright © 2017-2018 Houzz. All rights reserved. </div>
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content --> 
  </div>
</div> 

<!-- jQuery -->
<script src="<?php echo e(url('/')); ?>/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap.min.js"></script>
<!-- DateJS -->
<script src="<?php echo e(url('/')); ?>/js/build/date.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo e(url('/')); ?>/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo e(url('/')); ?>/js/icheck.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo e(url('/')); ?>/js/moment.min.js"></script>
<script src="<?php echo e(url('/')); ?>/js/daterangepicker.js"></script>
<script src="<?php echo e(url('/')); ?>/js/custom.min.js"></script>


<script src='//production-assets.codepen.io/assets/common/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js'></script><script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
 
<script >$(".messages").animate({ scrollTop: $(document).height() }, "fast");

function newMessage() {
	message = $(".message-input input").val();
	if($.trim(message) == '') {
		return false;
	}
	$('<li class="sent"><p>' + message + '</p></li>').appendTo($('.messages ul'));
	$('.message-input input').val(null);
	$('.contact.active .preview').html('<span>You: </span>' + message);
	$(".messages").animate({ scrollTop: $(document).height() }, "fast");
};

$('.submit').click(function() {
  newMessage();
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
    newMessage();
    return false;
  }
});
</script>
</body>
</html>
<?php /**PATH F:\xamp\htdocs\houzz\resources\views/vendor/chat-system.blade.php ENDPATH**/ ?>