<?php $__env->startSection('content'); ?>
<form method="post" action = "<?php echo e(url('/')); ?>/admin/add/slider" class="login-form" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php if($errors->any()): ?>
  <div class="alert alert-danger"> <strong>Danger!</strong> <?php echo e($errors->first()); ?> </div>
  <?php endif; ?> 
  <!-- page content -->
  <div class="right_col" role="main">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Product Management</h3>
          <h4 style="display: block;">Add Image Slider</h4>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">

      <div class="col-md-6 col-sm-12 col-xs-12">
      <div class="form-group">
                        <label>Category Name</label>
                        <select class="form-control" name="main_category">
                        <?php if(count($result)>0): ?>
                      <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<option value="<?php echo e($results->main_category); ?>"><?php echo e($results->main_category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
                        </select>
                      </div>
                      </div>
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_content">
            <div class="row">
              <div class="page-title">
                <h5><b>Images</b></h5>
              </div>
              <div class="col-lg-12">
                <div class="alert alert-info"> <strong>Info!</strong> Please Upload 500*500 pixel image. </div>
                <div class="row">
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="file" class="form-control" onchange="readURL(this);"/>
                    <img id="blah" src="images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images2" class="form-control" onchange="preview_image(this);"/>
                    <img id="blah2" src="images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                  <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images3" class="form-control" onchange="preview_img(this);"/>
                    <img id="blah3" src="images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                    <div class="form-group col-lg-4 col-sm-12 col-md-4">
                    <input type="file" name="images4" class="form-control" onchange="preview_imgs(this);"/>
                    <img id="blah4" src="images/demo.png" alt="Product Image" style="width:350px; height:300px;" /> </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="divider"></div>
            </div>
            <div class="col-md-6 pull-right">
              <button id="send" type="submit" class="btn btn-success btn-lg pull-right">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content -->
</form>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/admin/create_image_slider.blade.php ENDPATH**/ ?>