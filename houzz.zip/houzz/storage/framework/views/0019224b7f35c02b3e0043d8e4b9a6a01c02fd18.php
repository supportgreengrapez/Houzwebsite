<!doctype html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Houzz</title>
<meta name="description" content="">
<meta name="robots" content="noindex, follow" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, follow"/>
<!-- Place favicon.ico in the root directory -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('/')); ?>/pic/favicon.png">
<!--All Css Here-->

<!-- Bootstrap CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/bootstrap.min.css">
<!-- Linearicon CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/linearicons.min.css">
<!-- Font Awesome CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/font-awesome.min.css">

<!-- Animate CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/animate.css">
<!-- Owl Carousel CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/owl.carousel.min.css">
<!-- Slick CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/slick.css">
<!-- Meanmenu CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/meanmenu.min.css">
<!-- Venobox CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/venobox.css">
<!-- Jquery Ui CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/jquery-ui.css">
<!-- Easyzoom CSS-->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/easyzoom.css">
<!-- Style CSS -->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="<?php echo e(URL('/')); ?>/css1/responsive.css">
<!-- Modernizr Js -->
<script src="<?php echo e(url('/')); ?>/js1/vendor/modernizr-2.8.3.min.js"></script>
<style>
.message {
	display: none;
}
.message.is-open {
	display: block;
}
.click {
	display: inline-block;
	color: #689a29;
}
.img-ful img {
	width: 60%;
}
button[disabled="disabled"]{
    background:grey;
    cursor: not-allowed;
}
</style>
</head>
<div class="wrapper"> 
  <!--Header Area Start-->
  <header>
    <div class="header-container"> 
      <!--Header Top Area Start-->
      <div class="header-top-area black-bg">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-md-8"> 
              <!--Header Top Left Start-->
              <div class="header-top-left">
                <div class="header-top-language-currency">
                  <div class="switcher">
                    <p>Free Deliver <strong style="color:#689a29;">Applies on more then 50$ and return is always free</strong> </p>
                  </div>
                </div>
              </div>
              <!--Header Top Left End--> 
            </div>
            <div class="col-lg-4 col-md-4"> 
              <!--Header Top Right Start-->
              <div class="header-top-right">
                <ul class="menu-top-menu text-md-right">
                  <li><a href=""><i class="fa fa-facebook"></i></a></li>
                  <li><a href=""><i class="fa fa-twitter"></i></a></li>
                  <li><a href=""><i class="fa fa-instagram"></i></a></li>
                </ul>
              </div>
              <!--Header Top Right End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Header Top Area End--> 
      <!--Header Middle Area Start-->
      <div class="header-middle-area">
        <div class="container">
          <div class="row">
            <div class="col-xl-2 col-lg-3 col-md-4"> 
              <!--Header Logo Start-->
              <div class="header-logo"> <a href="<?php echo e(url('/')); ?>/"><img src="<?php echo e(url('/')); ?>/pic/logo.png" alt=""></a> </div>
              <!--Header Logo End--> 
            </div>
            <div class="col-xl-3 col-lg-3 col-md-10"> 
              <!--Header Search Area-->
              <div class="header-search-area">
                <form  role="form" action="<?php echo e(url('/')); ?>/search" method="post" id="payment-form">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-input">
                    <input name="search" id="search" placeholder="Search ...." type="text" required>
                    <button type="submit" class="header-search-btn"><i class="fa fa-search"></i></button>
                  </div>
                </form>
              </div>
              <!--Header Search Area--> 
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4">
              <div class="header-top-right">
                <ul class="nav justify-content-center">
                  <li class="nav-item"> <a class="nav-link" href="#">Forums</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="#">Maps</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/blog">Blog</a> </li>
                </ul>
              </div>
            </div>
            <div class="col-xl-2 col-lg-3 col-md-4">
              <div class="mini-cart"> <a href="#"> <span class="cart-icon"> <span class="cart-quantity"><?php echo e(Session::has('cart') ? Session::get('cart')->totalQty : '0'); ?></span> </span> <span class="cart-title">Your cart <br>
                <strong>PKR <?php echo e(number_format($totalPrice)); ?></strong></span> </a> 
                <!--Cart Dropdown Start--> 
                <?php if(Session::has('cart')): ?>
                <div class="cart-dropdown">
                  <ul>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="single-cart-item">
                      <div class="cart-img"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($product['item']->thumbnail); ?>" alt=""> </div>
                      <div class="cart-content">
                        <h5 class="product-name"><?php echo e($product['item']->name); ?></h5>
                        <span class="cart-price"><?php echo e($product['qty']); ?> × PKR <?php echo e(number_format($product['item']->price)); ?>

                        <?php if($product['save']>0): ?> saving -<?php echo e($product['save']); ?><?php endif; ?></span> </div>
                      <div class="cart-remove"> <a title="Remove" href="<?php echo e(URL('/')); ?>/remove/item/cart/<?php echo e($product['item']->pk_id); ?>/<?php echo e($product['size']); ?>/<?php echo e($product['qty']); ?>/<?php echo e($product['delivery_charges']); ?>"><i class="fa fa-times"></i></a> </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <p class="cart-subtotal"><strong>Subtotal:</strong> <span class="float-right">PKR <?php echo e(number_format($totalPrice)); ?></span></p>
                  <p class="cart-btn"> <a href="<?php echo e(url('/')); ?>/cart">View cart</a> <a href="<?php echo e(url('/')); ?>/cart/checkout">Checkout</a> </p>
                </div>
                <?php endif; ?> 
                <!--Cart Dropdown End--> 
              </div>
            </div>
            
            <div class="col-xl-2 col-lg-3 col-md-4">
                
                <?php if(Session::has('username')): ?> 
                        
                                <div class="currency-box"> <a href="#"><img src="<?php echo e(url('/')); ?>/pic/icon.png" alt="icon"> <?php echo e(session::get('name')); ?> </a>
                                  <div class="currency-dropdown">
                                    <ul class="menu-top-menu">
                                      <li><a href="<?php echo e(URL('/')); ?>/order/tracking/view">Order Tracking</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/client/payment/list/view/<?php echo e(session::get('pk_id')); ?>">Payment List</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/realtor/dashboard">Switch to My Account</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/client/send/message">Compose Message</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/client/chat/<?php echo e(session::get('pk_id')); ?>">Chat</a></li>
                                      <li><a href="<?php echo e(URL('/')); ?>/logout">Logout</a></li>
                                    </ul>
                                  </div>
                                </div>
                        <?php else: ?>
                        <div class="header-top-right">
                <ul class="nav justify-content-center">
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/login">Login</a> </li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/')); ?>/signup">Signin</a> </li>
                </ul>
              </div>
                        <?php endif; ?>
              
            </div>
          </div>
        </div>
      </div>
      <!--Header Middle Area End--> 
      <!--Header Bottom Area Start-->
      <div class="header-bottom-area header-sticky">
        <div class="header-boxshadow">
          <div class="header-inner">
            <div class="container">
              <div class="row">
                <div class="col-12"> 
                  <!--Logo Sticky Start-->
                  <div class="logo-sticky"> <a href="<?php echo e(url('/')); ?>/"><img src="<?php echo e(url('/')); ?>/pic/logo2.png" alt=""></a> </div>
                  <!--Logo Sticky End--> 
                  <!--Main Menu Area Start-->
                  <div class="header-menu text-center">
                    <nav>
                      <ul class="main-menu">
                        <li><a href="<?php echo e(url('/')); ?>/">home</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/shop">Shop</a>
                            <!--Mega Menu Start-->
                            <ul class="mega-menu">
                                <?php
                                $Furniture = DB::select("select* from sub_category where main_category = 'Furniture' LIMIT 5");
                                $Kitchen= DB::select("select* from sub_category where main_category = 'Kitchen and Dining' LIMIT 5");
                                $Bath= DB::select("select* from sub_category where main_category = 'Bath' LIMIT 5");
                                $Lighting= DB::select("select* from sub_category where main_category = 'Lighting' LIMIT 5");
                                $Outdoor= DB::select("select* from sub_category where main_category = 'Outdoor' LIMIT 5");
                                $Bedroom= DB::select("select* from sub_category where main_category = 'Bedroom' LIMIT 5");
                                $Living= DB::select("select* from sub_category where main_category = 'Living' LIMIT 5");
                                $Home= DB::select("select* from sub_category where main_category = 'Home Decor' LIMIT 5");
                                ?>
                                
                                <?php if(count($Furniture)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Furniture[0]->main_category); ?>" class="item-link"><?php echo e($Furniture[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Furniture[0]->main_category); ?>" style="color:green">See All</a></li>
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                
                                
                                <?php if(count($Bath)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bath[0]->main_category); ?>" class="item-link"><?php echo e($Bath[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Bath; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bath[0]->main_category); ?>" style="color:green">See All</a></li>
                                    
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Lighting)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Lighting[0]->main_category); ?>" class="item-link"><?php echo e($Lighting[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Lighting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Lighting[0]->main_category); ?>" style="color:green">See All</a></li>
                                  
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Outdoor)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Outdoor[0]->main_category); ?>" class="item-link"><?php echo e($Outdoor[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Outdoor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Outdoor[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Bedroom)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bedroom[0]->main_category); ?>" class="item-link"><?php echo e($Bedroom[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Bedroom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Bedroom[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Living)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Living[0]->main_category); ?>" class="item-link"><?php echo e($Living[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Living; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Living[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Kitchen)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Kitchen[0]->main_category); ?>" class="item-link"><?php echo e($Kitchen[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Kitchen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Kitchen[0]->main_category); ?>" style="color:green">See All</a></li>
                                 
                                    </ul>
                                </li>
                                <?php endif; ?>
                                
                                <?php if(count($Home)>0): ?>
                                <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($Home[0]->main_category); ?>" class="item-link"><?php echo e($Home[0]->main_category); ?></a>
                                    <ul>
                                        
                                <?php $__currentLoopData = $Home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($results->main_category); ?>/<?php echo e($results->sub_category); ?>"><?php echo e($results->sub_category); ?></a></li>
                                        
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(URL('/')); ?>/shop" style="color:green">See All</a></li>
                                    </ul>
                                </li>
                                <?php endif; ?>
                            </ul>
                            <!--Mega Menu End-->
                        </li>
                        <li><a href="<?php echo e(url('/')); ?>/sale/view">Sale</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/seller/list/view">Seller</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/properties">Properties</a></li>
                        <li><a href="<?php echo e(url('/')); ?>/collection">Collections</a></li>
                        
                      </ul>
                    </nav>
                  </div>
                  <!--Main Menu Area End--> 
                </div>
              </div>
              <div class="row">
                <div class="col-12"> 
                  <!--Mobile Menu Area Start-->
                  <div class="mobile-menu d-lg-none"></div>
                  <!--Mobile Menu Area End--> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--Header Bottom Area End--> 
    </div>
  </header>
  <!--Header Area End--> 
<!--Breadcrumb One Start-->
<div class="container-fluid">
  <div class="breadcrumb-content breadcrumb-content-tow mt-20 mb-20">
    <ul>
      <?php if(count($result)>0): ?>
      <li><a href="<?php echo e(URL('/')); ?>/">Home</a></li>
      <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($result[0]->category); ?>"><?php echo e($result[0]->category); ?></a></li>
      <li><a href="<?php echo e(URL('/')); ?>/product/<?php echo e($result[0]->category); ?>/<?php echo e($result[0]->sub_category); ?>"><?php echo e($result[0]->sub_category); ?></a></li>
      <li class="active"><?php echo e($result[0]->product_type); ?></li>
      <?php endif; ?>
    </ul>
  </div>
</div>
<!--Breadcrumb One End--> 
<?php if(count($result)>0): ?> 
<!--Single Product Area Start-->
<div class="single-product-area mb-20">
  <div class="container"> 
    
    <?php if( Session::has('modal_message')): ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.hide').css({display: 'block'});
        });
    </script>
    <div class="hide">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h3>Notification: Please read</h3>
        </div>
        <div class="modal-body">
            <p>
                <?php echo e(Session::get('modal_message')); ?>

            </p>
        </div>
        <div class="modal-footer">
            <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        </div>
    </div>
<?php endif; ?>
    <div class="row">
      <div class="col-md-7 col-lg-7 col-sm-12 col-xs-12">
        <div class="product-details-img-tab"> 
          <!--Product Tab Content Start-->
          <div class="tab-content single-product-img">
            <div class="tab-pane fade show active" id="product1">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
            <div class="tab-pane fade" id="product2">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail2); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail2); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail2); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
            <div class="tab-pane fade" id="product3">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail3); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail3); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail3); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
            <div class="tab-pane fade" id="product4">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail4); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail4); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail4); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
            <div class="tab-pane fade" id="product5">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail5); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail5); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail5); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
            <div class="tab-pane fade" id="product6">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail6); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail6); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail6); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
            <div class="tab-pane fade" id="product7">
              <div class="product-large-thumb img-ful">
                <div class="easyzoom easyzoom--overlay"> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail7); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail7); ?>" alt=""> </a> <a href="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail7); ?>" class="popup-img venobox" data-gall="myGallery"><i class="fa fa-search"></i></a> </div>
              </div>
            </div>
          </div>
          <!--Product Tab Content End--> 
          <!--Product Tab Menu Start-->
          <div class="product-menu">
            <div class="nav product-tab-menu">
              <div class="product-details-img"> <a class="active" data-toggle="tab" href="#product1"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" alt=""></a> </div>
              <div class="product-details-img"> <a data-toggle="tab" href="#product2"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail2); ?>" alt=""></a> </div>
              <div class="product-details-img"> <a data-toggle="tab" href="#product3"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail3); ?>" alt=""></a> </div>
              <div class="product-details-img"> <a data-toggle="tab" href="#product4"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail4); ?>" alt=""></a> </div>
              <div class="product-details-img"> <a data-toggle="tab" href="#product5"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail5); ?>" alt=""></a> </div>
              <div class="product-details-img"> <a data-toggle="tab" href="#product6"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail6); ?>" alt=""></a> </div>
              <div class="product-details-img"> <a data-toggle="tab" href="#product7"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail7); ?>" alt=""></a> </div>
            </div>
          </div>
          <!--Product Tab Menu End--> 
        </div>
        <!--Product Description Review Area Start-->
        <div class="product-description-review-area mb-20 mt-20">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <div class="product-review-tab"> 
                  <!--Review And Description Tab Menu Start-->
                  <ul class="nav dec-and-review-menu">
                    <li> <a class="active" data-toggle="tab" href="#description">Description</a> </li>
                    <li> <a data-toggle="tab" href="#reviews">Product Specification</a> </li>
                    <li> <a data-toggle="tab" href="#ship">Shipment and Return</a> </li>
                  </ul>
                  <!--Review And Description Tab Menu End--> 
                  <!--Review And Description Tab Content Start-->
                  <div class="tab-content product-review-content-tab" id="myTabContent-4">
                    <div class="tab-pane fade active show" id="description">
                      <div class="single-product-description">
                        <p><?php echo e($result[0]->description); ?></p>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="reviews">
                      <div class="review-page-comment">
                        <p><?php echo e($result[0]->material); ?> <br>
                          <?php echo e($result[0]->style); ?></p>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="ship">
                      <div class="single-product-description">
                        <p><?php echo e($result[0]->return_policy); ?></p>
                      </div>
                    </div>
                  </div>
                  <!--Review And Description Tab Content End--> 
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--Product Description Review Area Start--> 
      </div>
      <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12"> 
        <!--Product Details Content Start-->
        <form method="post" action ="<?php echo e(url('/')); ?>/product/add/cart/<?php echo e($result[0]->pk_id); ?>" enctype="multipart/form-data" >
          <?php echo e(csrf_field()); ?>

          <div class="product-details-content">
            <h2><?php echo e($result[0]->name); ?></h2>
            <h4>By <?php echo e($result[0]->brand_name); ?></h4>
            <div class="rating" style="float:none;">
              <div class="stars"> <?php
                
                $star = 5 - $average;
                ?>
                <?php for($i = 0; $i<$average; $i++): ?>
                 <span class="fa fa-star checked"></span> <?php endfor; ?>
                <?php for($i = 0; $i<$star; $i++): ?>
                  <span class="fa fa-star" style="color:lightgrey"></span> <?php endfor; ?> <span class="review-no"><?php echo e(count($review)); ?> reviews</span> </div>
            </div>
            <?php if(count($d)>0): ?>
            <div class="single-product-price"> <span class="price new-price">PKR <?php echo e($d[0]->price); ?>  Off <?php echo e($d[0]->percentage); ?>%</span> <span class="regular-price">
              <h2 style="color:#689a29">PKR <?php echo e(number_format($discount_price)); ?></h2>
              </span> </div>
            <?php elseif(count($result)>0): ?>
            <div class="single-product-price"> <span  class="regular-price">
              <h2 style="color:#689a29">PKR <?php echo e(number_format($result[0]->price)); ?></h2>
              </span> </div>
            <?php endif; ?>
            <p class="stock in-stock"><span id="stock"></span> <span class="label-success label" id="myspan">In Stock</span></p>
            <div class="single-product-quantity">
              <div class="mb-10">
                <lable>Color</lable>
                <div class="color-choose"> <?php if(count($result1)>0): ?>
                  <?php $__currentLoopData = $result1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>">
                  <input id="black" type="button" name="color">
                  <label><span style="background-color:<?php echo e($results->color); ?> "></span></label>
                  </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?> </div>
              </div>
              <div class="mb-10">
                <lable>Size</lable>
                 <select class="form-control col-4" name="size" id="size" required>
                <option value="">---Select Size---</option>
                
                
                	<?php if(count($array)>0): ?>
							<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arrays): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                
                <option value="<?php echo e($arrays->pk_id); ?>"><?php echo e($arrays->size); ?></option>
                
                
            		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
       
            
              
              </select>
              </div>
              <div class="form-group">
                <div class="form-check">
                  <label>
                    <input type="radio" name="tab" value="Free Delivery" checked>
                    <span class="label-text">Free Delivery in days <strong><?php echo e($result[0]->free_delivery); ?> days</strong> </span> <a href="#" class="click">Write click here for more shipment options</a></label>
                </div>
              </div>
            </div>
            <div class="product-quantity">
              <input name="quantity" value="1" type="number" id="myInput">
            </div>
            <div class="add-to-link">
              <button type="submit" class="product-btn" id="cartbtn" >add to cart</button>
            </div>
            <div class="message single-product-quantity">
              <div class="form-group">
                <div class="form-check">
                  <label>
                    <input type="radio" name="tab" value="Urgent Delivery">
                    <span class="label-text">Urgent Delivery PKR <?php echo e($result[0]->urgent_charges); ?> in <strong><?php echo e($result[0]->urgent_time); ?> days</strong> </span> </label>
                </div>
                <div class="form-check">
                  <label>
                    <input type="radio" name="tab" value="Express Delivery">
                    <span class="label-text">Express Delivery PKR <?php echo e($result[0]->express_charges); ?> in <strong><?php echo e($result[0]->express_time); ?> days</strong> </span> </label>
                </div>
                <div class="form-check">
                  <label>
                    <input type="radio" name="tab" value="Normal Delivery" >
                    <span class="label-text">Normal Delivery PKR <?php echo e($result[0]->normal_charges); ?> in <strong><?php echo e($result[0]->normal_time); ?> days</strong> </span> </label>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
      <!--Product Details Content End--> 
    </div>
  </div>
</div>
<!--Single Product Area End--> 
<?php endif; ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-12">
      <div class="section-title text-center mb-20 mt-30"> <span>
        <h3>Related Products</h3>
        </span> </div>
    </div>
  </div>
</div>
<div class="home-product-layout-area mt-20">
  <div class="container-fluid">
    <div class="row"> <?php if(count($related)>0): ?>
      <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3"> 
        <!--Single Product Start-->
        <div class="single-product mb-25">
          <div class="product-img img-full img-size"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="img" style=" position: relative;"> </a>
            <div class="product-action">
              <ul>
                <li><a href="#open-modal<?php echo e($results->pk_id); ?>" data-toggle="modal" title="Quick view"><i class="fa fa-search"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="product-content">
            <h2><a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>"><?php echo e($results->name); ?></a></h2>
            <p>PKR <?php echo e(number_format($results->price)); ?></p>
            <div class="product-price">
              <div class="wishlist-compare-btn"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" class="add-btn">add to cart</a> <a href="<?php echo e(URL('/')); ?>/product/add/wishlist/<?php echo e($results->pk_id); ?>" class="wishlist-btn mt-10">Add to Wishlist</a> </div>
            </div>
          </div>
        </div>
        <!--Single Product End--> 
      </div>
      <!-- Modal Area Strat -->
      <form method="post" action = "<?php echo e(url('/')); ?>/product/add/cart/<?php echo e($results->pk_id); ?>">
        <?php echo e(csrf_field()); ?>

        <div class="modal fade" id="open-modal<?php echo e($results->pk_id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
              </div>
              <div class="modal-body">
                <div class="row"> 
                  <!--Modal Img-->
                  <div class="col-md-7 col-xs-12 col-sm-12"> 
                    <!--Modal Tab Content Start-->
                    <div class="tab-content product-details-large" id="myTabContent">
                      <div class="tab-pane fade show active" id="single-slide1" role="tabpanel" aria-labelledby="single-slide-tab-1"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                      <div class="tab-pane fade" id="single-slide2" role="tabpanel" aria-labelledby="single-slide-tab-2"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail2); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                      <div class="tab-pane fade" id="single-slide3" role="tabpanel" aria-labelledby="single-slide-tab-3"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail3); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                      <div class="tab-pane fade" id="single-slide4" role="tabpanel" aria-labelledby="single-slide-tab-4"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail4); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                      <div class="tab-pane fade" id="single-slide5" role="tabpanel" aria-labelledby="single-slide-tab-5"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail5); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                      <div class="tab-pane fade" id="single-slide6" role="tabpanel" aria-labelledby="single-slide-tab-6"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail6); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                      <div class="tab-pane fade" id="single-slide7" role="tabpanel" aria-labelledby="single-slide-tab-7"> 
                        <!--Single Product Image Start-->
                        <div class="single-product-img img-full"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail7); ?>" alt="img"> </div>
                        <!--Single Product Image End--> 
                      </div>
                    </div>
                    <!--Modal Content End--> 
                    <!--Modal Tab Menu Start-->
                    <div class="single-product-menu">
                      <div class="nav single-slide-menu owl-carousel" role="tablist">
                        <div class="single-tab-menu img-full"> <a class="active" data-toggle="tab" id="single-slide-tab-1" href="#single-slide1"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail); ?>" alt="img"></a> </div>
                        <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-2" href="#single-slide2"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail2); ?>" alt="img"></a> </div>
                        <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-3" href="#single-slide3"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail3); ?>" alt="img"></a> </div>
                        <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-4" href="#single-slide4"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail4); ?>" alt="img"></a> </div>
                        <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-5" href="#single-slide5"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail5); ?>" alt="img"></a> </div>
                        <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-6" href="#single-slide6"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail6); ?>" alt="img"></a> </div>
                        <div class="single-tab-menu img-full"> <a data-toggle="tab" id="single-slide-tab-7" href="#single-slide7"><img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($results->thumbnail7); ?>" alt="img"></a> </div>
                      </div>
                    </div>
                    <!--Modal Tab Menu End--> 
                  </div>
                  <!--Modal Img--> 
                  <!--Modal Content-->
                  <div class="col-md-5 col-sm-12 col-xs-12">
                    <div class="modal-product-info">
                      <h1><?php echo e($results->name); ?></h1>
                      <div class="modal-product-price"><span class="new-price">PKR <?php echo e(number_format($results->price)); ?></span> </div>
                      <div class="mb-10">
                        <lable>Color</lable>
                        <div class="color-choose"> <?php if(count($result)>0): ?>
                          <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>">
                          <input id="black" type="button" name="color">
                          <label><span style="background-color:<?php echo e($results->color); ?> "></span></label>
                          </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endif; ?> </div>
                      </div>
                      <div>
                        <div class="form-group">
                          <div>
                            <label>
                              <input type="radio" name="tab" value="Free Delivery" checked>
                              <span class="label-text">Free Delivery in <?php echo e($results->free_delivery); ?> days</span> </label>
                          </div>
                          <div>
                            <label>
                              <input type="radio" name="tab" value="Urgent Delivery">
                              <span class="label-text">Urgent Delivery PKR <?php echo e($results->urgent_charges); ?> in <?php echo e($result[0]->urgent_time); ?> days</span> </label>
                          </div>
                          <div>
                            <label>
                              <input type="radio" name="tab" value="Express Delivery">
                              <span class="label-text">Express Delivery PKR <?php echo e($results->express_charges); ?> in <?php echo e($result[0]->express_time); ?> days</span> </label>
                          </div>
                          <div>
                            <label>
                              <input type="radio" name="tab" value="Normal Delivery">
                              <span class="label-text">Normal Delivery PKR <?php echo e($results->normal_charges); ?> in <?php echo e($result[0]->normal_time); ?> days</span> </label>
                          </div>
                        </div>
                      </div>
                      <div class="add-to-cart quantity">
                        <div class="add-to-link"> <a href="<?php echo e(URL('/')); ?>/products/details/<?php echo e($results->pk_id); ?>/<?php echo e($results->sku); ?>" class="add-btn text-center">add to cart</a> </div>
                      </div>
                      <div class="faq-accordion">
                        <div id="accordion">
                          <div class="card">
                            <div class="card-header" id="headingThree">
                              <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"> Product Description </a> </h5>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                              <div class="card-body"> <?php echo e($results->description); ?></div>
                            </div>
                          </div>
                          <div class="card">
                            <div class="card-header" id="headingTwo">
                              <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"> Product Specifications </a> </h5>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                              <div class="card-body"> <?php echo e($results->material); ?> <?php echo e($results->style); ?></div>
                            </div>
                          </div>
                          <div class="card">
                            <div class="card-header" id="headingFour">
                              <h5 class="mb-0"> <a class="collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour"> Shipping & Returns </a> </h5>
                            </div>
                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
                              <div class="card-body"> <?php echo e($results->return_policy); ?> </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!--Modal Content--> 
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
      <!-- Modal Area End --> 
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?> </div>
  </div>
</div>
<hr>
<div class="container">
  <div class="row">
    <div class="col-12">
      <h2>Customer Reviews</h2>
    </div>
    <div class="col-sm-2">
      <div class="rating-block">
        <h2 class="bold padding-bottom-7"><?php echo e(round($average, 1)); ?></h2>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="rating">
        <div class="stars"> <?php
          
          $star = 5 - $average;
          ?>
          <?php for($i = 0; $i<$average; $i++): ?>
                 <span class="fa fa-star checked"></span> <?php endfor; ?>
          <?php for($i = 0; $i<$star; $i++): ?>
                  <span class="fa fa-star" style="color:lightgrey"></span> <?php endfor; ?> </div>
        <span class="review-no"><?php echo e(count($review)); ?> reviews</span> </div>
    </div>
    <?php if(Session::has('username')): ?>
    <div class="col-lg-6 col-sm-12 col-xs-12"> <a href="#open-modals" data-toggle="modal" class="btn btnnav">Write a reviews</a> </div>
    <?php else: ?>
    <div class="col-lg-6 col-sm-12 col-xs-12"> </div>
    <?php endif; ?>
    <?php if(count($review)>0): ?>
    <div class="col-sm-3">
      <div class="pull-left">
        <div class="pull-left" style="width:35px; line-height:1;">
          <div style="height:9px; margin:5px 0;">5 <span class="fa fa-star checked"></span></div>
        </div>
        <div class="pull-left" style="width:180px;">
          <div class="progress" style="height:9px; margin:8px 0;">
            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo e((count($five)/count($review))*100); ?>%"> <span class="sr-only">80% Complete (danger)</span> </div>
          </div>
        </div>
        <div class="pull-right" style="margin-left:10px;"><?php echo e(round((count($five)/count($review))*100)); ?> %</div>
      </div>
      <div class="pull-left">
        <div class="pull-left" style="width:35px; line-height:1;">
          <div style="height:9px; margin:5px 0;">4 <span class="fa fa-star checked"></span></div>
        </div>
        <div class="pull-left" style="width:180px;">
          <div class="progress" style="height:9px; margin:8px 0;">
            <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo e((count($four)/count($review))*100); ?>%"> <span class="sr-only">80% Complete (danger)</span> </div>
          </div>
        </div>
        <div class="pull-right" style="margin-left:10px;"><?php echo e(round((count($four)/count($review))*100)); ?> %</div>
      </div>
      <div class="pull-left">
        <div class="pull-left" style="width:35px; line-height:1;">
          <div style="height:9px; margin:5px 0;">3 <span class="fa fa-star checked"></span></div>
        </div>
        <div class="pull-left" style="width:180px;">
          <div class="progress" style="height:9px; margin:8px 0;">
            <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="3" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo e((count($three)/count($review))*100); ?>%"> <span class="sr-only">80% Complete (danger)</span> </div>
          </div>
        </div>
        <div class="pull-right" style="margin-left:10px;"><?php echo e(round((count($three)/count($review))*100)); ?> %</div>
      </div>
      <div class="pull-left">
        <div class="pull-left" style="width:35px; line-height:1;">
          <div style="height:9px; margin:5px 0;">2 <span class="fa fa-star checked"></span></div>
        </div>
        <div class="pull-left" style="width:180px;">
          <div class="progress" style="height:9px; margin:8px 0;">
            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="2" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo e((count($two)/count($review))*100); ?>%"> <span class="sr-only">80% Complete (danger)</span> </div>
          </div>
        </div>
        <div class="pull-right" style="margin-left:10px;"><?php echo e(round((count($two)/count($review))*100)); ?> %</div>
      </div>
      <div class="pull-left">
        <div class="pull-left" style="width:35px; line-height:1;">
          <div style="height:9px; margin:5px 0;">1 <span class="fa fa-star checked"></span></div>
        </div>
        <div class="pull-left" style="width:180px;">
          <div class="progress" style="height:9px; margin:8px 0;">
            <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" style="width: <?php echo e((count($one)/count($review))*100); ?>%"> <span class="sr-only">80% Complete (danger)</span> </div>
          </div>
        </div>
        <div class="pull-right" style="margin-left:10px;"><?php echo e(round((count($one)/count($review))*100)); ?> % </div>
      </div>
    </div>
    <?php endif; ?> </div>
  <div class="row"> <?php if(count($review)>0): ?>
    <?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $product = DB::select("select* from client_details where pk_id = '$results->user_id'");
    ?>
    <div class="col-sm-7">
      <div class="review-block">
        <div class="row">
          <div class="col-sm-3"> <img src="http://dummyimage.com/60x60/666/ffffff&text=No+Image" class="img-rounded" alt=""> <?php if(count($product)>0): ?>
            <div class="review-block-name"><?php echo e($product[0]->fname); ?> <?php echo e($product[0]->lname); ?></div>
            <?php endif; ?>
            <div class="review-block-date"><?php echo e($results->created_at); ?><br/>
            </div>
          </div>
          <div class="col-sm-9">
            <div class="">
              <div class="stars"> <?php
                $count = $results->rating;
                $star = 5 - $count;
                ?>
                <?php for($i = 0; $i<$count; $i++): ?>
                 <span class="fa fa-star checked"></span> <?php endfor; ?>
                <?php for($i = 0; $i<$star; $i++): ?>
                  <span class="fa fa-star" style="color:lightgrey;"></span> <?php endfor; ?> </div>
            </div>
            <div class="review-block-description pull-left"><?php echo e($results->comment); ?></div>
          </div>
        </div>
        <hr/>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?> </div>
</div>

  <!--Footer Area Start-->
  <footer>
    <div class="footer-container"> 
      <!--Footer Top Area Start-->
      <div class="footer-top-area">
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="<?php echo e(url('/')); ?>/faq">Faqs</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/terms/and/conditions">Terms & Condition</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/warranty/and/repairs">Warrenty and Repairs</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/returns/and/refunds">Return and Refund</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/privacy/policy">Privacy Policy</a></li>
                  <li><a href="#">Be a Realtor</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/sell_on_houzz">Sell on Houzz</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/advertise_with_us">Advertise with us</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End--> 
            </div>
            <div class="col-lg-3 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="single-footer-widget mb-40">
                <div class="footer-title"> </div>
                <ul class="link-widget">
                  <li><a href="<?php echo e(url('/')); ?>/aboutus">About Us</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/contact/us">Contact Us</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/">Payment Information</a></li>
                  <li><a href="#">Blog</a></li>
                  <li><a href="<?php echo e(url('/')); ?>/vendor/login">Seller Login</a></li>
                  <li><a href="">Be a Professional</a></li>
                </ul>
              </div>
              <!--Single Footer Widget End--> 
            </div>
            <div class="col-lg-6 col-md-6"> 
              <!--Single Footer Widget Start-->
              <div class="text-center"> <a href="" target="_blank" class="btn-social btn-facebook"><i class="fa fa-facebook"></i></a> <a href="" target="_blank" class="btn-social btn-instagram"><i class="fa fa-instagram"></i></a> <a href="" target="_blank" class="btn-social btn-twitter"><i class="fa fa-twitter"></i></a> </div>
              <div class="footer-title mt-40">
                <h3>Contact Us</h3>
              </div>
              <div class="single-footer-widget mb-40">
                <div class="news-letter-form mb-10">
                  <form class="popup-subscribe-form validate" target="_blank" novalidate>
                    <div id="mc_embed_signup_scroll">
                      <div id="mc-form" class="mc-form subscribe-form " style=" border-top: 1px solid white;border-bottom: 1px solid white;
    padding: 1%;">
                        <input id="mc-email" type="email" autocomplete="off" placeholder="Enter your email here">
                        <button type="button" class="btn btn-serach">Login</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!--Single Footer Widget End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Footer Top Area End--> 
      <!--Footer Bottom Area Start-->
      <div class="footer-bottom-area pt-50 pb-50">
        <div class="container">
          <div class="row">
            <div class="col-md-12"> 
              <!--Footer Copyright Start-->
              <div class="footer-copyright">
                <p>Copyright © <a href="http://general.greengrapez.com/houzz/public/">Houzz.pk</a> All Rights Reserved</p>
              </div>
              <div class="footer-copyright">
                <p>Powered By <a href="https://greengrapez.com/"><img src="<?php echo e(url('/')); ?>/pic/greengrapez.png" alt="Green Grapez"></a></p>
              </div>
              <!--Footer Copyright End--> 
            </div>
          </div>
        </div>
      </div>
      <!--Footer Bottom Area End--> 
    </div>
  </footer>
  <!--Footer Area End--> 
</div>
<?php if(count($result)>0): ?>
<form method="post" action = "<?php echo e(url('/')); ?>/client/add/review/<?php echo e($result[0]->pk_id); ?>" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <div class="modal fade" id="open-modals" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" style="max-width:63%;">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-close"></i></button>
        </div>
        <div class="modal-body" style="padding:34px 0px 34px 0px;">
          <div class="row"> 
            
            <!--Modal Content-->
            <div class="col-lg-5 col-sm-12 col-xs-12">
              <div class="modal-image"> <img src="<?php echo e(URL('/')); ?>/storage/images/<?php echo e($result[0]->thumbnail); ?>" alt="img" style="width:300px;height:250px;"> </div>
            </div>
            <div class="col-lg-6 col-sm-12 col-xs-12">
              <div class="modal-text">
                <p><?php echo e($result[0]->name); ?></p>
                <fieldset class="rating" >
                  <input type="radio" id="star5" name="rating" value="5" />
                  <label class = "full" for="star5" title="Awesome - 5 stars"></label>
                  <input type="radio" id="star4" name="rating" value="4" />
                  <label class = "full" for="star4" title="Pretty good - 4 stars"></label>
                  <input type="radio" id="star3" name="rating" value="3" />
                  <label class = "full" for="star3" title="Meh - 3 stars"></label>
                  <input type="radio" id="star2" name="rating" value="2" />
                  <label class = "full" for="star2" title="Kinda bad - 2 stars"></label>
                  <input type="radio" id="star1" name="rating" value="1" required/>
                  <label class = "full" for="star1" title="Sucks big time - 1 star" ></label>
                </fieldset>
                <label>What do you like or dislike about this product? We're Curious!</label>
                <textarea rows="4" cols="50" name="comment"  style="width: 100%;
    border-radius: 5px;background-color:white;border:1px solid black;"></textarea>
                <button type="submit"  class="btn btnnav">Submit</button>
              </div>
            </div>
            
            <!--Modal Content--> 
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal Area End -->
</form>
<?php endif; ?> 
<script src="<?php echo e(url('/')); ?>/js1/vendor/jquery-1.12.4.min.js"></script> 
<!--Popper--> 
<script src="<?php echo e(url('/')); ?>/js1/popper.min.js"></script> 
<!--Bootstrap--> 
<script src="<?php echo e(url('/')); ?>/js1/bootstrap.min.js"></script> 
<!--Imagesloaded--> 
<script src="<?php echo e(url('/')); ?>/js1/imagesloaded.pkgd.min.js"></script> 
<!--Isotope--> 
<script src="<?php echo e(url('/')); ?>/js1/isotope.pkgd.min.js"></script> 
<!--Waypoints--> 
<script src="<?php echo e(url('/')); ?>/js1/waypoints.min.js"></script> 
<!--Counterup--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.counterup.min.js"></script> 
<!--Carousel--> 
<script src="<?php echo e(url('/')); ?>/js1/owl.carousel.min.js"></script> 
<!--Slick--> 
<script src="<?php echo e(url('/')); ?>/js1/slick.min.js"></script> 
<!--Meanmenu--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.meanmenu.min.js"></script> 
<!--Easyzoom--> 
<script src="<?php echo e(url('/')); ?>/js1/easyzoom.min.js"></script> 
<!--Nice Select--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.nice-select.min.js"></script> 
<!--ScrollUp--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.scrollUp.min.js"></script> 
<!--Wow--> 
<script src="<?php echo e(url('/')); ?>/js1/wow.min.js"></script> 
<!--Venobox--> 
<script src="<?php echo e(url('/')); ?>/js1/venobox.min.js"></script> 
<!--Jquery Ui--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery-ui.js"></script> 
<!--Countdown--> 
<script src="<?php echo e(url('/')); ?>/js1/jquery.countdown.min.js"></script> 
<!--Plugins--> 
<script src="<?php echo e(url('/')); ?>/js1/plugins.js"></script> 
<!--Main Js--> 
<script src="<?php echo e(url('/')); ?>/js1/main.js"></script>

<script>  
$("#size").on('change',function(e){
    var type_id = e.target.value;
    $.get('<?php echo e(URL('/')); ?>/client/ajax-size?type_id='+ type_id,function(data){
   
    if(data <= 0 )
    {
        document.getElementById("myspan").textContent="Out of Stock";  
        $("#cartbtn").attr("disabled", true);
        $('#cartbtn').AddClass("notactive");
        
    }
    
    else{
        
        $("#cartbtn").removeAttr("disabled");
        document.getElementById("myspan").textContent="In Stock";
    }
    
    $("#myInput").attr({
       "max" : data
    });
    
    });


 });
</script>

<script>

var button = $(".click"),
		message = $(".message"),
		open = false;

button.on("click touchstart", function(e) {
	e.preventDefault();
	
	// if opened is true, then we will want to close
	// the overlay as it will mean its already visible.
	if (open){
		open = false;
		message.removeClass("is-open");
	} 
	// if false, then we want to open the overlay
	// so we set open equal to true. 
	else{
		open = true;
		message.addClass("is-open");
		console.log(open);
	}
	
});

function show1(){
      document.getElementById('div1').style.display ='none';
       $("#div1 input[type=text]").val('');
       $("#div1 input[type=tel]").val('');
    }
    function show2(){
      document.getElementById('div1').style.display = 'block';
    }
 var countChecked = function () {
    var n = $("input:checked").length;
    if (n >= 1) {
        $("#selected-toolbar").css({
            "display": "block"
        });
    } else {
        $("#selected-toolbar").css({
            "display": "none"
        });
    }
};
countChecked();

$("input[type=checkbox]").on("click", countChecked);

$(document).ready(function() {
   $('.js-example-basic-multiple').select2();
});

function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>
</body>
</html><?php /**PATH /home/greengra/general.greengrapez.com/houzz/resources/views/client/product_detail_view.blade.php ENDPATH**/ ?>